CREATE PACKAGE PKGSEARCHUTILS AS

  /*----------------------------------------------------------------------------
  NAME
    createSearchTab()
  FUNCTION
    Creates all necessary AttrGroups and Attributes for displaying specified Search Profile
    on separate tab of objects with specified Object Type
  PARAMETERS
    objectTypeId (IN) - nc_object_type_id of OT for which tab will be created
    profileId (IN) - nc_object_id of Search profile which will be shown on new tab
    attrSchemaId (IN) - id of AttrSchema in which new attributes will be bound to OT
    tabName (IN) - name of new Search Tab
    createCopyButton (IN) - this flag specifies if Copy button should be created and displayed on new tab
    createEditButton (IN) - this flag specifies if Edit button should be created and displayed on new tab
    createDeleteButton (IN) - this flag specifies if Delete button should be created and displayed on new tab
  NOTES
  ----------------------------------------------------------------------------*/
  PROCEDURE createSearchTab(objectTypeId IN INTEGER,
            profileId IN INTEGER,
            attrSchemaId IN INTEGER,
            tabName IN VARCHAR2 DEFAULT 'Search Tab',
            createCopyButton IN BOOLEAN default true,
            createEditButton IN BOOLEAN default true,
            createDeleteButton IN BOOLEAN default true);

END PKGSEARCHUTILS;
/
