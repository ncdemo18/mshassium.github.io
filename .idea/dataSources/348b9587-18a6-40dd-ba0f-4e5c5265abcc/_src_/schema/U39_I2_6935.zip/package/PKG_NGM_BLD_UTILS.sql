CREATE PACKAGE PKG_NGM_BLD_UTILS AS
TYPE ref_cursor IS REF CURSOR;

MSG_ERROR     constant int := 1;
MSG_WARNING constant int := 2;
MSG_INFO        constant int := 3;
MSG_TRACE     constant int := 4;
MSG_PROGRESS constant int := 5;

PRC_STATE_STARTED constant int := 1;
PRC_STATE_NOT_STARTED constant int := 2;

/*tools for loging*/
procedure init_log;
procedure init_log(request_id IN INT);
FUNCTION get_request_id RETURN INT;
procedure load_messages;
procedure set_msg_level(new_level int);
FUNCTION is_msg_level(check_level int) RETURN boolean;
procedure ngm_add_error(incident_code int, params varchar2, duration int default null);
procedure ngm_add_warning(incident_code int, params varchar2, duration int default null);
procedure ngm_add_info(incident_code int, params varchar2, duration int default null);
procedure ngm_add_trace(msg varchar2, duration int default null);
procedure ngm_add_progress(incident_code int, params varchar2);
FUNCTION get_log RETURN ref_cursor;
function get_messages(list_errors TableOf2Strings) RETURN ARRAYOFSTRINGS;

/*tools for context*/
PROCEDURE build_context_map(v_graph_spec_id IN NUMBER, context_keys IN ARRAYOFSTRINGS, context_values IN ARRAYOFSTRINGS);
FUNCTION get_context RETURN TableOf2Strings;
FUNCTION get_context_value(context_key varchar2) RETURN varchar2;
FUNCTION get_context_values(context_key varchar2) RETURN ARRAYOFSTRINGS;
FUNCTION get_runtime_parameter(owner_id IN NUMBER,runtime_attr_id IN NUMBER) RETURN NUMBER;
FUNCTION get_runtime_parameter_value(owner_id IN NUMBER,runtime_attr_id IN NUMBER) RETURN VARCHAR2;
FUNCTION get_runtime_parameter_values(owner_id IN NUMBER,runtime_attr_id IN NUMBER) RETURN ARRAYOFSTRINGS;
FUNCTION get_runtime_parameter_values(runtime_param_id IN NUMBER) RETURN ARRAYOFSTRINGS;
FUNCTION get_runtime_parameters_values(owner_id IN NUMBER) RETURN TableOf2Strings;
FUNCTION get_runtime_parameters_values RETURN TableOf2Strings;
PROCEDURE add_context_value(context_key varchar2, context_value varchar2);
PROCEDURE add_context_values(context_key varchar2, context_value ARRAYOFSTRINGS);


FUNCTION get_total_sec(start_time IN TIMESTAMP) RETURN NUMBER;
FUNCTION get_total_msec(start_time IN TIMESTAMP) RETURN NUMBER;

FUNCTION get_needed_args(graph_spec_id NUMBER, selectors arrayofnumbers, filters arrayofnumbers) RETURN arrayofnumbers;
FUNCTION get_args_by_request_spec(request_spec_id NUMBER) RETURN TableOf2Numbers;

PROCEDURE set_user_id(user_id NUMBER);
FUNCTION get_user_id RETURN NUMBER;
PROCEDURE set_dp_context(dp_context NUMBER);
FUNCTION get_dp_context RETURN NUMBER;


PROCEDURE read_processor_types(graph_spec_id NUMBER) ;
FUNCTION get_used_processor_type RETURN VARCHAR2;
FUNCTION get_default_processor_type RETURN VARCHAR2;
FUNCTION get_processor(func_type NUMBER, processor_property VARCHAR2) RETURN VARCHAR2;
PROCEDURE set_processor_state(state INT);
FUNCTION get_processor_state RETURN INT;

PROCEDURE set_graph_id(graph_id NUMBER);
FUNCTION get_graph_id RETURN NUMBER;

FUNCTION get_argument_by_name(spec_id IN NUMBER, arg_name IN VARCHAR2) RETURN ARRAYOFSTRINGS;
FUNCTION get_argument_by_name(arg_name IN VARCHAR2, v_graph_spec_id IN NUMBER) RETURN ARRAYOFSTRINGS;

FUNCTION get_last_rev_num(v_graph_id IN NUMBER, v_request_id IN NUMBER) RETURN NUMBER;

/*Service Functions*/
FUNCTION get_elements_sources(v_graph_id IN NUMBER, spec_id IN NUMBER) RETURN TableOf2Numbers;
FUNCTION get_all_elements_sources(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER) RETURN TableOf3Numbers;
FUNCTION get_elements_sources(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_ids IN ArrayOfNumbers) RETURN TableOf3Numbers;
FUNCTION get_elements_sources(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_id IN NUMBER) RETURN TableOf3Numbers;
FUNCTION get_element_ids(v_graph_id NUMBER, prizn VARCHAR2, start_id NUMBER, element_codes ArrayOfNumbers) RETURN TableOf2Numbers;
FUNCTION get_edges_av(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_ids IN ArrayOfNumbers) RETURN TableOf3Numbers;
FUNCTION get_paths_av(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_ids IN ArrayOfNumbers) RETURN TableOfPE;
FUNCTION get_last_node_id(v_graph_id NUMBER,  v_request_id NUMBER, prizn VARCHAR2 default PKG_NGM_BLD_LIB.PREFIX_NODE) RETURN NUMBER;
FUNCTION get_last_edge_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;
FUNCTION get_last_nested_node_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;
FUNCTION get_last_port_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;
FUNCTION get_last_path_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;

FUNCTION get_graph_hashcode(v_graph_spec_id NUMBER, build_time_params TableOf2Strings) RETURN VARCHAR2;

PROCEDURE prolongate_graph_request(v_graph_id NUMBER,  v_request_id NUMBER, sec NUMBER);

END PKG_NGM_BLD_UTILS;
/
