CREATE package pkg_baip_ui
is
    function calculate_address_line (address_unit_id number, line_number varchar2) return varchar2;

    function calculate_country (address_unit_id number) return number;

    function calculate_postal_code (address_unit_id number) return varchar2;

    function calculate_error_message (address_unit_id number) return varchar2;

    function get_remote_timezone return varchar2;
end;
/
