CREATE PACKAGE "FLEX_GRAPH_VIEW"
IS
PROCEDURE ADD_START_FROM_OBJECT_BTN(
  policy_id IN NUMBER,
  object_type_id IN NUMBER,
  tui_table_group_id IN NUMBER,
  button_name IN VARCHAR2,
  path_to_jsp IN VARCHAR2 DEFAULT '/graphview/graphview.jsp'
);

PROCEDURE ADD_START_FROM_SELECTION_BTN(
  policy_id IN NUMBER,
  object_type_id IN NUMBER,
  tui_table_group_id IN NUMBER,
  button_name IN VARCHAR2,
  path_to_jsp IN VARCHAR2 DEFAULT '/graphview/graphview.jsp'
);

END;
/
