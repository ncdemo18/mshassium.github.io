CREATE PACKAGE PKG_CALC_INDEX
AS

    PROCEDURE add_attr_metadata( given_attr_id NUMBER,
                                 given_object_type_id NUMBER);

    PROCEDURE add_attr_metadata_to_temp( given_attr_id NUMBER,
                                         given_object_type_id NUMBER );


    FUNCTION is_bind( given_attr_id        NUMBER,
                      given_ot_id          NUMBER,
                      given_attr_schema_id NUMBER)
             RETURN PLS_INTEGER;

   FUNCTION is_valid_attr_metadata( given_attr_id NUMBER,
                                    given_string_ids varchar2 )
             RETURN PLS_INTEGER;

   PROCEDURE createIndex( indexName Varchar2, tableName Varchar2);

END PKG_CALC_INDEX;
/
