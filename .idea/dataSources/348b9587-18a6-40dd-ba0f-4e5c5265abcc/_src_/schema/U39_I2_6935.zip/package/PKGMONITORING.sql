CREATE package pkgmonitoring is
  procedure store_events(ids  arrayofnumbers, events arrayofstrings);
  procedure remove_events(ids in arrayofnumbers, events in arrayofstrings);

end pkgmonitoring;
/
