CREATE PACKAGE          "PKGVPROF" is
	function colorByTypeAndInterface(obj_id number) return varchar2;
	function colorByFrequency(obj_id number) return varchar2;
	function colorByStatus(obj_id number) return varchar2;
	function colorByManufacturer(obj_id number) return varchar2;

	function widthByTypeAndInterface(obj_id number) return number;
	function styleByProtection(obj_id number) return number;

	function rrByTypeAndInterface(colorstr varchar2) return number;
	function ggByTypeAndInterface(colorstr varchar2) return number;
	function bbByTypeAndInterface(colorstr varchar2) return number;

	function grayen(colorstr varchar2, grayness number) return varchar2;
end;



/
