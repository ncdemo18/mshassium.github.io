CREATE package pkgSessions is

SUBTYPE SID_TYPE is nc_sessions.session_id%TYPE;

/**
 * Checks if session is currently active.
 *
 * @param p_session_id session ID to be checked
 * @param p_user_id check if session was created for this user. This parameter can be 'null'.
 * @return 0 - if session is not active
 *         1 - is session is active
 */
function is_session_active(p_session_id SID_TYPE, p_user_id number) return pls_integer;

/**
 * Tries to add session to list of currently active sessions and log this session in
 * nc_access table.
 * In case of success, this function add record to nc_sessions table and insert 'in' record
 * in nc_access table.
 *
 * @param p_session_id session ID (from UserSession object) to be logged
 * @param p_user_id object_id for user which is owner of this session
 * @param p_type_id user type: 0 for normal user, 1 for read-only user
 * @param p_machine_id machineID code for machine on which current session is stored
 * @param p_node_id runtime ID for machine on which current session is stored
 * @param p_tolerate if this flag is equal to 1, then less than one month passed
 *                   from license issued date
 * @param p_guaranteed if this flag is equal to 1, then user has reserved sessions
 *                     and we need to check only active sessions count (without guaranteed)
 * @param p_running_nodes_ids array of runtimeIDs for currently running nodes
 * @param p_node_name name of current server
 * @param p_old_session_id old session to be replaced if required
 * @param p_sessions cursor contains list of current user sessions
 * @param p_service_id ID of auth service; null by default
 * @param p_subst_service_id ID of service which was substitued by p_service_id
 * 							 because of p_subst_service_id's CCU limit reach; null by default
 * @param p_remote_system_id ID of session from remote system; null by default
 * @return 1 - if session can't be logged in because of license limitations
 *         2 - if license limitations were exceeded, but was logged in by replacing of
 *             one of previously logged session for given user
 *         3 - if license limitations were exceeded, but session was logged in as one month
 *             period from license issue date wasn't ended
 *         4 - if session was successfully logged in
 *         5 - if session with given session_id was already logged in
 *         6 - if user sessions count limit was reached
 *         7 - if session limitation was exceeded, but session was logged by automatic replacement
 *             of one (or more) previously logged in session
 *         8 - if session limitation was exceeded and p_sessions contains list of currently active
 *             sessions for the given user
 */
function add_session(
    p_session_id SID_TYPE,
    p_user_id number,
    p_type_id number,
    p_machine_id varchar2,
    p_node_id varchar2,
    p_maximum_concurrent number,
    p_tolerate number,
    p_guaranteed number,
    p_running_nodes_ids arrayofnumbers,
    p_node_name varchar2,
    p_old_session_id SID_TYPE,
    p_sessions out sys_refcursor,
    p_service_id number default null,
    p_subst_service_id number default null,
    p_remote_system_id number default null
    ) return number;


/**
 * Removes session from list of currently active sessions and add 'out' record to nc_access table.
 *
 * @param p_session_id session (from UserSession object) to be removed
 * @param p_running_nodes_ids array of runtimeIDs for currently running nodes
 */
procedure dispose_session(p_session_id SID_TYPE, p_running_nodes_ids arrayofnumbers);

--ALSH1209 [05.13.2010] [[8.0_QA_Core] - [8.0_QA_Core] - [SC_2.1] Sequrity error after delete active user.] Start
/**
 * Removes all user's sessions from list of currently active sessions and add 'out' record to nc_access table for each session.
 *
 * @param p_user_id user, whose sessions to be removed
 * @param p_running_nodes_ids array of runtimeIDs for currently running nodes
 */
procedure dispose_user_sessions(p_user_id number, p_running_nodes_ids arrayofnumbers);
--ALSH1209 [05.13.2010] [[8.0_QA_Core] - [8.0_QA_Core] - [SC_2.1] Sequrity error after delete active user.] End

procedure dispose_sessions_by_service(p_user_id number, p_running_nodes_ids arrayofnumbers, p_service_id NUMBER);

/**
 * Returns number of currently active sessions in the list.
 *
 * @param p_running_nodes_ids array of runtimeIDs for currently running nodes
 * @param p_type_id user type of users which sessions we are counting (0 - normal, 1 - read-only)
 * @return number of currently active sessions in the nc_sessions table for given list of
 *         running nodes and user type
 */
function get_sessions_count(
    p_running_nodes_ids arrayofnumbers,
    p_type_id number) return pls_integer;

function get_sessions_count_by_service(
    p_running_nodes_ids arrayofnumbers,
    p_type_id number,
    p_service_id NUMBER) return pls_integer;

/**
 * Calculates count of occupied (active and reserved) sessions of a specified type for a specified service.
 * The algorithm:
 * Occupied Sessions Count = SUM for each group(MAX(Guaranteed capacity for group, Real Session Count for group)),
 * 	where Real Session Count for group = SUM for each user in group(MAX(Guaranteed capacity for user, Real Session Count for user)),
 * 	  where Real Session Count for user = number of currently active sessions of user in the nc_sessions table (of specified service and type)
 *          and group is the primary group for user.
 *
 * @param p_running_nodes_ids IDs of currently running nodes
 * @param p_type_id type of users which sessions we are counting (0 - normal, 1 - read-only)
 * @param p_service_id ID of the service which is used to log in
 * @return number of currently occupied (active and reserved) sessions for given list of running nodes, user type and service
 */
function get_occupied_sessions_count(
    p_running_nodes_ids arrayofnumbers,
    p_type_id number,
    p_service_id NUMBER) return pls_integer;

function get_time_out_for_service (
    p_service_id NUMBER) return NUMBER;

/**
 * Returns number of active sessions for which initial service (p_subst_service_id)
 * was substituted with new one (p_service_id), accroding to sharing rules,
 * specified in NC License file
 *
 * @param p_node_id runtime ID for machine on which current session is stored
 * @param p_type_id user type: 0 for normal user, 1 for read-only user
 * @param p_service_id ID of service which is shared with initial one
 * @param p_subst_service_id initial ID of service which was substituted
 * @return number of currently active sessions, which service was substituted
 */
FUNCTION get_subst_sessions_count(
    p_node_id          NUMBER,
    p_type_id          NUMBER,
    p_service_id       NUMBER,
    p_subst_service_id NUMBER)
  RETURN pls_integer;

/**
 * Returns total number of active sessions for which some initial service
 * was substituted with new one (p_service_id), accroding to sharing rules,
 * specified in NC License file
 *
 * @param p_node_id runtime ID for machine on which current session is stored
 * @param p_type_id user type: 0 for normal user, 1 for read-only user
 * @return number of currently active sessions, which service
 *         was substituted with p_service_id
 */
FUNCTION get_subst_count_by_service(
    p_node_id          NUMBER,
    p_type_id          NUMBER,
    p_service_id       NUMBER)
  RETURN pls_integer;

/**
 * Returns number of active sessions for which initial service (p_subst_service_id)
 * was substituted with new one (p_service_id), according to sharing rules,
 * specified in NC License file.
 *
 * Method doesn't take into account number of sessions created by p_user_id.
 *
 * @param p_node_id	         runtime ID for machine on which current session is stored
 * @param p_type_id          user type: 0 for normal user, 1 for read-only user
 * @param p_service_id       ID of service which is shared with initial one
 * @param p_subst_service_id initial ID of service which was substituted
 * @param p_user_id          ID of user which sessions aren't counted
 * @return number of currently active sessions, which service was substituted
 */
FUNCTION get_subst_sessions_count_user(
    p_node_id          NUMBER,
    p_type_id          NUMBER,
    p_service_id       NUMBER,
    p_subst_service_id NUMBER,
    p_user_id          NUMBER)
  RETURN pls_integer;

/**
 * Returns number of active sessions for which initial service (p_subst_service_id)
 * was substituted with some new one, accroding to sharing rules, specified in NC License file
 *
 * @param p_node_id runtime ID for machine on which current session is stored
 * @param p_type_id user type: 0 for normal user, 1 for read-only user
 * @param p_subst_service_id initial ID of service which was substituted
 * @return number of currently active sessions, which service was substituted
 */
FUNCTION get_subst_count_by_subst_id(
    p_node_id          NUMBER,
    p_type_id          NUMBER,
    p_subst_service_id       NUMBER)
  RETURN pls_integer;

/**
 * Adds 'crash' record into nc_access table for each record from nc_sessions table with given
 * machine id and remove all such records from nc_sessions table after that, i.e. remove all
 * sessions bound to given machine from list of currently active sessions.
 * Note: this procedure 'closes' only such records in nc_access table, which have corresponded
 *       records in nc_sessions table.
 *
 * @param p_machine_id machineID code for machine
 */
procedure remove_sessions_for_machine(p_machine_id varchar2);

/**
 * Add 'crash' record for each 'in' record in nc_access table which has no corresponded 'out'
 * or 'crash' record and removes all records from nc_sessions table.
 * Note: this procedure 'closes' all records in nc_access table regardless of content of
 *       nc_sessions table.
 */
procedure remove_all_sessions;


/**
 * Check session is exist. If session exist then update last_action_date filed;
 */

FUNCTION check_session (
           p_session_id   NUMBER
          ,p_web_ui_delta NUMBER )
      RETURN pls_integer;

/**
 * This function inserts row in nc_sessions_replication if session is existing;
 * @param p_session_id session id to be checked and replicated
 * @param p_machine_id machineID code for machine on which current session is stored
 * @return 1 if row was inserted in nc_sessions_replication and 0 if it is not.
 */
FUNCTION replicate_session(
           p_session_id NUMBER,
           p_machine_id VARCHAR2
) RETURN NUMBER;

end pkgSessions;
/
