CREATE PACKAGE pkgnaming
IS
   /*
      This procedure generates and updates object name according to repository object naming rules.
      Parameters:
         object_id - object ID to be processed
         use_inventory_mask - if this parameter is 0, naming mask will be taken from DL source
            objects; otherwise naming mask will be taken from Inventory objects
         attr_id - if this parameter is 0, actual object name will be updated with newly generated
            name; otherwise object's parameter with the specified ID will be set to store newly
            generated name
         user_id - ID of current user, this parameter is used for attributes calculating
         language_id - current user language ID, this parameter is used for attributes calculating
         locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   --deprecated, use update_repository_obj_name
   PROCEDURE update_repository_object_name (
      object_id            IN   nc_objects.object_id%TYPE,
      attr_id              IN   nc_attributes.attr_id%TYPE DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   );

   PROCEDURE update_repository_obj_name (
      object_id            IN   nc_objects.object_id%TYPE,
      attr_id              IN   nc_attributes.attr_id%TYPE DEFAULT 0,
      use_template_mask    IN   NUMBER DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   );

   /*
      This function generates new name for the specified object according to repository naming rules.
      Return:
         Newly generated name
      Parameters:
         object_id - object ID to be processed
         use_inventory_mask - if this parameter is 0, naming mask will be taken from DL source
            objects; otherwise naming mask will be taken from Inventory objects
         return_null - if this parameter is 0, the function will return current object name in case
            of absence of naming mask for the specified object; otherwise it will return null
         user_id - ID of current user, this parameter is used for attributes calculating
         language_id - current user language ID, this parameter is used for attributes calculating
         locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   --deprecated, use get_repository_object_name2
   FUNCTION get_repository_object_name (
      object_id            IN   nc_objects.object_id%TYPE,
      return_null          IN   NUMBER DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   )
      RETURN nc_objects.NAME%TYPE;

   FUNCTION get_repository_object_name2 (
      object_id            IN   nc_objects.object_id%TYPE,
      use_template_mask    IN   NUMBER DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      return_null          IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   )
      RETURN nc_objects.NAME%TYPE;


   /*
      This procedure generates and updates object names according to repository object naming rules.
      Parameters:
         object_ids - colletion of object IDs to be processed
         use_inventory_mask - if this parameter is 0, naming mask will be taken from DL source
            objects; otherwise naming mask will be taken from Inventory objects
         p_attr_id - if this parameter is 0, actual object name will be updated with newly generated
            name; otherwise object's parameter with the specified ID will be set to store newly
            generated name
         user_id - ID of current user, this parameter is used for attributes calculating
         language_id - current user language ID, this parameter is used for attributes calculating
         locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   --deprecated, use update_repository_obj_names
   PROCEDURE update_repository_object_names (
      object_ids           IN   arrayofnumbers,
      p_attr_id            IN   nc_attributes.attr_id%TYPE DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   );

   PROCEDURE update_repository_obj_names (
      object_ids           IN   arrayofnumbers,         -- IDs to be processed
      p_attr_id            IN   nc_attributes.attr_id%TYPE DEFAULT 0,
      use_template_mask    IN   NUMBER DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   );

   /*
      This function generates and updates object names according to repository object naming rules.
      Parameters:
         object_ids - colletion of object IDs to be processed
         use_template_mask - if this parameter is 1, naming mask will be taken from template source
            objects; otherwise naming mask will be taken depending on use_inventory_mask value
         use_inventory_mask - if this parameter is 0, naming mask will be taken from DL source
            objects; otherwise naming mask will be taken from Inventory objects
         p_attr_id - if this parameter is 0, actual object name will be updated with newly generated
            name; otherwise object's parameter with the specified ID will be set to store newly
            generated name
         user_id - ID of current user, this parameter is used for attributes calculating
         language_id - current user language ID, this parameter is used for attributes calculating
         locale_id - current user locale ID, this parameter is used for attributes calculating
		 return - the function returns the IDs and masks of objects that can not be named because of errors
   */
   FUNCTION update_repository_obj_names (
      object_ids           IN   arrayofnumbers,         -- IDs to be processed
      p_attr_id            IN   nc_attributes.attr_id%TYPE DEFAULT 0,
      use_template_mask    IN   NUMBER DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   )
     RETURN names_table;

   /*
      This function generates new names for the specified objects according to repository naming rules.
      Return:
         Newly generated names
      Parameters:
         object_ids - object IDs to be processed
         use_inventory_mask - if this parameter is 0, naming mask will be taken from DL source
            objects; otherwise naming mask will be taken from Inventory objects
         return_null - if this parameter is 0, the function will return current object names in case
            of absence of naming mask for the specified object; otherwise it will return null
         user_id - ID of current user, this parameter is used for attributes calculating
         language_id - current user language ID, this parameter is used for attributes calculating
         locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   --deprecated, use get_repository_object_names2
   FUNCTION get_repository_object_names (
      object_ids           IN   arrayofnumbers,
      return_null          IN   NUMBER DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   )
      RETURN names_table;

   FUNCTION get_repository_object_names2 (
      object_ids           IN   arrayofnumbers,         -- IDs to be processed
      use_template_mask    IN   NUMBER DEFAULT 0,
      use_inventory_mask   IN   NUMBER DEFAULT 0,
      return_null          IN   NUMBER DEFAULT 0,
      user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id          IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id            IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   )
      RETURN names_table;

   /*
      This function generates new names for the specified objects according to object naming rules.
      Return:
         Newly generated names
      Parameters:
         object_ids - object IDs to be processed
         return_null - if this parameter is 0, the function will return current object names in case
            of absence of naming mask for the specified object; otherwise it will return null
         user_id - ID of current user, this parameter is used for attributes calculating
         language_id - current user language ID, this parameter is used for attributes calculating
         locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   FUNCTION get_object_names (
      object_ids    IN   arrayofnumbers,
      return_null   IN   NUMBER DEFAULT 0,
      user_id       IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id   IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id     IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   )
      RETURN names_table;

   /*
      This function generates new name for the specified object according to object naming rules.
      Return:
         Newly generated name
      Parameters:
         object_id - object ID to be processed
         return_null - if this parameter is 0, the function will return current object name in case
            of absence of naming mask for the specified object; otherwise it will return null
         user_id - ID of current user, this parameter is used for attributes calculating
         language_id - current user language ID, this parameter is used for attributes calculating
         locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   FUNCTION get_object_name (
      object_id     IN   nc_objects.object_id%TYPE,
      return_null   IN   NUMBER DEFAULT 0,
      user_id       IN   nc_objects.object_id%TYPE DEFAULT NULL,
      language_id   IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      locale_id     IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   )
      RETURN nc_objects.NAME%TYPE;

   /*
      This procedure generates and updates object name according to object naming rules.
      Parameters:
         p_object_id - object ID to be processed
         p_attr_id - if this parameter is 0, actual object name will be updated with newly generated
            name; otherwise object's parameter with the specified ID will be set to store newly
            generated name
         p_user_id - ID of current user, this parameter is used for attributes calculating
         p_language_id - current user language ID, this parameter is used for attributes calculating
         p_locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   PROCEDURE update_object_name (
      p_object_id     IN   nc_objects.object_id%TYPE,
      p_attr_id       IN   nc_attributes.attr_id%TYPE DEFAULT 0,
      p_user_id       IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_language_id   IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      p_locale_id     IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   );

   /*
      This procedure generates and updates object names according to object naming rules.
      Parameters:
         p_object_ids - object IDs to be processed
         p_attr_id - if this parameter is 0, actual object name will be updated with newly generated
            name; otherwise object's parameter with the specified ID will be set to store newly
            generated name
         p_user_id - ID of current user, this parameter is used for attributes calculating
         p_language_id - current user language ID, this parameter is used for attributes calculating
         p_locale_id - current user locale ID, this parameter is used for attributes calculating
   */
   PROCEDURE update_object_names (
      p_object_ids    IN   arrayofnumbers,
      p_attr_id       IN   nc_attributes.attr_id%TYPE DEFAULT 0,
      p_user_id       IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_language_id   IN   nc_references.REFERENCE%TYPE DEFAULT NULL,
      p_locale_id     IN   nc_references.REFERENCE%TYPE DEFAULT NULL
   );

   FUNCTION get_mask(
  	 obj_id IN nc_objects.object_id%TYPE,
     is_template   IN   NUMBER DEFAULT 0,
     is_inventory  IN   NUMBER DEFAULT 0
   )
     RETURN  VARCHAR2;

   FUNCTION get_count_objects_before
   (
		scopeid IN NUMBER,
		objectid IN NUMBER,
		parentid IN NUMBER,
		object_class_id IN NUMBER,
		group_by_attr_id IN VARCHAR2,
		group_value IN VARCHAR2,
		with_hierarchy IN NUMBER DEFAULT 0
    )
	RETURN NUMBER;

	FUNCTION not_apply_naming_convention( obj_id IN NUMBER ) RETURN NUMBER;

END pkgnaming;
/
