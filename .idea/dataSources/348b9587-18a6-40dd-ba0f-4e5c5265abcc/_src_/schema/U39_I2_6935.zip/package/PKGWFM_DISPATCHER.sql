CREATE package pkgwfm_dispatcher is

  -- Author  : VLCH0810
  -- Created : 07.10.2010 13:55:14
  -- Purpose :

  -- message statuses
    MS_NEW constant int := 1;
    MS_WAIT constant int := 2;
    MS_ACTIVE constant int := 3;
    MS_SUCCESS constant int := 4;
    MS_FAILURE constant int := 5;
    MS_PREPARATION constant int := 6;
    MS_PROCESSED constant int := 7;


    TR_NETWORK constant int := 9125500430113707769;
    TR_SMS constant int := 9132416330013141379;
    TR_EMAIL constant int := 9132416330013141378;
    TR_VOICE constant int := 9125500430113707767;


  procedure notif_setStatus(pNotifID number, pValue number, pOldValue number := MS_NEW);
  procedure notif_setStatusID(pNotifID number, pValue number, pOldValue number := MS_NEW);
  procedure address_setStatus(pAddrID number, pValue number, pOldValue number := MS_NEW);
  procedure address_setStatusID(pAddrID number, pValue number, pOldValue number := MS_NEW);

  procedure transport_setExtStatus(pTransport number, pExtID varchar2, pValue number, pOldValue number := MS_NEW);
  procedure address_setExtID(pAddrid number, pExtID varchar2);

  procedure queue_setStatus(pCallback_id number, pValue number, pOldValue number := MS_PREPARATION);
  function sql_queue_addr_set_status(pRecord_id number, pValue number) return int;

  procedure trigger_transport_upd_result(p_employee_id in number, p_queue_id number, p_status in number);
  procedure trigger_employee_upd_result(p_callback_id number, p_notif_id number, p_result in number);
  procedure trigger_notif_upd_result(p_callback_id number, p_result in number);

  procedure finish_dispatching(pID number, pError varchar2);

  procedure send_mail(pAddress varchar2, pSubject varchar2, pMessage clob, ptimeout int);
  procedure send_sms(pPhone varchar2, pMessage clob, ptimeout int);

  function put_in_queue(
    pCALLBACK_ID in number,
    pNOTIFICATION_ID in number,
    pTimeout in int,
    pTRANSPORT in number,
    pSUBJECT in varchar2,
    pNOTIFICATION_BODY in clob,
    pPARENT_ID in number,
    pSTATUS in number,
    pEMPLOYEE_ID in number,
    pDEVICE_ID in number,
    pADDRESS in varchar2,
    pType in number,
    pAttachments in arrayofstrings DEFAULT arrayofstrings()
  )return number;

  function analize_queue return int;

  procedure SetLogType(i int);
end;
/
