CREATE package PKG_ORCH_QUEUESERVICE is

  LOWEST_PRIORITY NUMBER(10):=1;
  NORMAL_PRIORITY NUMBER(10):=7;
  HIGHEST_PRIORITY NUMBER(10):=15;

  ACQUIRED_SUCCESS NUMBER(2):=1;
  ACQUIRED_FAIL NUMBER(2):=0;

  EXECUTE_ACTION_TYPE NUMBER(10):=1;

  REMOVE_IMMEDIATELY_NO NUMBER(2):=0;
  REMOVE_IMMEDIATELY_YES NUMBER(2):=1;

  /**
     Add message to the Queue:
         - add message to the storage
  */
  procedure queueMessage(proc_id in number, action_type in number, family_id in number,
  	task_id in number default null, details in clob default null, priority in number default NORMAL_PRIORITY,
    queue_priority in number, node in varchar2, user_id in number, msg_id out number);


  /**
     Acquire next ready message from the queue for process.

     If both process and family are null acquire first message from all messages of queue.
     If only process is null acquire first message from all messages for specified family.
     If process is not null acquire first message from all messages for specified process.

     The acquired process should be not locked at the acquiring time.
     The acquired process is locked after acquirement.
  */
  procedure acquireNextMessage(current_proc_id in number, current_family_id in number, remove_immediately in integer,
      msg_id out number, proc_id out number,
      action_type out number, family_id out number, task_id out number, details out clob,
      priority out number, queue_priority out number, node in out varchar2, user_id out number, error_code out integer,
      queue_priorities in arrayofnumbers);

  /**
     Remove message by its ID.
  */
  procedure removeMessage(msg_id in number);

  /**
     Lock process in exclusive mode
  */
  -- DMMA0210 [18.05.2010] [Synchronous lock process for update] Start
  --procedure acquireLock(family_id in number);
  procedure acquireLock(family_id in number, timeout in integer default 0, error_code out integer);
  -- DMMA0210 [18.05.2010] [Synchronous lock process for update] End

  /**
     Queue message for synchronous execution:
           1. Lock process in exclusive mode
           2. Insert message in queue table
     Out parameters: msg_id - ID of the message
                     error_code - 20300 if process was locked, 0 otherwise
  */
  procedure queueMessageSync(proc_id in number, action_type in number, family_id in number, task_id in number default null,
      details in clob default null,
      priority in number default NORMAL_PRIORITY, queue_priority in number, node in varchar2, user_id in number, msg_id out number, error_code out integer);

  /**
     Remove message from the queue in autonomous transaction
  */
  procedure dequeueMessageSync(msg_id in number);

  /**
    Release the acquired lock
  */
  procedure releaseProcessLock(family_id in number);

  function getWaitingMessageCount return integer;

  function getWaitMsgCountForNodeByPrior(nodeName in VARCHAR2, priority in number) return integer;

  /**
     Check if process contains system messages with higher priority:
       Returns 1 if true and 0 if false
  */
  function getMessagesForFamily(family_id in number, priority in number, msg_id in number) return number;

  /**
     Returns next ready message from the queue for process.

     If both process and family are null returns first message from all messages of queue.
     If only process is null returns first message from all messages for specified family.
     If process is not null returns first message from all messages for specified process.
  */
  procedure getNextMessage(current_proc_id in number, current_family_id in number, msg_id out number, proc_id out number,
      action_type out number, family_id out number, task_id out number, details out clob, priority out number,
      queue_priority out number, node in out varchar2, user_id out number, queue_priorities in arrayofnumbers);

end PKG_ORCH_QUEUESERVICE;
/
