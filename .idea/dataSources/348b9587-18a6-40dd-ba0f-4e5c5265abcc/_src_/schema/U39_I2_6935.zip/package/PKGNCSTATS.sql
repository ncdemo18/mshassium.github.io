CREATE PACKAGE          "PKGNCSTATS" 
AS
   PROCEDURE gatherVersionStats ( VERSION IN VARCHAR2 );

   PROCEDURE gatherStats;

   PROCEDURE gatherCommonStats;

   PROCEDURE gatherHistograms;
END;



/
