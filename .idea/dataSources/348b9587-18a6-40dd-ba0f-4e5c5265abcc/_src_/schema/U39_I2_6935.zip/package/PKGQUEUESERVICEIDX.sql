CREATE package pkgQueueServiceIDX is

 procedure updateIDX(queue_id in number);

 procedure correctIDX;

end pkgQueueServiceIDX;
/
