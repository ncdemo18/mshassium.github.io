CREATE PACKAGE PKG_LCM_UTILS AS
/******************************************************************************
   NAME:       PKG_LCM_UTILS
******************************************************************************/
type event_row is record (
    event_id   varchar2(100)
   );
type event_table is table of event_row;

type trn_event_row is record (
    trn_id   number,
    event_id   varchar2(100)
   );
type trn_event_table is table of trn_event_row;

function is_available_event (conf_id number,object_id number,event_id varchar2) return number;
function is_poc_available_button (object_id number,event_id varchar2,conf_id number DEFAULT 9140545500413225433) return number;
function is_plm return number;
function is_transition_prohibited(trn_id number) RETURN number;
function get_status (conf_id number,objectId number) return number;
function get_available_events (conf_id number,object_id number) return event_table pipelined;
function get_available_transitions (conf_id number,object_id number) return trn_event_table pipelined;
POC_CONF_ID number := 9140545500413225433 /* Product Offering Lifecycle */;
DISCOUNT_CONF_ID number := 9142101345913292273 /* Discount Lifecycle */;
PV_CONF_ID number := 9142065890013110986 /* Price Value Lifecycle */;
ENABLED_LV  number := 9127109081813843669 /* enabled */;
HIDDEN_LV   number := 9127109081813843671 /* hidden */;
PLM_CONF_ID number := 9140720706513380914 /* PLM Configuration */;
POC_CONF_PROJECT_ID number := 9142102832013696703 /* POC Configuration */;
PROHIBITED_TRANSITIONS_ATTR_ID number := 9144158656613642453 /* Prohibited Transitions */;

END PKG_LCM_UTILS;
/
