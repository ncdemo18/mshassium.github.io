CREATE package pkgCUStats as

  STAT_BACKUP_TABLE_NAME constant varchar2(15) := 'nc_backup_stats';
  TABLE_NAME_MACROS constant varchar2(13) := '#$tablename$#';

  BEFORE_STATISTICS_GATHERING constant varchar2(27) := 'BEFORE STATISTICS GATHERING';
  AFTER_STATISTICS_GATHERING constant varchar2(26) := 'AFTER STATISTICS GATHERING';
  DEFAULT_STAT_GATHERING constant varchar2(28) := 'DEFAULT STATISTICS GATHERING';

  STAT_GATHERING_IS_STARTED   constant varchar2(29) := 'Statistics gathering started.';
  STAT_GATHERING_IS_COMPLETED constant varchar2(31) := 'Statistics gathering completed.';
  STAT_GATHERING_IS_FAILED constant varchar2(28) := 'Statistics gathering failed.';
  STAT_TABLE_NOT_EXISTS constant varchar2(63) := 'Statistics gathering for table failed. Table not exists. Name: ';

  STAT_SAVED constant varchar2(39) := 'Statistics saved successfully. StatID: ';
  STAT_DELETED constant varchar2(41) := 'Statistics deleted successfully. StatID: ';
  STAT_NOT_SAVED constant varchar2(21) := 'Statistics not saved!';
  STAT_NOT_DELETED constant varchar2(23) := 'Statistics not deleted!';

  STAT_RESTORED constant varchar2(33) := 'Statistics was restored. StatID: ';
  STAT_NOT_RESTORED constant varchar2(24) := 'Statistics not restored!';

  STAT_START_EXEC_BEFORE constant varchar2(24) := '"BEFORE" script started.';
  STAT_FAIL_EXEC_BEFORE constant varchar2(23) := '"BEFORE" script failed!';
  STAT_SUCCESS_EXEC_BEFORE constant varchar2(26) := '"BEFORE" script completed.';

  STAT_START_EXEC_AFTER constant varchar2(23) := '"AFTER" script started.';
  STAT_FAIL_EXEC_AFTER constant varchar2(22) := '"AFTER" script failed!';
  STAT_SUCCESS_EXEC_AFTER constant varchar2(25) := '"AFTER" script completed.';

  STAT_START_EXEC_CONF constant varchar2(49) := 'Custom configuration execution started.';
  STAT_SUCCESS_EXEC_CONF constant varchar2(51) := 'Custom configuration execution completed.';
  STAT_FAIL_EXEC_CONF constant varchar2(38) := 'Custom configuration execution failed!';

  STAT_CONFIG_REMOVED constant varchar2(26) := 'Statistics config removed.';
  INCORRECT_DEFAULT_RECORD constant varchar2(101) := 'New config record cannot be added! Default statistics gathering record should contain "' || TABLE_NAME_MACROS || '"';
  DEFAULT_RECORD_EXISTS constant varchar2(86) := 'New config record cannot be added! Default statistics gathering record already exists!';

  ORDER_NUMBER constant varchar2(15) := ' Order number: ';
  TABLE_NAME constant varchar2(13) := ' Table name: ';

  procedure gatherStats(backup_old_stats BOOLEAN DEFAULT TRUE);

  procedure gatherStatsForTable(tab_name VARCHAR2, backup_old_stats BOOLEAN DEFAULT TRUE);

  procedure insertStatsConfig(tab_name VARCHAR2, e_code VARCHAR2, ord_number NUMBER DEFAULT NULL);

  procedure removeStatsConfig;

  procedure backupCurrentStats;

  procedure restoreStats(stat_id VARCHAR2, backup_stats BOOLEAN DEFAULT TRUE);

  procedure removeBackupStats(stat_id VARCHAR2);

end pkgCUStats;
/
