CREATE PACKAGE PKGPSTN
IS

    subtype PHONE_BOOK_MODEL is integer(1);
    type TABLE_OF_ARRAYOFNUMBERS is table of arrayofnumbers;
    CLASS_ID__PHONE_NUMBER constant number := 15001;
    CLASS_ID__PHONE_RANGE constant number := 15002;
    --OBJECT_TYPE_ID__CATEGORY_CONTAINER
    OBJTYPE_ID__CATEGORY_CONTAINER constant number := 9131647070413913865;
    --OBJECT_TYPE_ID__NUMBER_CATEGORY
    OBJTYPE_ID__NUMBER_CATEGORY constant number := 9131647070413913869;
    --OBJECT_TYPE_ID__NUMBER_MASK
    OBJTYPE_ID__NUMBER_MASK constant number := 9131647070413913876;
    --OBJECT_TYPE_ID__NUMBER_INVENTORY_CONTAINER
    OBJTYPE_ID__NUMBER_INV_CONT constant number := 15006;
    --ATTR_ID__REGULAR_EXPRESSION
    ATTR_ID__REG_EXPR constant number := 9131689730013925936;
    ATTR_ID__MASK_POSITION constant number := 9131708330113943789;
    --ATTR_ID__CLASSIFICATION_PERFORMED
    ATTR_ID__CLASSIFICATION_PERF constant number := 9131689880313926200;
	--ATTR_ID__CLASSIFICATION_DATE
    ATTR_ID__CLASSIFICATION_DATE constant number := 9140822002113414210;
    --ATTR_ID--APPLY_CATEGORY_DEFINITION
    ATTR_ID__APPLY_CATEGORY_DEF constant number := 9131689880313926153;
    --list value IDs of attr type def 9131699100613940340
    LV__YES constant number := 9131699100613940341;
    LV__NO constant number := 9131699100613940342;
    --ATTR_ID__VIP_CATEGORIES_DEFINITION
    ATTR_ID__VIP_CATEGORIES_DEF constant number := 9131648070613915023;
    ATTR_ID__VIP_CATEGORY constant number := 9131648465013915262;

    ATTR_ID__PHONE_NUMBER constant number := 15100;
    US_ATTR_ID__DISCONNECTION_DATE constant number := 15110;
    EU_ATTR_ID__DISCONNECTION_DATE constant number := 9123983146513901614;
    US_ATTR_ID__STATUS constant number := 15105;
    EU_ATTR_ID__STATUS constant number := 5051946481013506925;
    US_ATTR_STATUS_LV_ID__VC constant number := 15421;
    US_ATTR_STATUS_LV_ID__VP constant number := 15409;
    EU_ATTR_STATUS_LV_ID__FREE constant number := 5051946053013506923;
    ATTR_ID__STATUS constant arrayofnumbers := arrayofnumbers(US_ATTR_ID__STATUS, EU_ATTR_ID__STATUS);
    ATTR_ID__DISCONNECTION_DATE constant arrayofnumbers := arrayofnumbers(US_ATTR_ID__DISCONNECTION_DATE, EU_ATTR_ID__DISCONNECTION_DATE);
    ATTR_STATUS_LV_IDS__AVAILABLE constant TABLE_OF_ARRAYOFNUMBERS := TABLE_OF_ARRAYOFNUMBERS(
                                                                        arrayofnumbers(US_ATTR_STATUS_LV_ID__VC, US_ATTR_STATUS_LV_ID__VP),
                                                                        arrayofnumbers(EU_ATTR_STATUS_LV_ID__FREE));
    PB_MODEL_PROPERTY constant varchar2(20) := 'nc.phonebook.model';
    US_PB_MODEL_PROPERTY_VALUE  constant varchar2(2) := 'US';
    EU_PB_MODEL_PROPERTY_VALUE  constant varchar2(2) := 'EU';

    DURATION_TYPE_PROP constant varchar2(13) := 'duration_type';

    ATTR_TYPE_ID__REFERENCE constant nc_attributes.attr_type_id%type := 9;
    ATTR_TYPE_ID__LIST constant nc_attributes.attr_type_id%type := 7;
    ATTR_TYPE_ID__DATE constant nc_attributes.attr_type_id%type := 4;



    PROCEDURE createrangenumbers(
        p_parent      IN NUMBER,
        p_type_id     IN NUMBER,
        p_firstnumber IN NUMBER,
        p_lastnumber  IN NUMBER );

    PROCEDURE removerange(p_range_id IN NUMBER);

    PROCEDURE add_modification_info(
        p_parent IN NUMBER,
        username IN VARCHAR2);

    PROCEDURE updateGroupParameters(
        etalon_id IN NUMBER,
        group_id IN NUMBER,
        attrs IN ARRAYOFNUMBERS);

    /**
    * Return phone number with expired value of attribute
    *
    * @param p_project_id - ID of project with phone numbers when timing transition needed
    * @param p_toggle_attr_id - attribute ID of phone number for change in transition
    * @param p_soutce_lv - source list value ID of attribute specified in p_toggle_attr_id
    * @param p_date_attr - attribute ID of phone number with date when attribute specified in p_toggle_attr_id had been set in p_soutce_lv
    * @param p_duration_attr - attribute ID of phone number with duration stay p_toggle_attr_id in p_soutce_lv before transit to p_destination_lv
    *
    * @see performTimedTransition
    */
    function get_expired_numbers(p_project_id number,
                                 p_toggle_attr_id number,
                                 p_list_value number,
                                 p_date_attr number,
                                 p_duration_attr number) return arrayofnumbers;

    /**
    * Change value of attribute when time period pass.
    *
    * @param p_project_id - ID of project with phone numbers when timing transition needed
    * @param p_toggle_attr_id - attribute ID of phone number for change in transition
    * @param p_soutce_lv - source list value ID of attribute specified in p_toggle_attr_id
    * @param p_destination_lv - destination list value ID of attribute specified in p_toggle_attr_id
    * @param p_date_attr - attribute ID of phone number with date when attribute specified in p_toggle_attr_id had been set in p_soutce_lv
    * @param p_duration_attr - attribute ID of phone number with duration stay p_toggle_attr_id in p_soutce_lv before transit to p_destination_lv
    * @param clear_attrs - ???ptional parameter. Attribute IDs of phone number for clear in transition.
    */
    procedure performTimedTransition(p_project_id number,
                                      p_toggle_attr_id number,
                                      p_soutce_lv number,
                                      p_destination_lv number,
                                      p_date_attr number,
                                      p_duration_attr number,
                                      clear_attrs arrayofnumbers default null);
    /**
    * Find available phone number(s).
    *
    * @param p_ranges - phone number range IDs.
    * @param searchMask - mask of phone numbers for 'like' expression
    * @param howMany phone numbers search count.
    * @param p_hierarchical search phone numbers in range hierarchy start with p_ranges.
    *        Search performed without hierarchy by default.
    * @param p_for_update TBD
    * @return list of available phone number IDs
    */
    function find_avail_num(p_ranges arrayofnumbers,
                            search_mask varchar2,
                            how_many number,
                            p_hierarchical number default 0,
                            p_for_update number default 1) return arrayofnumbers;

    /**
    * Perform classification of phone numbers into specified project or ranges.
    *
    * @param p_project_id inventory project with phone numbers for classification
    * @param p_range_ids ranges of fone number for categorization. To process all phone numburs
                         into inventory project set null. System process all numbers into project by default.
    */
    procedure performCategorization(p_project_id number,
                                    p_range_ids arrayofnumbers default null);

    /**
    * Calculate category for phone number and store it in DB.
    *
    * @param p_phone_id phone range ID
    * @return calculated category ID
    */
    function updatePhoneNumberCategory(p_phone_id number) return number;

    /**
    * Prepare recalculation category of range numbers.
    * @param p_mode if 1 preparation will be performed for all subranges.
    *               If 2 preparation will be performed for subranges with sane category container.
    */
    procedure prepare_recalculation(p_range_id number, p_mode number default 1);

    /**
    * Prepare recalculation category of range numbers associated with category container.
    *
    * @param p_container_id all range associated with this container will be prepared for recalculation
    * @return phone range IDs for recalculation
    */
    function prepare_recal_container(p_container_id number) return arrayofnumbers;

    /**
     * Generates and executes dynamic SQL query for searching or filtering phone numbers by multiple criteria.
     * Optionally it is possible to lock found numbers via 'select ... for update' and/or mark matching
     * numbers with provided set of parameters.
     *
     * @param p_numbers - array of number object_ids to filter by criteria
     * @param p_ranges - array of range object_ids to search numbers in
     * @param p_is_hier - 1 if range object_ids should be treated as range hierarhy roots, to select all subranges from.
     *             0 if range object_ids are direct parents of searched phone numbers.
     * @param p_types - array of object_type_ids to explititly filter on
     * @param p_num_mask - mask of phone numbers for 'like' expression
     * @param p_pos_attrs - array of attr_ids for positive attribute filter on number's parameters
     * @param p_pos_values - array of values for positive attribute filter on number's parameters
     * @param p_neg_attrs - array of attr_ids for negative attribute filter on number's parameters
     * @param p_neg_values - array of values for negative attribute filter on number's parameters
     * @param p_blank_or_set_to_attrs - array of attr_ids for 'blank or equals to' attribute filter on number's parameters
     * @param p_blank_or_set_to_values - array of values for 'blank or equals to' attribute filter on number's parameters
     * @param p_parent_pos_attrs - array of attr_ids for positive attribute filter on immediate number's parent (range's) parameters
     * @param p_parent_pos_values - array of values for positive attribute filter on immediate number's parent (range's) parameters
     * @param p_parent_neg_attrs - array of attr_ids for negative attribute filter on immediate number's parent (range's) parameters
     * @param p_parent_neg_values - array of values for negative attribute filter on immediate number's parent (range's) parameters
     * @param p_limit - quantity of numbers to be searched
     * @param p_is_for_update - inticates if found numbers should be locked via 'select ... for update'
     * @param p_set_attrs - array of attr_ids for parameters to be set on found numbers
     * @param p_set_values - array of values for parameters to be set on found numbers
     * @param p_set_type - object_type_id to be set on found numbers
     * @return array of found numbers object_ids
     */
    function find_nums_by_multi_criteria(
      p_numbers arrayofnumbers default null,
      p_ranges arrayofnumbers default null,
      p_is_hier number default 0,
      p_types arrayofnumbers default null,
      p_num_mask varchar2 default null,
      p_pos_attrs arrayofnumbers default null,
      p_pos_values arrayofstrings default null,
      p_neg_attrs arrayofnumbers default null,
      p_neg_values arrayofstrings default null,
      p_blank_or_set_to_attrs arrayofnumbers default null,
      p_blank_or_set_to_values arrayofstrings default null,
      p_parent_pos_attrs arrayofnumbers default null,
      p_parent_pos_values arrayofstrings default null,
      p_parent_neg_attrs arrayofnumbers default null,
      p_parent_neg_values arrayofstrings default null,
      p_limit number default 5,
      p_is_for_update number default 0,
      p_set_attrs arrayofnumbers default null,
      p_set_values arrayofstrings default null,
      p_set_type number default null
    ) return arrayofnumbers;

    /**
     * Inserts record about categorization errors in pstn_errors table
     * @param ex_date - date of the exception
     * @param rangeIDs - string of ids of ranges for which categories are recalculated
     * @param message - exception message
     * @param ex_type - type of exception
	 * @param stack_trace - stack trace of exception
	 */
	procedure write_error(ex_date timestamp, rangeIDs varchar2, message varchar2, ex_type varchar2, stack_trace clob);
END;
/
