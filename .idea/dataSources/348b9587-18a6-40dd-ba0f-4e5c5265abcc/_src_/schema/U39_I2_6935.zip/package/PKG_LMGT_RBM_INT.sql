CREATE PACKAGE pkg_lmgt_rbm_int AS

  procedure createLoyaltyProgram(p_loyaltyprogramid       IN OUT INTEGER,
                                    p_loyaltyprogramname     IN VARCHAR2,
                                    p_loyaltyprogramstatus   IN INTEGER,
                                    p_loyaltyprogramdesc     IN VARCHAR2,
                                    p_initialcategoryid      IN INTEGER,
                                    p_initialrewardpoints    IN INTEGER,
                                    p_deactivationcategoryid IN INTEGER,
                                    p_disableaccumulationboo IN VARCHAR2,
                                    p_disableredemptionboo   IN VARCHAR2);

  procedure modifyLoyaltyProgram(p_loyaltyprogramid          IN INTEGER,
                                    p_oldloyaltyprogramname     IN VARCHAR2,
                                    p_oldloyaltyprogramstatus   IN INTEGER,
                                    p_oldloyaltyprogramdesc     IN VARCHAR2,
                                    p_oldinitialcategoryid      IN INTEGER,
                                    p_oldinitialrewardpoints    IN INTEGER,
                                    p_olddeactivationcategoryid IN INTEGER,
                                    p_olddisableaccumulationboo IN VARCHAR2,
                                    p_olddisableredemptionboo   IN VARCHAR2,
                                    p_newloyaltyprogramname     IN VARCHAR2,
                                    p_newloyaltyprogramstatus   IN INTEGER,
                                    p_newloyaltyprogramdesc     IN VARCHAR2,
                                    p_newinitialcategoryid      IN INTEGER,
                                    p_newinitialrewardpoints    IN INTEGER,
                                    p_newdeactivationcategoryid IN INTEGER,
                                    p_newdisableaccumulationboo IN VARCHAR2,
                                    p_newdisableredemptionboo   IN VARCHAR2);

  procedure deleteLoyaltyProgram(p_loyaltyprogramid       IN INTEGER,
                                    p_loyaltyprogramname     IN VARCHAR2,
                                    p_loyaltyprogramstatus   IN INTEGER,
                                    p_loyaltyprogramdesc     IN VARCHAR2,
                                    p_initialcategoryid      IN INTEGER,
                                    p_initialrewardpoints    IN INTEGER,
                                    p_deactivationcategoryid IN INTEGER,
                                    p_disableaccumulationboo IN VARCHAR2,
                                    p_disableredemptionboo   IN VARCHAR2);





  procedure createLoyaltyCategory(p_loyaltycategoryid     IN OUT INTEGER,
                                     p_loyaltycategoryname   IN VARCHAR2,
                                     p_loyaltycategorystatus IN INTEGER,
                                     p_loyaltycategorydesc   IN VARCHAR2);

  procedure modifyLoyaltyCategory(p_loyaltycategoryid        IN INTEGER,
                                     p_oldloyaltycategoryname   IN VARCHAR2,
                                     p_oldloyaltycategorystatus IN INTEGER,
                                     p_oldloyaltycategorydesc   IN VARCHAR2,
                                     p_newloyaltycategoryname   IN VARCHAR2,
                                     p_newloyaltycategorystatus IN INTEGER,
                                     p_newloyaltycategorydesc   IN VARCHAR2);

  procedure deleteLoyaltyCategory(p_loyaltycategoryid     IN INTEGER,
                                     p_loyaltycategoryname   IN VARCHAR2,
                                     p_loyaltycategorystatus IN INTEGER,
                                     p_loyaltycategorydesc   IN VARCHAR2);



  procedure createLoyaltyProgHasCat(p_loyaltyprogramid          IN INTEGER,
                                       p_loyaltycategoryid         IN INTEGER,
                                       p_loyaltygroupstatus        IN INTEGER,
                                       p_pointsexpiryperiod        IN INTEGER,
                                       p_pointsexpiryperiodunits   IN VARCHAR2,
                                       p_downgradepoints           IN INTEGER,
                                       p_downgradecategoryid       IN INTEGER,
                                       p_dgaccumulationperiod      IN INTEGER,
                                       p_dgaccumulationperiodunits IN VARCHAR2,
                                       p_upgradepoints             IN INTEGER,
                                       p_upgradecategoryid         IN INTEGER,
                                       p_ugaccumulationperiod      IN INTEGER,
                                       p_ugaccumulationperiodunits IN VARCHAR2);

  procedure modifyLoyaltyProgHasCat(p_loyaltyprogramid             IN INTEGER,
                                       p_loyaltycategoryid            IN INTEGER,
                                       p_oldloyaltygroupstatus        IN INTEGER,
                                       p_oldpointsexpiryperiod        IN INTEGER,
                                       p_oldpointsexpiryperiodunits   IN VARCHAR2,
                                       p_olddowngradepoints           IN INTEGER,
                                       p_olddowngradecategoryid       IN INTEGER,
                                       p_olddgaccumulationperiod      IN INTEGER,
                                       p_olddgaccumulationperiodunits IN VARCHAR2,
                                       p_oldupgradepoints             IN INTEGER,
                                       p_oldupgradecategoryid         IN INTEGER,
                                       p_oldugaccumulationperiod      IN INTEGER,
                                       p_oldugaccumulationperiodunits IN VARCHAR2,
                                       p_newloyaltygroupstatus        IN INTEGER,
                                       p_newpointsexpiryperiod        IN INTEGER,
                                       p_newpointsexpiryperiodunits   IN VARCHAR2,
                                       p_newdowngradepoints           IN INTEGER,
                                       p_newdowngradecategoryid       IN INTEGER,
                                       p_newdgaccumulationperiod      IN INTEGER,
                                       p_newdgaccumulationperiodunits IN VARCHAR2,
                                       p_newupgradepoints             IN INTEGER,
                                       p_newupgradecategoryid         IN INTEGER,
                                       p_newugaccumulationperiod      IN INTEGER,
                                       p_newugaccumulationperiodunits IN VARCHAR2);

  procedure deleteLoyaltyProgHasCat(p_loyaltyprogramid          IN INTEGER,
                                       p_loyaltycategoryid         IN INTEGER,
                                       p_loyaltygroupstatus        IN INTEGER,
                                       p_pointsexpiryperiod        IN INTEGER,
                                       p_pointsexpiryperiodunits   IN VARCHAR2,
                                       p_downgradepoints           IN INTEGER,
                                       p_downgradecategoryid       IN INTEGER,
                                       p_dgaccumulationperiod      IN INTEGER,
                                       p_dgaccumulationperiodunits IN VARCHAR2,
                                       p_upgradepoints             IN INTEGER,
                                       p_upgradecategoryid         IN INTEGER,
                                       p_ugaccumulationperiod      IN INTEGER,
                                       p_ugaccumulationperiodunits IN VARCHAR2);



  procedure createLoyaltyPointRate(p_loyaltyprogramid          IN INTEGER,
                                      p_loyaltycategoryid         IN INTEGER,
                                      p_cataloguechangeid         IN INTEGER,
                                      p_startdat                  IN DATE,
                                      p_tariffid                  IN INTEGER,
                                      p_productid                 IN INTEGER,
                                      p_otcid                     IN INTEGER,
                                      p_enddat                    IN DATE,
                                      p_oneoffaccrualpoints       IN INTEGER,
                                      p_oneoffaccrualpointrate    IN INTEGER,
                                      p_oneoffredemptionpoints    IN INTEGER,
                                      p_oneoffredemptionpointrate IN INTEGER,
                                      p_recurringaccrualpoints    IN INTEGER,
                                      p_recurringaccrualpointrate IN INTEGER,
                                      p_eventpointrate            IN INTEGER,
                                      p_accrueonpartialredempboo  IN VARCHAR2);

  procedure modifyLoyaltyPointRate(p_loyaltyprogramid             IN INTEGER,
                                      p_loyaltycategoryid            IN INTEGER,
                                      p_cataloguechangeid            IN INTEGER,
                                      p_startdat                     IN DATE,
                                      p_oldtariffid                  IN INTEGER,
                                      p_oldproductid                 IN INTEGER,
                                      p_oldotcid                     IN INTEGER,
                                      p_oldenddat                    IN DATE,
                                      p_oldoneoffaccrualpoints       IN INTEGER,
                                      p_oldoneoffaccrualpointrate    IN INTEGER,
                                      p_oldoneoffredemptionpoints    IN INTEGER,
                                      p_oldoneoffredemptionpointrate IN INTEGER,
                                      p_oldrecurringaccrualpoints    IN INTEGER,
                                      p_oldrecurringaccrualpointrate IN INTEGER,
                                      p_oldeventpointrate            IN INTEGER,
                                      p_oldaccrueonpartialredempboo  IN VARCHAR2,
                                      p_newtariffid                  IN INTEGER,
                                      p_newproductid                 IN INTEGER,
                                      p_newotcid                     IN INTEGER,
                                      p_newenddat                    IN DATE,
                                      p_newoneoffaccrualpoints       IN INTEGER,
                                      p_newoneoffaccrualpointrate    IN INTEGER,
                                      p_newoneoffredemptionpoints    IN INTEGER,
                                      p_newoneoffredemptionpointrate IN INTEGER,
                                      p_newrecurringaccrualpoints    IN INTEGER,
                                      p_newrecurringaccrualpointrate IN INTEGER,
                                      p_neweventpointrate            IN INTEGER,
                                      p_newaccrueonpartialredempboo  IN VARCHAR2);

  procedure deleteLoyaltyPointRate(p_loyaltyprogramid          IN INTEGER,
                                      p_loyaltycategoryid         IN INTEGER,
                                      p_cataloguechangeid         IN INTEGER,
                                      p_startdat                  IN DATE,
                                      p_tariffid                  IN INTEGER,
                                      p_productid                 IN INTEGER,
                                      p_otcid                     IN INTEGER,
                                      p_enddat                    IN DATE,
                                      p_oneoffaccrualpoints       IN INTEGER,
                                      p_oneoffaccrualpointrate    IN INTEGER,
                                      p_oneoffredemptionpoints    IN INTEGER,
                                      p_oneoffredemptionpointrate IN INTEGER,
                                      p_recurringaccrualpoints    IN INTEGER,
                                      p_recurringaccrualpointrate IN INTEGER,
                                      p_eventpointrate            IN INTEGER,
                                      p_accrueonpartialredempboo  IN VARCHAR2);




  procedure createLoyaltyPointSource(p_lpsourceid   OUT INTEGER,
                                        p_lpsourcename IN VARCHAR2,
                                        p_lpsourcedesc IN VARCHAR2,
                                        p_lpsourcetype IN INTEGER);


  procedure modifyLoyaltyPointSource(p_lpsourceid      IN INTEGER,
                                        p_oldlpsourcename IN VARCHAR2,
                                        p_oldlpsourcedesc IN VARCHAR2,
                                        p_oldlpsourcetype IN INTEGER,
                                        p_newlpsourcename IN VARCHAR2,
                                        p_newlpsourcedesc IN VARCHAR2,
                                        p_newlpsourcetype IN INTEGER);

  procedure deleteLoyaltyPointSource(p_lpsourceid   IN INTEGER,
                                        p_lpsourcename IN VARCHAR2,
                                        p_lpsourcedesc IN VARCHAR2,
                                        p_lpsourcetype IN INTEGER);


END pkg_lmgt_rbm_int;
/
