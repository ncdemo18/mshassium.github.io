CREATE PACKAGE pkg_cia_rules IS

    --Default severity propagation rule
    FUNCTION get_default_service_level(object_id IN NUMBER) RETURN NUMBER;

    --Dynamic SQL rule execution with binding <object_id> as #$objectid$#
    FUNCTION dynamic_execution(sql_string IN VARCHAR2, object_id IN NUMBER) RETURN NUMBER;

    --Trying to find matching rule for object <object_id>
    FUNCTION get_sql_rule(object_id IN NUMBER) RETURN NUMBER;

    --If SQL rule exists for object <object_id> this function is used
    FUNCTION get_severity_by_sql_rule(object_id IN NUMBER) RETURN NUMBER;

    --If there is no SQL rule for object <object_id> this function is used
    FUNCTION get_severity_by_default_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 7040354549013045907 /* Network */
    FUNCTION network_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 7040354549013045876 /* Link Path Element */
    FUNCTION link_path_element_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 7040567641013049695 /* Optional Component */
    FUNCTION optional_componet_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 7040570849013049696 /* Protection Group */
    FUNCTION protection_group_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 7040556536013048948 /* Resource Facing Service Instance */
    FUNCTION rfs_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 7040354549013045877 /* Customer Facing Service Instance */
    FUNCTION cfs_rule(object_id IN NUMBER) RETURN NUMBER;

    --Returns the least service level of used by circuit <circuit_id> networks
    FUNCTION get_child_net_service_level(circuit_id IN NUMBER) RETURN NUMBER;


    FUNCTION CPE_CHECK(in_object_id IN NUMBER) RETURN NUMBER;



END pkg_cia_rules;
/
