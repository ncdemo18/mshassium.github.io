CREATE PACKAGE pkg_cia_propagation_rules IS

    --Standard dependecy propagation rule 7071854841013352899 /* Parent -> Child Relation */
    PROCEDURE parent_to_child(depth               IN NUMBER,
                              rule_id             IN NUMBER,
                              objects             IN arrayofnumbers,
                              target_object_types IN arrayofnumbers,
                              root_object_id      IN NUMBER:=null);

    --Standard dependecy propagation rule 7071858804013352901 /* Child -> Parent Relation */
    PROCEDURE child_to_parent(depth               IN NUMBER,
                              rule_id             IN NUMBER,
                              objects             IN arrayofnumbers,
                              target_object_types IN arrayofnumbers,
                              root_object_id      IN NUMBER:=null);

    --Standard dependecy propagation rule 7071858804013352904 /* By Reference Attribute */
    PROCEDURE object_id_to_reference(depth               IN NUMBER,
                                     rule_id             IN NUMBER,
                                     objects             IN arrayofnumbers,
                                     target_object_types IN arrayofnumbers,
                                     attributes          IN arrayofnumbers,
                                     root_object_id      IN NUMBER:=null);

    --Standard dependecy propagation rule 7071858804013352906 /* By Backward Reference Attribute */
    PROCEDURE reference_to_object_id(depth               IN NUMBER,
                                     rule_id             IN NUMBER,
                                     objects             IN arrayofnumbers,
                                     target_object_types IN arrayofnumbers,
                                     attributes          IN arrayofnumbers,
                                     root_object_id      IN NUMBER:=null);

    --Standard backward dependecy propagation rule 7071854841013352899 /* Parent -> Child Relation */
    PROCEDURE parent_to_child_backward(depth              IN NUMBER,
                                      rule_id             IN NUMBER,
                                      objects             IN arrayofnumbers,
                                      source_object_types IN arrayofnumbers,
                                      root_object_id      IN NUMBER:=null);

    --Standard backward dependecy propagation rule 7071858804013352901 /* Child -> Parent Relation */
    PROCEDURE child_to_parent_backward(depth              IN NUMBER,
                                      rule_id             IN NUMBER,
                                      objects             IN arrayofnumbers,
                                      source_object_types IN arrayofnumbers,
                                      root_object_id      IN NUMBER:=null);

    --Standard backward dependecy propagation rule 7071858804013352904 /* By Reference Attribute */
    PROCEDURE object_id_to_ref_backward(depth              IN NUMBER,
                                       rule_id             IN NUMBER,
                                       objects             IN arrayofnumbers,
                                       source_object_types IN arrayofnumbers,
                                       attributes          IN arrayofnumbers,
                                       root_object_id      IN NUMBER:=null);

    --Standard backward dependecy propagation rule 7071858804013352906 /* By Backward Reference Attribute */
    PROCEDURE ref_to_object_id_backward(depth              IN NUMBER,
                                       rule_id             IN NUMBER,
                                       objects             IN arrayofnumbers,
                                       source_object_types IN arrayofnumbers,
                                       attributes          IN arrayofnumbers,
                                       root_object_id      IN NUMBER:=null);
END pkg_cia_propagation_rules;
/
