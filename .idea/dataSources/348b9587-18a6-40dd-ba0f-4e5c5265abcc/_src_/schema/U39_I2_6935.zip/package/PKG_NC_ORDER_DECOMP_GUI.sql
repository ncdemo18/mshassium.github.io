CREATE PACKAGE PKG_NC_ORDER_DECOMP_GUI is
  VERTIVAL_LINK_OBJECT_TYPE number := 7030640040013263235;
  ASSOC_TO_ORDER_REFERENCE_ATTR number := 7081557355013588775;
  --GENERIC_ORDER_OBJECT_TYPE number := 9120748958013833564;

  TYPE tableOfLinksDatas IS table of arrayofnumbers;
  function getOrdersDecomposition(startWithOrders IN arrayofnumbers) return arrayofnumbers;

  procedure fillOrders_REQ(ordrs IN arrayofnumbers, result_orders IN OUT arrayofnumbers);
  function findLinksTargets(orders IN arrayofnumbers, exclude_target_orders IN arrayofnumbers) return arrayofnumbers;
  function findLinks(orders IN arrayofnumbers) return tableOfLinksDatas PIPELINED;
  function findLinks_INNER(orders IN arrayofnumbers, exclude_target_orders IN arrayofnumbers) return tableOfLinksDatas;
  procedure addToArray(destArray IN OUT arrayofnumbers, sourceArray IN arrayofnumbers);
  procedure filterUniq(arr IN OUT arrayofnumbers);
end PKG_NC_ORDER_DECOMP_GUI;
/
