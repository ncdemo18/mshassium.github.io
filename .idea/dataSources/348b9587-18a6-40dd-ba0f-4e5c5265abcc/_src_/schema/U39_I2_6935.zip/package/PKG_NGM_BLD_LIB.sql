CREATE PACKAGE PKG_NGM_BLD_LIB AS

PREFIX_NODE constant VARCHAR2(2) := '0';
PREFIX_EDGE constant VARCHAR2(2) := '1';
PREFIX_NESTED_NODE constant VARCHAR2(2) := '2';
PREFIX_NESTED_EDGE constant VARCHAR2(2) := '3';
PREFIX_PORT constant VARCHAR2(2) := '4';
PREFIX_PATH constant VARCHAR2(2) := '5';


/*Node Sources Search Function*/
PROCEDURE nsr_search_by_object_type(node_spec_id IN NUMBER,  func_id IN NUMBER);
PROCEDURE nsr_search_by_template(node_spec_id IN NUMBER,  func_id IN NUMBER);
PROCEDURE nsr_search_by_plsql(node_spec_id IN NUMBER,  func_id IN NUMBER);
PROCEDURE nsr_search_by_sql(node_spec_id IN NUMBER,  func_id IN NUMBER);

/*Edge Sources Search Function*/
PROCEDURE esr_search_by_sql(edge_spec_id IN NUMBER,  func_id IN NUMBER);
PROCEDURE esr_search_by_plsql(edge_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE esr_search_circuit_by_ot(edge_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE esr_search_cable_by_tr(edge_spec_id IN NUMBER, func_id IN NUMBER);

/*Path Sources Search Functions*/
PROCEDURE path_search_by_plsql(v_graph_id IN NUMBER, path_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE path_search_by_sql(v_graph_id IN NUMBER, path_spec_id IN NUMBER, func_id IN NUMBER);

/*Port Sources Search Functions*/
PROCEDURE port_search_by_plsql(v_graph_id IN NUMBER, port_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE port_search_by_sql(v_graph_id IN NUMBER, port_spec_id IN NUMBER, func_id IN NUMBER);

/*Node Sources Group Function*/
PROCEDURE nsr_group_by_plsql(node_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE nsr_group_by_parent(node_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE nsr_group_by_sql(node_spec_id IN NUMBER,  func_id IN NUMBER);

/*Edge Sources Group Function*/
PROCEDURE esr_group_by_plsql(v_graph_id IN NUMBER, edge_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE esr_group_by_parallel(v_graph_id IN NUMBER, edge_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE esr_group_by_sql(v_graph_id IN NUMBER, edge_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE esr_group_by_discrit(v_graph_id IN NUMBER, edge_spec_id IN NUMBER, func_id IN NUMBER);

/*Implementation of selectors*/
PROCEDURE nss_selector_by_parent(v_graph_id IN NUMBER, selector_id IN NUMBER);
PROCEDURE nss_selector_by_attribute(v_graph_id IN NUMBER, selector_id IN NUMBER);
PROCEDURE nss_selector_by_plsql(v_graph_id IN NUMBER, selector_id IN NUMBER);
PROCEDURE nss_selector_by_breadth(v_graph_id IN NUMBER, selector_id IN NUMBER);
PROCEDURE nss_selector_by_sql(v_graph_id IN NUMBER, selector_id IN NUMBER);

/*Implementation of filters*/
PROCEDURE nfs_filter_by_parent(v_graph_id IN NUMBER, filter_id IN NUMBER, num_step IN int);
PROCEDURE nfs_filter_by_attribute(v_graph_id IN NUMBER, filter_id IN NUMBER, num_step IN int);
PROCEDURE nfs_filter_by_plsql(v_graph_id IN NUMBER, filter_id IN NUMBER,  num_step IN int);
PROCEDURE nfs_filter_by_sql(v_graph_id IN NUMBER, filter_id IN NUMBER,  num_step IN int);
PROCEDURE efs_filter_by_plsql(v_graph_id IN NUMBER, filter_id IN NUMBER,  num_step IN int);
PROCEDURE efs_filter_by_attribute(v_graph_id IN NUMBER, filter_id IN NUMBER,  num_step IN int);
PROCEDURE efs_filter_by_sql(v_graph_id IN NUMBER, filter_id IN NUMBER, num_step IN int);
PROCEDURE nfs_filter_by_breadth(v_graph_id IN NUMBER, filter_id IN NUMBER, num_step IN int);

/*Param Spec Function*/
PROCEDURE psr_calc_by_attr(v_graph_id IN NUMBER, spec_id IN NUMBER,  param_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE psr_calc_by_parent_name(v_graph_id IN NUMBER, spec_id IN NUMBER, param_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE psr_calc_by_name(v_graph_id IN NUMBER, spec_id IN NUMBER, param_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE psr_calc_by_plsql(v_graph_id IN NUMBER, spec_id IN NUMBER,  param_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE psr_calc_by_sql(v_graph_id IN NUMBER, spec_id IN NUMBER, param_spec_id IN NUMBER, func_id IN NUMBER);
PROCEDURE psr_calc_by_constant(v_graph_id IN NUMBER, p_spec_id IN NUMBER, param_spec_id IN NUMBER, func_id IN NUMBER);

/*Nested Edge Search Function*/
PROCEDURE ner_search_by_plsql(v_graph_id IN NUMBER, nes_spec_id  IN NUMBER, func_id  IN NUMBER);
PROCEDURE ner_search_by_parent(v_graph_id IN NUMBER, nes_spec_id  IN NUMBER, func_id  IN NUMBER);
PROCEDURE ner_search_by_sql(v_graph_id IN NUMBER, nes_spec_id  IN NUMBER, func_id  IN NUMBER);

/*Processing of Generic Actualize Process*/
PROCEDURE generic_actualize_process(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, process_id IN NUMBER);
PROCEDURE actualize_params_by_plsql(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, rule_id IN NUMBER);
PROCEDURE actualize_param_by_plsql(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, rule_id IN NUMBER);
PROCEDURE actualize_param_by_spec(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, rule_id IN NUMBER);
PROCEDURE actualize_graph_by_plsql(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, rule_id IN NUMBER);
PROCEDURE actualize_graph_by_spec(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, rule_id IN NUMBER);

/*Service Functions*/
FUNCTION get_elements_sources(v_graph_id IN NUMBER, spec_id IN NUMBER) RETURN TableOf2Numbers;
FUNCTION get_all_elements_sources(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER) RETURN TableOf3Numbers;
FUNCTION get_elements_sources(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_ids IN ArrayOfNumbers) RETURN TableOf3Numbers;
FUNCTION get_elements_sources(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_id IN NUMBER) RETURN TableOf3Numbers;
FUNCTION get_runtime_parameters_vals(runtime_arg_id NUMBER) RETURN VARCHAR2;
FUNCTION get_found_sources(v_spec_id IN NUMBER) RETURN TableOf3Numbers;
FUNCTION get_port_specs_info(graph_spec_id NUMBER) RETURN TableOf3Numbers;
FUNCTION get_linked_nodes_by_port_spec(p_graph_id NUMBER, port_spec_id NUMBER) RETURN TableOf2Numbers;
FUNCTION get_nodes_by_port_spec(p_graph_id NUMBER, port_spec_id NUMBER) RETURN ArrayOfNumbers;
FUNCTION get_element_ids(v_graph_id NUMBER, prizn VARCHAR2, start_id NUMBER, element_codes ArrayOfNumbers) RETURN TableOf2Numbers;
FUNCTION get_edges_av(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_ids IN ArrayOfNumbers) RETURN TableOf3Numbers;
FUNCTION get_paths_av(v_graph_id IN NUMBER, v_request_id IN NUMBER, v_rev_num IN NUMBER, v_spec_ids IN ArrayOfNumbers) RETURN TableOfPE;

FUNCTION get_last_node_id(v_graph_id NUMBER,  v_request_id NUMBER, prizn VARCHAR2 default PREFIX_NODE) RETURN NUMBER;
FUNCTION get_last_edge_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;
FUNCTION get_last_nested_node_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;
FUNCTION get_last_port_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;
FUNCTION get_last_path_id(v_graph_id NUMBER,  v_request_id NUMBER) RETURN NUMBER;

/*Internal Functions*/
PROCEDURE nsr_search_by_plsql_internal(node_spec_id IN NUMBER,  func_id IN NUMBER, plsql_func IN VARCHAR);
PROCEDURE nsr_search_by_sql_internal(node_spec_id IN NUMBER,  func_id IN NUMBER, sql_query varchar2);
PROCEDURE path_search_by_plsql_internal(v_graph_id IN NUMBER, path_spec_id IN NUMBER, func_id IN NUMBER, plsql_func VARCHAR);
PROCEDURE path_search_by_sql_internal(v_graph_id IN NUMBER, path_spec_id IN NUMBER, func_id IN NUMBER,sql_query varchar2);
PROCEDURE port_search_by_plsql_internal(v_graph_id IN NUMBER, port_spec_id IN NUMBER, func_id IN NUMBER, plsql_func VARCHAR);
PROCEDURE port_search_by_sql_internal(v_graph_id IN NUMBER, port_spec_id IN NUMBER, func_id IN NUMBER, sql_query VARCHAR2);
PROCEDURE esr_search_by_sql_internal(edge_spec_id IN NUMBER,  func_id IN NUMBER, sql_query IN varchar2);
PROCEDURE esr_search_by_plsql_internal(edge_spec_id IN NUMBER, func_id IN NUMBER,plsql_func IN VARCHAR);
PROCEDURE nsr_group_by_sql_internal(node_spec_id IN NUMBER,  func_id IN NUMBER,sql_query IN varchar2);
PROCEDURE nsr_group_by_plsql_internal(node_spec_id IN NUMBER, func_id IN NUMBER,plsql_func IN VARCHAR);
PROCEDURE esr_group_by_sql_internal(v_graph_id IN NUMBER, edge_spec_id IN NUMBER, func_id IN NUMBER, sql_query IN varchar2);
PROCEDURE esr_group_by_plsql_internal(v_graph_id IN NUMBER, edge_spec_id IN NUMBER, func_id IN NUMBER, plsql_func IN VARCHAR);
PROCEDURE nss_selector_by_plsql_internal(v_graph_id IN NUMBER, selector_id IN NUMBER, plsql_func IN varchar2);
PROCEDURE nss_selector_by_sql_internal(v_graph_id IN NUMBER, selector_id IN NUMBER, sql_query IN varchar2);
PROCEDURE nfs_filter_by_plsql_internal(v_graph_id IN NUMBER, filter_id IN NUMBER,  plsql_func In varchar2, num_step IN int);
PROCEDURE nfs_filter_by_sql_internal(v_graph_id IN NUMBER, filter_id IN NUMBER, sql_query varchar2, num_step IN int);
PROCEDURE efs_filter_by_plsql_internal(v_graph_id IN NUMBER, filter_id IN NUMBER, plsql_func varchar2, num_step IN int);
PROCEDURE efs_filter_by_sql_internal(v_graph_id IN NUMBER, filter_id IN NUMBER, sql_query IN varchar2, num_step IN int);
PROCEDURE psr_calc_by_plsql_internal(v_graph_id IN NUMBER, spec_id IN NUMBER, param_spec_id IN NUMBER, func_id IN NUMBER, plsql_func varchar);
PROCEDURE psr_calc_by_sql_internal(v_graph_id IN NUMBER, spec_id IN NUMBER, param_spec_id IN NUMBER, func_id IN NUMBER, sql_query varchar2);
PROCEDURE ner_search_by_sql_internal(v_graph_id IN NUMBER, nes_spec_id  IN NUMBER, func_id  IN NUMBER, sql_query varchar2);
PROCEDURE ner_search_by_plsql_internal(v_graph_id IN NUMBER, nes_spec_id  IN NUMBER, func_id  IN NUMBER, plsql_func varchar);


PROCEDURE actlz_params_by_plsql_internal(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER, rule_id IN NUMBER, plsql_func varchar);
PROCEDURE actlz_param_by_plsql_internal(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER, rule_id IN NUMBER, param_id NUMBER, plsql_func varchar);
PROCEDURE actlz_param_by_spec_internal(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER, rule_id IN NUMBER, param_id NUMBER);
PROCEDURE actlz_graph_by_plsql_internal(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER, v_rule_id IN NUMBER, plsql_func varchar);
PROCEDURE actlz_graph_by_spec_internal(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER, rule_id IN NUMBER, spec_id NUMBER);


/*graph build functions*/
PROCEDURE create_nodes_by_spec(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, v_spec_id NUMBER);
FUNCTION create_edges_by_spec(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, v_spec_id NUMBER, v_start_id NUMBER) RETURN NUMBER;
PROCEDURE create_nested_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, v_spec_id NUMBER, v_graph_spec_id NUMBER);
PROCEDURE validate_paths(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER);
PROCEDURE create_paths_by_spec(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, v_spec_id NUMBER);
PROCEDURE create_ports_by_spec(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, v_spec_id NUMBER, v_graph_spec_id NUMBER);
PROCEDURE get_node_sources_by_edge(edge_spec_id IN NUMBER);
PROCEDURE add_to_filtered(element_type VARCHAR2, v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER);
PROCEDURE remove_from_filtered(element_type VARCHAR2, v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER);

PROCEDURE remove_element_by_id(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER, element_id  IN NUMBER);
PROCEDURE remove_element_by_source(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER, source_object_id  IN NUMBER,  spec_id  IN NUMBER);
PROCEDURE apply_removed_elements(v_graph_id IN NUMBER, v_request_id  IN NUMBER, v_rev_num  IN NUMBER);

END PKG_NGM_BLD_LIB;
/
