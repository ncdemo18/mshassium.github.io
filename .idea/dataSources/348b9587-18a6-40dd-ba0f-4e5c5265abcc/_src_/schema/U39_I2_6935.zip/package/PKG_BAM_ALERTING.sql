CREATE package PKG_BAM_ALERTING is

	procedure reschedule(varActivityDefinitionId in number, varAlertCaseId in number, varActivityInstanceId in number, varVerifyWhen in timestamp, varStatus in varchar2);

	procedure remove_triggers(varActivityDefinitionId in number);

end PKG_BAM_ALERTING;
/
