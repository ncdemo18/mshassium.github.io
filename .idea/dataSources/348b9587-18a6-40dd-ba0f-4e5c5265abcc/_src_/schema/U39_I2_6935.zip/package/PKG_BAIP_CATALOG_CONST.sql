CREATE package pkg_baip_catalog_const as

  PROVISIONING_STATUS_ATTR_ID   CONSTANT number(20) := 9135688263813316246;
  PROV_STATUS_SUCCESS_LV_ID     CONSTANT number(20) := 9141435688313637896; /*Synchronized*/
  PROV_STATUS_ERROR_LV_ID       CONSTANT number(20) := 9135688365513316313;
  PROV_STATUS_MODIFIED_LV_ID    CONSTANT number(20) := 9135688365513316315;
  PROV_STATUS_IN_PROGRESS_LV_ID CONSTANT number(20) := 9135688263813316267;
  PROV_STATUS_NEW_LV_ID         CONSTANT number(20) := 9135688263813316261;

  ------------------ Message Journal Constants  --------------------------------
  MESSAGE_OBJECT_TYPE_ID       CONSTANT number(20) := 9142041350013170949;
  MESSAGE_TYPE_ERROR_ID        CONSTANT number(20) := 9142041440113171212;
  MESSAGE_TYPE_INFO_ID         CONSTANT number(20) := 9142041440113171214;

  ------------------ Offering Price Details provisioning -----------------------
  OPD_PROV_STATUS_ATTR_ID   CONSTANT number(20) := 9140596834413528956;

  -------------------------------------------
  OPERATION_STATUS_ATTR_ID CONSTANT number(20) := 9136304130713181865;

  OPERATION_STATUS_NEW_LV_ID     CONSTANT number(20) := 9136304046013181570;
  OPERATION_IN_PROGRESS_LV_ID    CONSTANT number(20) := 9136304046013181571;
  OPERATION_COMPLETED_LV_ID      CONSTANT number(20) := 9136304046013181572;
  OPERATION_COMPL_WITH_ERR_LV_ID CONSTANT number(20) := 9136304046013181573;
  OPERATION_TERMINATED_LV_ID     CONSTANT number(20) := 9136304099613181664;
  OPERATION_TERMBY_TIMEOUT_LV_ID CONSTANT number(20) := 9136304099613181682;

  ----------------------------- CATALOGUE STATUSES ------------------------------
  CAT_STATUS_DESIGN_LV_ID       CONSTANT number(20) := 9136079954513608580;
  CAT_STATUS_TEST_LV_ID         CONSTANT number(20) := 9136079954513608581;
  CAT_STATUS_LIVE_LV_ID         CONSTANT number(20) := 9136079954513608582;
  CAT_STATUS_REJECTED_LV_ID     CONSTANT number(20) := 9136079954513608583;
  CAT_STATUS_SUPERSEDED_LV_ID   CONSTANT number(20) := 9136079954513608584;
  CAT_STATUS_DELETED_LV_ID      CONSTANT number(20) := 9136079954513608585;
  CAT_STATUS_PROV_IN_PROG_LV_ID CONSTANT number(20) := 9136079954513608586;
  CAT_OPERATION_STATUS          CONSTANT number(20) := 9136079954513608574;


/*******************************************************************************
                      Price Override
*******************************************************************************/

  type PriceOverride is record (
     init_obj_id                     varchar2(20)
    ,periodic_obj_id                 varchar2(20)
    ,term_obj_id                     varchar2(20)
    ,susp_obj_id                     varchar2(20)
    ,susp_recur_obj_id               varchar2(20)
    ,react_obj_id                    varchar2(20)
    ,session_id                      varchar2(20)
    ,product_id                      number(9)
    ,tariff_id                       number(9)
    ,start_dat                       date
    ,catalogue_change_id             number(9)
    ,end_dat                         date
    ,init_min_number                 number(18,0)
    ,init_min_mod_type_id            number(9)
    ,init_max_number                 number(18,0)
    ,init_max_mod_type_id            number(9)
    ,recur_min_number                number(18,0)
    ,recur_min_mod_type_id           number(9)
    ,recur_max_number                number(18,0)
    ,recur_max_mod_type_id           number(9)
    ,term_min_number                 number(18,0)
    ,term_min_mod_type_id            number(9)
    ,term_max_number                 number(18,0)
    ,term_max_mod_type_id            number(9)
    ,init_ov_rev_code_id             number(9)
    ,recur_ov_rev_code_id            number(9)
    ,term_ov_rev_code_id             number(9)
    ,susp_min_number                 number(18,0)
    ,susp_min_mod_type_id            number(9)
    ,susp_max_number                 number(18,0)
    ,susp_max_mod_type_id            number(9)
    ,susp_recur_min_number           number(18,0)
    ,susp_recur_min_mod_type_id      number(9)
    ,susp_recur_max_number           number(18,0)
    ,susp_recur_max_mod_type_id      number(9)
    ,react_min_number                number(18,0)
    ,react_min_mod_type_id           number(9)
    ,react_max_number                number(18,0)
    ,react_max_mod_type_id           number(9)
    ,susp_ov_rev_code_id             number(9)
    ,susp_recur_ov_rev_code_id       number(9)
    ,react_ov_rev_code_id            number(9)
  );


/*******************************************************************************
                      Tariff Element
*******************************************************************************/

  TYPE ProductPrice IS RECORD (
    opd_obj_id                      VARCHAR2(20)
    ,session_id                     VARCHAR2(20)

    ,product_id                     number(9)
    ,tariff_id                      number(9)
    ,start_dat                      date
    ,catalogue_change_id            number(9)
    ,end_dat                        date
    ,charge_period                  number(2)
    ,charge_period_units            varchar2(1)
    ,in_advance_boo                 varchar2(1)
    ,pro_rate_boo                   varchar2(1)
    ,refundable_boo                 varchar2(1)
    ,bonus_scheme_id                number(9)
    ,marginal_boo                   varchar2(1)
    ,init_revenue_code_id           number(9)
    ,recur_revenue_code_id          number(9)
    ,term_revenue_code_id           number(9)
    ,early_term_fix_rev_code_id     number(9)
    ,early_term_mult_rev_code_id    number(9)
    ,susp_rev_code_id               number(9)
    ,susp_recur_rev_code_id         number(9)
    ,react_rev_code_id              number(9)
    ,track_changes_boo              varchar2(1)
    ,early_term_pro_rate_boo        varchar2(1)
    ,init_rec_class_id              number(9)
    ,recur_rec_class_id             number(9)
    ,term_rec_class_id              number(9)
    ,non_use_rec_class_id           number(9)
    ,age_dependent_price_id         number(9)
    ,activation_rule                number(2)
    ,suspension_rule                number(2)
    ,reactivation_rule              number(2)
    ,termination_rule               number(2)
    ,init_rev_recog_class_id        number(9)
    ,recur_rev_recog_class_id       number(9)
    ,term_rev_recog_class_id        number(9)
    ,non_use_rev_recog_class_id     number(9)
    ,one_off_number                 number(18)
    ,one_off_mod_type_id            number(9)
    ,recurring_number               number(18)
    ,recurring_mod_type_id          number(9)
    ,termination_number             number(18)
    ,termination_mod_type_id        number(9)
    ,one_off_points                 number(9)
    ,recurring_points               number(9)
    ,event_point_rate               number(9)
    ,early_term_fix_mny             number(18)
    ,early_term_mult_mny            number(18)
    ,susp_number                    number(18)
    ,susp_mod_type_id               number(9)
    ,susp_recur_number              number(18)
    ,susp_recur_mod_type_id         number(9)
    ,react_number                   number(18)
    ,react_mod_type_id              number(9)
    ,default_prod_lifetime          number(9)
    ,default_prod_lifetime_unit     varchar2(1)
  );


/*******************************************************************************
                      Tariff Element Band
*******************************************************************************/

  type TariffElementBand is record (
     init_obj_id                      varchar2(20)
    ,periodic_obj_id                  varchar2(20)
    ,term_obj_id                      varchar2(20)
    ,susp_obj_id                      varchar2(20)
    ,susp_recur_obj_id                varchar2(20)
    ,react_obj_id                     varchar2(20)
    ,early_term_fix_obj_id            varchar2(20)
    ,early_term_mult_obj_id           varchar2(20)
    ,session_id                       varchar2(20)
    ,product_id                       number(9)
    ,tariff_id                        number(9)
    ,start_dat                        date
    ,catalogue_change_id              number(9)
    ,end_dat                          date
    ,charge_period                    number(2)
    ,charge_period_units              varchar2(1)
    ,in_advance_boo                   varchar2(1)
    ,pro_rate_boo                     varchar2(1)
    ,refundable_boo                   varchar2(1)
    ,bonus_scheme_id                  number(9)
    ,marginal_boo                     varchar2(1)
    ,init_revenue_code_id             number(9)
    ,recur_revenue_code_id            number(9)
    ,term_revenue_code_id             number(9)
    ,early_term_fix_rev_code_id       number(9)
    ,early_term_mult_rev_code_id      number(9)
    ,susp_rev_code_id                 number(9)
    ,susp_recur_rev_code_id           number(9)
    ,react_rev_code_id                number(9)
    ,track_changes_boo                varchar2(1)
    ,early_term_pro_rate_boo          varchar2(1)
    ,init_rec_class_id                number(9)
    ,recur_rec_class_id               number(9)
    ,term_rec_class_id                number(9)
    ,non_use_rec_class_id             number(9)
    ,age_dependent_price_id           number(9)
    ,activation_rule                  number(2)
    ,suspension_rule                  number(2)
    ,reactivation_rule                number(2)
    ,termination_rule                 number(2)
    ,init_rev_recog_class_id          number(9)
    ,recur_rev_recog_class_id         number(9)
    ,term_rev_recog_class_id          number(9)
    ,non_use_rev_recog_class_id       number(9)
    ,default_prod_lifetime            number(9)
    ,default_prod_lifetime_unit       varchar2(1)
    ,initiation_number                number(18,2)
    ,initiation_mod_type_id           number(9)
    ,periodic_number                  number(18,2)
    ,periodic_mod_type_id             number(9)
    ,termination_number               number(18,2)
    ,termination_mod_type_id          number(9)
    ,initiation_points                number(9)
    ,periodic_points                  number(9)
    ,event_point_rate                 number(9)
    ,early_term_fix_mny               number(9)
    ,early_term_mult_mny              number(9)
    ,susp_number                      number(18,2)
    ,susp_mod_type_id                 number(9)
    ,susp_recur_number                number(18,2)
    ,susp_recur_mod_type_id           number(9)
    ,react_number                     number(18,2)
    ,react_mod_type_id                number(9)
    ,product_quantity_threshold       number
  );

/*******************************************************************************
                      Composite Filter
*******************************************************************************/

 type CompositeFilter is record (
     composite_filter_id              number(9)
    ,filter_number                    number(9)
    ,catalogue_change_id              number(9)
    ,event_filter_id                  number(9)
 );

end;
/
