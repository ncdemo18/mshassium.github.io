CREATE PACKAGE pkg_history
AS
    C_ACTION_CREATE CONSTANT VARCHAR2(6)                := 'create';
    C_ACTION_DELETE CONSTANT VARCHAR2(6)                := 'delete';
    C_ACTION_MODIFY CONSTANT VARCHAR2(6)                := 'modify';
    C_ACTION_PARAM_CHANGE CONSTANT VARCHAR2(16)         := 'parametersChange';
    C_ACTION_COPY_OBJECT CONSTANT VARCHAR2(11)          := 'Copy Object';
    C_ACTION_MODIFY_GRANTS CONSTANT VARCHAR2(12)        := 'modifyGrants';
    C_ACTION_UNATHORIZED_ACCESS CONSTANT VARCHAR2(18)   := 'unauthorizedAccess';
    C_ACTION_UNKNOWN CONSTANT VARCHAR2(7)               := 'unknown';
    C_ACTION_LOGIN CONSTANT VARCHAR2(5)                 := 'login';
    C_ACTION_LOGIN_FAILED CONSTANT VARCHAR2(11)         := 'loginFailed';
    C_ACTION_LOGOUT CONSTANT VARCHAR2(6)                := 'logout';

    C_STRVALUE_SIZE CONSTANT INT                        := 4000;

    SUBTYPE t_string         IS VARCHAR(250);
    SUBTYPE t_objectid       IS nc_objects.object_id%type;
    SUBTYPE t_objecttypeid   IS nc_object_types.object_type_id%type;
    SUBTYPE t_attrid         IS nc_attributes.attr_id%type;
    SUBTYPE t_listvalueid    IS nc_list_values.list_value_id%type;
    SUBTYPE t_name           IS nc_objects.name%type;
    SUBTYPE t_strvalue       IS nc_params.value%type;
    SUBTYPE t_strvaluebig    IS VARCHAR(32000);
    SUBTYPE t_number         IS NUMBER;
    SUBTYPE t_message        IS nc_history.message%type;
    SUBTYPE t_date           IS nc_history.change_date%type;

    SUBTYPE t_history_rec    IS nc_history%rowtype;
    TYPE t_history_rec_table IS TABLE OF t_history_rec;

    TYPE t_event_data        IS RECORD
    (
-- CR Extend NC History API. Start. Added fields userId and userName in the
    	userId				 t_objectid,
    	userName             t_name,
-- CR Extend NC History API. End
        objectId             t_objectid,
        objectName           t_name,
        objectTypeId         t_objecttypeid,
        objectTypeName       t_name,
        objectClassId        t_objecttypeid,
        description          t_string,
        parentId             t_objectid,
        parentName           t_name,
        parentTypeId         t_objecttypeid,
        parentTypeName       t_name,
        parentClassId        t_objecttypeid
    );
    TYPE t_events_data_array IS TABLE OF t_event_data;
    TYPE t_events_cursor IS REF CURSOR RETURN t_event_data;


    TYPE t_mdfy_fld_event_data IS RECORD
    (
-- CR Extend NC History API. Start. Added fields userId and userName in the
    	userId				 t_objectid,
    	userName             t_name,
-- CR Extend NC History API. End
        objectId             t_objectid,
        objectName           t_name,
        objectTypeId         t_objecttypeid,
        objectTypeName       t_name,
        objectClassId        t_objecttypeid,
        description          t_string,
        parentId             t_objectid,
        parentName           t_name,
        parentTypeId         t_objecttypeid,
        parentTypeName       t_name,
        parentClassId        t_objecttypeid,
        fieldName            t_name,
        oldValue             t_name,
        newValue             t_name

    );
    TYPE t_mdfy_fld_event_data_array IS TABLE OF t_mdfy_fld_event_data;
    TYPE t_mdfy_fld_events_cursor IS REF CURSOR RETURN t_mdfy_fld_event_data;

    TYPE t_move_event_data   IS RECORD
    (
-- CR Extend NC History API. Start. Added fields userId and userName in the
    	userId				 t_objectid,
    	userName             t_name,
-- CR Extend NC History API. End
        objectId             t_objectid,
        objectName           t_name,
        objectTypeId         t_objecttypeid,
        objectTypeName       t_name,
        objectClassId        t_objecttypeid,
        description          t_string,
        oldParentId          t_objectid,
        oldParentName        t_name,
        oldParentTypeId      t_objecttypeid,
        oldParentTypeName    t_name,
        oldParentClassId     t_objecttypeid,
        newParentId          t_objectid,
        newParentName        t_name,
        newParentTypeId      t_objecttypeid,
        newParentTypeName    t_name,
        newParentClassId     t_objecttypeid
    );
    TYPE t_move_event_data_array IS TABLE OF t_move_event_data;
    TYPE t_move_events_cursor IS REF CURSOR RETURN t_move_event_data;

    TYPE t_param_change_event_data IS RECORD
    (
-- CR Extend NC History API. Start. Added fields userId and userName in the
    	userId				 t_objectid,
    	userName             t_name,
-- CR Extend NC History API. End
        objectId             t_objectid,
        objectName           t_name,
        objectTypeId         t_objecttypeid,
        objectTypeName       t_name,
        objectClassId        t_objecttypeid,
        description          t_string,

        attrId               t_attrid,
        attrName             t_name,
        oldValue             t_strvaluebig,
        newValue             t_strvaluebig,
        oldDate              t_date,
        newDate              t_date,
        oldId                t_listvalueid,
        newId                t_listvalueid,
        oldValueName         t_name,
        newValueName         t_name
    );
    TYPE t_prm_chng_event_data_array IS TABLE OF t_param_change_event_data;
    TYPE t_param_change_events_cursor IS REF CURSOR RETURN t_param_change_event_data;


    PROCEDURE enable;

    PROCEDURE disable;

    FUNCTION is_history_enabled RETURN t_number;

--write single  event
    FUNCTION fire_create_event(
        userId                IN t_objectid,
        userName              IN t_name,
        changeDate            IN t_date,

        taskId                IN t_objectid,
        subSystemId           IN integer,
        contextId             IN t_number,
        contextDesc           IN t_string,
        orderNumber           IN nc_history.order_number%type,

        objectId              IN t_objectid,
        objectName            IN t_name,
        objectTypeId          IN t_objecttypeid,
        objectTypeName        IN t_name,
        objectClassId         IN t_objecttypeid,
        description           IN t_string) RETURN t_number;

    FUNCTION fire_create_event(
        subAction             IN t_string,
        userId                IN t_objectid,
        userName              IN t_name,
        changeDate            IN t_date,

        taskId                IN t_objectid,
        subSystemId           IN integer,
        contextId             IN t_number,
        contextDesc           IN t_string,
        orderNumber           IN nc_history.order_number%type,

        parentObjectId        IN t_objectid,
        parentObjectName      IN t_name,
        parentObjectTypeId    IN t_objecttypeid,
        parentObjectTypeName  IN t_name,
        parentObjectClassId   IN t_objecttypeid,
        description           IN t_string,

        objectId              IN t_objectid,
        objectName            IN t_name,
        objectTypeId          IN t_objecttypeid,
        objectTypeName        IN t_name,
        objectClassId         IN t_objecttypeid,
        objectRole            IN t_string) RETURN t_number;

    FUNCTION fire_modify_event(
        subAction             IN t_string,
        userId                IN t_objectid,
        userName              IN t_name,
        changeDate            IN t_date,

        taskId                IN t_objectid,
        subSystemId           IN integer,
        contextId             IN t_number,
        contextDesc           IN t_string,
        orderNumber           IN nc_history.order_number%type,

        mainObjectId          IN t_objectid,
        mainObjectName        IN t_name,
        mainObjectTypeId      IN t_objecttypeid,
        mainObjectTypeName    IN t_name,
        mainObjectClassId     IN t_objecttypeid,
        description           IN t_string,

        corrObject1Id         IN t_objectid,
        corrObject1Name       IN t_name,
        corrObject1TypeId     IN t_objecttypeid,
        corrObject1TypeName   IN t_name,
        corrObject1ClassId    IN t_objecttypeid,
        corrObject1Role       IN t_name,

        corrObject2Id         IN t_objectid,
        corrObject2Name       IN t_name,
        corrObject2TypeId     IN t_objecttypeid,
        corrObject2TypeName   IN t_name,
        corrObject2ClassId    IN t_objecttypeid,
        corrObject2Role       IN t_name,

        fieldName             IN t_name,
        oldFieldValue         IN t_name,
        newFieldValue         IN t_name) RETURN t_number;

    FUNCTION fire_modify_object_event(
        userId                IN t_objectid,
        userName              IN t_name,
        changeDate            IN t_date,

        taskId                IN t_objectid,
        subSystemId           IN integer,
        contextId             IN t_number,
        contextDesc           IN t_string,
        orderNumber           IN nc_history.order_number%type,

        mainObjectId          IN t_objectid,
        mainObjectName        IN t_name,
        mainObjectTypeId      IN t_objecttypeid,
        mainObjectTypeName    IN t_name,
        mainObjectClassId     IN t_objecttypeid,
        description           IN t_string) RETURN t_number;


    FUNCTION fire_delete_event(
        subAction             IN t_string,
        userId                IN t_objectid,
        userName              IN t_name,
        changeDate            IN t_date,

        taskId                IN t_objectid,
        subSystemId           IN integer,
        contextId             IN t_number,
        contextDesc           IN t_string,
        orderNumber           IN nc_history.order_number%type,

        parentObjectId        IN t_objectid,
        parentObjectName      IN t_name,
        parentObjectTypeId    IN t_objecttypeid,
        parentObjectTypeName  IN t_name,
        parentObjectClassId   IN t_objecttypeid,
        description           IN t_string,

        objectId              IN t_objectid,
        objectName            IN t_name,
        objectTypeId          IN t_objecttypeid,
        objectTypeName        IN t_name,
        objectClassId         IN t_objecttypeid,
        objectRole            IN t_string) RETURN t_number;

    FUNCTION fire_param_change_event(
        subAction             IN t_string,
        userId                IN t_objectid,
        userName              IN t_name,
        changeDate            IN t_date,

        taskId                IN t_objectid,
        subSystemId           IN integer,
        contextId             IN t_number,
        contextDesc           IN t_string,
        orderNumber           IN t_number,

        objectId              IN t_objectid,
        objectName            IN t_name,
        objectTypeId          IN t_objecttypeid,
        objectTypeName        IN t_name,
        objectClassId         IN t_objecttypeid,
        description           IN t_string,

        attributeId           IN t_attrid,
        attributeName         IN t_name,
        oldValue              IN t_strvaluebig, --t_strvalue,
        newValue              IN t_strvaluebig, --t_strvalue,
        oldDate               IN t_date,
        newDate               IN t_date,
        oldListValueId        IN t_listvalueid,
        newListValueId        IN t_listvalueid,
        oldValueName          IN t_name,
        newValueName          IN t_name) return t_number;

    /*
     * Family of functions which use DynamicSQL to processing batch of event data
     *
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *  	userId,
     *  	userName,
     *  	objectId,
     *  	objectName,
     *  	objectTypeId,
     *  	objectTypeName,
     *  	objectClassId,
     *  	attrId,
     *  	oldParamValue,
     *  	newParamValue,
     *  	oldDate,
     *  	newDate,
     *  	message
     * 	 from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *  	objectId,
     *  	objectName,
     *  	objectTypeId,
     *  	objectTypeName,
     *  	objectClassId,
     *  	attrId,
     *  	oldParamValue,
     *  	newParamValue,
     *  	oldDate,
     *  	newDate,
     *  	message
     *   from ...
     */
    FUNCTION fire_bulk_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) return t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *  	userId,
     *  	userName,
     *  	objectId,
     *  	objectName,
     *  	objectTypeId,
     *  	objectTypeName,
     *  	objectClassId,
     *  	attrId,
     *  	oldParamValue,
     *  	newParamValue,
     *  	oldDate,
     *  	newDate,
     *      oldValueName,
     *      newValueName,
     *  	message
     * 	 from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *  	objectId,
     *  	objectName,
     *  	objectTypeId,
     *  	objectTypeName,
     *  	objectClassId,
     *  	attrId,
     *  	oldParamValue,
     *  	newParamValue,
     *  	oldDate,
     *  	newDate,
     *      oldValueName,
     *      newValueName,
     *  	message
     *   from ...
     */
    FUNCTION fire_bulk_events_extended(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) return t_number;


    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     */
    FUNCTION fire_bulk_create_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     */
    FUNCTION fire_bulk_addchild_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     */
    FUNCTION fire_bulk_deletechild_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;


    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     */
    FUNCTION fire_bulk_addgrpmbr_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     */
    FUNCTION fire_bulk_deletegrpmbr_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       description,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       fieldName,
     *       oldValue,
     *       newValue
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       description,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       fieldName,
     *       oldValue,
     *       newValue
     *   from ...
     */
    FUNCTION fire_bulk_modify_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       description,
     *       oldParentId,
     *       oldParentName,
     *       oldParentTypeId,
     *       oldParentTypeName,
     *       oldParentClassId,
     *       newParentId,
     *       newParentName,
     *       newParentTypeId,
     *       newParentTypeName,
     *       newParentClassId
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       description,
     *       oldParentId,
     *       oldParentName,
     *       oldParentTypeId,
     *       oldParentTypeName,
     *       oldParentClassId,
     *       newParentId,
     *       newParentName,
     *       newParentTypeId,
     *       newParentTypeName,
     *       newParentClassId
     *   from ...
     */
    FUNCTION fire_bulk_move_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     */
    FUNCTION fire_bulk_occupy_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *       userId,
     *       userName,
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId,
     *       description
     *   from ...
     */
    FUNCTION fire_bulk_free_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *  	 userId,
     *       userName,
     * 	     objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       parentId,
     *       parentName,
     *       parentTypeId,
     *       parentTypeName,
     *       parentClassId
     *   from ...
     */
    FUNCTION fire_bulk_delete_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * WARNING!
     * There are two template queries depending on arguments.
     *
     * Template query for arguments userId AND userName are null
     *   select
     *  	 userId,
     *   	 userName,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       description,
     *       attrId,
     *       attrName,
     *       oldValue,
     *       newValue,
     *       oldDate,
     *       newDate,
     *       oldId,
     *       newId,
     *       oldValueName,
     *       newValueName
     *   from ...
     *
     * Template query if one of userId OR userName is not null
     *   select
     *       objectId,
     *       objectName,
     *       objectTypeId,
     *       objectTypeName,
     *       objectClassId,
     *       description,
     *       attrId,
     *       attrName,
     *       oldValue,
     *       newValue,
     *       oldDate,
     *       newDate,
     *       oldId,
     *       newId,
     *       oldValueName,
     *       newValueName
     *   from ...
     */
    FUNCTION fire_bulk_param_change_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        selectQuery IN varchar2) RETURN t_number;

    /*
     * Family of functions which use cursors to processing batch of event data
     */
    FUNCTION fire_bulk_create_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_addchild_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_deletechild_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_addgrpmbr_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_deletegrpmbr_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_modify_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_mdfy_fld_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_move_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_move_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_occupy_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_free_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_delete_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_events_cursor) RETURN t_number;

    FUNCTION fire_bulk_param_change_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventCursor IN t_param_change_events_cursor) RETURN t_number;

    /*
     * Family of functions which use arrays to processing batch of event data
     */
    FUNCTION fire_bulk_create_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_addchild_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_deletechild_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_addgrpmbr_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_deletegrpmbr_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_modify_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_mdfy_fld_event_data) RETURN t_number;

    FUNCTION fire_bulk_move_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_move_event_data) RETURN t_number;

    FUNCTION fire_bulk_occupy_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_free_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_delete_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_event_data) RETURN t_number;

    FUNCTION fire_bulk_param_change_events(
        userId      IN t_objectid,
        userName    IN t_name,
        changeDate  IN t_date,

        taskId      IN t_objectid,
        subSystemId IN integer,
        contextId   IN t_number,
        contextDesc IN t_string,
        orderOffset IN t_number,

        eventArray  IN array_of_prm_chng_event_data) RETURN t_number;


    /*
     * Additional functions
     */
    FUNCTION makeEventMessageOnCreate(
        action t_name,
        subAction t_name,
        userId t_strvalue,
        changeDate t_strvalue,
        taskId t_strvalue,

        objectId t_objectid,
        objectName t_name,
        objectTypeId t_objecttypeid,
        objectTypeName t_name,
        objectClassId t_objecttypeid,
        description t_string,

        parentId t_objectid,
        parentName t_name,
        parentTypeId t_objecttypeid,
        parentTypeName t_name,
        parentClassId t_objecttypeid) RETURN t_message;

    FUNCTION makeEventMessageOnDelete(
        action t_name,
        subAction t_name,
        userId t_strvalue,
        changeDate t_strvalue,
        taskId t_strvalue,

        objectId t_objectid,
        objectName t_name,
        objectTypeId t_objecttypeid,
        objectTypeName t_name,
        objectClassId t_objecttypeid,
        description t_string,

        parentId t_objectid,
        parentName t_name,
        parentTypeId t_objecttypeid,
        parentTypeName t_name,
        parentClassId t_objecttypeid) RETURN t_message;

    FUNCTION makeEventMessageOnOccupy(
        action t_name,
        subAction t_name,
        userId t_strvalue,
        changeDate t_strvalue,
        taskId t_strvalue,

        objectId t_objectid,
        objectName t_name,
        objectTypeId t_objecttypeid,
        objectTypeName t_name,
        objectClassId t_objecttypeid,
        description t_string,

        parentId t_objectid,
        parentName t_name,
        parentTypeId t_objecttypeid,
        parentTypeName t_name,
        parentClassId t_objecttypeid) RETURN t_message;

    FUNCTION makeEventMessageOnPrmChng(
        action t_name,
        subAction t_name,
        userId t_strvalue,
        changeDate t_strvalue,
        taskId t_strvalue,

        objectId t_objectid,
        objectName t_name,
        objectTypeId t_objecttypeid,
        objectTypeName t_name,
        objectClassId t_objecttypeid,
        description t_string,

        attrId t_attrid,
        attrName t_name,
        oldValue t_strvaluebig,
        newValue t_strvaluebig,
        oldDate t_date,
        newDate t_date,
        oldId t_listvalueid,
        newId t_listvalueid,
        oldValueName t_name,
        newValueName t_name) RETURN t_message;

    FUNCTION makeEventMessageOnMove(
        action t_name,
        subAction t_name,
        userId t_strvalue,
        changeDate t_strvalue,
        taskId t_strvalue,

        objectId t_objectid,
        objectName t_name,
        objectTypeId t_objecttypeid,
        objectTypeName t_name,
        objectClassId t_objecttypeid,
        description t_string,

        oldParentId t_objectid,
        oldParentName t_name,
        oldParentTypeId t_objecttypeid,
        oldParentTypeName t_name,
        oldParentClassId t_objecttypeid,

        newParentId t_objectid,
        newParentName t_name,
        newParentTypeId t_objecttypeid,
        newParentTypeName t_name,
        newParentClassId t_objecttypeid) RETURN t_message;

    FUNCTION makeEventMessageOnModify(
        action t_name,
        subAction t_name,
        userId t_strvalue,
        changeDate t_strvalue,
        taskId t_strvalue,

        objectId t_objectid,
        objectName t_name,
        objectTypeId t_objecttypeid,
        objectTypeName t_name,
        objectClassId t_objecttypeid,
        description t_string,

        parentId t_objectid,
        parentName t_name,
        parentTypeId t_objecttypeid,
        parentTypeName t_name,
        parentClassId t_objecttypeid,

        fieldName t_string,
        oldValue t_string,
        newValue t_string) RETURN t_message;

    PROCEDURE resetCntr(cntrValue t_number default 0);

    FUNCTION nextCntrValue RETURN t_number;

    FUNCTION getCntrValue RETURN t_number;

    E_NOT_IMPLEMENTED EXCEPTION;

    --removes all recent which older than SYSDATE - retention time or if collection_id missing
    PROCEDURE CLEAN_RECENT_DATA;

END;
/
