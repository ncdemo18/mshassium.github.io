CREATE package CAMPAIGN_CHUNKS is

  -- Author  : YUST0313
  -- Created : 25.09.2015 13:20:16
  -- Purpose :

  -- Public function and procedure declarations
  procedure  set_and_get_status(

                              pcampaign        number,
                              ptask            varchar2,
                              pparty           number,
                              predeliveryLimit number,
                              pstatus          number,
                              pstartObj        number,
															pprocess_status out number,
															info out varchar2) ;

end CAMPAIGN_CHUNKS;
/
