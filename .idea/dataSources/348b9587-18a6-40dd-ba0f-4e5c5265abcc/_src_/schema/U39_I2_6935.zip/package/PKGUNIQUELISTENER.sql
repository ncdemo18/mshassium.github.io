CREATE PACKAGE pkgUniqueListener
AS

	TYPE_OBJECTTYPE CONSTANT VARCHAR2(10) := 'objecttype';
	TYPE_CLASS CONSTANT VARCHAR2(5) := 'class';

	FUNCTION getSiteUniqueCount(
		objectTypeID IN nc_object_types.object_type_id%TYPE,
		objectID IN nc_objects.object_id%TYPE,
		subObjectTypeID IN nc_object_types.object_type_id%TYPE,
		subObjectID IN nc_objects.object_id%TYPE,
		subName IN nc_objects.name%TYPE,
		mainObjectTypeID IN nc_object_types.object_type_id%TYPE,
		typeClass IN VARCHAR2,
		casesensitive      IN   INTEGER
	) RETURN NUMBER;

	FUNCTION getSimpleSiteUniqueCount(
		objectID IN nc_objects.object_id%TYPE,
		subObjectID IN nc_objects.object_id%TYPE,
		subName IN nc_objects.name%TYPE,
		mainObjectTypeID IN nc_object_types.object_type_id%TYPE,
		typeClass IN VARCHAR2,
		casesensitive      IN   INTEGER
	) RETURN NUMBER;

	FUNCTION getProjectUniqueCount(
		projectID IN nc_objects.project_id%TYPE,
		subName IN nc_objects.name%TYPE,
		mainObjectTypeID IN nc_object_types.object_type_id%TYPE,
		typeClass IN VARCHAR2,
    objectid           IN   nc_objects.object_id%TYPE,
    casesensitive      IN   INTEGER
	) RETURN NUMBER;

	FUNCTION getSystemUniqueCount(
		subName IN nc_objects.name%TYPE,
		mainObjectTypeID IN nc_object_types.object_type_id%TYPE,
		typeClass IN VARCHAR2,
		objectid IN   nc_objects.object_id%TYPE,
		casesensitive      IN   INTEGER
	) RETURN NUMBER;

	PROCEDURE clearUniqueParams(
		objID IN nc_objects.object_id%TYPE
	);

    PROCEDURE clearUniqueParams(
		objID IN nc_objects.object_id%TYPE,
        isHierarchicly IN NUMBER
	);

    PROCEDURE clearUniqueParams(
        objID             IN nc_objects.object_id%TYPE,
        isHierarchicly    IN NUMBER,
        is_del_duplicates IN NUMBER
    );

  	FUNCTION getContainer(
      objID IN nc_objects.object_id%TYPE,
      attrID IN nc_attributes.attr_id%TYPE
	) RETURN nc_objects.object_id%TYPE;

	FUNCTION getContainer(
      objID IN nc_objects.object_id%TYPE,
      attrID IN nc_attributes.attr_id%TYPE,
	  containerID IN nc_object_types.object_type_id%TYPE
	) RETURN nc_objects.object_id%TYPE;

	FUNCTION getContainers(
      objID IN nc_objects.object_id%TYPE,
      attrID IN nc_attributes.attr_id%TYPE
	) RETURN arrayofnumbers;

	FUNCTION issite(objid IN nc_objects.object_id%TYPE,   attrid IN nc_attributes.attr_id%TYPE) RETURN NUMBER;

END pkgUniqueListener;
/
