CREATE package pkg_cmt_patch_install is
  procedure merge_nc_attr_schemes_proto(
    p_attr_schema_id in NUMERIC,
    p_name in VARCHAR2);
  procedure merge_nc_object_types_proto(
    p_object_type_id in NUMERIC,
    p_name in VARCHAR2);
  procedure merge_nc_objects_proto(
    p_object_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_object_class_id in NUMERIC,
    p_name in VARCHAR2);
  procedure merge_nc_po_tasks_proto(
    p_task_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_container_id in NUMERIC);
  procedure merge_nc_attr_groups(
    p_attr_group_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_name in VARCHAR2,
    p_show_order in NUMERIC,
    p_attr_access_type in NUMERIC,
    p_flags in NUMERIC,
    p_description in VARCHAR2,
    p_subgroup in VARCHAR2,
    p_alias in VARCHAR2,
    p_params in VARCHAR2);
  procedure merge_nc_attr_object_types(
    p_attr_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_isdisplayed in NUMERIC,
    p_required in NUMERIC,
    p_options in NUMERIC,
    p_default_value in VARCHAR2,
    p_flags in NUMERIC);
  procedure merge_nc_attr_schemes(
    p_attr_schema_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_name in VARCHAR2,
    p_attr_access_type in NUMERIC,
    p_issystem in NUMERIC,
    p_description in VARCHAR2,
    p_flags in NUMERIC,
    p_internal_name in VARCHAR2);
  procedure merge_nc_attr_type_defs(
    p_attr_type_def_id in NUMERIC,
    p_attr_type_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_name in VARCHAR2,
    p_dtd in CLOB,
    p_attr_access_type in NUMERIC,
    p_object_ref_attr_id in NUMERIC,
    p_attr_ref_id in NUMERIC,
    p_flags in NUMERIC);
  procedure merge_nc_attributes(
    p_attr_id in NUMERIC,
    p_attr_type_id in NUMERIC,
    p_attr_type_def_id in NUMERIC,
    p_attr_group_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_name in VARCHAR2,
    p_attr_access_type in NUMERIC,
    p_ismultiple in NUMERIC,
    p_isextgenerated in NUMERIC,
    p_isextstored in NUMERIC,
    p_adaptername in VARCHAR2,
    p_params in VARCHAR2,
    p_unique_level in NUMERIC,
    p_show_order in NUMERIC,
    p_show_history in NUMERIC,
    p_issearchable in NUMERIC,
    p_mask in VARCHAR2,
    p_def_value in VARCHAR2,
    p_flags in NUMERIC,
    p_description in VARCHAR2,
    p_properties in VARCHAR2,
    p_rules in NUMERIC,
    p_tooltip in VARCHAR2,
    p_av_adapter_name in VARCHAR2,
    p_av_adapter_properties in VARCHAR2,
    p_internal_name in VARCHAR2);
  procedure merge_nc_channelization_rules(
    p_src_interface in NUMERIC,
    p_dst_interface in NUMERIC,
    p_channels_number in NUMERIC,
    p_kind in NUMERIC,
    p_template_id in NUMERIC,
    p_name in VARCHAR2);
  procedure merge_nc_cmt_package_elements(
    p_entity_id in VARCHAR2,
    p_package_name in VARCHAR2,
    p_entity_type_id in VARCHAR2);
  procedure merge_nc_cmt_package_entities(
    p_entity_id in VARCHAR2,
    p_package_name in VARCHAR2,
    p_entity_type_id in VARCHAR2,
    p_entity_group in VARCHAR2);
  procedure merge_nc_cmt_packages(
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_config in CLOB);
  procedure merge_nc_devplug(
    p_device_id in NUMERIC,
    p_plugin_id in NUMERIC,
    p_slots_number in NUMERIC,
    p_properties in VARCHAR2);
  procedure merge_nc_directory(
    p_key in VARCHAR2,
    p_value in VARCHAR2,
    p_node_name in VARCHAR2);
  procedure merge_nc_event_listeners(
    p_listener_id in NUMERIC,
    p_action_id in NUMERIC,
    p_subaction_id in NUMERIC,
    p_object_class_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_object_id in NUMERIC,
    p_listener in VARCHAR2,
    p_priority in NUMERIC,
    p_attr_id in NUMERIC,
    p_is_active in NUMERIC,
    p_listener_name in VARCHAR2,
    p_description in VARCHAR2,
    p_category in VARCHAR2,
    p_properties in CLOB);
  procedure merge_nc_generic_artefacts(
    p_nc_entity_id in NUMERIC,
    p_type in VARCHAR2,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure merge_nc_grants(
    p_object_id in NUMERIC,
    p_user_id in NUMERIC,
    p_grants in NUMERIC,
    p_isinheritable in NUMERIC);
  procedure merge_nc_list_values(
    p_list_value_id in NUMERIC,
    p_attr_type_def_id in NUMERIC,
    p_value in VARCHAR2,
    p_show_order in NUMERIC,
    p_additional in VARCHAR2,
    p_flags in NUMERIC);
  procedure merge_nc_meta_references(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC,
    p_ref_attr_id in NUMERIC,
    p_ref_object_type_id in NUMERIC,
    p_ref_attr_schema_id in NUMERIC,
    p_show_order in NUMERIC);
  procedure merge_nc_nls_attr_groups(
    p_attr_group_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_subgroup in VARCHAR2);
  procedure merge_nc_nls_attr_schemes(
    p_attr_schema_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure merge_nc_nls_attributes(
    p_attr_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_tooltip in VARCHAR2);
  procedure merge_nc_nls_list_values(
    p_list_value_id in NUMERIC,
    p_language_id in NUMERIC,
    p_value in VARCHAR2,
    p_list_value_group in VARCHAR2);
  procedure merge_nc_nls_object_types(
    p_object_type_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure merge_nc_nls_objects(
    p_object_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure merge_nc_nls_resources(
    p_resource_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure merge_nc_object_types(
    p_object_type_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_picture_id in NUMERIC,
    p_icon_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_alias in VARCHAR2,
    p_isclass in NUMERIC,
    p_issystem in NUMERIC,
    p_issearchable in NUMERIC,
    p_isabstract in NUMERIC,
    p_flags in NUMERIC,
    p_properties in VARCHAR2,
    p_internal_name in VARCHAR2);
  procedure merge_nc_objects(
    p_object_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_object_class_id in NUMERIC,
    p_project_id in NUMERIC,
    p_picture_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_attr_schema_id in NUMERIC,
    p_order_number in NUMERIC,
    p_source_object_id in NUMERIC);
  procedure merge_nc_params(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC,
    p_attr_access_type in NUMERIC,
    p_value in VARCHAR2,
    p_data in CLOB,
    p_list_value_id in NUMERIC,
    p_show_order in NUMERIC,
    p_date_value in DATE,
    p_priority in NUMERIC);
  procedure merge_nc_pictures(
    p_picture_id in NUMERIC,
    p_name in VARCHAR2,
    p_url in VARCHAR2,
    p_width in NUMERIC,
    p_height in NUMERIC);
  procedure merge_nc_po_actions(
    p_action_id in NUMERIC,
    p_task_id in NUMERIC);
  procedure merge_nc_po_task_dependencies(
    p_to_task_id in NUMERIC,
    p_from_task_id in NUMERIC);
  procedure merge_nc_po_tasks(
    p_task_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_container_id in NUMERIC);
  procedure merge_nc_references(
    p_attr_id in NUMERIC,
    p_reference in NUMERIC,
    p_object_id in NUMERIC,
    p_show_order in NUMERIC,
    p_priority in NUMERIC,
    p_attr_access_type in NUMERIC);
  procedure merge_nc_resources(
    p_resource_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure merge_nc_uri_resources(
    p_uri in VARCHAR2,
    p_resource_id in NUMERIC);
  procedure merge_nc_view(
    p_object_id in NUMERIC,
    p_component_id in VARCHAR2,
    p_attr_id in NUMERIC,
    p_mask in NUMERIC,
    p_priority in NUMERIC,
    p_order_number in NUMERIC,
    p_object_type_id in NUMERIC);
  procedure merge_qrtz_blob_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_blob_data in BLOB);
  procedure merge_qrtz_cron_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_cron_expression in VARCHAR2,
    p_time_zone_id in VARCHAR2);
  procedure merge_qrtz_simple_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_repeat_count in NUMERIC,
    p_repeat_interval in NUMERIC,
    p_times_triggered in NUMERIC);
  procedure merge_qrtz_trigger_listeners(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_trigger_listener in VARCHAR2);
  procedure merge_qrtz_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_job_name in NUMERIC,
    p_job_group in VARCHAR2,
    p_is_volatile in VARCHAR2,
    p_description in VARCHAR2,
    p_next_fire_time in NUMERIC,
    p_prev_fire_time in NUMERIC,
    p_trigger_state in VARCHAR2,
    p_trigger_type in VARCHAR2,
    p_start_time in NUMERIC,
    p_end_time in NUMERIC,
    p_calendar_name in VARCHAR2,
    p_misfire_instr in NUMERIC,
    p_job_data in BLOB,
    p_priority in NUMERIC);
  procedure insert_nc_attr_groups(
    p_attr_group_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_name in VARCHAR2,
    p_show_order in NUMERIC,
    p_attr_access_type in NUMERIC,
    p_flags in NUMERIC,
    p_description in VARCHAR2,
    p_subgroup in VARCHAR2,
    p_alias in VARCHAR2,
    p_params in VARCHAR2);
  procedure insert_nc_attr_object_types(
    p_attr_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_isdisplayed in NUMERIC,
    p_required in NUMERIC,
    p_options in NUMERIC,
    p_default_value in VARCHAR2,
    p_flags in NUMERIC);
  procedure insert_nc_attr_schemes(
    p_attr_schema_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_name in VARCHAR2,
    p_attr_access_type in NUMERIC,
    p_issystem in NUMERIC,
    p_description in VARCHAR2,
    p_flags in NUMERIC,
    p_internal_name in VARCHAR2);
  procedure insert_nc_attr_type_defs(
    p_attr_type_def_id in NUMERIC,
    p_attr_type_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_name in VARCHAR2,
    p_dtd in CLOB,
    p_attr_access_type in NUMERIC,
    p_object_ref_attr_id in NUMERIC,
    p_attr_ref_id in NUMERIC,
    p_flags in NUMERIC);
  procedure insert_nc_attributes(
    p_attr_id in NUMERIC,
    p_attr_type_id in NUMERIC,
    p_attr_type_def_id in NUMERIC,
    p_attr_group_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_name in VARCHAR2,
    p_attr_access_type in NUMERIC,
    p_ismultiple in NUMERIC,
    p_isextgenerated in NUMERIC,
    p_isextstored in NUMERIC,
    p_adaptername in VARCHAR2,
    p_params in VARCHAR2,
    p_unique_level in NUMERIC,
    p_show_order in NUMERIC,
    p_show_history in NUMERIC,
    p_issearchable in NUMERIC,
    p_mask in VARCHAR2,
    p_def_value in VARCHAR2,
    p_flags in NUMERIC,
    p_description in VARCHAR2,
    p_properties in VARCHAR2,
    p_rules in NUMERIC,
    p_tooltip in VARCHAR2,
    p_av_adapter_name in VARCHAR2,
    p_av_adapter_properties in VARCHAR2,
    p_internal_name in VARCHAR2);
  procedure insert_nc_channelization_rules(
    p_src_interface in NUMERIC,
    p_dst_interface in NUMERIC,
    p_channels_number in NUMERIC,
    p_kind in NUMERIC,
    p_template_id in NUMERIC,
    p_name in VARCHAR2);
  procedure insert_nc_cmt_package_elements(
    p_entity_id in VARCHAR2,
    p_package_name in VARCHAR2,
    p_entity_type_id in VARCHAR2);
  procedure insert_nc_cmt_package_entities(
    p_entity_id in VARCHAR2,
    p_package_name in VARCHAR2,
    p_entity_type_id in VARCHAR2,
    p_entity_group in VARCHAR2);
  procedure insert_nc_cmt_packages(
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_config in CLOB);
  procedure insert_nc_devplug(
    p_device_id in NUMERIC,
    p_plugin_id in NUMERIC,
    p_slots_number in NUMERIC,
    p_properties in VARCHAR2);
  procedure insert_nc_directory(
    p_key in VARCHAR2,
    p_value in VARCHAR2,
    p_node_name in VARCHAR2);
  procedure insert_nc_event_listeners(
    p_listener_id in NUMERIC,
    p_action_id in NUMERIC,
    p_subaction_id in NUMERIC,
    p_object_class_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_object_id in NUMERIC,
    p_listener in VARCHAR2,
    p_priority in NUMERIC,
    p_attr_id in NUMERIC,
    p_is_active in NUMERIC,
    p_listener_name in VARCHAR2,
    p_description in VARCHAR2,
    p_category in VARCHAR2,
    p_properties in CLOB);
  procedure insert_nc_generic_artefacts(
    p_nc_entity_id in NUMERIC,
    p_type in VARCHAR2,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure insert_nc_grants(
    p_object_id in NUMERIC,
    p_user_id in NUMERIC,
    p_grants in NUMERIC,
    p_isinheritable in NUMERIC);
  procedure insert_nc_list_values(
    p_list_value_id in NUMERIC,
    p_attr_type_def_id in NUMERIC,
    p_value in VARCHAR2,
    p_show_order in NUMERIC,
    p_additional in VARCHAR2,
    p_flags in NUMERIC);
  procedure insert_nc_meta_references(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC,
    p_ref_attr_id in NUMERIC,
    p_ref_object_type_id in NUMERIC,
    p_ref_attr_schema_id in NUMERIC,
    p_show_order in NUMERIC);
  procedure insert_nc_nls_attr_groups(
    p_attr_group_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_subgroup in VARCHAR2);
  procedure insert_nc_nls_attr_schemes(
    p_attr_schema_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure insert_nc_nls_attributes(
    p_attr_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_tooltip in VARCHAR2);
  procedure insert_nc_nls_list_values(
    p_list_value_id in NUMERIC,
    p_language_id in NUMERIC,
    p_value in VARCHAR2,
    p_list_value_group in VARCHAR2);
  procedure insert_nc_nls_object_types(
    p_object_type_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure insert_nc_nls_objects(
    p_object_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure insert_nc_nls_resources(
    p_resource_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure insert_nc_object_types(
    p_object_type_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_picture_id in NUMERIC,
    p_icon_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_alias in VARCHAR2,
    p_isclass in NUMERIC,
    p_issystem in NUMERIC,
    p_issearchable in NUMERIC,
    p_isabstract in NUMERIC,
    p_flags in NUMERIC,
    p_properties in VARCHAR2,
    p_internal_name in VARCHAR2);
  procedure insert_nc_objects(
    p_object_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_object_class_id in NUMERIC,
    p_project_id in NUMERIC,
    p_picture_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_attr_schema_id in NUMERIC,
    p_order_number in NUMERIC,
    p_source_object_id in NUMERIC);
  procedure insert_nc_params(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC,
    p_attr_access_type in NUMERIC,
    p_value in VARCHAR2,
    p_data in CLOB,
    p_list_value_id in NUMERIC,
    p_show_order in NUMERIC,
    p_date_value in DATE,
    p_priority in NUMERIC);
  procedure insert_nc_pictures(
    p_picture_id in NUMERIC,
    p_name in VARCHAR2,
    p_url in VARCHAR2,
    p_width in NUMERIC,
    p_height in NUMERIC);
  procedure insert_nc_po_actions(
    p_action_id in NUMERIC,
    p_task_id in NUMERIC);
  procedure insert_nc_po_task_dependencies(
    p_to_task_id in NUMERIC,
    p_from_task_id in NUMERIC);
  procedure insert_nc_po_tasks(
    p_task_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_container_id in NUMERIC);
  procedure insert_nc_references(
    p_attr_id in NUMERIC,
    p_reference in NUMERIC,
    p_object_id in NUMERIC,
    p_show_order in NUMERIC,
    p_priority in NUMERIC,
    p_attr_access_type in NUMERIC);
  procedure insert_nc_resources(
    p_resource_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure insert_nc_uri_resources(
    p_uri in VARCHAR2,
    p_resource_id in NUMERIC);
  procedure insert_nc_view(
    p_object_id in NUMERIC,
    p_component_id in VARCHAR2,
    p_attr_id in NUMERIC,
    p_mask in NUMERIC,
    p_priority in NUMERIC,
    p_order_number in NUMERIC,
    p_object_type_id in NUMERIC);
  procedure insert_qrtz_blob_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_blob_data in BLOB);
  procedure insert_qrtz_cron_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_cron_expression in VARCHAR2,
    p_time_zone_id in VARCHAR2);
  procedure insert_qrtz_simple_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_repeat_count in NUMERIC,
    p_repeat_interval in NUMERIC,
    p_times_triggered in NUMERIC);
  procedure insert_qrtz_trigger_listeners(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_trigger_listener in VARCHAR2);
  procedure insert_qrtz_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_job_name in NUMERIC,
    p_job_group in VARCHAR2,
    p_is_volatile in VARCHAR2,
    p_description in VARCHAR2,
    p_next_fire_time in NUMERIC,
    p_prev_fire_time in NUMERIC,
    p_trigger_state in VARCHAR2,
    p_trigger_type in VARCHAR2,
    p_start_time in NUMERIC,
    p_end_time in NUMERIC,
    p_calendar_name in VARCHAR2,
    p_misfire_instr in NUMERIC,
    p_job_data in BLOB,
    p_priority in NUMERIC);
  procedure delete_nc_attr_groups(
    p_attr_group_id in NUMERIC);
  procedure delete_nc_attr_object_types(
    p_attr_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_attr_schema_id in NUMERIC);
  procedure delete_nc_attr_schemes(
    p_attr_schema_id in NUMERIC);
  procedure delete_nc_attr_type_defs(
    p_attr_type_def_id in NUMERIC);
  procedure delete_nc_attributes(
    p_attr_id in NUMERIC);
  procedure delete_nc_channelization_rules(
    p_src_interface in NUMERIC);
  procedure delete_nc_cmt_package_elements(
    p_entity_id in VARCHAR2);
  procedure delete_nc_cmt_package_entities(
    p_entity_id in VARCHAR2,
    p_entity_group in VARCHAR2);
  procedure delete_nc_cmt_packages(
    p_name in VARCHAR2);
  procedure delete_nc_devplug(
    p_device_id in NUMERIC);
  procedure delete_nc_directory(
    p_key in VARCHAR2,
    p_node_name in VARCHAR2);
  procedure delete_nc_event_listeners(
    p_listener_id in NUMERIC);
  procedure delete_nc_generic_artefacts(
    p_nc_entity_id in NUMERIC);
  procedure delete_nc_grants(
    p_object_id in NUMERIC,
    p_user_id in NUMERIC);
  procedure delete_nc_list_values(
    p_list_value_id in NUMERIC,
    p_attr_type_def_id in NUMERIC);
  procedure delete_nc_meta_references(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC,
    p_show_order in NUMERIC);
  procedure delete_nc_nls_attr_groups(
    p_attr_group_id in NUMERIC,
    p_language_id in NUMERIC);
  procedure delete_nc_nls_attr_schemes(
    p_attr_schema_id in NUMERIC,
    p_language_id in NUMERIC);
  procedure delete_nc_nls_attributes(
    p_attr_id in NUMERIC,
    p_language_id in NUMERIC);
  procedure delete_nc_nls_list_values(
    p_list_value_id in NUMERIC,
    p_language_id in NUMERIC);
  procedure delete_nc_nls_object_types(
    p_object_type_id in NUMERIC,
    p_language_id in NUMERIC);
  procedure delete_nc_nls_objects(
    p_object_id in NUMERIC,
    p_language_id in NUMERIC);
  procedure delete_nc_nls_resources(
    p_resource_id in NUMERIC,
    p_language_id in NUMERIC);
  procedure delete_nc_object_types(
    p_object_type_id in NUMERIC);
  procedure delete_nc_objects(
    p_object_id in NUMERIC);
  procedure delete_nc_params(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC);
  procedure delete_nc_pictures(
    p_picture_id in NUMERIC);
  procedure delete_nc_po_actions(
    p_action_id in NUMERIC);
  procedure delete_nc_po_task_dependencies(
    p_to_task_id in NUMERIC);
  procedure delete_nc_po_tasks(
    p_task_id in NUMERIC);
  procedure delete_nc_references(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC);
  procedure delete_nc_resources(
    p_resource_id in NUMERIC);
  procedure delete_nc_uri_resources(
    p_uri in VARCHAR2,
    p_resource_id in NUMERIC);
  procedure delete_nc_view(
    p_object_id in NUMERIC,
    p_component_id in VARCHAR2,
    p_attr_id in NUMERIC,
    p_priority in NUMERIC,
    p_object_type_id in NUMERIC);
  procedure delete_qrtz_blob_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2);
  procedure delete_qrtz_cron_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2);
  procedure delete_qrtz_simple_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2);
  procedure delete_qrtz_trigger_listeners(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_trigger_listener in VARCHAR2);
  procedure delete_qrtz_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2);
  procedure update_nc_attr_groups(
    p_attr_group_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_name in VARCHAR2,
    p_show_order in NUMERIC,
    p_attr_access_type in NUMERIC,
    p_description in VARCHAR2,
    p_subgroup in VARCHAR2,
    p_alias in VARCHAR2);
  procedure update_nc_attr_object_types(
    p_attr_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_isdisplayed in NUMERIC,
    p_required in NUMERIC,
    p_options in NUMERIC,
    p_default_value in VARCHAR2);
  procedure update_nc_attr_schemes(
    p_attr_schema_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_name in VARCHAR2,
    p_attr_access_type in NUMERIC,
    p_issystem in NUMERIC,
    p_description in VARCHAR2,
    p_internal_name in VARCHAR2);
  procedure update_nc_attr_type_defs(
    p_attr_type_def_id in NUMERIC,
    p_attr_type_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_name in VARCHAR2,
    p_dtd in CLOB,
    p_attr_access_type in NUMERIC,
    p_object_ref_attr_id in NUMERIC,
    p_attr_ref_id in NUMERIC);
  procedure update_nc_attributes(
    p_attr_id in NUMERIC,
    p_attr_type_id in NUMERIC,
    p_attr_type_def_id in NUMERIC,
    p_attr_group_id in NUMERIC,
    p_attr_schema_id in NUMERIC,
    p_name in VARCHAR2,
    p_attr_access_type in NUMERIC,
    p_ismultiple in NUMERIC,
    p_isextgenerated in NUMERIC,
    p_isextstored in NUMERIC,
    p_adaptername in VARCHAR2,
    p_unique_level in NUMERIC,
    p_show_order in NUMERIC,
    p_show_history in NUMERIC,
    p_issearchable in NUMERIC,
    p_mask in VARCHAR2,
    p_def_value in VARCHAR2,
    p_description in VARCHAR2,
    p_rules in NUMERIC,
    p_tooltip in VARCHAR2,
    p_av_adapter_name in VARCHAR2,
    p_internal_name in VARCHAR2);
  procedure update_nc_channelization_rules(
    p_src_interface in NUMERIC,
    p_dst_interface in NUMERIC,
    p_channels_number in NUMERIC,
    p_kind in NUMERIC,
    p_template_id in NUMERIC,
    p_name in VARCHAR2);
  procedure update_nc_cmt_package_elements(
    p_entity_id in VARCHAR2,
    p_package_name in VARCHAR2,
    p_entity_type_id in VARCHAR2);
  procedure update_nc_cmt_package_entities(
    p_entity_id in VARCHAR2,
    p_package_name in VARCHAR2,
    p_entity_type_id in VARCHAR2,
    p_entity_group in VARCHAR2);
  procedure update_nc_cmt_packages(
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_config in CLOB);
  procedure update_nc_devplug(
    p_device_id in NUMERIC,
    p_plugin_id in NUMERIC,
    p_slots_number in NUMERIC);
  procedure update_nc_directory(
    p_key in VARCHAR2,
    p_value in VARCHAR2,
    p_node_name in VARCHAR2);
  procedure update_nc_event_listeners(
    p_listener_id in NUMERIC,
    p_action_id in NUMERIC,
    p_subaction_id in NUMERIC,
    p_object_class_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_object_id in NUMERIC,
    p_listener in VARCHAR2,
    p_priority in NUMERIC,
    p_attr_id in NUMERIC,
    p_is_active in NUMERIC,
    p_listener_name in VARCHAR2,
    p_description in VARCHAR2,
    p_category in VARCHAR2);
  procedure update_nc_generic_artefacts(
    p_nc_entity_id in NUMERIC,
    p_type in VARCHAR2,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure update_nc_grants(
    p_object_id in NUMERIC,
    p_user_id in NUMERIC,
    p_grants in NUMERIC,
    p_isinheritable in NUMERIC);
  procedure update_nc_list_values(
    p_list_value_id in NUMERIC,
    p_attr_type_def_id in NUMERIC,
    p_value in VARCHAR2,
    p_show_order in NUMERIC,
    p_additional in VARCHAR2);
  procedure update_nc_meta_references(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC,
    p_ref_attr_id in NUMERIC,
    p_ref_object_type_id in NUMERIC,
    p_ref_attr_schema_id in NUMERIC,
    p_show_order in NUMERIC);
  procedure update_nc_nls_attr_groups(
    p_attr_group_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_subgroup in VARCHAR2);
  procedure update_nc_nls_attr_schemes(
    p_attr_schema_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure update_nc_nls_attributes(
    p_attr_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_tooltip in VARCHAR2);
  procedure update_nc_nls_list_values(
    p_list_value_id in NUMERIC,
    p_language_id in NUMERIC,
    p_value in VARCHAR2,
    p_list_value_group in VARCHAR2);
  procedure update_nc_nls_object_types(
    p_object_type_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure update_nc_nls_objects(
    p_object_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure update_nc_nls_resources(
    p_resource_id in NUMERIC,
    p_language_id in NUMERIC,
    p_name in VARCHAR2);
  procedure update_nc_object_types(
    p_object_type_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_picture_id in NUMERIC,
    p_icon_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_alias in VARCHAR2,
    p_isclass in NUMERIC,
    p_issystem in NUMERIC,
    p_issearchable in NUMERIC,
    p_isabstract in NUMERIC,
    p_internal_name in VARCHAR2);
  procedure update_nc_objects(
    p_object_id in NUMERIC,
    p_parent_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_object_class_id in NUMERIC,
    p_project_id in NUMERIC,
    p_picture_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2,
    p_attr_schema_id in NUMERIC,
    p_order_number in NUMERIC,
    p_source_object_id in NUMERIC);
  procedure update_nc_params(
    p_attr_id in NUMERIC,
    p_object_id in NUMERIC,
    p_attr_access_type in NUMERIC,
    p_value in VARCHAR2,
    p_data in CLOB,
    p_list_value_id in NUMERIC,
    p_show_order in NUMERIC,
    p_date_value in DATE,
    p_priority in NUMERIC);
  procedure update_nc_pictures(
    p_picture_id in NUMERIC,
    p_name in VARCHAR2,
    p_url in VARCHAR2,
    p_width in NUMERIC,
    p_height in NUMERIC);
  procedure update_nc_po_actions(
    p_action_id in NUMERIC,
    p_task_id in NUMERIC);
  procedure update_nc_po_task_dependencies(
    p_to_task_id in NUMERIC,
    p_from_task_id in NUMERIC);
  procedure update_nc_po_tasks(
    p_task_id in NUMERIC,
    p_object_type_id in NUMERIC,
    p_container_id in NUMERIC);
  procedure update_nc_references(
    p_attr_id in NUMERIC,
    p_reference in NUMERIC,
    p_object_id in NUMERIC,
    p_show_order in NUMERIC,
    p_priority in NUMERIC,
    p_attr_access_type in NUMERIC);
  procedure update_nc_resources(
    p_resource_id in NUMERIC,
    p_name in VARCHAR2,
    p_description in VARCHAR2);
  procedure update_nc_uri_resources(
    p_uri in VARCHAR2,
    p_resource_id in NUMERIC);
  procedure update_nc_view(
    p_object_id in NUMERIC,
    p_component_id in VARCHAR2,
    p_attr_id in NUMERIC,
    p_mask in NUMERIC,
    p_priority in NUMERIC,
    p_order_number in NUMERIC,
    p_object_type_id in NUMERIC);
  procedure update_qrtz_blob_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_blob_data in BLOB);
  procedure update_qrtz_cron_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_cron_expression in VARCHAR2,
    p_time_zone_id in VARCHAR2);
  procedure update_qrtz_simple_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_repeat_count in NUMERIC,
    p_repeat_interval in NUMERIC,
    p_times_triggered in NUMERIC);
  procedure update_qrtz_trigger_listeners(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_trigger_listener in VARCHAR2);
  procedure update_qrtz_triggers(
    p_trigger_name in VARCHAR2,
    p_trigger_group in VARCHAR2,
    p_job_name in NUMERIC,
    p_job_group in VARCHAR2,
    p_is_volatile in VARCHAR2,
    p_description in VARCHAR2,
    p_next_fire_time in NUMERIC,
    p_prev_fire_time in NUMERIC,
    p_trigger_state in VARCHAR2,
    p_trigger_type in VARCHAR2,
    p_start_time in NUMERIC,
    p_end_time in NUMERIC,
    p_calendar_name in VARCHAR2,
    p_misfire_instr in NUMERIC,
    p_job_data in BLOB,
    p_priority in NUMERIC);
  procedure delete_nc_params(
    p_object_id in NUMERIC);
  procedure delete_nc_references(
    p_object_id in NUMERIC);
  procedure delete_nc_meta_references(
    p_object_id in NUMERIC);
  procedure delete_nc_grants(
    p_object_id in NUMERIC);
  procedure delete_nc_grants(
    p_user_id in NUMERIC);
  procedure delete_nc_po_actions(
    p_task_id in NUMERIC);
  procedure delete_nc_po_task_dependencies(
    p_from_task_id in NUMERIC);
  procedure delete_qrtz_triggers(
    p_job_name in NUMERIC);
  procedure delete_nc_view(
    p_object_id in NUMERIC);
  procedure delete_nc_view(
    p_component_id in NUMERIC);
  procedure merge_nc_directory_multiple(
    p_key in VARCHAR2,
    p_value in VARCHAR2,
    p_node_name in VARCHAR2);
  procedure insert_nc_directory(
    p_key in VARCHAR2,
    p_value in VARCHAR2);
  procedure delete_nc_directory(
    p_key in VARCHAR2,
    p_value in VARCHAR2);
  procedure delete_nc_cmt_package_entities(
    p_entity_id in VARCHAR2,
    p_entity_group in VARCHAR2,
    p_package_name in VARCHAR2);
  procedure unpackage_list_nc_object(
    p_package_name in VARCHAR2,
    p_object_id in VARCHAR2);
  procedure unpackage_list_po(
    p_package_name in VARCHAR2,
    p_object_id in VARCHAR2);
  procedure varchar2_concat(
    p_long_varchar in out VARCHAR2,
    p_chunk in VARCHAR2);
  procedure clob_concat(
    p_data_clob in out CLOB,
    p_content in VARCHAR2);
  procedure blob_concat(
    p_data_blob in out BLOB,
    p_content in RAW);
end pkg_cmt_patch_install;
/
