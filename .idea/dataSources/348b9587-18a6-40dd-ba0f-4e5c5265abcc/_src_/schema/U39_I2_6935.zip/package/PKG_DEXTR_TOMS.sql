CREATE PACKAGE PKG_DEXTR_TOMS
AUTHID CURRENT_USER AS

  PROCEDURE extract_data (
    top_object_ids IN arrayofnumbers
  );

  PROCEDURE import_data(
    batch_num IN INTEGER
  );

  PROCEDURE clear_extracted_data;

  PROCEDURE provide_import_report;

END PKG_DEXTR_TOMS;
/
