CREATE package pkgRegexp is

function find(string in varchar2, from_loc in integer, pattern in varchar2) return number;
function match(string in varchar2, pattern in varchar2) return number;
function extractString(string in varchar2, pattern in varchar2) return varchar2;
function replaceString(string in varchar2, pattern in varchar2, replacement in varchar2) return varchar2;
function replaceAll(string in varchar2, pattern in varchar2, replacement in varchar2) return varchar2;

end PKGREGEXP;
/
