CREATE PACKAGE "PKG_NCXPATH" IS

  function getSQLDateMask(java_mask varchar2) return varchar2;

END PKG_NCXPATH;
/
