CREATE PACKAGE pkg_cust_list IS
  TYPE CUST_LIST_VALUE IS RECORD (
    object_id nc_objects.object_id%TYPE,
    value nc_objects.name%TYPE
   );
  TYPE CUST_LIST_VALUES IS TABLE OF CUST_LIST_VALUE;

  FUNCTION getAvailableValues(list_id varchar2/*required*/) RETURN CUST_LIST_VALUES PIPELINED;
  FUNCTION getValuesWithLvFilter(list_id IN NUMBER, filter_attr_id IN NUMBER, filter_lv_id IN NUMBER) RETURN CUST_LIST_VALUES PIPELINED;
  FUNCTION getValuesWithLvFilter(list_id IN NUMBER, filter_attr_id IN NUMBER, filter_lv_ids IN ARRAYOFNUMBERS) RETURN CUST_LIST_VALUES PIPELINED;
  FUNCTION getContacts(related_object IN NUMBER) RETURN CUST_LIST_VALUES PIPELINED;
  FUNCTION getStatusOfAppointment(object_id IN NUMBER) RETURN CUST_LIST_VALUES PIPELINED;
  FUNCTION getStatusOfAppointmentFlat(object_id IN NUMBER) RETURN CUST_LIST_VALUES PIPELINED;

END pkg_cust_list;
/
