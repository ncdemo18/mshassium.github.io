CREATE PACKAGE PKG_PLM_LCM_UTILS AS
/******************************************************************************
   NAME:       PKG_PLM_LCM_UTILS
******************************************************************************/
function is_plm_available_button (object_id number,event_id varchar2,conf_id number) return number;
function get_plm_configuration return number;
function is_plm_po_available_button (object_id number,event_id varchar2,conf_id number) return number;
function is_plm_po_available_button_t (object_id number,event_id varchar2,conf_id number) return number;
function is_plm_disc_available_button (object_id number,event_id varchar2,conf_id number) return number;
function is_plm_disc_available_button_t (object_id number,event_id varchar2,conf_id number) return number;
function is_plm_pv_available_button (object_id number,event_id varchar2,conf_id number) return number;
function is_plm_pv_available_button_t (object_id number,event_id varchar2,conf_id number) return number;
POC_CONF_ID number := 9140545500413225433 /* Product Offering Lifecycle */;
DISCOUNT_CONF_ID number := 9142101345913292273 /* Discount Lifecycle */;
PV_CONF_ID number := 9142065890013110986 /* Price Value Lifecycle */;
PLM_CONF_ID number := 9140720706513380914 /* PLM Configuration */;
CONF_ENV number := 9141037124213495073 /* Configuration Environment*/;
PROD_ENV number := 9141037124213495072 /* Production Environment*/;
TEST_ENV number := 9141037124213495074 /* Testing Environment*/;
PO_STATUS_TESTING number := 9140545748713273965 /* Testing */;
PO_STATUS_TESTED number := 8121960709013849138 /* Tested */;
DISC_STATUS_TESTING number := 9141688068213603662 /* Testing */;
DISC_STATUS_TESTED number := 9141688068213603663 /* Tested */;
DISC_STATUS_RELEASED number := 9142152072313328103 /* Released */;
PV_STATUS_DEVELOPED number := 9142091750013125012 /* Developed */;
PV_STATUS_RELEASED number := 9142091750013125013 /* Released */;

END PKG_PLM_LCM_UTILS;
/
