CREATE package PKG_BAM_UPGRADE is

  -- Author  : ANMI0707
  -- Created : 28/11/2012
  -- Purpose : Upgrade Data Warehouse model according to Mondrian requirements. Is used during installation and on each import to cover case of old Activity Definitions

  EMPTY_REFERENCE NUMBER(20) := -1;

  PROCEDURE updateDataWarehouse;

end PKG_BAM_UPGRADE;
/
