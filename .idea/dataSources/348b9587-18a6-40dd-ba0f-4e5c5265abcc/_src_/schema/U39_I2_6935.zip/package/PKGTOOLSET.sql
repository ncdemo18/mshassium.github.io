CREATE package PKGTOOLSET as
FUNCTION delete_objects_with_black_spot(batch_size     IN INTEGER,
                                            xml_file_infos OUT arrayofstrings)
        RETURN INTEGER;

end PKGTOOLSET;
/
