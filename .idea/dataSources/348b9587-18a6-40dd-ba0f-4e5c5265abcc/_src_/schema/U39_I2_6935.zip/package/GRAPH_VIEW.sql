CREATE PACKAGE "GRAPH_VIEW"
IS
    PROCEDURE CREATE_GV_POLICY(
      policy_id IN NUMBER,
      policy_name IN VARCHAR2,
      policy_provider_id IN NUMBER,
      impl_class IN VARCHAR2,
      description IN VARCHAR2 DEFAULT '[graph-view]',
      provider_type_id IN NUMBER DEFAULT 9127281770013843874, /* object_type_id: "Graph View Policy Provider v2" */
      policy_parent_id IN NUMBER DEFAULT 6020656900013858996  /* parent_id: "Policies" */
    );
END;
/
