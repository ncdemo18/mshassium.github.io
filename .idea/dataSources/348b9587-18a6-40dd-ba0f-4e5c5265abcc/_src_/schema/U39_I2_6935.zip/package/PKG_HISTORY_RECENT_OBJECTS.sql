CREATE PACKAGE pkg_history_recent_objects
AS

  PROCEDURE merge_history_record(
    p_collection_id NUMBER,
    p_event_info    VARCHAR,
    p_event_details CLOB,
    p_event_date    TIMESTAMP
  );

  PROCEDURE delete_records_over_limit(
    p_collection_id       NUMBER,
    p_history_items_limit INT
  );

END;
/
