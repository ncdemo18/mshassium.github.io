CREATE PACKAGE pkg_cia_sdh_rules IS

    --Rule for object types 81012 /* Main MS Path Element */, 81011 /* Protection MS Path Element */
    FUNCTION ms_path_element_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 81005 /* Server Trail */
    FUNCTION server_trail_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 81006 /* Client Trail */
    FUNCTION client_trail_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 81007 /* Concatenated Trail */
    FUNCTION concatenated_trail_rule(object_id IN NUMBER) RETURN NUMBER;

    --Rule for object type 81019 /* Span */
    FUNCTION span_rule(object_id IN NUMBER) RETURN NUMBER;

END pkg_cia_sdh_rules;
/
