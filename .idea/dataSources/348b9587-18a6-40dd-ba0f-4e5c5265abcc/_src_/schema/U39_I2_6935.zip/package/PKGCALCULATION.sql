CREATE PACKAGE pkgcalculation
IS
   is_debug_enabled number(1) := 0;
   dateFormat CONSTANT VARCHAR2 (50) := 'YYYY-MM-DD HH24:MI:SS';

   -- Allows to specify some context properties
   PROCEDURE set_context_property(
      context_property           IN      VARCHAR2,
      context_property_value     IN      VARCHAR2
   );

   --clear all context properties
   PROCEDURE clear_context_properties;

   --clear specified context property
   PROCEDURE clear_context_property(
      context_property          IN      VARCHAR2
   );

    --Get date values for specified attribute and object as âarrayofdatesâ. If values exist in database, then they will be returned, otherwise if attribute is calculable â it should be calculated
    --
    --IN p_object_id - object id
    --IN p_attr_id - attribute id of Date attribute type
    --
    --OUT arrayofdates
   FUNCTION get_parameter_as_date(
      p_object_id           IN  nc_objects.object_id%TYPE,
      p_attr_id             IN  nc_attributes.attr_id%TYPE,
      query_property_name   IN  VARCHAR2 DEFAULT NULL
      )
    RETURN arrayofdates;

   --Get values of specified attribute for object as "arrayofstrings". If attribute is calculable - it should be calculated, otherwise the simple attribute values should be returned (list, date, reference, ReferenceToAttribute) from database.
   --
   --IN p_object_id - object id
   --IN p_attr_id - attribute id
   --IN p_user_id - user_id to replace in #$currentuser$# macros
   --IN p_language_id - language_id to replace in #$languageid$# macros
   --IN p_locale_id - locale_id to replace in #$localeid$# macros
   --IN p_resolve_references - 1 - if name of referenced object should be return, 0 -  object_id
   --IN p_resolve_lists - 1 - if value of list value should be return, 0 -  list_values_id
   --IN p_check_calculate_always_flag - 1 - if necessary to check calculate always flag, 0 - not necessary to check
   --
   -- OUT values as arrayofstrings
   FUNCTION get_parameter_as_text (
      p_object_id                     IN   nc_objects.object_id%TYPE,
      p_attr_id                       IN   nc_attributes.attr_id%TYPE,
      p_user_id                       IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_language_id                   IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_locale_id                     IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_resolve_references            IN   NUMBER DEFAULT 1,
      p_resolve_lists                 IN   NUMBER DEFAULT 1,
      p_check_calculate_always_flag   IN   NUMBER DEFAULT 0,
      query_property_name             IN   VARCHAR2 DEFAULT NULL
   )
      RETURN arrayofstrings;

   --Get values of specified attribute for array of objects as âtable_of_rec_calcbyqueryâ. If attribute is calculable - it should be calculated, otherwise the simple attribute values should be returned (list, date, reference, ReferenceToAttribute) from database.
   --
   --IN p_object_ids - array of objects id
   --IN p_attr_id - attribute id
   --IN p_user_id - user_id to replace in #$currentuser$# macros
   --IN p_language_id - language_id to replace in #$languageid$# macros
   --IN p_locale_id - locale_id to replace in #$localeid$# macros
   --IN p_resolve_references - 1 - if name of referenced object should be return, 0 -  object_id
   --IN p_resolve_lists - 1 - if value of list value should be return, 0 -  list_values_id
   --IN p_check_calculate_always_flag - 1 - if necessary to check calculate always flag, 0 - not necessary to check
   --
   -- OUT values as arrayofstrings
   FUNCTION get_parameter_as_text (
      p_object_ids                    IN   arrayofnumbers,
      p_attr_id                       IN   nc_attributes.attr_id%TYPE,
      p_user_id                       IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_language_id                   IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_locale_id                     IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_resolve_references            IN   NUMBER DEFAULT 1,
      p_resolve_lists                 IN   NUMBER DEFAULT 1,
      p_check_calculate_always_flag   IN   NUMBER DEFAULT 0,
      query_property_name             IN   VARCHAR2 DEFAULT NULL
   )
      RETURN table_of_rec_calcbyquery;

   --Function for getting calculated object' parameter value of "Integer" type
   --
   --IN p_object_id -  objects id
   --IN p_attr_id - attribute id
   --IN p_curr_user - user_id to replace in #$currentuser$# macros
   --IN p_lang_id - language_id to replace in #$languageid$# macros
   --IN p_locale_id - locale_id to replace in #$localeid$# macros
   --
   -- OUT values as arrayofnumbers
   FUNCTION getcalculatedvalues (
      p_object_id           nc_objects.object_id%TYPE,
      p_attr_id             nc_attributes.attr_id%TYPE,
      p_curr_user           nc_objects.object_id%TYPE DEFAULT NULL,
      p_lang_id             nc_objects.object_id%TYPE DEFAULT NULL,
      p_locale_id           nc_objects.object_id%TYPE DEFAULT NULL,
      query_property_name   VARCHAR2 DEFAULT NULL,
      calc_only_calculatable_attrs  NUMBER DEFAULT 0
   )
      RETURN arrayofnumbers;

   --Function for getting calculated objects' parameters values of "Integer" type
   --IN p_object_ids -  array of objects id
   --IN p_attr_id - attribute id
   --IN p_curr_user - user_id to replace in #$currentuser$# macros
   --IN p_lang_id - language_id to replace in #$languageid$# macros
   --IN p_locale_id - locale_id to replace in #$localeid$# macros
   --
   -- OUT values as tableof2numbers (object - value)
   FUNCTION getcalculatedvalues (
      p_object_ids          arrayofnumbers,
      p_attr_id             nc_attributes.attr_id%TYPE,
      p_curr_user           nc_objects.object_id%TYPE DEFAULT NULL,
      p_lang_id             nc_objects.object_id%TYPE DEFAULT NULL,
      p_locale_id           nc_objects.object_id%TYPE DEFAULT NULL,
      query_property_name   VARCHAR2 DEFAULT NULL
   )
      RETURN tableof2numbers;

   -- returns colelction of ids. for internal purpose.
   FUNCTION get_object_ids
      RETURN arrayofnumbers;

   --Get query for attribute and replace macroses.  p_object_id and p_object_ids cannot be not null simultaneously
   --
   --IN p_attr_id - attribute id
   --IN p_object_id -  object_id to replace in #$objectid$# macros
   --IN p_object_ids - object_ids to replace in #$objectids$# macros
   --IN p_curr_user - user_id to replace in #$currentuser$# macros
   --IN p_lang_id - language_id to replace in #$languageid$# macros
   --IN p_locale_id - locale_id to replace in #$localeid$# macros
   --
   -- OUT query as nc_attributes.properties%TYPE
   FUNCTION getquery (
      p_attr_id             IN   nc_attributes.attr_id%TYPE,
      p_object_id           IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_curr_user           IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_lang_id             IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_locale_id           IN   nc_objects.object_id%TYPE DEFAULT NULL,
      p_object_ids          IN   arrayofnumbers DEFAULT NULL,
      query_property_name   IN   VARCHAR2 DEFAULT NULL
   )
      RETURN nc_attributes.properties%TYPE;
END pkgcalculation;
/
