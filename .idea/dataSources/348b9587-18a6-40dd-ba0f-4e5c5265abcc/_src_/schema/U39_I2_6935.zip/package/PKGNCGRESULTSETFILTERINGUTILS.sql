CREATE package pkgNCGResultSetFilteringUtils is
  function applyFilter(filterName VARCHAR2, ids arrayofnumbers, siteID NUMBER) return arrayofnumbers;
end pkgNCGResultSetFilteringUtils;
/
