CREATE PACKAGE pkgNCDOTroubleShooting AS

  PROCEDURE createErrorMirror(
    newObjects   IN NC_OBJECTS_TABLE_TYPE,
    dirtyObjects IN NC_OBJECTS_TABLE_TYPE,
    param_coll_u IN nc_params_object_table := NULL, --single parameters (Clob attribute types can be also saved throug it)
    param_coll_m IN nc_params_object_table := NULL, --multiple parameters (Clob attribute types can be also saved throug it)
    ref_coll_u   IN nc_ref_object_table := NULL, --single references
    ref_coll_m   IN nc_ref_object_table := NULL, --multiple references
    mref_coll_u  IN NC_META_REFERENCE_OBJECT_TABLE := NULL, --single meta-referneces
    mref_coll_m  IN NC_META_REFERENCE_OBJECT_TABLE := NULL, --multiple meta-referneces
    transaction_id OUT VARCHAR2
  );

  PROCEDURE createErrNCObjectsMirror(objects NC_OBJECTS_TABLE_TYPE, state VARCHAR2, transaction_id VARCHAR2);

  PROCEDURE createErrParamsMirror(
    transaction_id IN VARCHAR2,
    param_coll_u   IN nc_params_object_table := NULL, --single parameters (Clob attribute types can be also saved throug it)
    param_coll_m   IN nc_params_object_table := NULL, --multiple parameters (Clob attribute types can be also saved throug it)
    ref_coll_u     IN nc_ref_object_table := NULL, --single references
    ref_coll_m     IN nc_ref_object_table := NULL, --multiple references
    mref_coll_u    IN NC_META_REFERENCE_OBJECT_TABLE := NULL, --single meta-referneces
    mref_coll_m    IN NC_META_REFERENCE_OBJECT_TABLE := NULL --multiple meta-referneces
  );

  PROCEDURE clearErrorMirrorTables;

END pkgNCDOTroubleShooting;
/
