CREATE PACKAGE PKG_DEXTR
AUTHID CURRENT_USER
as

  procedure set_batch_size(new_size in number);

  PROCEDURE extract_data (
    rbm IN boolean,
    cm IN boolean,
    ids_view_name IN VARCHAR2
  );

  PROCEDURE extract_batches (
    rbm IN boolean,
    cm IN boolean,
    batch_ids IN arrayofnumbers
  );

  PROCEDURE extract_remaining_batches(
    rbm IN boolean,
    cm IN boolean
  );

  PROCEDURE import_data (
    rbm IN boolean,
    cm IN boolean
  );

  PROCEDURE import_batches(
    rbm IN boolean,
    cm IN boolean,
    batch_ids arrayofnumbers
  );

  PROCEDURE import_remaining_batches(
    rbm IN boolean,
    cm IN boolean
  );

END PKG_DEXTR;
/
