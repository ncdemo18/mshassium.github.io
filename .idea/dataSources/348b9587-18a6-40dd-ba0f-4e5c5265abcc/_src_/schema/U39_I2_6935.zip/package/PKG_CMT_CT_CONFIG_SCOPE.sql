CREATE PACKAGE PKG_CMT_CT_CONFIG_SCOPE AS

  -- Functionality of working with SCM Triggers
  -- Creation date: 2015-03-05
  -- Created by alch0513

  -- update nc_cmt_ct_filters table
  procedure update_nc_cmt_ct_filters(
    v_config_scope_id IN NUMBER,
    v_ct_filters IN NC_CMT_CT_FILTERS_TYPE_TABLE);

    -- check the presence of configuration item in configuration scope
  function in_scope(
    p_arr in NC_CMT_Hash_Table,
    p_scope_id in varchar2,
    p_ci_table_name in varchar2)
  return boolean;

  function get_global_scope return number;

  function in_scope(
    p_scope_id in number,
    p_table_name in varchar2,
    p_arr in NC_CMT_Hash_Table,
    p_ci_id varchar2,
    p_ci_table_name varchar2,
    p_ci_key varchar2)
  return boolean;

  function get_hash_arr(
    p_ci_id in varchar2,
    p_ci_table in varchar2,
    p_ci_key in varchar2)
  return NC_CMT_Hash_Table;

END PKG_CMT_CT_CONFIG_SCOPE;
/
