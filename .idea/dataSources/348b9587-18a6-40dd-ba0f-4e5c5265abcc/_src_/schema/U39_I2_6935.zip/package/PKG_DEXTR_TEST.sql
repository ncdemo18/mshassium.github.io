CREATE package "PKG_DEXTR_TEST" as
PRAGMA SERIALLY_REUSABLE;
  procedure run;
  procedure cleanup;

END PKG_DEXTR_TEST;
/
