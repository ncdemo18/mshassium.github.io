CREATE PACKAGE pkgRefValues
AS

	/*This function returns data for specified object, reference, attribute and show order*/
	FUNCTION getReferenceValue(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		showorder IN nc_attr_references.show_order%TYPE
	) RETURN pkgNCObject.ref_cur;

	/*This function returns data for specified object, reference, attribute*/
	FUNCTION getReferenceValue(
		objectID IN nc_objects.object_id%TYPE,
		refID IN nc_objects.object_id%TYPE,
		attrID IN nc_attributes.attr_id%TYPE
	) RETURN pkgNCObject.ref_cur;

	/*This function returns data for specified object, reference*/
	FUNCTION getReferenceValue(
		objectID IN nc_objects.object_id%TYPE,
		refID IN nc_objects.object_id%TYPE
	) RETURN pkgNCObject.ref_cur;

	/*This function returns data for specified object*/
	FUNCTION getReferenceValue(
		objectID IN nc_objects.object_id%TYPE
	) RETURN pkgNCObject.ref_cur;

-- ELLA0715 [AUG-23-2011][pkgRefValues::getAllReferenceValue is missed] Start
	/* This function returns data for specified object, attribute*/
	FUNCTION getAllReferenceValue (
		objectID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE
	) RETURN pkgNCObject.ref_cur;
-- ELLA0715 [AUG-23-2011][pkgRefValues::getAllReferenceValue is missed] End

	/* This procedure saves the reference numeric value*/
	PROCEDURE saveNumReferenceValue(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		numValue IN nc_attr_references.numeric_value%TYPE,
		showorder IN nc_attr_references.show_order%TYPE DEFAULT 1,
		aPriority IN nc_attr_references.priority%TYPE DEFAULT 0
	);

	/* This procedure saves the reference list value*/
	PROCEDURE saveListReferenceValue(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		listID IN nc_attr_references.list_value_id%TYPE,
		showorder IN nc_attr_references.show_order%TYPE DEFAULT 1,
		aPriority IN nc_attr_references.priority%TYPE DEFAULT 0
	);

	/* This procedure saves the reference date value*/
	PROCEDURE saveDateReferenceValue(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		dateVal IN nc_attr_references.date_value%TYPE,
		showorder IN nc_attr_references.show_order%TYPE DEFAULT 1,
		aPriority IN nc_attr_references.priority%TYPE DEFAULT 0
	);

	/* This procedure saves the reference text value (char length < 51) */
	PROCEDURE saveTextReferenceValue(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		textVal IN nc_attr_references.text_value%TYPE,
		showorder IN nc_attr_references.show_order%TYPE DEFAULT 1,
		aPriority IN nc_attr_references.priority%TYPE DEFAULT 0
	);

	/* This procedure gets the reference clob value for read*/
	PROCEDURE getClobRefValueForRead(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		clobVal OUT NOCOPY nc_attr_references.long_data%TYPE
	);

	/* This procedure gets the reference clob value for write*/
	PROCEDURE getClobRefValueForWrite(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		clobVal OUT NOCOPY nc_attr_references.long_data%TYPE,
		showorder IN nc_attr_references.show_order%TYPE DEFAULT 1,
		aPriority IN nc_attr_references.priority%TYPE DEFAULT 0
	);


	/* This procedure removes the ref value*/
	PROCEDURE removeRefValue(
		objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
		showorder IN nc_attr_references.show_order%TYPE DEFAULT 1
	);

    -- ILSM0706 [Nov-26-2010] [RefValueManager should support single and multiple refernces] Start
	PROCEDURE saveReferenceValues(
        objectID IN nc_attr_references.object_id%TYPE,
		specificObjectID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE,
        refValues IN arrayofnumbers
    );

    FUNCTION getReferenceValues(
        objectID IN nc_attr_references.object_id%TYPE,
		refID IN nc_attr_references.object_id%TYPE,
		attrID IN nc_attr_references.attr_id%TYPE
    ) RETURN arrayofnumbers;
    -- ILSM0706 [Nov-26-2010] [RefValueManager should support single and multiple refernces] End


END pkgRefValues;
/
