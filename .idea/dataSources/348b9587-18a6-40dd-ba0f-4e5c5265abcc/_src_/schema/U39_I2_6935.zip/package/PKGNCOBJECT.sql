CREATE PACKAGE pkgNCObject
AS
	/***DMNK 01-24-04 TW#26 */
	TYPE ref_cur IS REF CURSOR;

	/*** This procedure has to be called after creation of the new object
	It is responsible for the processing of the business rules in DB*/
/*	PROCEDURE doPostCreate(
			objectID nc_objects.object_id%TYPE,
			parentID nc_objects.parent_id%TYPE,
			objectTypeID nc_objects.object_type_id%TYPE,
			objectClassID nc_objects.object_class_id%TYPE,
			projectID nc_objects.project_id%TYPE,
			sourceObjectID nc_objects.source_object_id%TYPE,
			attrSchemaID nc_objects.attr_schema_id%TYPE
	);*/

	/*** This procedure has to be called after updating of the existing object
	It is responsible for the processing of the business rules in DB*/
/*	PROCEDURE doPostStore(
			objectID nc_objects.object_id%TYPE,
			parentID nc_objects.parent_id%TYPE,
			objectTypeID nc_objects.object_type_id%TYPE,
			objectClassID nc_objects.object_class_id%TYPE,
			projectID nc_objects.project_id%TYPE,
			sourceObjectID nc_objects.source_object_id%TYPE,
			attrSchemaID nc_objects.attr_schema_id%TYPE
	);*/

	/*** This procedure has to be called after deletion of the existing object
	It is responsible for the processing of the business rules in DB*/
/*	PROCEDURE doPreDelete(
			objectID nc_objects.object_id%TYPE,
			parentID nc_objects.parent_id%TYPE,
			objectTypeID nc_objects.object_type_id%TYPE,
			objectClassID nc_objects.object_class_id%TYPE,
			projectID nc_objects.project_id%TYPE,
			sourceObjectID nc_objects.source_object_id%TYPE,
			attrSchemaID nc_objects.attr_schema_id%TYPE
	);*/

	/* This function returns data for the single object as a cursor variable*/
	FUNCTION loadObject(objectID IN nc_objects.object_id%TYPE)
	RETURN ref_cur;

	/* This function returns parameters for the single object as a cursor variable*/
	FUNCTION loadParameters(objectID IN nc_objects.object_id%TYPE)
	RETURN ref_cur;

	/* This function returns connection data for the single object as a cursor variable*/
	FUNCTION loadConnection(objectID IN nc_objects.object_id%TYPE)
	RETURN ref_cur;

	/* This function returns attribute schema
	 for the single object based on itself, it's project or parent object*/
	FUNCTION getAttrSchema(objectID IN nc_objects.object_id%TYPE)
	RETURN nc_objects.object_id%TYPE;

	/* This function returns set of secondary (priority=0) parameters for single object*/
	FUNCTION loadSecondaryParameters(
		objectID IN nc_objects.object_id%TYPE
	)
	RETURN ref_cur;

	/* This procedure stores the data of the object in database*/
	PROCEDURE doStore(
			objectID nc_objects.object_id%TYPE,
			parentID nc_objects.parent_id%TYPE,
			objectTypeID nc_objects.object_type_id%TYPE,
			objectClassID nc_objects.object_class_id%TYPE,
			projectID nc_objects.project_id%TYPE,
		        pictureID nc_objects.picture_id%TYPE,
			aName nc_objects.name%TYPE,
			aDescription nc_objects.description%TYPE,
			orderNumber nc_objects.order_number%TYPE,
			sourceObjectID nc_objects.source_object_id%TYPE,
			attrSchemaID nc_objects.attr_schema_id%TYPE
	);

	/* This function loads the set of object data. IDs of objects have to be
	inserted into nc$_temp_ids temporary table before call of this function*/
	FUNCTION bulkLoadingObjects
	RETURN ref_cur;

	/* This function loads the set of object data when localization is used.
	IDs of objects have to be inserted into nc$_temp_ids temporary table
	before call of this function*/
	FUNCTION bulkLoadingLocalizedObjects
	RETURN ref_cur;


	/* This function loads the set of object connection data.
	IDs of objects have to be inserted into nc$_temp_ids temporary table
	before call of this function*/
	FUNCTION bulkLoadingConnections
	RETURN ref_cur;

	/* This procedure adds object ID to inner package collection. This collection is
	used further to fulfill temporary table.*/
	PROCEDURE addID (
		objectID IN nc_objects.object_id%TYPE
	);

	/* This procedure fulfills the temporary table.*/
	PROCEDURE fillIDsTable;

	/* This function returns object's Project ID if any */
	FUNCTION getProject(
		objID IN nc_objects.object_id%TYPE
	) RETURN nc_objects.project_id%TYPE;

	/* This function returns object's Project ID if any */
	FUNCTION getParentSite(
		objID IN nc_objects.object_id%TYPE
	) RETURN nc_objects.object_id%TYPE;

	/* The procedure deletes nc_params and nc_references of all objects
	in the given project that are not used according to the given
	attribute schema.
	*/
	PROCEDURE deleteUnusedParams(
		projectID IN nc_objects.project_id%TYPE,
		attrSchemaID IN nc_attr_schemes.attr_schema_id%TYPE
	);

    PROCEDURE saveObjectRectangle(
		objectID IN nc_coords.object_id%TYPE,
		containerID IN nc_coords.container_id%TYPE,
		x1 IN NUMBER,
		y1 IN NUMBER,
		x2 IN NUMBER,
		y2 IN NUMBER
	);

	PROCEDURE clearObjectRectangle(
		objectID IN nc_coords.object_id%TYPE,
		containerID IN nc_coords.container_id%TYPE
	);

    FUNCTION getObjectIDs RETURN arrayofnumbers;

    FUNCTION getCalcAttrValues(
        P_object_id IN nc_objects.object_id%TYPE,
        p_attr_id IN nc_attributes.attr_id%TYPE,
        p_curr_user IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_lang_id IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_locale_id IN nc_objects.object_id%TYPE DEFAULT NULL
    ) RETURN tableofncparameters;

    FUNCTION getCalcAttrValues(
        p_object_ids IN arrayofnumbers,
        p_attr_id IN nc_attributes.attr_id%TYPE,
        p_curr_user IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_lang_id IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_locale_id IN nc_objects.object_id%TYPE DEFAULT NULL
    ) RETURN tableofncparameters;

    FUNCTION getRefToAttrAttrValues(
        p_object_id IN nc_objects.object_id%TYPE,
        p_attr_id IN nc_attributes.attr_id%TYPE,
        p_macroses_values IN TableOf2Strings
    ) RETURN tableofncparameters;

    FUNCTION getRefToAttrAttrValues(
        p_object_ids IN arrayofnumbers,
        p_attr_id IN nc_attributes.attr_id%TYPE,
        p_macroses_values IN TableOf2Strings
    ) RETURN tableofncparameters;

    FUNCTION getRefToAttrAttrValues(
        p_object_id IN nc_objects.object_id%TYPE,
        p_attr_id IN nc_attributes.attr_id%TYPE,
        p_curr_user IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_lang_id IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_locale_id IN nc_objects.object_id%TYPE DEFAULT NULL
    ) RETURN tableofncparameters;

    FUNCTION getRefToAttrAttrValues(
        p_object_ids IN arrayofnumbers,
        p_attr_id IN nc_attributes.attr_id%TYPE,
        p_curr_user IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_lang_id IN nc_objects.object_id%TYPE DEFAULT NULL,
        p_locale_id IN nc_objects.object_id%TYPE DEFAULT NULL
    ) RETURN tableofncparameters;

    /* This procedure removes nc_params of given object that are not used according to the given attribute schema. */
    PROCEDURE removeUnusedParamsFromObject(
        p_object_id IN nc_objects.object_id%TYPE,
        p_attr_schema_id IN nc_attr_schemes.attr_schema_id%TYPE
    );

    /* This procedure removes nc_references of given object that are not used according to the given attribute schema. */
    PROCEDURE removeUnusedRefsFromObject(
        p_object_id IN nc_objects.object_id%TYPE,
        p_attr_schema_id IN nc_attr_schemes.attr_schema_id%TYPE
    );

    /* This function return attributes that binds to given object in given attribute schema */
    FUNCTION getUsedAttributes (
        p_object_id IN nc_objects.object_id%TYPE,
        p_attr_schema_id IN nc_attr_schemes.attr_schema_id%TYPE
        ) RETURN ARRAYOFNUMBERS;

END pkgNCObject;
/
