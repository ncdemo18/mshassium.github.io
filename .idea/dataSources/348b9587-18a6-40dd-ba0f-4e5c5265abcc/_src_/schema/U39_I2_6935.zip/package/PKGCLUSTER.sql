CREATE package pkgCluster is
  procedure updateNodeTimeStamp(p_node_name varchar2);
  procedure createNodeTimeStamp(p_node_name varchar2, p_node_id varchar2,
                                p_node_status number, p_machine_id varchar2, p_data varchar2);
  procedure clearNode(p_node_name varchar2);
  procedure addMessage(p_src_node varchar2, p_dst_node varchar2, p_dst_id varchar2,
                       p_action varchar2, p_target varchar2, p_params clob);
  procedure writeAlertMessage(p_node varchar2, p_time date, p_severity number, p_message varchar2);
end;
/
