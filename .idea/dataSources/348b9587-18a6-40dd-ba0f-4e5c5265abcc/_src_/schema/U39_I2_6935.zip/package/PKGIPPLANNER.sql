CREATE package pkgIPPlanner is

  subtype ADDR_STR_TYPE is varchar2(43);

  subtype IP_VERSION_TYPE is integer(1);

  subtype IP_SPACE_TYPE is integer(1);

  subtype ADDR_WIDTH is integer(3);

  type ADDR_WIDTHS_TYPE is table of ADDR_WIDTH;

  subtype ADDR_IPv4_TYPE is number(10, 0);

  subtype BIT_MASK_TYPE is number;
  type ALL_BITS_TYPE is table of BIT_MASK_TYPE;

  type IDS is table of number;

  type ref_cursor is ref cursor;

  subtype param_value_type is nc_params.value%type;

  subtype lv_id_type is nc_list_values.list_value_id%type;

  type IP_VERSION_VALUES_TYPE is table of VARCHAR2(4000);

  ------------------------------------------------------------------------------

  -- Multiplier used for virtual address ids generation
  -- IMPORTANT: for IP Planner versions prior to 6.5 should be 100000000000
  VIRTUAL_ADDRESS_ID_MULTIPLIER constant number := 10000000000000000000000000000000000000000;

  -- ( Range_id (as string) || 40 signs of postfix ) is virtual address
  VIRTUAL_ADDRESS_ID_POSTFIX_LEN constant number := 40;

  -- Top Range object type id
  TYPE_ID__TOP_RANGE            constant number := 5042946185013963560;

  -- Private IP Range object type id
  TYPE_ID__PRIVATE_IP_RANGE     constant number := 14003;

  -- Host-Addresses IP Range object type id
  TYPE_ID__HOST_ADDR_IP_RANGE   constant number := 14032;
  ------------------------------------------------------------------------------

  -- IP Range object class id (IPv4)
  CLASS_ID__IPv4_RANGE          constant number := 14001;

  -- IP Address object class id (IPv4)
  CLASS_ID__IPv4_ADDR           constant number := 14002;

  -- IP Range object class id (IPv6)
  CLASS_ID__IPv6_RANGE          constant number := 14601;

  -- IP Address object class id (IPv6)
  CLASS_ID__IPv6_ADDR           constant number := 14602;

  -- IP Pool object class id
  CLASS_ID__IP_POOL             constant number := 7080365065013898296;

  ------------------------------------------------------------------------------

  -- IP Address attribute id (numeric representation)
  ATTR_ID__IP_ADDR              constant number := 14100;

--LESO0105 [24/09/07] [Make universal IP Address and Broadcast IP Address attributes for IPv4_IPv6] Start
  -- IPv4 Address attribute id (String representation)
  /**
   * @deprecated use ATTR_ID__IP_TXT_ADDR
   */
  ATTR_ID__IPv4_TXT_ADDR        constant number := 14101;

  -- IPv4 Address attribute id (String representation)
  ATTR_ID__IP_TXT_ADDR        constant number := 14101;

--  -- IPv6 Address attribute id (String representation)
--  ATTR_ID__IPv6_TXT_ADDR        constant number := 14611;

  -- IP Broadcast Address attribute id (numeric representation)
  ATTR_ID__IP_BC_ADDR           constant number := 14199;

  -- IPv4 Broadcast Address attribute id (String representation)
  /**
   * @deprecated use ATTR_ID__TXT_BC_ADDR
   */
  ATTR_ID__IPv4_TXT_BC_ADDR     constant number := 14104;

  -- Broadcast Address attribute id (String representation)
  ATTR_ID__TXT_BC_ADDR     constant number := 14104;

--  -- IPv6 Broadcast Address attribute id (String representation)
--  ATTR_ID__IPv6_TXT_BC_ADDR     constant number := 14614;
--LESO0105 [24/09/07] [Make universal IP Address and Broadcast IP Address attributes for IPv4_IPv6] End

  -- IP Address subnet mask attribute id (String representation)
  ATTR_ID__CIDR                 constant number := 14102;

--*** LESO0105 [25/09/07] [Remove 'Mask' attributes from IP Address object types] Start
--  -- Textual representation of IP Address Mask
--  ATTR_ID__IPv4_MASK            constant number := 14103;
--
--  -- Textual representation of IPv6 Address Mask
--  ATTR_ID__IPv6_MASK            constant number := 14613;
--*** LESO0105 [25/09/07] [Remove 'Mask' attributes from IP Address object types] End

  /**
   * Show Edge Addresses attribute id (List value)
   *
   * Denotes whether subnet and broadcast addresses of the range
   * are shown on IP Addresses tab
   */
  ATTR_ID__SHOW_EDGE_ADDR       constant number := 14190;

--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes start
  ATTR_ID__IS_HOST_ADDRESSES   constant number := 14132;
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes end
--***ALFE0608 [04-05-2009][Restrict Overlapping: Existing IP Planner API, business logic and UI changes] Start
  ATTR_ID__RESTRICT_OVERLAPPING constant number := 14188;
--***ALFE0608 [04-05-2009][Restrict Overlapping: Existing IP Planner API, business logic and UI changes] End
  -- Created By attribute id
  ATTR_ID__CREATED_BY           constant number := 61;

  -- Created When attribute id
  ATTR_ID__CREATED_WHEN         constant number := 62;

  -- LESO0105 [27/08/2007] [Merge IP Pools] Start

  -- IP Pool attribute id
  ATTR_ID__IP_RANGE_IP_POOL     constant number := 7080365065013898346;

  -- Reallocated to attribute id
  ATTR_ID__REALLOCATED_TO     constant number := 9141823387513393776;

  -- Registry (of IP Range) attribute id
  ATTR_ID__IP_RANGE_REGISTRY    constant number := 7080365065013898345;
  -- LESO0105 [27/08/2007] [Merge IP Pools] End

  --*** MIZA0603 [2009-04-29] [byStrings creation API] start
  -- Modified By attribute id
  ATTR_ID__MODIFIED_BY           constant number := 63;

  -- Modified When attribute id
  ATTR_ID__MODIFIED_WHEN         constant number := 64;
  --*** MIZA0603 [2009-04-29] [byStrings creation API] end
  ------------------------------------------------------------------------------

  -- List value ID
  LV_ID__BOOLEAN__FALSE         constant lv_id_type := 0;
  LV_ID__BOOLEAN__TRUE          constant lv_id_type := 1;

  ------------------------------------------------------------------------------

--LESO0105 [05/10/2007] [IPv6: support attribute-based model] Start
--  IP_RANGE_CLASSES              constant IDS := IDS(CLASS_ID__IPv4_RANGE, CLASS_ID__IPv6_RANGE);
--  IP_ADDR_CLASSES               constant IDS := IDS(CLASS_ID__IPv4_ADDR, CLASS_ID__IPv6_ADDR);
  IP_RANGE_CLASSES              IDS;
  IP_ADDR_CLASSES               IDS;
--LESO0105 [05/10/2007] [IPv6: support attribute-based model] End

  ------------------------------------------------------------------------------

--LESO0105 [24/09/07] [Make universal IP Address and Broadcast IP Address attributes for IPv4_IPv6] Start
--  TXT_ADDR_ATTR_IDS             constant IDS := IDS(ATTR_ID__IPv4_TXT_ADDR, ATTR_ID__IPv6_TXT_ADDR);
--  TXT_BC_ADDR_ATTR_IDS          constant IDS := IDS(ATTR_ID__IPv4_TXT_BC_ADDR, ATTR_ID__IPv6_TXT_BC_ADDR);
  TXT_ADDR_ATTR_IDS             constant IDS := IDS(ATTR_ID__IP_TXT_ADDR, ATTR_ID__IP_TXT_ADDR);
  TXT_BC_ADDR_ATTR_IDS          constant IDS := IDS(ATTR_ID__TXT_BC_ADDR, ATTR_ID__TXT_BC_ADDR);
--LESO0105 [24/09/07] [Make universal IP Address and Broadcast IP Address attributes for IPv4_IPv6] End

  ------------------------------------------------------------------------------

--LESO0105 [05/10/2007] [IPv6: support attribute-based model] Start
--  IPv4_CLASSES                  constant IDS := IDS(CLASS_ID__IPv4_RANGE, CLASS_ID__IPv4_ADDR);
--  IPv6_CLASSES                  constant IDS := IDS(CLASS_ID__IPv6_RANGE, CLASS_ID__IPv6_ADDR);
  IPv4_CLASSES                   IDS;
  IPv6_CLASSES                   IDS;
--LESO0105 [05/10/2007] [IPv6: support attribute-based model] End

  ------------------------------------------------------------------------------

  BIT_8                         constant number := power(2,   8);
  BIT_16                        constant number := power(2,  16);
  BIT_24                        constant number := power(2,  24);
  BIT_32                        constant number := power(2,  32);
  BIT_48                        constant number := power(2,  48);
  BIT_64                        constant number := power(2,  64);
  BIT_80                        constant number := power(2,  80);
  BIT_96                        constant number := power(2,  96);
  BIT_112                       constant number := power(2, 112);
  BIT_127                       constant number := power(2, 127);
  BIT_128                       constant number := power(2, 128);

  ------------------------------------------------------------------------------

  ALL_BITS_32                   constant number := BIT_32 - 1;
  ALL_BITS_128                  constant number := power(2, 128) - 1;

  ------------------------------------------------------------------------------

  ADDR_10_0_0_0                 constant ADDR_IPv4_TYPE := 167772160;
  ADDR_172_16_0_0               constant ADDR_IPv4_TYPE := 2886729728;
  ADDR_192_168_0_0              constant ADDR_IPv4_TYPE := 3232235520;

  ------------------------------------------------------------------------------

  IPv4                          constant IP_VERSION_TYPE := 1;
  IPv6                          constant IP_VERSION_TYPE := 2;

  ------------------------------------------------------------------------------

--*** LESO0105 [11/10/2007] [Private IP Ranges: support attribute-based model] Start
  SPACE_PUBLIC                  constant IP_SPACE_TYPE := 1;

  SPACE_PRIVATE                 constant IP_SPACE_TYPE := 2;
--*** LESO0105 [11/10/2007] [Private IP Ranges: support attribute-based model] End

  ------------------------------------------------------------------------------

  ADDR_WIDTHS                   constant ADDR_WIDTHS_TYPE := ADDR_WIDTHS_TYPE(32, 128);

  ------------------------------------------------------------------------------

  ALL_BITS                      constant ALL_BITS_TYPE := ALL_BITS_TYPE(ALL_BITS_32, ALL_BITS_128);

  ------------------------------------------------------------------------------

  MAX_CIDRS                     constant ADDR_WIDTHS_TYPE := ADDR_WIDTHS_TYPE(32, 128);

  ------------------------------------------------------------------------------

--*** LESO0105 [25/09/07] [Remove 'Mask' attributes from IP Address object types] Start
--  MASK_ATTR_IDS                 constant IDS := IDS(ATTR_ID__IPv4_MASK, ATTR_ID__IPv6_MASK);
--*** LESO0105 [25/09/07] [Remove 'Mask' attributes from IP Address object types] End

  ------------------------------------------------------------------------------

--LESO0105 [05/10/2007] [IPv6: support attribute-based model] Start
  MODE_OBJECT_TYPE_BASED constant VARCHAR2(40) := 'object_type_based';
  MODE_ATTRIBUTE_BASED   constant VARCHAR2(40) := 'attribute_based';
--LESO0105 [05/10/2007] [IPv6: support attribute-based model] End
  ------------------------------------------------------------------------------
--*** ALFE0608 [03-12-2009] [isFolder API] Start
  IP_FOLDER_PROPERTY constant varchar (10) := 'ip_folder';
--*** ALFE0608 [03-12-2009] [isFolder API] End
--*** ALFE0608 [06-01-2010] [API: Create IP Range from template] Start
  COPY_FROM_TEMPLATE_PROPERTY constant varchar2(20) := 'copy_from_template';
--*** ALFE0608 [06-01-2010] [API: Create IP Range from template] End
--SERK0810 [16-09-2010][Error during the spliting IP Range after unassignment of IP address with the device] start
  IS_SYSTEM_REFERENCE_PROPERTY constant varchar2(20) := 'is_sys_ref';
--SERK0810 [16-09-2010][Error during the spliting IP Range after unassignment of IP address with the device] end
--*** VIKN0810 [03-03-2011][Customize propagation for parameters of virtual IP addresses] START
  DISABLE_PROPAGATION_PROPERTY constant varchar2(20) := 'disable_propagation';
--*** VIKN0810 [03-03-2011][Customize propagation for parameters of virtual IP addresses] END
--ALFE0608 [22/07/2011] [Duplicate IP Addresses in ranges] Start
  IP_PLANNER_USER_LOCK_PREFIX constant varchar2(15) := 'ip_planner_lock';
  ------------------------------------------------------------------------------
  /**
  * Create lock for specified variable
  * @param p_lockname - Name of the lock
  * @return lock mode status:
  *    0 - Success
  *    1 - Timeout
  *    2 - Deadlock
  *    3 - Parameter error
  *    4 - Already own lock specified by id or lockhandle
  *    5 - Illegal lock handle
  */
  function request_lock(p_lockname varchar2) return number;
--ALFE0608 [22/07/2011] [Duplicate IP Addresses in ranges] End
--***ALFE0608[12-03-2009][PL/SQL API for get edges of IP range] Start
  /**
   * Get left address of range
   *
   * @param p_range_id           Range ID
   */
  function get_left_addr (
    p_range_id                  number
  ) return number;

  /**
   * Get right address of range
   *
   * @param p_range_id           Range ID
   */
  function get_right_addr (
    p_range_id                  number
  ) return number;
--***ALFE0608[12-03-2009][PL/SQL API for get edges of IP range] End

  /**
   * Sink persistent addresses from range into subranges
   *
   * @param range_id            Range ID
   */
  procedure sinkAddresses (
    p_range_id                  number
  );

--*** LESO0105 [IP02 - IP Subnetting] [13/02/2008] Start
  /**
   * Raise persistent addresses from source subrange into destination range
   *
   * @param p_src_range_id      Source range ID
   * @param p_dst_range_id      Destination range ID
   * @param p_hierarchy         Specifies whether to raise all IP addresses hierarchically or not.
   *                            1 - hierarchically (default value)
   *                            0 - only first-level IP addresses
   */
  procedure raiseAddressesToRange (
    p_src_range_id              number,
    p_dst_range_id              number,
    p_hierarchy                 number default 1
  );


  /**
   * Raise persistent addresses and sub-ranges from source subrange into parent range.
   * Only direct children are raisen (not hierarchically).
   *
   * @param p_range_id      Source range ID
   */
  procedure raise_children ( p_range_id number );

  /**
   * Raise persistent addresses and sub-ranges from source subrange into target range.
   * Only direct children are raisen (not hierarchically).
   *
   * @param p_range_id        Source range ID
   * @param p_target_range_id Target range ID
   */
  procedure raise_children ( p_range_id number, p_target_range_id number );

--*** LESO0105 [IP02 - IP Subnetting] [13/02/2008] End

--*** LESO0105 [IP01 - IP Supernetting] [25/02/2008] Start
  /**
   * Raise persistent addresses and sub-ranges from source subranges into target range.
   * Only direct children are raisen (not hierarchically).
   *
   * @param p_range_ids        Source range IDs
   * @param p_target_range_id  Target range ID
   */
  procedure raise_children( p_range_ids arrayofnumbers, p_target_range_id number );

--*** LESO0105 [IP01 - IP Supernetting] [25/02/2008] End

  /**
   * Raise persistent addresses from children subranges into parent range
   *
   * @param p_range_id          Parent range ID
   */
  procedure raiseChildAddressesToRange (
    p_range_id                  number
  );

  /**
   * Check overlapping given addresses diapason with top ranges of pointed classes ranges
   *
   * Since introduction of the hybrid IPv6 model this method
   * supports only object-type based model.
   *
   * @param p_top_range_id      Top range ID
   * @param p_left_addr         Left bound of checked diapason
   * @param p_right_addr        Right bound of checked diapason
   * @param p_object_type_id    Object type ID checked ranges
   * @return                    -1 if not overlapped randes, or max ID of overlapped range
   */
  function check_overlapping_top_ranges (
    p_top_range_id              number,
    p_left_addr                 number,
    p_right_addr                number,
    p_object_type_id            number
  ) return number;

  /**
   * Check overlapping given addresses diapason with top ranges of pointed classes ranges
   *
   * @param p_top_range_id      Top range ID
   * @param p_left_addr         Left bound of checked diapason
   * @param p_right_addr        Right bound of checked diapason
   * @param p_object_type_id    Object type ID checked ranges
   * @param p_ip_version        Version of IP protocol
   * @return                    -1 if not overlapped randes, or max ID of overlapped range
   */
  function check_overlapping_top_ranges (
    p_top_range_id              number,
    p_left_addr                 number,
    p_right_addr                number,
    p_object_type_id            number,
    p_ip_version                IP_VERSION_TYPE
  ) return number;

--***EVKA0310 [02/12/2010 ] [ Ability to Cut IP range in IP ranges hierarchy ] added Start
  /**
   * Check overlapping given addresses diapason with subranges of pointed range
   *
   * @param p_range_id          Parent range ID
   * @param p_left_addr         Left bound of checked diapason
   * @param p_ip_version        Version of IP protocol
   * @param p_exclude_range_id  Exclude range ID
   * @return                    -1 if not overlapped randes, or max ID of overlapped range
   */
  function checkOverlapping (
    p_range_id                  number,
    p_left_addr                 number,
    p_right_addr                number,
    p_exclude_range_id          number := null,
    p_ip_version                IP_VERSION_TYPE
  ) return number;
--***EVKA0310 [02/12/2010 ] [ Ability to Cut IP range in IP ranges hierarchy ] added End
  /**
   * Check overlapping given addresses diapason with subranges of pointed range
   *
   * @param p_range_id          Parent range ID
   * @param p_left_addr         Left bound of checked diapason
   * @param p_exclude_range_id  Exclude range ID
   * @return                    -1 if not overlapped randes, or max ID of overlapped range
   */
  function checkOverlapping (
    p_range_id                  number,
    p_left_addr                 number,
    p_right_addr                number,
    p_exclude_range_id          number := null
  ) return number;

  --***EVKA0310 [02/12/2010 ] [ Ability to Cut IP range in IP ranges hierarchy ] added Start
  /**
   * Return overlapping subranges under range
   *
   * @param p_range_id          Parent range ID
   * @param p_ip_version        Version of IP protocol
   * @return                    List of overlapping subranges
   */
  function get_overlapping_subranges (p_range_id number, p_ip_version IP_VERSION_TYPE) return ref_cursor;
--***EVKA0310 [02/12/2010 ] [ Ability to Cut IP range in IP ranges hierarchy ] added End

--*** ALFE0608 [03-12-2009] [Extra IPRange API: hasOverlapping, hasOwnPersistentAddresses methods] Start
  /**
   * Return overlapping subranges under range
   *
   * @param p_range_id          Parent range ID
   * @return                    List of overlapping subranges
   */
  function get_overlapping_subranges (p_range_id number) return ref_cursor;

  /**
   * Check overlapping subranges under range
   *
   * @param p_range_id          Parent range ID
   * @return                    0 if not overlapped randes, else 1
   */
  function has_overlapping_subranges (p_range_id number) return number;
--*** ALFE0608 [03-12-2009] [Extra IPRange API: hasOverlapping, hasOwnPersistentAddresses methods] End
--*** ALFE0608 [06-24-2010][Ability to choose template for new IP Range] Start
  /**
   * Check contains IP folder under range
   *
   * @param p_range_id          Parent range ID
   * @return                    0 if not contains IP folder, else 1
   */
  function has_ip_folder_subranges(p_range_id number) return number;

  /**
   * Find same parent IP range addresses for create new range from template and IP range template addresses
   *
   * @param p_parent_rng_id      parent IP range ID
   * @param p_addr               addr for new IP range
   * @param p_count_rng          count new IP range
   * @param p_templ_rng_id       IP range template ID
   * @return                     1 if there are same IP addresses, else 0
   */
  function has_same_addr(p_parent_rng_id number, p_addr number, p_count_rng number, p_templ_rng_id number) return number;
--*** ALFE0608 [06-24-2010][Ability to choose template for new IP Range] End
--*** ALFE0608 [06-01-2010] [API: Create IP Range from template] Start
  procedure copy_range_hierarchy(p_source_rng number, p_dest_rngs arrayofnumbers, p_range_type_id number, p_copy_addr number, p_addr_type_id number, p_user_name varchar2);
--*** ALFE0608 [06-01-2010] [API: Create IP Range from template] End

--*** ALFE0608 [03-27-2009] [IP folders: Edit Subrange changes]] Start
  /**
   * Return count own persistent addresses for specified range between p_left_addr and p_right_addr
   * @param p_range_id          range ID
   * @param p_left_addr         left address for search
   * @param p_right_addr        right address for search
   * @return                    count own persistent addresses
  */
  function count_own_persistent_addr(
    p_range_id          number,
    p_left_addr         number,
    p_right_addr        number
  ) return number;
--*** ALFE0608 [03-27-2009] [IP folders: Edit Subrange changes]] End

  /**
   * Count of addresses outside subranges of given range
   *
   * @param p_range_id          Parent range ID
   * @return                    Count of addresses outside subranges of given range
   */
  function getRangeFreeSpace (
    p_range_id                  number
  ) return number;

  /**
   * @deprecated use get_first_subnet_by_cidr(number, number):number
   * Find the left bounds of first unoccupied addresses diapason in given
   * range for create subrange
   *
   * @param p_range_id          Range ID
   * @param p_range_subnet      Start address for searching
   * @param p_range_broadcast   End address for searching
   * @param p_volume            Count addresses in subrange
   * @return                    -1 if not free space, or address of first available range
   */
  function getFirstAvailableAddress (
    p_range_id                  number,
    p_range_subnet              number,
    p_range_broadcast           number,
    p_volume                    number
  ) return number;

  /**
   * @deprecated use update_range(number, number):number
   * Extend or narrow range
   *
   * @param p_range_id          Range ID
   * @param p_parent_id         Parent ID
   * @param p_left_addr         Left bound new diapason
   * @param p_right_addr        Right bound new diapason
   * @param p_old_cidr          Old CIDR
   * @param p_new_cidr          New CIDR
   * @return                    0 - complet, not 0 - count overlapped ranges
   */
  function updateRange (
    p_range_id                  number,
    p_parent_id                 number,
    p_left_addr                 number,
    p_right_addr                number,
    p_old_cidr                  number,
    p_new_cidr                  number
  ) return number;

  /**
   * Extend or narrow range
   *
   * @param p_range_id          Range ID
   * @param p_new_cidr          New CIDR
   * @return                    0 - complet, not 0 - count overlapped ranges
   */
  function update_range (
    p_range_id                  number,
    p_new_cidr                  number
  ) return number;

  /**
   * Check up use of the address as range bounds
   *
   * @param p_range_id          Range ID
   * @param p_address           Address (text representation)
   * @return
   */
  function checkEliminatedAddress (
    p_range_id                  number,
    p_address                   varchar2
  ) return number;

  /**
   * Count of addresses used as bounds of range and subranges
   *
   * @param p_range_id          Range ID
   * @return
   */
  function countEliminatedAddresses (
    p_range_id                  number
  ) return number;

  /**
   * Count of addresses used as bounds of range and subranges in given range
   *
   * @param p_range_id          Range ID
   * @param p_left_addr         Left address
   * @param p_right_addr        Right address
   * @return                    Count of addresses
   */
  function countEliminatedAddresses (
    p_range_id                  number,
    p_left_addr                 number,
    p_right_addr                number
  ) return number;

  /**
   * @deprecated use split_range(number, number, number, varchar2):ref_cursor
   * This procedure should replace IPManager.splitRange method and IPRange.Create
   * to increase performance of splitting
   */
  procedure splitRange (
    p_parent_id                 number,
    p_object_type_id            number,
    p_parent_cidr               int,
    p_address                   number,
    p_cidr                      int,
    p_user_name                 varchar2,
    p_private_range_type_id     number,
    p_private_cidr              varchar2
  );

--*** LESO0105 [IP02 - IP Subnetting] [13/02/2008] start
  /**
   * Split the range on subranges with specified CIDR
   *
   * @param p_range_id          Range ID
   * @param p_subnet_cidr       SubRange CIDR
   * @param p_subnet_object_type_id SubRange Object Type ID
   * @param p_user_name         User name
   * @return                    List of created ranges
   */
/*  function split_range (
    p_range_id                  number,
    p_subnet_cidr               number,
    p_subnet_object_type_id     number,
    p_user_name                 varchar2
  ) return ref_cursor;
*/
  /**
   * Split the range on subranges with specified CIDR
   *
   * @param p_range_id          Range ID
   * @param p_subnet_cidr       SubRange CIDR
   * @param p_subnet_object_type_id SubRange Object Type ID
   * @param p_user_name         User name
   * @param p_description       Description of IP Ranges to be created
   * @return                    List of created ranges
   */

  function split_range (
    p_range_id                  number,
    p_subnet_cidr               number,
    p_subnet_object_type_id     number,
    p_user_name                 varchar2,
    p_description               varchar2 default null,
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes start
    p_loopback                  number default null
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes end
  ) return ref_cursor;
--*** LESO0105 [IP02 - IP Subnetting] [13/02/2008] end

  /**
   * Convert the address text representation into number representation
   *
   * @param p_addr_str          Text representation of address
   * @param p_ip_version        Version of IP (1 - IPv4, 2 - IPv6)
   * @return
   */
  function addr_aton (
    p_addr_str                  varchar2,
    p_ip_version                IP_VERSION_TYPE
  ) return number;

  /**
   * Convert the address number representation into text representation
   *
   * @param p_addr_num          Number representation of address
   * @param p_ip_version        Version of IP (1 - IPv4, 2 - IPv6)
   * @return
   */
  function addr_ntoa (
    p_addr_num                  number,
    p_ip_version                IP_VERSION_TYPE
  ) return varchar2;

  /**
   * Align address on bounds of range with given CIDR
   *
   * @param p_addr_num          Number representation of address
   * @param p_cidr              CIDR
   * @param p_ip_version        Version of IP (1 - IPv4, 2 - IPv6)
   * @return
   */
  function align_addr_by_cidr (
    p_addr_num                  number,
    p_cidr                      number,
    p_ip_version                IP_VERSION_TYPE
  ) return number;

  /**
   * Checks, whether one address is parental to another
   *
   * @param p_addr              Address
   * @param p_cidr              CIDR
   * @param p_parent_addr       Parent address
   * @param p_parent_cidr       Parent CIDR
   * @param p_ip_version        Version of IP (1 - IPv4, 2 - IPv6)
   * @return                    flag (0 - no, 1 - yes)
   */
  function is_parent_range (
    p_addr                      number,
    p_cidr                      number,
    p_parent_addr               number,
    p_parent_cidr               number,
    p_ip_version                IP_VERSION_TYPE
  ) return number;

--*** ALFE0608 [03-12-2009] [isFolder API] Start
  /**
   * Checks if the specified IPRange is folder,
   * and returns 1 (true) if it folder, else 0 (false)
   */
  function is_folder(p_range number) return number;
--*** ALFE0608 [03-12-2009] [isFolder API] End
--*** ALFE0608 [03-30-2009] [IP Pools restrictions on IP folders] Start
  /** Return top IP Folders under p_range_id.
   *
   * @param parentRange range for search ip folders.
   * @return list IDs of ip folder, subnet addresses and prefix length.
   */
  function get_top_child_folders(p_range_id number) return ref_cursor;
--*** ALFE0608 [03-30-2009] [IP Pools restrictions on IP folders] End
  /**
   * Checks, whether the address enters into a private range
   * (for IPv4 only)
   *
   * @param p_addr              Address
   * @param p_cidr              CIDR
   * @return                    flag (0 - no, 1 - yes)
   */
  function is_private_range (
    p_addr                      number,
    p_cidr                      number
  ) return number;

  /**
   * Transform CIDR to mask
   *
   * @param p_cidr              CIDR
   * @param p_ip_version        Version of IP (1 - IPv4, 2 - IPv6)
   * @return                    mask
   */
  function cidr_to_mask (
    p_cidr                      number,
    p_ip_version                IP_VERSION_TYPE
  ) return number;

  /**
   * Create range(s)
   *
   * @param p_parent_id         Parent ID
   * @param p_range_addr        Start address for create range(s)
   * @param p_range_cidr        CIDR
   * @param p_range_type_id     Object type ID created range(s)
   * @param p_count             Count of ranges
   * @param p_is_autocomplete   Flag of autocompleting (0 - no, not 0 - yes)
   * @param p_user_name         User name
   * @return                    ID`s of created ranges
   */
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes start
--  function create_ranges (
--    p_parent_id                 number,
--    p_range_addr                number,
--    p_range_cidr                number,
--    p_range_type_id             number,
--    p_count                     number,
--    p_is_autocomplete           number,
--    p_user_name                 varchar2
--  ) return ref_cursor;
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes end

--***LESO0105 [04/09/2007][IP Planner: IP Range creation dialog should allow to specify description] Start
  /**
   * Create range(s)
   *
   * @param p_parent_id         Parent ID
   * @param p_range_addr        Start address for create range(s)
   * @param p_range_cidr        CIDR
   * @param p_range_type_id     Object type ID created range(s)
   * @param p_count             Count of ranges
   * @param p_is_autocomplete   Flag of autocompleting (0 - no, not 0 - yes)
   * @param p_user_name         User name
   * @param p_description       Range's description
   * @return                    ID`s of created ranges
   */
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes start
--  function create_ranges (
--    p_parent_id                 number,
--    p_range_addr                number,
--    p_range_cidr                number,
--    p_range_type_id             number,
--    p_count                     number,
--    p_is_autocomplete           number,
--    p_user_name                 varchar2,
--    p_description               varchar2
--  ) return ref_cursor;
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes end
--***LESO0105 [04/09/2007][IP Planner: IP Range creation dialog should allow to specify description] End

--*** LESO0105 [11/10/2007] [Private IP Ranges: support attribute-based model] Start
  /**
   * Create range(s)
   *
   * @param p_parent_id         Parent ID
   * @param p_range_addr        Start address for create range(s)
   * @param p_range_cidr        CIDR
   * @param p_range_type_id     Object type ID created range(s)
   * @param p_count             Count of ranges
   * @param p_is_autocomplete   Flag of autocompleting (0 - no, not 0 - yes)
   * @param p_user_name         User name
   * @param p_description       Range's description
   * @param p_check_overlapping Flag of check for overlapping (0 - no, not 0 - yes)
   * @return                    ID`s of created ranges
   */
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes start
--  function create_ranges (
--    p_parent_id                 number,
--    p_range_addr                number,
--    p_range_cidr                number,
--    p_range_type_id             number,
--    p_count                     number,
--    p_is_autocomplete           number,
--    p_user_name                 varchar2,
--    p_description               varchar2,
--    p_check_overlapping         number
--  ) return ref_cursor;
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes end
--*** LESO0105 [11/10/2007] [Private IP Ranges: support attribute-based model] End

--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes start
  /**
   * Create range(s)
   *
   * @param p_parent_id         Parent ID
   * @param p_range_addr        Start address for create range(s)
   * @param p_range_cidr        CIDR
   * @param p_range_type_id     Object type ID created range(s)
   * @param p_count             Count of ranges
   * @param p_is_autocomplete   Flag of autocompleting (0 - no, not 0 - yes)
   * @param p_user_name         User name
   * @param p_description       Range's description
   * @param p_check_overlapping Flag of check for overlapping (0 - no, not 0 - yes)
   * @param p_loopback          Flag defining whether created ranges should be Host-Addresses or not (0=no, 1=yes)
   * @return                    ID`s of created ranges
   */
  function create_ranges (
    p_parent_id                 number,
    p_range_addr                number,
    p_range_cidr                number,
    p_range_type_id             number,
    p_count                     number,
    p_is_autocomplete           number,
    p_user_name                 varchar2,
    p_description               varchar2 default null,
    p_check_overlapping         number default 1,
    p_loopback                  number default null,
--***ALFE0608 [04-05-2009][Restrict Overlapping: Existing IP Planner API, business logic and UI changes] Start
    p_restrict_overlapping      number default 0
--***ALFE0608 [04-05-2009][Restrict Overlapping: Existing IP Planner API, business logic and UI changes] End
  ) return ref_cursor;
--*** MIZA06030 [03-11-08][Host-Addresses IP Range for Private and IPv6 Ranges] changes end

  /**
   * Receive the list of identifiers of the created ranges
   *
   * @return                    the list of identifiers of the created ranges
   */
  function get_new_ranges_ids
  return ref_cursor;
--ALFE0608 [15-09-2008] [Usability improvement of Allocate to IP Pool dialog] Start
  /**
  *Return object_id, subnet_address and cidr of allocated subranges for source range
  *@param p_range_id            source range
  *@return                      allocated subrange
  */
  function get_allocated_ranges(p_range_id number) return ref_cursor;
--ALFE0608 [15-09-2008] [Usability improvement of Allocate to IP Pool dialog] End

  /**
   * Count accessible to creation subnetworks with CIDR in the specified range
   *
   * @param p_range_id          Range ID
   * @param p_cidr              CIDR
   * @return                    Count of subnetworks
   */
  function get_free_ranges_count_by_cidr (
    p_range_id                  number,
    p_cidr                      number
  ) return number;

  /**
   * Finish distribution of free space of a range set by addresses
   *
   * @param p_range_id          Range ID
   * @param p_subnet_type_id    Subnet type ID
   * @param p_user_name         User name
   * @return                    ID`s of created ranges
   */
  function fill_range (
    p_range_id                  number,
    p_subnet_type_id            number,
    p_user_name                 varchar2
  ) return ref_cursor;

  /**
   * Calculate address of first free subnet with given CIDR
   *
   * @param p_range_id          Range ID
   * @param p_subnet_cidr       Subnet CIDR
   * @return                    Subnet address
   */
  function get_first_subnet_by_cidr (
    p_range_id                  number,
    p_subnet_cidr               number
  ) return number;

  /**
   * Find largest subnet
   *
   * @param p_subnet_addr       Subnet address (-1, if not exists)
   * @param p_subnet_cidr       Subnet CIDR (-1, if not exists)
   * @param p_range_id          Range ID
   */
  procedure get_largest_subnet (
    p_subnet_addr           out number,
    p_subnet_cidr           out number,
    p_range_id                  number
  );
--ALFE0608 [11-11-2008] [Edit operation for Top Ranges] Start
  /**
  * Find largest subrange under range and return his prefix length
  * If subrange not found then return -1
  * @param p_parent_range_id
  */
  function get_largest_subrange_prefix(p_parent_range_id number)
    return number;

  /**
  * Find maximum persistent address under range and his subrange and return his.
  * If persistent address not found return -1
  * @p_range_id
  */
  function get_max_persistent_address(p_range_id number)
    return number;
--//ALFE0608 [11-11-2008] [Edit operation for Top Ranges] End
  /**
   * Searches for a range of the bottom level to which belong the specified address
   *
   * @param p_root_range_id     Root range ID
   * @param addr                Address
   * @return                    Range ID
   */
  function get_range_by_addr (
    p_root_range_id             number,
    p_addr                      number,
	--***SVMA0311 [04-19-2011] [Performance problem on IP address tab of IP range with folders structure] Changed start
    p_has_folder                number default 1,
    p_return_folder             number default 0
    --***SVMA0311 [04-19-2011] [Performance problem on IP address tab of IP range with folders structure] Changed end
  ) return number;

  /**
   * Generate list of addresses in the given range
   *
   * @param p_range_id          Range ID
   * @param p_start_addr        Start address
   * @param p_end_addr          End address
   * @return                    List of addresses
   */
  function get_addr_list (
    p_range_id                  number,
    p_start_addr                number,
    p_end_addr                  number
  ) return ref_cursor;

--***DMLA0706 [2007-10-11] [Problems with cached persistent IP Addresses] Start
  procedure append_referrers;
--***DMLA0706 [2007-10-11] [Problems with cached persistent IP Addresses] End

  /**
   * Age objects
   * (for NC ver. >= 6.5)
   * updates nc_objects.version column for ids in temp table nc$_ids
   */
  procedure age_objects;

  /**
   * Checks if the specified IPRange is terminal (has no subranges),
   * and returns 1 (true) if it is terminal, else 0 (false)
   *
   * @param p_range_id          Range ID
   * @return                    flag (0 - no, 1 - yes)
   */
  function is_terminal_range (
    p_range_id                  number
  ) return number;

  /**
   * Drop all children ranges given range
   *
   * @param p_range_id          Range ID
   */
  procedure drop_children_ranges (
    p_range_id                  number
  );

--*** ALFE0608 [03-29-2011][Extend parameters of pkgipplanner.get_addr_block function] Start
  /**
   * Generate list of addresses in the given range
   *
   * @param p_range_id          Range ID
   * @param p_start_addr        Start address of address block
   * @param p_end_addr          End address of address block
   * @param p_start_line        Start line of address block
   * @param p_end_line          End line of address block
   * @return                    List of addresses
   */
  function get_addr_block (
    p_range_id                  number,
    p_start_addr                number,
    p_end_addr                  number,
    p_start_line                number,
    p_end_line                  number
  ) return ref_cursor;
--*** ALFE0608 [03-29-2011][Extend parameters of pkgipplanner.get_addr_block function] End

  /**
   * Generate list of addresses in the given range
   *
   * @param p_range_id          Range ID
   * @param p_start_line        Start line of address block
   * @param p_end_line          End line of address block
   * @return                    List of addresses
   */
  function get_addr_block (
    p_range_id                  number,
    p_start_line                number,
    p_end_line                  number
  ) return ref_cursor;

  /**
   * Drops persistent IP Addresses data for all not-referred addresses
   * whithin given project
   *
   * @param p_project_id        Project ID
   */
  procedure release_unassigned_ips (
    p_project_id                number
  );

  /**
   * Returns for a range p_range_id the list subranges, directly containing
   * addresses with a cidr p_addr_cidr. The returned set is ordered on increase
   * of addresses, odd records describe the left borders, and even - the right
   * borders. Each record contains the address (the left or right border),
   * ID of a range-owner and count of records.
   *
   * @param p_range_id          Range ID
   * @param p_addr_cidr         Address CIDR
   * @return                    The list of the left and right addresses
   *                            of borders of ranges into which the specified
   *                            range is divided
   */
  function get_range_splitting (
    p_range_id                  number,
    p_addr_cidr                 number
  ) return ref_cursor;

--***LESO0105 [20/05/2008] [Support IP Folders in the IP Search Context Provider ] Start
  /**
   * Returns for a range p_top_range_id the list of subranges, directly containing addresses.
   *
   * - When p_cidr parameter is not null, only addresses with cidr = p_cidr are considered.
   * - When p_cidr is null, all addresses are considered.
   *
   * Each record contains:
   *   [object_id]    - id of the IP range directly containing addresses
   *   [left_addr]    - left bound of the IP addresses
   *   [right_addr]   - right bound of the IP addresses
   *   [record_count] - total number of records returned
   *
   * Records are ordered in the ascending order by the [left_addr] field.
   * Records with same [left_addr] values are ordered in the ascending order by [object_id] field.
   */
  function get_range_splitting2(p_top_range_id number,
                                p_left_bnd     number,
                                p_right_bnd    number,
                                p_cidr         number default null
                                ) return ref_cursor;
--***LESO0105 [20/05/2008] [Support IP Folders in the IP Search Context Provider ] End

  --LESO0105 [09/08/2007] [Create new Allocation/Deallocation/Move jsp] Start
   /**
    * Searches for IP Range starting from the IP Range with object_id = p_top_range_id, which will be parent for the IP Range with:
    *    sub-net address <code>p_range_address</code>
    *    sub-net mask length <code>p_range_cidr</code>
    *
    * @param p_top_range_id object_id of the IP Range to start the search from
    * @param p_range_address Sub-net address of the IP Range to find parent for
    * @param p_range_cidr Sub-net mask length of the IP Range to find parent for
    * @param p_ip_version <code>2</code> if the IP Range to find parent for is IPv6 range, <code>1</code> - for IPv4
    *
    * @return object_id of IP Range which is expected parent for the range with given parameters. If the range with
    *    sub-net address <code>subnetAddress</code>
    *    sub-net mask length <code>prefixLength</code>
    * already exists in the specified project, it will be returned.
    */
  function  get_potential_parent_for_range(
            p_top_range_id    number,
            p_range_address   number,
            p_range_cidr      number,
            p_ip_version      IP_VERSION_TYPE) return number;
  --LESO0105 [09/08/2007] [Create new Allocation/Deallocation/Move jsp] Start

  --*** MYOL0102 [14-03-2011] [API: find potential parents for address or range] Begin
  /**
    * Searches for IP ranges starting from the IP range with object_id = p_top_range_id, which will be parent for the IP range with:
    *    sub-net address <code>p_range_address</code>
    *    sub-net mask length <code>p_range_cidr</code>
    *
    * @param p_top_range_id object_id of the IP range to start the search from
    * @param p_range_address Sub-net address of the IP range to find parent for
    * @param p_range_cidr prefix length of the IP range to find parent for
    * @param p_ip_version <code>2</code> if the IP range to find parent for is IPv6 range, <code>1</code> - for IPv4
    *
    * @return object ids of IP ranges which are expected parent for the range with given parameters
    */
  function  get_potential_parents_for_rng(
              p_top_range_id    number,
              p_range_address   number,
              p_range_cidr      number,
              p_ip_version      IP_VERSION_TYPE) return arrayofnumbers;

  /**
    * Searches for IP range starting from the IP range with object_id = p_top_range_id, which will be parent for the IP address with
    * sub-net address <code>p_ address</code>
    *
    * @param p_top_range_id object_id of the IP range to start the search from
    * @param p_address address to find parent for
    * @param p_ip_version <code>2</code> if the IP address to find parent for is IPv6 address, <code>1</code> - for IPv4
    *
    * @return object ids of IP Range which is expected parent for the address with given parameters
    */
  function get_potential_parent_for_addr(
              p_top_range_id    number,
              p_address   number,
              p_ip_version      IP_VERSION_TYPE) return number;

  /**
    * Searches for IP ranges starting from the IP range with object_id = p_top_range_id, which will be parent for the IP address with
    * sub-net address <code>p_ address</code>
    *
    * @param p_top_range_id object_id of the IP range to start the search from
    * @param p_address address to find parent for
    * @param p_ip_version <code>2</code> if the IP address to find parent for is IPv6 address, <code>1</code> - for IPv4
    *
    * @return object ids of IP Ranges which are expected parent for the address with given parameters
    */
  function  get_potential_parents_for_addr(
              p_top_range_id    number,
              p_address         number,
              p_ip_version      IP_VERSION_TYPE) return arrayofnumbers;
  --*** MYOL0102 [14-03-2011] [API: find potential parents for address or range] End

  -- LESO0105 [27/08/2007] [Merge IP Pools] Start
  /**
   * Returns the cursor for the result set, containing single column -
   * unique values of the "Registry" attribute selected from all IP Ranges allocated
   * to the given set of IP Pools
   *
   * @param poolIds Collection of object_ids of IP Pools
   * @return unique values of the "Registry" attribute
   */
  function get_unique_registries(
                                 poolIds ARRAYOFNUMBERS
                                )
                                return ref_cursor;
  -- LESO0105 [27/08/2007] [Merge IP Pools] End

   --*** YUOP0707 [09-07-07][IPPlanner 1.2][Short IPv6 Notation Support] added start
  /**
   * Converts full IPv6 address notation (i.e. HHHH:HHHH:HHHH:HHHH:HHHH:HHHH:HHHH:HHHH) into short one.
   * For example <pre>2001:DB8:0:0:0:0:1428:57AB</pre>
   * will be converted into <pre>2001:DB8::1428:57AB</pre>
   *
   * @param p_addr_str - address or range string both acceptable
   * @return short notation of given address or range string
   */
  function shortV6Notation(p_addr_str varchar2) return varchar2;

  /**
   * Converts short IPv6 address notation (i.e. HHHH::HHHH:HHHH) into full one.
   * For example <pre>2001:DB8::1428:57AB</pre>
   * will be converted into <pre>2001:DB8:0:0:0:0:0:57AB</pre>
   *
   * @param p_addr_str - short address or range string, both acceptable
   * @return full notation of given address or range string
   */
  function fullV6notation(p_addr_str varchar2) return varchar2;
  --*** YUOP0707 [09-07-07][IPPlanner 1.2][Short IPv6 Notation Support] added end

  --*** MIZA06030 [09-24-07][IPPlanner 1.2][Automatic IP Range Assignment Listener] added start
  /**
   * Returns the ref_cursor {(object_id, prefix_value)} of IP Ranges allocated
   * to given IP Pool (and their subranges) having prefix (CIDR) value not greater than p_prefix,
   * ordered by prefix value descending and subnet address
   *
   * @param p_pool_id - object_id of IP Pool to select IP Ranges from
   * @param p_prefix - prefix of searched IP Ranges
   * @return ref_cursor {(object_id, prefix_value)}
   */
  function get_ranges_for_assignment(p_pool_id number, p_prefix number) return ref_cursor;
  --*** MIZA06030 [09-24-07][IPPlanner 1.2][Automatic IP Range Assignment Listener] added end


--***LESO0105 [30/11/2007] [Create IP Planner PL-SQL package for Telstra] Start
  ------------------------------------------------------------------------------
  IP_RNG_OUT_OF_PARENT_RANGE_ERR constant number := -20140;

  IP_RNG_OVERLAPPING_ERR constant number := -20141;
  ------------------------------------------------------------------------------

  /**
   * Checks whether is it allowed to create IP Range with given subnet address and CIDR
   * under the given IP Range.
   *
   * @param p_range_id ID of the IP Range to look in
   * @param p_subnet_addr subnet address of the IP Range to be created
   * @param p_cidr CIDR of the IP Range to be created
   * @param p_object_type_id object_type_id of the IP Range to be created
   * @param p_ip_version IP Version of the IP Range to be created
   * @return 1 - is allowed,
   *         0 - is NOT allowed
   */
  function is_available_address(p_range_id        number,
                                p_subnet_addr     number,
                                p_cidr            number,
                                p_object_type_id  number,
                                p_ip_version      IP_VERSION_TYPE DEFAULT IPv4
            ) return number;


  ------------------------------------------------------------------------------
  /**
   * Checks whether is it allowed to create top range with given subnet address and CIDR
   * under the given Root range.
   *
   * @param p_root_range_id ID of the Root Range of project
   * @param p_subnet_addr subnet address of the IP Range to be created
   * @param p_cidr CIDR of the IP Range to be created
   * @param p_object_type_id object_type_id of the IP Range to be created
   * @param p_ip_version IP Version of the IP Range to be created
   * @return 1 - is allowed,
   *         0 - is NOT allowed
   */
  function is_available_top_range_address(p_root_range_id   number,
                                          p_subnet_addr     number,
                                          p_cidr            number,
                                          p_object_type_id  number,
                                          p_ip_version      IP_VERSION_TYPE DEFAULT IPv4
           ) return number;

  ------------------------------------------------------------------------------

  /**
   * Creates new IP Range with given:
   *  - object_id
   *  - object_type_id
   *  - subnet address
   *  - CIDR
   *  - Description
   * under the specified parent IP Range.
   *
   * @param p_parent_id ID of the parent IP Range
   * @param p_range_id  ID of the IP Range to be created
   * @param p_range_type_id object_type_id of the IP Range to be created
   * @param p_subnet_addr Subnet address of the IP Range to be created
   * @param p_cidr CIDR of the IP Range to be created
   * @param p_description Description of the IP Range to be created
   * @param p_ip_version p_ip_version IP Version of the IP Range to be created (IPv4 by default)
   * @param p_ip_space Space of the IP Range to be created (public by default)
   *
   * @throws ORA-00001 when object with object_id = p_range_id already exists
   * @throws ORA-20140 when IP Range to be imported is out of parent range's bounds
   * @throws ORA-20141 when IP Range to be imported overlaps with existing IP Range
   */
  procedure import_range(p_parent_id           number,
                         p_range_id            number,
                         p_range_type_id       number,
                         p_subnet_addr         number,
                         p_cidr                number,
                         p_description         varchar2,
                         p_ip_version          IP_VERSION_TYPE DEFAULT IPv4,
                         p_ip_space            IP_SPACE_TYPE   DEFAULT SPACE_PUBLIC
            );

--***LESO0105 [30/11/2007] [Create IP Planner PL-SQL package for Telstra] End

--*** LESO0105 [IP01 - IP Supernetting] [25/02/2008] Start

  /**
   * Moves all sub-ranges and IP addresses from the IP ranges to be merged into target IP range.
   * Removes IP ranges to be merged.
   *
   * @param p_target_range_id Target IP range ID
   * @param p_merge_range_ids IDs of IP ranges to be merged
   */
  procedure merge_ranges(p_target_range_id number, p_merge_range_ids arrayofnumbers);

--***ALFE0608 [08-19-2009][Merge operation without remove merged ranges] Start
  /**
   * Moves all the IP ranges to be inserted into inserted IP range.
   * Sink IP addresses from parent of inserted IP range to it.
   *
   * @param p_inserted_range_id inserted IP range ID
   * @param p_merge_range_ids IDs of IP ranges to be merged into inserted IP range
   */
  procedure insert_range(p_inserted_range_id number, p_merge_range_ids arrayofnumbers);
--***ALFE0608 [08-19-2009][Merge operation without remove merged ranges] End

--*** LESO0105 [IP01 - IP Supernetting] [25/02/2008] End

--*** MIZA06030 [02-29-08][IP03] added start
  /**
   * Returns the ref_cursor {(name)} of invisible edge IP Addresses
   * referenced by entities.
   *
   * @param p_range_id - object_id of IP Range to search addresses in
   * @param p_hierarchy         Specifies whether to find all assigned edge IP addresses hierarchically or not.
   *                            1 - hierarchically (default value)
   *                            0 - only first-level IP addresses
   * @return ref_cursor {(name)}
   */
  --***ALFE0608 [07-08-2010][Eliminate hierarchical subqueries in pkgIPPlanner.get_assigned_edge_ips and pkgIPPlanner.sinkAddresses] Start
  --function get_assigned_edge_ips(p_range_id number) return ref_cursor;
  function get_assigned_edge_ips(p_range_id number, p_hierarchy number default 1) return ref_cursor;
--***ALFE0608 [07-08-2010][Eliminate hierarchical subqueries in pkgIPPlanner.get_assigned_edge_ips and pkgIPPlanner.sinkAddresses] End
--*** MIZA06030 [02-29-08][IP03] added end

--*** VYLO0807 [08.04.2008] [Bugs in IP Planner Localization] Start
  /**
   * Used to insert localized names for Top Ranges object
   * Inserts records into nc_nls_objects for object with p_range_id taken from nc_nls_resources
   * for resource with p_resource_id.
   *
   * @param p_range_id object_id of Top Ranges object to insert localized records for
   * @param p_resource_id resource_id of string resouce containing localized names.
   */
  procedure insert_nls_names(p_range_id number, p_resource_id number);
--*** VYLO0807 [08.04.2008] [Bugs in IP Planner Localization] End

/* VYLO0807 [11/20/2008] Start
 * [Merge of IP Range's parameters during 'Merge IP Ranges' operation]
 * [Propagation of IP Range's parameters during 'Split' operation] */
 /**
  * Returns the ref_cursor {(object_id, attr_id)} - objects that have references
  * to given objects.
  *
  * @param p_object_ids array of objects to seek backreferences for
  * @param p_prop nc_attributes.params filter
  * @param p_ismultiple = 1 to filter out onle backreferences from multiple attributes, 0 to ignore multiplicity
  * @return ref_cursor {(object_id, attr_id)}
  */
function get_refs_to_object(p_object_ids arrayofnumbers, p_prop varchar2, p_ismultiple number) return ref_cursor;
/* VYLO0807 [11/20/2008] End
 * [Merge of IP Range's parameters during 'Merge IP Ranges' operation]
 * [Propagation of IP Range's parameters during 'Split' operation] */

--***ALFE0608 [09-07-2009][Change API pkgipplanner.get_refs_to_object] Start
 /**
  * Returns the ref_cursor {(object_id, attr_id)} - objects that have references
  * to given objects.
  *
  * @param p_object_ids array of objects to seek backreferences for
  * @param p_prop nc_attributes.params filter
  * @param p_prop_exclude nc_attributes.params exclude filter
  * @param p_ismultiple = 1 to filter out onle backreferences from multiple attributes, 0 to ignore multiplicity
  * @return ref_cursor {(object_id, attr_id)}
  */
function get_refs_to_object(p_object_ids arrayofnumbers, p_prop varchar2, p_prop_exclude varchar2, p_ismultiple number) return ref_cursor;
--***ALFE0608 [09-07-2009][Change API pkgipplanner.get_refs_to_object] End

  --***VLGR0308 [12.02.2008] ["Next Available IP Range/IP Address" API] [Start]
  /**
   * Returns the ref_cursor of available IP addresses from specified IP range
   *
   * @param p_range_id - object_id of IP range to select IP addresses from
   * @param p_how_many - requires number of IP addresses
   * @return ref_cursor {(addr, object_id, parent_id)}
   */
  function get_avail_addr_list (p_range_id number, p_how_many number) return ref_cursor;

  /**
   * Returns the ref_cursor of available IP ranges allocated to specified IP pool
   *
   * @param p_pool_id - object_id of IP pool to select IP ranges belong to
   * @paran p_prefix_length - IP range prefix length
   * @param p_how_many - requires number of IP ranges
   * @return ref_cursor {(object_id)}
   */
  function get_avail_ranges_list (p_pool_id number, p_prefix_length number, p_how_many number) return ref_cursor;
  --***VLGR0308 [12.02.2008] ["Next Available IP Range/IP Address" API] [End]
--*** MIZA0603 [2009-03-17] [IPManager.recallAddresses API] Start
  /**
   * Wipes out persistent addresses under given range
   * (and its subranges) within given boundaries inclusive.
   * To be used when creating IP folder-type subrange and during IP range to IP Folder transition.
   *
   * @param p_range_id object_id of IP range object to clean addresses under
   * @param p_left_addr left boundary address in numeric format
   * @param p_right_addr right boundary address in numeric format
   * @param p_hierarchical indicates whether address deletion to be performed only
   *                        in p_range_id (0) or in p_range_id and its subranges (1).
   */
  procedure recall_addresses(p_range_id number, p_left_addr number, p_right_addr number, p_hierarchical number);
--*** MIZA0603 [2009-03-17] [IPManager.recallAddresses API] End

--***ALSK0708 [2009-03-25] [Seek Range functionality] Start
  /**
  * Returns the number of the page block of ip ranges that contains ip range
  * that most near by name to p_address_mask. Comparing executes with 'like' operator.
  * This function is for navigation under Top Ranges and Subranges but not under Terminal Ranges
  *
  * @param p_range_id object_id of range under that determines p_address_mask position
  * @param p_address_mask string representation of ip range that containce '%' instead of empty octets
  * @return the number of the block - if there is a ip range that satisfy the p_address_mask
  *         0 - if there is no it
  */
--***ARAR0512 [14.02.2013] [CR IPv6 Improvement PDCR-2257] Start
--  function get_range_num_by_name(p_range_id number, p_address_mask varchar2) return number;
--***ARAR0512 [14.02.2013] [CR IPv6 Improvement PDCR-2257] End
  /**
  * Returns the number of the page block of terminal ip ranges that contains ip range
  * that most near by name to p_address_mask. Comparing executes with 'like' operator.
  * This function is for navigation only under Terminal Ranges
  *
  * @param p_project_id object_id of project under that determines p_address_mask position
  * @param p_address_mask string representation of ip range that containce '%' instead of empty octets
  * @return the number of the block - if there is a terminal ip range that satisfy the p_address_mask
  *         0 - if there is no it
  */
  function get_terminal_range_num_by_name(p_project_id number, p_address_mask varchar2) return number;

  /**
  * Returns the number of the page block of ip ranges that contains ip range
  * that most near by subnet address attribute value to p_address. Comparing executes
  * with find of subtraction between p_address and other ip ranges under the p_range_id.
  * This function is for navigation under Top Ranges and Subranges but not under Terminal Ranges
  *
  * @param p_range_id object_id of range under that determines p_address position
  * @param p_address number that define desired subnet address
  * @return the number of the block with the least difference
  */
--***ARAR0512 [14.02.2013] [CR IPv6 Improvement PDCR-2257] Start
  --function get_range_num_by_address(p_address number, p_range_id number) return number;
--***ARAR0512 [14.02.2013] [CR IPv6 Improvement PDCR-2257] End
  /**
  * Returns the number of the page block of terminal ip ranges that contains ip range
  * that most near by subnet address attribute value to p_address. Comparing executes
  * with find of subtraction between p_address and other terminal ip ranges in the the p_project_id project.
  * This function is for navigation only under Terminal Ranges
  *
  * @param p_project_id object_id of project under that determines p_address position
  * @param p_address number that define desired subnet address
  * @return the number of the block with the least difference
  */
  function get_terminal_range_num_by_addr(p_address number, p_project_id number) return number;


  /**
  * Returns the quantity of subranges of specified classes excluding specified types under ip range id = parentRange.
  * This function is for count ip ranges under Top Ranges and Subranges but not under Terminal Ranges
  *
  * @param p_parent_id object_id of range under that counts subranges
  * @param p_types arrayofnumbers of ids of object classes which should be counted
  * @param p_excluded_types arrayofnumbers of ids of object types which should be excluded
  * @return quantity of ip ranges
  */
  function count_subranges_number(
      p_parent_id   number,
      p_types arrayofnumbers default arrayofnumbers(CLASS_ID__IPv4_RANGE, CLASS_ID__IPv6_RANGE),
      p_excluded_types arrayofnumbers default null)
      return number;
  /**
  * Returns the quantity of terminal ip ranges.
  * This function is for count only under Terminal Ranges
  *
  * @param p_project_id object_id of project under that counts terminal ip ranges
  * @return quantity of terminal ip ranges
  */
  function count_terminal_ranges_number(p_project_id number) return number;
--***ALSK0708 [2009-03-25] [Seek Range functionality] End

--***ARAR0512 [14.02.2013] [CR IPv6 Improvement PDCR-2257] Start
  /**
  * Returns the number of the page block of ip ranges that contains ip range
  * that most near by name to p_address_mask. Comparing executes with 'like' operator.
  * This function is for navigation under Top Ranges and Subranges but not under Terminal Ranges
  *
  * @param p_range_id object_id of range under that determines p_address_mask position
  * @param p_address_mask string representation of ip range that containce '%' instead of empty octets
  * @param p_types array of ids of object types which should be present on page
  * @param p_excluded_types array of ids of object types which should be absent on page
  * @return the number of the block - if there is a ip range that satisfy the p_address_mask
  *         0 - if there is no it
  */
  function get_range_num_by_name(p_range_id number,
                                 p_address_mask varchar2,
                                 p_types arrayofnumbers default new arrayofnumbers(14001),
                                 p_excluded_types arrayofnumbers default new arrayofnumbers()
                                ) return number;

/**
  * Returns the number of the page block of ip ranges that contains ip range
  * that most near by subnet address attribute value to p_address. Comparing executes
  * with find of subtraction between p_address and other ip ranges under the p_range_id.
  * This function is for navigation under Top Ranges and Subranges but not under Terminal Ranges
  *
  * @param p_range_id object_id of range under that determines p_address position
  * @param p_address number that define desired subnet address
  * @param p_types array of ids of object types which should be present on page
  * @param p_excluded_types array of ids of object types which should be absent on page
  * @return the number of the block with the least difference
  */
  function get_range_num_by_address(p_address number,
                                    p_range_id number,
                                    p_types arrayofnumbers default new arrayofnumbers(14001),
                                    p_excluded_types arrayofnumbers default new arrayofnumbers()
                                   ) return number;
 --***ARAR0512 [14.02.2013] [CR IPv6 Improvement PDCR-2257] End

--*** MIZA0603 [01-04-09][pkgIPPlanner.sinkAddresses times out when splitting Top Range] added start
  /**
   * Sinks persistent addresses from root range into provided Top Ranges
   *
   * @param p_target_top_ids - object_ids of Top Ranges to sing addresses into
   */
  procedure sinkAddressesFromRoot(
    p_target_top_ids arrayofnumbers
  );
--*** MIZA0603 [01-04-09][pkgIPPlanner.sinkAddresses times out when splitting Top Range] added end

--*** MIZA0603 [2009-04-05] [Restrict Overlapping: Checking API] start
  /**
   * Checks overlapping restriction inside given IP range i.e. checks if there
   * is an IP range that overlaps with IP ranges having Restrict Overlapping attribute set to True.
   *
   * @param p_range_id object_id of IP range to check overlapping restriction integrity in
   * @return 0 if restriction is OK and if not - object_id of IP range whose restriction has been violated
   */
  function check_overlapping_restriction (p_range_id number) return number;

  /**
   * Checks presence of IP subrange with Restrict Overlapping attribute set to True inside given IP range.
   *
   * @param p_range_id object_id of IP range to look for restricted subranges in
   * @return 0 if there is no such subranges and object_id of IP subrange having restriction set otherwise
   */
  function check_restriction_presence(p_range_id number) return number;
--*** MIZA0603 [2009-04-05] [Restrict Overlapping: Checking API] end

--*** MIZA0603 [2009-04-13] [TreeNavAdapter for IP Ranges] start
  -- three functions incapsulating queries for tree-ctrl
  function get_treectrl_branch(p_range_id number) return ref_cursor;
  function get_treectrl_children(p_range_id number, p_start number, p_end number) return ref_cursor;
  function get_treectrl_search_results(p_range_id number, p_what varchar2, p_limit number) return ref_cursor;
--*** MIZA0603 [2009-04-13] [TreeNavAdapter for IP Ranges] end
  --*** MIZA0603 [2009-04-29] [byStrings creation API] start
  /**
   * Performs consistency checks and then bulk insertion of
   * IP ranges or addresses objects by previusly prepared data in format of arrayofstrings.
   *
   * @param p_enitiy_kind - 1 to create IP ranges, 0 for IP addresses
   * @param p_host_id - object_id of IP range to find appropriate parent ranges and host newly created ranges in
   * @param p_type_id - object_type_id of IP entities to create
   * @param p_best_effort - 1 to keep working on errors, 0 to bail out
   * @param p_user_name - user name for Modification Info group attributes
   * @param p_info_arr - main data parameter, contains pipe ('|') separated string
                         with arguments required for creation and validation processes.
                         Format goes like: 'keyString|subnetAddrNum|broadcastAddrNum|prefix|is_loopback|'
   * @return ref_cursor {(name, object_id, parent_id, is_created, overlapper_id, assigned_edge_id)}
   */
  function bulk_create_entities_by_str(
    p_enitiy_kind number,
    p_host_id number,
    p_type_id number,
    p_best_effort number,
    p_user_name varchar2,
    p_info_arr arrayofstrings
  ) return ref_cursor;
  --*** MIZA0603 [2009-04-29] [byStrings creation API] end

  --*** MIZA0603 [2009-05-16] [byStrings lookup API] start
  /**
   * Returns cursor of IP address object_ids (including virtual ones) for
   * addresses parsed from previously prepared data in format of arrayofstrings and spanned by IP range with p_host_id.
   *
   * @param p_host_id - object_id of IP range to lookup persistent and scout for parents of virtual addresses in
   * @param p_info_arr - main data parameter, contains pipe ('|') separated string
   *                     with arguments required for search processes.
   *                     Format goes like: 'keyString|subnetAddrNum|'
   * @return ref_cursor {(name, object_id)}
   */
  function lookup_addresses_by_str(p_host_id number, p_info_arr arrayofstrings)
  return ref_cursor;

  /**
   * Returns cursor of IP sub-ranges object_ids for
   * ranges parsed from previously prepared data in format of arrayofstrings and contained in IP range with p_host_id.
   *
   * @param p_host_id - object_id of IP range to lookup sub-ranges under
   * @param p_info_arr - main data parameter, contains pipe ('|') separated string
   *                     with arguments required for search processes.
   *                     Format goes like: 'keyString|subnetAddrNum|'
   * @return ref_cursor {(name, object_id)}
   */
  function lookup_ranges_by_str(p_host_id number, p_info_arr arrayofstrings)
  return ref_cursor;
  --*** MIZA0603 [2009-05-16] [byStrings lookup API] end

  --*** MIZA0603 [2010-01-22] [Forwardport of pkgIPPlanner.sinkAddressesCascade] start
 /**
   * Sink persistent addresses from range into subranges hierarchically
   *
   * @param range_id            Range ID
   * @param p_delete_foldered   flag allowing to stop when IP addresses-IP folders data conflict encountered.
   *                            Use 0 - to enable check, default 1 - will auto resolve conflict by deleting IP addresses
   *                            which will fall into IP folder.
   */
  procedure sinkAddressesCascade (
    p_range_id                  number,
    p_delete_foldered           number default 1
  );
  --*** MIZA0603 [2010-01-22] [Forwardport of pkgIPPlanner.sinkAddressesCascade] end

  --*** MIZA0603 [2010-02-17] [IPManager.getRanges crashes IP Range Assignment dialog] start
  /**
   * Returns list of IP pool's object_ids for given project_id
   * List ordered by value of subnet address.
   *
   * @param p_project_id object_id of IP Pool to check IP ranges in
   * @param p_is_v6 tells pools having ranges of which IP version ranges to seek (1 - look for IPv6, 0 - for IPv4)
   * @return object_ids as arrayofnumbers
   */
  function get_pools_by_ipv(p_project_id number, p_is_v6 number) return arrayofnumbers;

  /**
   * Returns list of IP range's object_ids which allocated to given IP pool.
   * List ordered by value of subnet address.
   *
   * @param p_pool_id to return ranges from
   * @param p_is_v6 tells which IP version ranges to take (1 - look for IPv6, 0 - for IPv4)
   * @param p_limit to limit amount of returned object_ids
   * @return object_ids as arrayofnumbers
   */
  function get_ranges_from_pool(p_pool_id number, p_is_v6 number, p_limit number) return arrayofnumbers;

  /**
   * Count IP ranges of certain IP version allocated to given IP pool.
   * List ordered by value of subnet address.
   *
   * @param p_pool_id to return ranges from
   * @param p_is_v6 tells which IP version ranges to count (1 - look for IPv6, 0 - for IPv4)
   * @return object_ids as arrayofnumbers
   */
  function count_ranges_in_pool(p_pool_id number, p_is_v6 number) return number;
  --*** MIZA0603 [2010-02-17] [IPManager.getRanges crashes IP Range Assignment dialog] end

  --*** EVKA0310 [01-12-10][Detailed warning message about extra IP addresses in IP Merge dialog] added Start
  /**
   * Return detailed information about extra boundaries of ranges in merge dialog
   *
   * @param p_range_id           ID of parent range
   * @param p_left_addr          Left address
   * @param p_right_addr         Right address
   */
  function get_gaps_for_ranges (
    p_left_addr                 number,
    p_right_addr                number,
    p_version                   IP_VERSION_TYPE,
    p_cidr                      number,
    p_range_ids                 arrayofnumbers
  )
  return ref_cursor;
  --*** EVKA0310 [01-12-10][Detailed warning message about extra IP addresses in IP Merge dialog] added End
end pkgIPPlanner;
/
