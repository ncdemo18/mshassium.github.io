CREATE PACKAGE pkgNCObjectParams
AS

	/*Special RECORD TYPE. Used to select CLOB parameters*/
	TYPE clob_rec IS RECORD (
		object_id nc_objects.object_id%TYPE,
		attr_id nc_attributes.attr_id%TYPE,
		rClob CLOB,
		numValue NUMBER(10),
		showOrder NUMBER(10),
		extVal NUMBER(10),
        --Added 09/15/04 by DMANSDG Parameters Flags
		accessType NUMBER(10)
		);


	TYPE clob_cur IS REF CURSOR RETURN clob_rec;

	/* This procedure clears inner collections in the package */
	PROCEDURE clearAllCollections;

	/* This procedure inserts new parameters for object based on inner collections which contain
	required values for parameters*/
	PROCEDURE processInsParameters(
		objectID IN nc_objects.object_id%TYPE
	);

	/* This procedure updates parameters for object based on inner collections which contain
	required values for parameters*/
	PROCEDURE processUpdParameters(
		objectID IN nc_objects.object_id%TYPE
	);

	/* This procedure deletes parameters for object based on inner collections content */
	PROCEDURE processDelParameters(
		objectID IN nc_objects.object_id%TYPE
	);

	/* This procedure fills internal collections for TEXT type parameters. */
	PROCEDURE fillInsertCollection(
		attrID IN nc_attributes.attr_id%TYPE,
		insValue IN nc_params.value%TYPE,
		attrTypeID IN nc_attributes.attr_type_id%TYPE,
		isMultiple IN nc_attributes.ismultiple%TYPE,
		aPriority IN nc_params.priority%TYPE,
        --Added 09/15/04 by DMANSDG Parameters Flags
		aAccessType IN nc_params.attr_access_type%TYPE
	);

	/* This procedure fills internal collections for DATE type parameters. */
	PROCEDURE fillInsertCollection(
		attrID IN nc_attributes.attr_id%TYPE,
		insValue IN nc_params.date_value%TYPE,
		attrTypeID IN nc_attributes.attr_type_id%TYPE,
		isMultiple IN nc_attributes.ismultiple%TYPE,
		aPriority IN nc_params.priority%TYPE,
        --Added 09/15/04 by DMANSDG Parameters Flags
		aAccessType IN nc_params.attr_access_type%TYPE
	);

	/* This procedure fills internal collections for NUMBER type parameters. */
	PROCEDURE fillInsertCollection(
		attrID IN nc_attributes.attr_id%TYPE,
		insValue IN NUMBER,
		attrTypeID IN nc_attributes.attr_type_id%TYPE,
		isMultiple IN nc_attributes.ismultiple%TYPE,
		aPriority IN nc_params.priority%TYPE,
        --Added 09/15/04 by DMANSDG Parameters Flags
		aAccessType IN nc_params.attr_access_type%TYPE
	);

	/* This procedure fills internal parameter collections depends on what type of attribute is specified. */
	PROCEDURE fillInsertCollection(
		attrID IN nc_attributes.attr_id%TYPE,
		insValue IN nc_params.value%TYPE,
		insNumber IN NUMBER,
		insDate IN nc_params.date_value%TYPE,
		attrTypeID IN nc_attributes.attr_type_id%TYPE,
		isMultiple IN nc_attributes.ismultiple%TYPE,
		aPriority IN nc_params.priority%TYPE,
        --Added 09/15/04 by DMANSDG Parameters Flags
		aAccessType IN nc_params.attr_access_type%TYPE
	);

	/* This procedure insert parameter attribute which will be deleted from the database for the specified object */
	PROCEDURE fillDeletedCollection(
		attrID IN nc_attributes.attr_id%TYPE,
		attrTypeID IN nc_attributes.attr_type_id%TYPE
	);

	/* This procedure returns CLOB data for specified object and attribute */
	PROCEDURE getClob(
		attrID IN nc_params.attr_id%TYPE,
		objectID IN nc_params.object_id%TYPE,
		priorityIN IN nc_params.priority%TYPE,
		refClob OUT NOCOPY CLOB
	);

  PROCEDURE setClob(
    attrID IN nc_params.attr_id%TYPE,
    objectID IN nc_params.object_id%TYPE,
    priorityIN IN nc_params.priority%TYPE,
    refClob IN CLOB
  );

	/* This procedure returns primary parameter data for the specified object */
	FUNCTION selectParameters(
		objectID IN nc_objects.object_id%TYPE
	) RETURN clob_cur;

	/* This procedure returns secondary parameter data for the specified object */
	FUNCTION selectSecondaryParameters(
		objectID IN nc_objects.object_id%TYPE
	) RETURN clob_cur;

	PROCEDURE fetchParameters(
		objectID OUT NOCOPY nc_objects.object_id%TYPE,
		attrID OUT NOCOPY nc_attributes.attr_id%TYPE,
		val OUT NOCOPY nc_params.value%TYPE,
		listVal OUT NOCOPY nc_params.list_value_id%TYPE,
		dateVal OUT NOCOPY nc_params.date_value%TYPE,
		val3 OUT NOCOPY nc_objects.object_type_id%TYPE,
		showOrder OUT NOCOPY nc_params.show_order%TYPE,
		extVal OUT NOCOPY nc_attributes.flags%TYPE,
        --Added 09/15/04 by DMANSDG Parameters Flags
        accessType OUT NOCOPY nc_params.attr_access_type%TYPE
	);

	/* This function returns parameters cursor for object ids inserted into temporary table
	nc$_temp_ids */
	FUNCTION bulkLoadingParams
	RETURN pkgNCObject.ref_cur;

	FUNCTION bitandWrap(
		arg1 IN INTEGER,
		arg2 IN INTEGER)
	RETURN INTEGER;

	FUNCTION emptyclobWrap
	RETURN CLOB;

	FUNCTION bulkLoadingParams(
		attrList VARCHAR2
	)
	RETURN pkgNCObject.ref_cur;

	PROCEDURE bulkLoadingParamsOrd (
		ordParams OUT NOCOPY pkgNCObject.ref_cur
	);

	PROCEDURE bulkLoadingAllParamsOrd (
		ordParams OUT NOCOPY pkgNCObject.ref_cur
	);
	PROCEDURE bulkLoadingParamsOrdByIDs (
		attrIDs		IN varchar2,
		ordParams OUT NOCOPY pkgNCObject.ref_cur
	);

	PROCEDURE bulkLoadingParamsOrdWOClobs (
		ordParams OUT NOCOPY pkgNCObject.ref_cur
	);

	PROCEDURE bulkLoadingParamsRef (
		refParams OUT NOCOPY pkgNCObject.ref_cur
	);
	PROCEDURE bulkLoadingAllParamsRef (
		refParams OUT NOCOPY pkgNCObject.ref_cur
	);
	PROCEDURE bulkLoadingParamsRefByIDs (
		attrIDs IN varchar2,
		refParams OUT NOCOPY pkgNCObject.ref_cur
	);

END;
/
