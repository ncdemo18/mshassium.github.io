CREATE package pkgNCQueue_LCM_Queue is

  SUCCESS number(1) := 0;
  UNSUCCESS number(1) := 1;

  IGNORE_UNIQUENESS number(1) := 1;
  THROW_ERROR_UNIQUENESS number(1) := 2;
  REPLACE_UNIQUENESS number(1) := 3;

  procedure acquireNextMessage(messageID in out number, cachedID in number, createdWhen out timestamp, priority in out number, targetListener out varchar2, sequence in out number, orderNum out number, uniqueKey out varchar2, nodeName out varchar2, status out number, trackMessageIsProcessing in int, removeImmediately in int , EventId out varchar2, ObjectId out number, ObjectTypeId out number, AdapterName out varchar2, Event out clob, ContextAlias out varchar2);

  procedure storeMessage(messageID out number, createdWhen out timestamp, priority in number, targetListener in varchar2, sequence in number, orderNum in number, uniqueKey in varchar2, uniqueType in number, nodeName in varchar2, status in number , EventId in varchar2, ObjectId in number, ObjectTypeId in number, AdapterName in varchar2, Event in clob, ContextAlias in varchar2);

  procedure storeMessage2(messageID in number, createdWhen in timestamp, priority in number, targetListener in varchar2, sequence in number, orderNum in number, uniqueKey in varchar2, uniqueType in number, nodeName in varchar2, status in number , EventId in varchar2, ObjectId in number, ObjectTypeId in number, AdapterName in varchar2, Event in clob, ContextAlias in varchar2);

  procedure storeMessageSync(messageID out number, createdWhen out timestamp, priority in number, targetListener in varchar2, sequence in number, orderNum in number, uniqueKey in varchar2, uniqueType in number, nodeName in varchar2, status in number , EventId in varchar2, ObjectId in number, ObjectTypeId in number, AdapterName in varchar2, Event in clob, ContextAlias in varchar2);

  procedure deleteMessageSync(messageID in number);

  procedure removeMessage(messageID in number);

  procedure storeErrorRecord(errorID out number, messageID in number, messageName in varchar2, messageType in number, errorName in varchar2, errorRecordType in number, queueID in number, exceptionClass in varchar2, stackTrace in clob);

  procedure retryMessage(errorID in number, messageID out number, priority out number, sequence out number);

  function getWaitingMessageCount return int;

  procedure clear (countBusy out int, skipBusy IN int :=1);

  procedure clear;

  procedure clearSequence(sequence in number,countBusy out int, skipBusy IN int :=1);

  procedure clearSequence(sequence in number);

  procedure suspendSequence(sequenceId in number);

  procedure resumeSequence(sequenceId in number);

  procedure deleteMessages(ids in arrayofnumbers, countBusy out int, skipBusy IN int :=1);

  procedure deleteMessages(ids in arrayofnumbers);

  procedure acquireLock(lockID in number);

  procedure releaseLock(lockID in number);

  procedure setMessageStatus(messageId in number, statusId in number);

end pkgNCQueue_LCM_Queue;
/
