CREATE PACKAGE pkgSFProfiles
IS
	procedure clean_profiles;
END pkgSFProfiles;
/
