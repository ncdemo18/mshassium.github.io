CREATE package pkg_geometry as
  procedure set_geometry(id nc_spatial.object_id%type, geom mdsys.sdo_geometry);
end pkg_geometry;
/
