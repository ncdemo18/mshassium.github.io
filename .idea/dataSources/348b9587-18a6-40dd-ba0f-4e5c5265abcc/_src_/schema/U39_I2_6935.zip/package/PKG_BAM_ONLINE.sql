CREATE package PKG_BAM_ONLINE is

  LOCAL varchar2(30):='LOCAL';
  REMOTE varchar2(30):='REMOTE';
  KPI_CONFIG_KEY varchar2(30):='nc.bam.kpi_config';
  KPI_SCHEMA_KEY varchar2(30):='nc.bam.kpi_schema';
  KPI_DBLINK_KEY varchar2(30):='nc.bam.kpi_dblink';

  /*
  function can be used to get first item from comma separated list of varchar
  */
  function get_first_varchar(
      var1 in varchar2,
      var2 in varchar2 default null,
      var3 in varchar2 default null,
      var4 in varchar2 default null,
      var5 in varchar2 default null,
      var6 in varchar2 default null,
      var7 in varchar2 default null,
      var8 in varchar2 default null,
      var9 in varchar2 default null,
      var10 in varchar2 default null
      ) return varchar2;

   /*
   procedure deletes trigger. if trigger doesn't exist- nothing is done.
   */
   procedure dropTrigger(trigger_name in varchar2);

   procedure disableTrigger(trigger_name in varchar2);

   /*
   procedure recompiles and enables trigger.
   */
   procedure enableTrigger(trigger_name in varchar2);

   /*
   tries to acquire exclusive lock for activity definition. Lock doesn't directly lock
   tables or rows- lock object is used. If lock is acquired- procedure immediately returns. Otherwise
   (if lock can't be acquired)- exception is thrown. Proceduer doesn't wait until lock is acquired.
   Lock is automatically released on commit or rollback
   activity_refinition_id- number isn't checked on size etc
   */
   procedure acquireExclusiveLock(activity_refinition_id in number);

   /*
     create new synonim for specified object name
   */
   procedure createSynonym(synonym_name in varchar2, object_name in varchar2, full_name in varchar2);

   procedure dropSynonym(synonym_name in varchar2);

   procedure dropLCRDispatcher(dispatcher_name in varchar2);

   procedure dropPackage(package_name in varchar2);

end PKG_BAM_ONLINE;
/
