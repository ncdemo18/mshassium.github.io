CREATE package PKG_CIA_TTM_MANAGEMENT is
  procedure cleanup_old_incident_tickets(days in integer := 90);
  function get_url_path(object_id number) return varchar2;

end PKG_CIA_TTM_MANAGEMENT;
/
