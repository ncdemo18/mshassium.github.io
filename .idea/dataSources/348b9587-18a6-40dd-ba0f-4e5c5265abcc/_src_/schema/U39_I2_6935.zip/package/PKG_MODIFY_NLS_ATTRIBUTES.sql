CREATE PACKAGE pkg_modify_nls_attributes IS

 function modify_nls_attributes(name in varchar2, attr in number, lang in number) return NUMBER;
--DMSH0811 [Jul-24-2012] [[QA] Impossible to change value of French in <Localization options> dialog] Start
 function modify_nls_attr_groups(name in varchar2, attr_group in number, lang in number) return NUMBER;
 function modify_nls_attr_schema(name in varchar2, attr_schema in number, lang in number) return NUMBER;
 function modify_nls_list_value(name in varchar2, list_value in number, lang in number) return NUMBER;
 function modify_nls_object_type(name in varchar2, object_type in number, lang in number) return NUMBER;
--DMSH0811 [Jul-24-2012] [[QA] Impossible to change value of French in <Localization options> dialog] End

END PKG_MODIFY_NLS_ATTRIBUTES;
--TASO1109 [13-12-2010] [Error if want save language value.update] 1 row
/
