CREATE package pkgWFProcessData is
procedure getfindprochierarchyUp(processes in out arrayofnumbers,includeGroup number);
procedure getfindprochierarchyDown(processes in out arrayofnumbers,topproc arrayofnumbers,includeAsynch number);
procedure getinformparents(processes in out arrayofnumbers, silent arrayofnumbers);
procedure getinformparentsSilent(processes in out arrayofnumbers);
procedure deleteUnusedHierarchy;

end pkgWFProcessData;
/
