CREATE PACKAGE pkgStartup
AS

	PROCEDURE setSessionParameters;

END pkgStartup;
/
