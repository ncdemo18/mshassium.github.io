CREATE package pkgsearch_update as

  -------------------- CONSTANTS

  	sp_type_id                  constant integer := 5011747956013640317;
	search_sets_attr_id         constant integer := 22;

	empty_version        constant varchar2(20) := 'empty';
	version0             constant varchar2(20) := '6.0';
	version1             constant varchar2(20) := '7.0';
	version2             constant varchar2(20) := '7.1.1.1';
	version2_subversions constant list := list('7.1.1.1',
                                             '7.1.1.2',
                                             '7.1.1.3',
                                             '7.1.1.4');
	version3             constant varchar2(20) := '7.2.2.0';
	version3_9           constant varchar2(20) := '7.3.3.9';
	version3_12          constant varchar2(20) := '7.3.3.12';
	version8_0           constant varchar2(20) := '8.0.3.33';
	final_version        constant varchar2(20) := version8_0;

	invalid_version exception;
	no_such_profile exception;
	no_22_parameter exception;

	type attrlist is table of varchar2(30);
	type paramlist is table of varchar2(1000);



/*----------------------------------------------------------------------------
  NAME
    getProfileVersion()
  FUNCTION
    Identifies version of Search Profile
  PARAMETERS
    profileId (IN) - nc_object_id of Search profile which version needs to be
                     identified
  RETURNS
    Version of profile
  NOTES
    prototype procedure for getting profile version
  ----------------------------------------------------------------------------*/
	function getprofileversion(profileid in integer) return varchar2;

  	  -- prototype procedure for setting profile version
	procedure setprofileversion(profileid in integer, version in varchar2);


	-- prototype procedure for comparing versions
	function compareversions(version1 in varchar2, version2 in varchar2) return integer;

	function makenode(	doc dbms_xmldom.domdocument,
						parentnode dbms_xmldom.domnode,
						nodename   varchar2,
						attr       attrlist,
						params     paramlist) return dbms_xmldom.domnode;


	/*----------------------------------------------------------------------------
	NAME
		upgrade_all_6_to_7()
	FUNCTION
		Converts all Search profiles in system from version 6.0 and lower to version 7.0
	PARAMETERS
		replaceProfiles (IN) - if TRUE then profiles will be replaced by their elder
							analogues if necessary
	NOTES
		prototype procedure for upgrading all profiles from version 6.0 to version 7.0
	----------------------------------------------------------------------------*/
	procedure upgrade_all_6_to_7(replaceprofiles boolean);



    /*----------------------------------------------------------------------------
    NAME
      upgrade_7_0_to_7_1_1_1()
    FUNCTION
      Converts desired profile from version 7.0 to 7.1.1.1 if given version
      is 7.0
    PARAMETERS
      profileId     (IN) - nc_object_id of converting Search profile
      versionNumber (IN) - version of converting profile
    NOTES
      prototype procedure for upgrading desired profile from version 7.0 to version 7.1.1.1
    ----------------------------------------------------------------------------*/
	procedure upgrade_7_0_to_7_1_1_1(profileid in integer, versionnumber in out varchar2);




	/*----------------------------------------------------------------------------
      NAME
        upgrade_7_1_1_1_to_7_2_2_0()
      FUNCTION
        Converts desired profile from version 7.1.1.1  to 7.2.2.0 if given version
        is 7.1.1.1
      PARAMETERS
        profileId     (IN) - nc_object_id of converting Search profile
        versionNumber (IN) - version of converting profile
      NOTES
        prototype procedure for upgrading desired profile from version 7.1.1.1  to version 7.2.2.0
    ----------------------------------------------------------------------------*/
    procedure upgrade_7_1_1_1_to_7_2_2_0(profileid integer, version in out varchar2);



	/*----------------------------------------------------------------------------
	NAME
		upgrade_7_2_to_7_3
	PROCEDURE
		Converts desired profile from version 7.2 to 7.3 if given version
    is 7.2
	----------------------------------------------------------------------------*/
	procedure upgrade_7_2_to_7_3(profileid in number, version in out varchar2);



	/*----------------------------------------------------------------------------
	NAME
		upgrade_7_3_to_8_0
	PROCEDURE
		Converts desired profile from version 7.3 to 8.0 if given version.
		replace useWildcards and CaseSensitive criteria from <SearchCriterion> tag to <Search_profile>
    is 7.3
	----------------------------------------------------------------------------*/
	procedure upgrade_7_3_to_8_0(profileid in number, version in out varchar2);


end pkgsearch_update;
/
