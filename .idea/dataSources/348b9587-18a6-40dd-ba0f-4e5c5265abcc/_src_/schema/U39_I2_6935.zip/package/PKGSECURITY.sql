CREATE package pkgsecurity
is
    --*** SECH0707 [03.07.08][pkgSecurity.getObjectsToLoad explicit casting can cause function failure] Start
    -- function getobjectstoload( objectids in arrayofnumbers) return arrayofnumbers;
    function getObjectsIDsToLoad( objectids in arrayofnumbers) return arrayofnumbers;
    --*** SECH0707 [03.07.08][pkgSecurity.getObjectsToLoad explicit casting can cause function failure] End

     procedure delete_unused_grants;

end;
/
