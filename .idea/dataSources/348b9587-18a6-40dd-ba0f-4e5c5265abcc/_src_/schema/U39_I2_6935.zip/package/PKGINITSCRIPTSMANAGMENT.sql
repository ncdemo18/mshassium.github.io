CREATE PACKAGE pkgInitScriptsManagment
AS
        main_script     varchar2(1000)  := '//Main initial script
    NCObjectManager = Packages.com.netcracker.ejb.wf.engine.tools.services.NCObjectManager;
    sys = NCObjectManager;
    Logger = Packages.com.netcracker.ejb.framework.Logger.getCoreLog();
    BigInteger = Packages.java.math.BigInteger;
    ReferenceResolver = Packages.com.netcracker.ejb.core.ReferenceResolver;
    ScriptingProjectClass = new JSClass("ScriptingProject","com.netcracker.platform.scripting.impl.js.host.ScriptingProject");
//Java Script NC Host Object
    JSNCObjectClass = new JSClass("JSNCObject","com.netcracker.platform.scripting.impl.js.host.JSNCObject");';


        objId           NUMBER(20)      := 5092850159013845029;
        attrId          NUMBER(20)      := 5090871468013259348;

        PROCEDURE insertScriptClause (
            p_clause IN varchar2
        );

        PROCEDURE updateScriptClause (
             p_old_clause IN varchar2
           , p_new_clause IN varchar2
        );

       PROCEDURE deleteScriptClause (
             p_clause IN varchar2
        );

        PROCEDURE installConfig;

        function make_configuration_clob return clob ;

END pkgInitScriptsManagment;
/
