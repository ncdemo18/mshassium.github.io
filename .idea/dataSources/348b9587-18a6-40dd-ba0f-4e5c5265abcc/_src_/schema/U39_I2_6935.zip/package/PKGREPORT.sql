CREATE PACKAGE pkgReport
IS
   FUNCTION getpath (
      p_object_id            NUMBER,
      separator              VARCHAR2,
      is_url                 NUMBER,
      url_prefix             VARCHAR2,
      last_object_class_id   NUMBER,
      last_object_include    NUMBER
   )
      RETURN VARCHAR2;
END;



/
