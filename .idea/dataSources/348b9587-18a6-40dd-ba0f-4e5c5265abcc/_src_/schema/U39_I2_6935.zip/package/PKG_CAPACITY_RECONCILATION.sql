CREATE package pkg_capacity_reconcilation is


    procedure  upd_cm_tables_after_integrat(documentid number);

end pkg_capacity_reconcilation;
/
