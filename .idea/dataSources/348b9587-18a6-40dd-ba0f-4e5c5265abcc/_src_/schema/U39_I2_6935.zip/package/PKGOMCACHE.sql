CREATE package pkgOMCache as
  procedure ensure_attrs(p_object_type_id number, p_attr_schema_id number);
  procedure ensure_attrs_tx(p_values_to_ensure tableof2numbers);
  procedure clear_cache;
end;
/
