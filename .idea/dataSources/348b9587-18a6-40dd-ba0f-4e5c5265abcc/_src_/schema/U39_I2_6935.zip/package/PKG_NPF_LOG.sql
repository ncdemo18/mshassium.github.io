CREATE PACKAGE PKG_NPF_LOG AS
  TYPE ref_cursor IS REF CURSOR;
  /* Severities of message */
  MSG_ERROR     constant int := 1;
  MSG_WARNING   constant int := 2;
  MSG_INFO      constant int := 3;

  FUNCTION hasErrors(task_id number) RETURN int;
  FUNCTION is_msg_level(check_level int) RETURN int;
  FUNCTION get_log_messages(task_id number) RETURN ref_cursor;
  FUNCTION get_log_messages(task_id number, in_severity number) RETURN ref_cursor;
  FUNCTION get_last_message(task_id number, in_severity number) RETURN ref_cursor;

  PROCEDURE init_log;
  PROCEDURE set_msg_level(new_level int);
  PROCEDURE add_log_message(severity number, task_id number, item_num number, incident_code number, params varchar2);

END PKG_NPF_LOG;
/
