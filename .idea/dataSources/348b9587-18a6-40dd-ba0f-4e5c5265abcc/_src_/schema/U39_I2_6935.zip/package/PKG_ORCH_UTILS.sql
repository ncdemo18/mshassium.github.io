CREATE PACKAGE "PKG_ORCH_UTILS" IS

  function getTaskMetric(ts_id number, a_id number) return VARCHAR2;
  function getActionMetric(ac_id number, a_id number) return VARCHAR2;
  function getActionMetricByTask(task_id number, a_id number) return VARCHAR2;
  function getTaskByOIandII(o_id number, i_id number) return arrayofnumbers;
  function getActionByOIandII(o_id number, i_id number) return arrayofnumbers;

END PKG_ORCH_UTILS;
/
