CREATE package NC_BACK_SCM_TOOL is

  /**
   * Searches backup by backup ID
   * @backupId - ID of backup to search
   */
  function findBackup(backupId number) return ARRAY_OF_NC_BACK_BACKUPS;

  /**
   * Searches backups by SCM CR ID
   * @crId - ID of SCM CR
   */
  function findBackups(crIds ARRAYOFNUMBERS) return ARRAY_OF_NC_BACK_BACKUPS;

  /**
   * Searches for last actual backup
   */
  function findLastBackups return ARRAY_OF_NC_BACK_BACKUPS;

  /**
   * Creates backup item in DB with specified backup ID and SCM CR ID
   * @backupId - ID of backup
   * @crId - ID of SCM CR
   * throws ALIENT_BACKUP_ERR exception if specified backup exists and belongs to CR differ from specified crId
   * throws INVALID_STATUS_ERR exception if specified backup exists and has 'BACKUP_STATE_CREATED_LV' status
   */
  function createBackup(backupId number, crIds ARRAYOFNUMBERS) RETURN ARRAY_OF_NC_BACK_BACKUPS;

  /**
   * Creates backup item in DB with specified backup ID and SCM CR ID
   * @backupId - ID of backup
   * @crId - ID of SCM CR
   * throws NOT_FOUND_ERR exception if specified backup not exists
   * throws INVALID_STATUS_ERR exception if specified backup exists and has not 'BACKUP_STATE_NOT_CREATED_LV' status
   */
  procedure completeBackup(backupId number);

  /**
   * Delete all data associated with specified backup
   * @backupId - ID of backup
   */
  procedure deleteBackup(backupId number);

  procedure backupAttrTypeDefs(backupId number, attrTypeDefItems ARRAYOFDECIMALS);
  procedure backupAttributes(backupId number, attributeItems ARRAYOFDECIMALS);
  procedure backupObjects(backupId number, objectItems ARRAYOFDECIMALS, isComposite number);
  procedure backupVersionedObjects(backupId number, versionedObjectItems ARRAYOFDECIMALS, isComposite number);

  function rollbackBackup(backupId number) RETURN ARRAYOFDECIMALS;

END NC_BACK_SCM_TOOL;
/
