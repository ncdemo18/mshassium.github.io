CREATE PACKAGE pkg_path_management
IS
   BREAKE_ITEM_ID NUMBER(20) := 9130386256013857329;

   TYPE pathmgmt_ix_type IS TABLE OF NUMBER INDEX BY VARCHAR2(30);

/* Finds and returns objects, connected to start element. */
   PROCEDURE find_items_for_start_item(start_item_id IN nc_objects.object_id%TYPE, item_ids OUT arrayofnumbers);

/* Finds and returns objects, connected to start element of the particular type. */
   FUNCTION find_items4start_cable_conn(start_item_id IN nc_objects.object_id%TYPE) RETURN arrayofnumbers;
   FUNCTION find_items4start_isp_wire(start_item_id IN nc_objects.object_id%TYPE) RETURN arrayofnumbers;
   FUNCTION find_items4start_trace(start_item_id IN nc_objects.object_id%TYPE) RETURN arrayofnumbers;
   FUNCTION find_items4start_dev_conn(start_item_id IN nc_objects.object_id%TYPE) RETURN arrayofnumbers;
   FUNCTION find_items4start_physical_cc(start_item_id IN nc_objects.object_id%TYPE) RETURN arrayofnumbers;

/* Finds and returns objects, connected to an element.
The function checks the circle in the path*/
   PROCEDURE find_next_item(
       curr_item_id IN nc_objects.object_id%TYPE,
       prev_item_id IN nc_objects.object_id%TYPE,
       next_item_id OUT nc_objects.object_id%TYPE);

   PROCEDURE find_next_items(
       curr_item_id IN nc_objects.object_id%TYPE,
       prev_item_id IN nc_objects.object_id%TYPE,
       branch_items OUT arrayofnumbers);

/* Finds and returns objects, connected to an element of the particular type.
The previous object is exculed from the result.
No checks for circle is performed. */
   FUNCTION find_next_item4_cable_conn(
     curr_item_id   IN   nc_objects.object_id%TYPE,
     prev_item_id   IN   nc_objects.object_id%TYPE)
   RETURN nc_objects.object_id%TYPE;

   FUNCTION find_next_item4_isp_wire(
     curr_item_id   IN   nc_objects.object_id%TYPE,
     prev_item_id   IN   nc_objects.object_id%TYPE)
   RETURN nc_objects.object_id%TYPE;

   FUNCTION find_next_item4_trace(
     curr_item_id   IN   nc_objects.object_id%TYPE,
     prev_item_id   IN   nc_objects.object_id%TYPE)
   RETURN nc_objects.object_id%TYPE;

   FUNCTION find_next_item4_dev_conn(
     curr_item_id   IN   nc_objects.object_id%TYPE,
     prev_item_id   IN   nc_objects.object_id%TYPE)
   RETURN nc_objects.object_id%TYPE;

   FUNCTION find_next_item4_physical_cc(
     curr_item_id   IN   nc_objects.object_id%TYPE,
     prev_item_id   IN   nc_objects.object_id%TYPE)
   RETURN nc_objects.object_id%TYPE;

/*  The function calculate one way path based on previous and current item.
The path is stored in element_path parameter.
Returns end element of the path
*/
   FUNCTION build_path (
      curr_item_in_id    IN   nc_objects.object_id%TYPE,
      prev_item_in_id    IN   nc_objects.object_id%TYPE,
      is_right_direction IN   BOOLEAN,
      element_path in out elements_table,
      element_path_ix in out pathmgmt_ix_type)
   RETURN nc_objects.object_id%TYPE;

/*  The function calculate path from the element.
The path is stored in element_path parameter.
Returns both end element of the path
*/
   FUNCTION get_path_for_element(
      start_item_in_id IN nc_objects.object_id%TYPE,
      element_path in out elements_table,
      element_path_ix in out pathmgmt_ix_type)
   RETURN arrayofnumbers;

-- ANAR0707 [Physical Path Tree calculation support] [25 june 2012] start changes
  function calculate_physical_path_tree(point_in_id in nc_objects.object_id%type)
    return elements_table;

  procedure calculate_physical_path_tree(
    p_point_id in nc_objects.object_id%type,
    p_element_path in out elements_table,
    p_element_path_ix in out pathmgmt_ix_type
  );
-- ANAR0707 [Physical Path Tree calculation support] [25 june 2012] end changes

   function calculatePhysicalPath( physical_path_id IN nc_objects.object_id%TYPE)
   return arrayofnumbers;

   function calculateIsConnected( physical_path_id IN nc_objects.object_id%TYPE)
   return number;

   function calculateUsedByPhysicalPath( element_id IN nc_objects.object_id%TYPE)
   return arrayofnumbers;

END;
/
