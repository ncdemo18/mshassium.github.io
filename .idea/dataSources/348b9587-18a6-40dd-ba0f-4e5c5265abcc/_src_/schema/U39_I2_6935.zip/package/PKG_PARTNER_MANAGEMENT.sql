CREATE PACKAGE PKG_PARTNER_MANAGEMENT AS
function get_discounts(contract_Id IN NUMBER) return arrayofnumbers;
function get_MerginOfferingsList(offeringIds in arrayofnumbers) return arrayofnumbers;
function get_branch_bpis(branch_Id IN NUMBER) return arrayofnumbers;
function get_partner_bpis(partner_id IN NUMBER) return arrayofnumbers;
function get_partner_salesorders(partner_Id IN NUMBER) return arrayofnumbers;
function get_offerings(contract_Id IN NUMBER)return arrayofnumbers;
function get_DiscountListbyOfferings(offeringIds in arrayofnumbers) return arrayofnumbers;
function get_offeringsFromDistChannel(distrChannelsId in NUMBER)return arrayofnumbers;
END PKG_PARTNER_MANAGEMENT;
/
