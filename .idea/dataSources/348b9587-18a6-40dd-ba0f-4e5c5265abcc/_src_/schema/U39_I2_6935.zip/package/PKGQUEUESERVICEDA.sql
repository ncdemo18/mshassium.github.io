CREATE package pkgQueueServiceDA is

  -- Author  : KARANASHEV
  -- Created : 11/25/2011 4:27:54 PM
  -- Purpose : Utils to advance DataAccess usage by QueueService

  -- Public function and procedure declarations

  -- Author  : KARANASHEV
  -- Created : 12/6/2011 1:37:02 PM
  -- Purpose : Generates Data Access Mappings for Message type based on Queue
  procedure updateDAMapping(queue_id in number);

  -- Author  : KARANASHEV
  -- Created : 12/8/2011 3:46:02 PM
  -- Purpose : Remove Data Access Mappings for Message type based on Queue
  procedure deleteDAMapping(queue_id in number);

end pkgQueueServiceDA;
/
