CREATE PACKAGE pkg_exportimport is

  enable_trigger_attr constant number(20)  := 9030547111013948783; --Enable history triggers
  status_session_attr constant number(20)  := 3022658414013493423; --Status
  import_session_type constant number(20)  := 5070666123013884366; --ImportSession

  yes_trigger_list_value constant number(20)  := 6050250174013843111; --Yes list value id for Enable history triggers
  no_trigger_list_value  constant number(20)  := 6050250174013843112; --No list value id for Enable history triggers
  in_progress_list_value constant number(20)  := 3022658414013493421; --In Progress list value for Status

  new_attr_record_attr_id constant number(20) := 3090241244013642396; -- for report about new attributes
  new_ot_record_attr_id   constant number(20) := 3090241244013642397; -- for report about new object types

  TYPE ObjRecord IS RECORD (
    object_id ei$nc_objects.object_id%TYPE,
    parent_id ei$nc_objects.parent_id%TYPE,
    source_object_id ei$nc_objects.source_object_id%TYPE,
    project_id ei$nc_objects.project_id%TYPE
  );

	FUNCTION get_priority  (in_attr_id IN nc_attributes.ATTR_ID %TYPE,in_object_type_id IN nc_object_types.OBJECT_TYPE_ID%TYPE,in_attr_schema_id IN nc_attributes.ATTR_SCHEMA_ID%TYPE) RETURN nc_references.PRIORITY%TYPE;
	PROCEDURE update_priority_params;
	PROCEDURE update_priority_references;
  	FUNCTION getExportPropertyRepDev ( device IN nc_devplug.DEVICE_ID %TYPE, plugin IN nc_devplug.PLUGIN_ID %TYPE, options IN number ) RETURN nc_devplug.PROPERTIES%TYPE;
	FUNCTION getImportPropertyRepDev ( device IN nc_devplug.DEVICE_ID %TYPE, plugin IN nc_devplug.PLUGIN_ID %TYPE, ei_property IN nc_devplug.PROPERTIES%TYPE) RETURN nc_devplug.PROPERTIES%TYPE;
	FUNCTION getPropertyForString ( property IN nc_devplug.PROPERTIES%TYPE, string IN nc_devplug.PROPERTIES%TYPE) RETURN nc_devplug.PROPERTIES%TYPE;
	FUNCTION getSubstrFromProperties ( property1 IN nc_devplug.PROPERTIES%TYPE, property2 IN nc_devplug.PROPERTIES%TYPE, string IN nc_devplug.PROPERTIES%TYPE) RETURN nc_devplug.PROPERTIES%TYPE;
	FUNCTION getSubstrFromProperty ( property IN nc_devplug.PROPERTIES%TYPE, string IN nc_devplug.PROPERTIES%TYPE) RETURN nc_devplug.PROPERTIES%TYPE;
	function set_param_outside_trans (obj_id in number, a_id in number, val in varchar2) return number;
	PROCEDURE create_ei_sub_objects (ei_parent_id IN NUMBER, nc_parent_id IN NUMBER,curr_user IN NC_PARAMS.VALUE%TYPE);
	procedure set_connector_for_sub_objects (ei_port_id IN NUMBER, nc_port_id IN NUMBER);
	procedure create_ei_sub_cards (ei_card_id IN NUMBER, nc_card_id IN NUMBER,curr_user IN NC_PARAMS.VALUE%TYPE);
	procedure create_db_element (ei_object_id IN NC_OBJECTS.object_id%TYPE, ei_parent_id IN NC_OBJECTS.object_id%TYPE, ei_object_type_id IN NC_OBJECTS.object_type_id%TYPE,
		  					 ei_name IN NC_OBJECTS.name%TYPE, ei_description IN NC_OBJECTS.description%TYPE, nc_object_id IN NC_OBJECTS.object_id%TYPE,curr_user IN NC_PARAMS.VALUE%TYPE);
	procedure set_ei_attr (ei_object_id IN NC_OBJECTS.object_id%TYPE);
  procedure disable_history_global (session_id number);
  procedure enable_history_global (session_id number);
  FUNCTION get_localized_list_value_sessn (session_id IN NUMBER,lv_id IN NUMBER)   RETURN VARCHAR2;
  -- transfer from EI$NC_OBJECTS to NC_OBJECTS
  procedure importNCObjects(
    session_id in number,
    update_query in varchar2,
    insertedStatistics out integer,
    failedStatistics out integer,
    hadSameIDStatistics out integer,
    childrenStatistics out integer);
  procedure importNCObjectsRecursively(
    session_id in number,
    update_query in varchar2,
    p_object_id in nc_objects.object_id%type,
    p_parent_id in nc_objects.parent_id%type,
    p_source_object_id in nc_objects.source_object_id%type,
    p_project_id in nc_objects.project_id%type,
    parentset in boolean,
    failed_ids in out nocopy arrayofnumbers,
    insertedStatistics in out integer,
    failedStatistics in out integer,
    hadSameIDStatistics in out integer,
    childrenStatistics in out integer );
  -- transfer from EI$NC_ATTRIBUTES and EI$NC_ATTR_TYPE_DEFS to NC_ATTRIBUTES and NC_ATTR_TYPE_DEFS
  procedure importAttrsAndAttrTypeDefs(
    session_id in number,
    update_attr_query in varchar2,
    update_atd_query in varchar2,
    insertedStatistics out integer,
    failedStatistics out integer,
    hadSameIDStatistics out integer);
  procedure importAttrTypeDef(
    session_id in number,
    update_attr_query in varchar2,
    update_atd_query in varchar2,
    p_atd_id in nc_attributes.attr_id%type,
    p_attr_ref_id in nc_attr_type_defs.attr_ref_id%type,
    p_object_ref_attr_id in nc_attr_type_defs.object_ref_attr_id%type,
    ids_set in boolean,
    failed_attr_ids in out nocopy arrayofnumbers,
    failed_atd_ids in out nocopy arrayofnumbers,
    insertedStatistics in out integer,
    failedStatistics in out integer,
    hadSameIDStatistics in out integer);
  procedure importAttr(
    session_id in number,
    update_attr_query in varchar2,
    update_atd_query in varchar2,
    p_attr_id in nc_attributes.attr_id%type,
    p_atd_id in nc_attr_type_defs.attr_type_def_id%type,
    atd_set in boolean,
    failed_attr_ids in out nocopy arrayofnumbers,
    failed_atd_ids in out nocopy arrayofnumbers,
    insertedStatistics in out integer,
    failedStatistics in out integer,
    hadSameIDStatistics in out integer);
  -- transfer hierarhical's tables (NC_OBJECT_TYPES, NC_ATTR_SCHEMAS, NC_SUB_CONNECTORS)
  procedure importHierarhical(
    session_id in number,
    table_name in varchar2,
    ei_table_name in varchar2,
    pk_column_name in varchar2,
    parent_id_column_name in varchar2,
    update_query in varchar2,
    insertedStatistics out integer,
    failedStatistics out integer,
    hadSameIDStatistics out integer);
  procedure importHierarhicalRecursively(
    session_id in number,
    table_name in varchar2,
    ei_table_name in varchar2,
    id in number,
    pk_column_name in varchar2,
    parent_id in number,
    parent_id_column_name in varchar2,
    update_query in varchar2,
    failed_ids in out nocopy arrayofnumbers,
    insertedStatistics in out integer,
    failedStatistics in out integer,
    hadSameIDStatistics in out integer);
  -- transfer for other tables
  procedure importPlain(
    session_id in number,
    table_name in varchar2,
    ei_table_name in varchar2,
    update_query in varchar2,
    insertedStatistics out integer,
    failedStatistics out integer,
    hadSameIDStatistics out integer);
  -- write logs in NC_EI_LOGS
  procedure logConstraint(
    session_id in number,
    table_name in varchar2,
    pk_column_name in varchar2,
    pk_id in number,
    row_id in rowid,
    error_msg in varchar2,
    error_sql_code in integer);
  procedure insertParam(p_object_id in number, p_attr_id in number, p_value in number);

  procedure setExportAttributeToChilds(p_parent_id      in number,
                                       p_parent_attr_id in number,
                                       p_child_ot       in number,
                                       p_child_attr_id  in number);
end;
/
