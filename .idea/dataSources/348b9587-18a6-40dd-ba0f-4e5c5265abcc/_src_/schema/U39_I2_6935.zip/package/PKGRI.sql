CREATE package pkgRI is

  ATTR_ID__PARENT_SLOTS         constant number := 11;
  ATTR_ID__PENDING_SLOTS        constant number := 5020464464013056362;
  ATTR_ID__CARRIER              constant number := 14;
  ATTR_ID__RESOURCES            constant number := 15;
  ATTR_ID__DEVICE_TO_NE_REF     constant number := 3091842003013833782;
  ATTR_ID__DEVICE_TO_NE_ALT_REF constant number := 30402;
  ATTR_ID_CONNECTIVITY          constant number := 457955;
  ATTR_ID_PREWIREDTO            constant number := 3012935634013428525;
  ATTR_ID_GENDER                constant number := 5;

  TYPE_ID__SITE                 constant number := 300;
  TYPE_ID__DEVICE               constant number := 301;
  TYPE_ID__NE                   constant number := 3061830882013808530;
  TYPE_ID_PORT                  constant number := 600;
  TYPE_ID_SLOT                  constant number := 601;
  TYPE_ID_CIRCUIT_PATH_ELEMENT  constant number := 9;
  TYPE_ID_DEVICE_CONNECTOR      constant number := 197;

  MALE_LIST_VALUE_ID            constant number := 51;

  PROP_KEY__PE_CARRIER_REF      constant varchar2(28) := 'pe_carrier_reference_attr_id';

  PROP_VAL__NE                  constant varchar2(2) := 'ne';
  PROP_VAL__CHASSIS             constant varchar2(7) := 'chassis';
  PROP_VAL__NOTHING             constant varchar2(7) := 'nothing';

  GET_SLOTS_AND_DEVICE_QUERY constant varchar2(2000) := 'select PairOfNumbers(slot.object_id, slot.parent_id)
    from nc_references card2slot,
     nc_objects slot
    where
     card2slot.attr_id = coalesce(
      (select attr_id from nc_references where object_id = card2slot.object_id and attr_id = 11 /*Parent Slots*/ and rownum = 1),
      (select attr_id from nc_references where object_id = card2slot.object_id and attr_id = 5020464464013056362 /*Pending Slots*/ and rownum = 1))
     and card2slot.object_id = :1
     and card2slot.reference = slot.object_id
     order by -slot.order_number, card2slot.attr_id';

  type ref_cursor is ref cursor;

  /**
   * Calculates and sets carriers for given (path element -like) objects assumming they have resources set.
   * More precisely, procedure emulates ChangeResourceListener's behaviour for given object_ids.
   * Procedure using config from nc_event_listeners to determine what type of objects to process and which attributes to treat as "resources" and "carrier".
   *
   * @param p_pe_ids           array of object_ids of pe-like objects to update.
   */
  procedure set_carriers_for_objects(p_pe_ids arrayofnumbers);

  /**
   * Calculate suggests resourses for path element by cable connections
   *
   * @param p_object_id           object id of path element
   * @return                      table with column:
   *                                field1 - object id of path element,
   *                                field2 - object id of suggest resources.
   */
  function get_suggests_res_by_cable(p_object_id number) return tableof2numbers;

  /**
   * Calculate suggests resourses for path element by Prewided To attribute
   *
   * @param p_object_id           object id of path element
   * @return                      table with column:
   *                                field1 - object id of path element,
   *                                field2 - object id of suggest resources.
   */
  function get_suggests_res_by_prewired(p_object_id number) return tableof2numbers;

  /**
   * Calculate suggests resourses for path element by Cross Connected To attribute
   *
   * @param p_object_id           object id of path element
   * @return                      table with column:
   *                                field1 - object id of path element,
   *                                field2 - object id of suggest resources.
   */
  function get_suggests_res_by_cross(p_object_id number) return tableof2numbers;

  /**
   * Calculate suggests resourses for path element by other circuit in project
   *
   * @param p_object_id           object id of path element
   * @return                      table with column:
   *                                field1 - object id of path element,
   *                                field2 - object id of suggest resources.
   */
  function get_suggests_res_by_circuit(p_object_id number) return tableof2numbers;

  /**
   * Return object_id of carrier for path element. If carrier not found, return NULL
   *
   * @param p_object_id           object id of path element
   * @return                      object_id of carrier for path element. If carrier not found, return NULL
   */
  function get_carrier_for_pe(p_object_id number) return number;

  /**
   * If circuit used resource then return 0, else return 1;
   *
   * @param r_obj_id           object id of resource
   * @param c_obj_id           object id of circuit
   * @return                   If circuit used resource then return 0, else return 1;
   */
  function is_resource_use_by_circuit(r_obj_id number, c_obj_id number) return number;

  /**
   * Returns carrier object_id by resource object_id.
   * Calculation mainly based on value of 'pe_carrier_reference_attr_id' OT property of resource's OT.
   * pe_carrier_reference_attr_id={ne|chassis|parent|<attr_id>}
   *
   * @param p_resource_id      object_id of resource object to calculate carrier from
   * @return                   object_id of carrier object for given resource
   */
  function get_carrier_by_resource(p_resource_id number) return number;

--ALGA1109 [08/04/2010] [Performance: getChassisID and getPluginID functions access to many objects] Start
  function get_plugin_by_object(p_obj_id number, p_level number) return number;
--ALGA1109 [08/04/2010] [Performance: getChassisID and getPluginID functions access to many objects] End

  /**
   * Returns chassis object_id by object.
   *
   * @param p_obj_id           object_id of object to find chassis for
   * @return                   object_id of chassis object or null if chassis does not exist for given object
   */
  function get_chassis_by_object(p_obj_id number) return number;

  function get_plugins_by_objects(p_obj_ids arrayofnumbers, p_level number) return tableof2numbers;

  function get_chassises_by_objects(p_obj_ids arrayofnumbers) return tableof2numbers;
  /**
   * Returns NE object_id for device.
   *
   * @param p_device_id        object_id of device to find NE for
   * @return                   object_id of NE object or null if NE does not set for given object
   */
  function get_ne_by_device(p_device_id number) return number;

  /**
   * Utility function to get object's reference. Calculable references supported.
   * In case of multiple reference attribute function returns the first reference value.
   *
   * @param p_object_id        object_id
   * @param p_attr_id          object_id
   * @return                   object_id of referenced object or null if reference parameter is empty
   */
  function get_reference(p_object_id number, p_attr_id number) return number;

  /**
   * Utility function to set object's reference.
   * Uses merge satement matching on object_id and attr_id in nc_references.
   * Multiple references not supported.
   *
   * @param p_object_id        object_id
   * @param p_attr_id          object_id
   * @return                   object_id of referenced object or null if reference parameter is empty
   */
  procedure set_reference(p_object_id number, p_attr_id number, p_reference number);

  /**
   * Utility function to check if one object type is subtype of another.
   * @param p_ancestor_type_id object_id
   * @param p_child_type_id    object_id
   * @return                   1 if type represented by p_child_type_id is child of p_ancestor_type_id
   *                           and 0 otherwise
   */
  function is_subtype_of(p_ancestor_type_id number, p_child_type_id number) return number;

  function get_type_by_object(p_object_id number) return number;

  function parse_property_value(
      p_properties varchar2,
      p_prop_key varchar2,
      p_delim varchar2,
      p_default_value varchar2 default null
    ) return varchar;

  function get_ot_property_inherited(p_ot_id number, p_key varchar2) return varchar2;

  function get_attributes_by_property(p_object_type_id number, p_schema_id number, p_property varchar2) return ref_cursor;

--ALTO0710[02-28-2011][Provide preloading attributes in SlotContextProvider] Start
  function get_slots_and_cards(p_device_id number) return arrayofnumbers;
--ALTO0710[02-28-2011][Provide preloading attributes in SlotContextProvider] End

  /**
   * Function that orders resources of p_class_id inside chassis taking into account.
   * Used in calculable attribute 9123499985013254463 for OOB port sorting
   * 1. network element
   * 2. name of device or value of p_shelf_order_attr_id on device (to sort resources from different devices of NE)
   * 3. order_number of slot resource located in plus hierarchy level
   * 4. order_number of resource
   *
   * @param p_resource_ids set of resource object_id-s to calculate order for
   * @param p_class_id object_class_id of objects to order
   * @p_shelf_order_attr_id attr_id of device ordering attribute (default null)
   * @return table of 2 number columns - (object_id, order_num}
   */
  function get_hierarchical_order(p_resource_ids arrayofnumbers, p_class_id number, p_shelf_order_attr_id number default null) return tableof2numbers;

--SERK0810 [11-11-2010] [[CSS 36] Cable Connector Sorting ] start
  /**
   * Function that orders resources of several p_class_id-s inside chassis taking into account.
   * Used in calculable attribute 9123499985013254463 for OOB port sorting
   * 1. network element
   * 2. name of device or value of p_shelf_order_attr_id on device (to sort resources from different devices of NE)
   * 3. order_number of slot resource located in plus hierarchy level
   * 4. order_number of resource
   *
   * @param p_resource_ids set of resource object_id-s to calculate order for
   * @param p_class_ids set of object_class_id-s of objects to order
   * @p_shelf_order_attr_id attr_id of device ordering attribute (default null)
   * @return table of 2 number columns - (object_id, order_num}
   */
  function get_hierarchical_order_multi(p_resource_ids arrayofnumbers, p_class_ids arrayofnumbers, p_shelf_order_attr_id number default null) return tableof2numbers;
--SERK0810 [11-11-2010] [[CSS 36] Cable Connector Sorting ] end

--VLSI0607[04-14-2011][[8.1_DEV_Inventory]Make 'Used By Circuit' attribute (id=457903) Calculate By Query]Start
  /**
   * Function that calculates circuits are used by object.
   * Used in calculable attribute 457903 Used By Circuit
   *
   * @param p_object_ids set of object_id-s to calculates circuits are used by object
   * @param carrier_ids set of attr_id-s of objects (default 14,15)
   * @return table of 2 number columns - (object_id, circuit_id}
   */
  function get_used_by_circuit(p_object_ids arrayofnumbers, p_carrier_ids arrayofnumbers default arrayofnumbers(14,15)) return tableof2numbers;
--VLSI0607[04-14-2011][[8.1_DEV_Inventory]Make 'Used By Circuit' attribute (id=457903) Calculate By Query]End

--DMPS0411[25-01-2012] [[8.2.1(FT)_QA_ResourceInventory] - [FT8.2.1][RI] Difference in 'Logical Inventory' parameters for OTS/OMS circuits] Start
  /**
   * Function that calculates number of circuits are used by object.
   * Used in calculable attribute 4012341241013311997 Number of used by circuits
   *
   * @param p_object_ids set of object_id-s to calculates circuits are used by object
   * @param carrier_ids set of attr_id-s of objects (default 14,15)
   * @return table of 2 number columns - (object_id, number_of_circuit}
   */
  function get_number_of_used_by_circuit(p_object_ids arrayofnumbers, p_carrier_ids arrayofnumbers) return tableof2numbers;
--DMPS0411[25-01-2012] [[8.2.1(FT)_QA_ResourceInventory] - [FT8.2.1][RI] Difference in 'Logical Inventory' parameters for OTS/OMS circuits] End

  FUNCTION getcalculatedvalues_by_config (
       configuration_id       IN   nc_objects.object_id%TYPE,
       p_object_ids           IN   arrayofnumbers,
       p_user_id              IN   nc_objects.object_id%TYPE DEFAULT NULL,
       p_language_id          IN   nc_objects.object_id%TYPE DEFAULT NULL,
       p_locale_id            IN   nc_objects.object_id%TYPE DEFAULT NULL
    )
  RETURN tableof2numbers;


  /**
   * Function buils path for object.
   *
   * @param p_object_id object for buil path.
   * @param separator path separator. Default separator is '/'.
   * @param is_url url is 1 for path item needs.
   * @param url_prefix applicable when is_url=1. Default prefix is '/ncobject.jsp?id='.
   * @param last_object_class_id class of first object in path. Null if full path needs.
   * @param last_object_include 1 if first object with class last_object_class_id should be presented in path.
   */
  function gethtmlpath (
    p_object_id          number,
	separator            varchar2,
    last_object_class_id number,
    last_object_include  number
  ) return varchar2;

  /**
   * Function buils path for device or card inserted into slot(s) of device. If card was inserted in a slot, path includs information about that.
   * For example, if card occupied two slots of device then the path is device/slot#1|slot#2/card.
   *
   * @param p_object_id object for buil path.
   * @param separator path separator. Default separator is '/'.
   * @param is_url url is 1 for path item needs.
   * @param url_prefix applicable when is_url=1. Default prefix is '/ncobject.jsp?id='.
   * @param last_object_class_id class of first object in path. Null if full path needs.
   * @param last_object_include 1 if first object with class last_object_class_id should be presented in path.
   */
  function gethtmlcardpath (
    p_object_id          number,
	  separator            varchar2,
    is_url               number,
    url_prefix           varchar2,
    last_object_class_id number,
    last_object_include  number,
    get_slots_and_parent_query varchar2 := GET_SLOTS_AND_DEVICE_QUERY
  ) return varchar2;

  /**
   * This function returns hierarchy of cards by ports. It's used in Card(457952) attribute in QUERY property.
   *
   * @param ports IDs which cards' hierarchy should be calculated.
   * @return table of 2 number columns - (port, card), (port, parent_slot_of_card), (port, parent_of_parent_card), etc
   */
  function get_cards_hierarchy_by_ports(ports arrayofnumbers) return tableof2numbers;

  /**
   * This function returns hierarchy of cards by ports and pre-calculated card hierarchy.
   *
   * @param ports IDs which cards' hierarchy should be calculated.
   * @param cards_hierarchy cards hierarchy with slots which presents by linked pairs. Example:
   *      (card, its_parent_slot), (its_parent_slot, parent_card), (parent_card, parent_slot_of_parent_card), (parent_slot_of_parent_card, chassis), etc.
   * @return table of 2 number columns - (port, card), (port, parent_slot_of_card), (port, parent_of_parent_card), etc
   */
  function get_cards_hierarchy_by_ports(ports arrayofnumbers, cards_hierarchy tableof2numbers) return tableof2numbers;

  /**
   * This function returns hierarchy of cards.
   *
   * @param cards - cards IDs;
   * @param get_slots_and_parent_query - query, which calculated parent slot(s) and parent device for card. For example see const GET_SLOTS_AND_DEVICE_QUERY.
   * @return table of 2 number columns - cards hierarchy with slots which presents by linked pairs. Example:
   *   (card, its_parent_slot), (its_parent_slot, parent_card), (parent_card, parent_slot_of_parent_card), (parent_slot_of_parent_card, chassis), etc.
   */
  function get_cards_hierarchy_by_cards(cards arrayofnumbers, get_slots_and_parent_query in varchar2 := GET_SLOTS_AND_DEVICE_QUERY) return tableof2numbers;

  function get_ports_by_chassis(p_object_ids arrayofnumbers) return tableof2numbers;

  function get_ports_by_chassis(p_object_ids NUMBER) return tableof2numbers;

  /**
   * Returns Ports, Port Channels, Sub-Interfaces and Virtual Interfaces of Network Element
   * @param ne_id - Id Of NetworkElement;
   * @param interface_classes - Collection of Interface Classes. Can contain only following values:
   * 600 - Port
   * 610 - Channel
   * 4111570991013824912 - Sub-interface
   * 4111570991013824911 - Virtual Interface;
   * @return Collection of entities with specified Interface Classes
   **/
  function get_interfaces_by_ne(ne_id number, interface_classes arrayofnumbers default null) return arrayofnumbers;

  FUNCTION get_connectors_by_chassis(p_object_ids arrayofnumbers) RETURN tableof2numbers;

  FUNCTION get_connectors_by_chassis(p_object_ids NUMBER) RETURN tableof2numbers;

  function get_united_frequency_ranges(object_ids arrayofnumbers default null) return arrayofstrings;

  /**
   * This function return Device IDs belonging to NE
   *
   * @param ne - Network Element ID
   * @return arrayofnumbers
   **/
  FUNCTION get_devices_by_ne(ne NUMBER) RETURN arrayofnumbers;

  --SVMA0311 [19-03-2014] [Suggestions Object For Carrier works slowly] Start
    function get_suggests_res_by_circuit(p_object_id number, p_count_records number) return tableof2numbers;
  --SVMA0311 [19-03-2014] [Suggestions Object For Carrier works slowly] End

end pkgRI;
/
