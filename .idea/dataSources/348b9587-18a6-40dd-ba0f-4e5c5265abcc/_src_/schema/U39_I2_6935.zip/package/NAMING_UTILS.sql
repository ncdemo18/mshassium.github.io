CREATE package naming_utils
is
    /**
     * Function calculating applying names for the specified objects and depending objects.
     *
     * @param p_object_ids  list of primary keys of nc_objects to generate names for.
     */
    procedure apply_naming_for_objects(p_object_ids in arrayofnumbers);

    /**
     * Function calculating names for the specified objects and depending objects.
     *
     * @param p_object_ids  list of primary keys of nc_objects to generate names for.
     * @return List of pairs (object_id, name) for the specified objects and their dependent objects.
     */
    function get_names(p_object_ids in arrayofnumbers)
       return tableofnumandstr;

    /**
     * Function calculating names for the specified objects and attributes and depending objects.
     *
     * @param p_object_ids  list of primary keys of nc_objects to generate names for.
     * @return List of pairs (object_id, name) for the specified objects and their dependent objects.
     */
    function get_names_with_aliases(p_object_ids in arrayofnumbers)
        return tableof2strings;

    /**
     * Compatibility method returning object_id and generated name list in encoded string array.
     *
     * @param p_object_ids  list of primary keys of nc_objects to generate names for.
     * @return Array of strings of format '{object_id},{name}' for the specified objects and their dependent objects.
     * @see #get_names
     */
    function get_names_flat(p_object_ids in arrayofnumbers)
        return arrayofstrings;

    /**
     * Compatibility method returning object_id or pair of attr_id  and object_id (in case of alias) and generated name list in encoded string array.
     *
     * @param p_object_ids  list of primary keys of nc_objects to generate names for.
     * @return Array of strings of format '{object_id},{name}' for the specified objects and their dependent objects.
     * @see #get_names
     */
    function get_names_with_aliases_flat(p_object_ids in arrayofnumbers)
        return arrayofstrings;

    /**
     * Function searching objects which name depends on the specified object name.
     *
     * @param p_object_id  primary key of nc_object to search dependent objects for.
     * @return Array of primary keys of dependent nc_objects.
     */
    function find_child_objects_to_rename(p_object_id in number)
        return arrayofnumbers;

    /**
     * @param p_trig_cond_ids  array of primary keys of nc_objects of triggering conditions.
     */
    procedure create_listeners(p_trig_cond_ids in arrayofnumbers);

    /**
     * @param p_trig_cond_ids  array of primary keys of nc_objects of triggering conditions.
     */
    procedure remove_from_listeners(p_trig_cond_ids in arrayofnumbers);

    /**
     * Function generating approximate object name.
     *
     * @param p_parent_id  primary key of parent object.
     * @param p_object_type_id  primary key of object type of creating object.
     * @param p_project_id  primary key of project of crating object.
     * @return String approximate name.
     */
    function generate_approximate_name(p_parent_id      in number,
                                       p_object_type_id in number,
                                       p_project_id     in number)
        return varchar2;
	/**
	* Function returns table of object types with priority of their rules.
	* Types with higer priority have naming rules that depends on naming of objects with object types of lowest priority
	*/
	function get_prioritized_types
      return tableof2numbers;

	function get_prioritized_types (p_object_types arrayofnumbers)
    return tableof2numbers;

	/**
    * @param event_query is an SQL query string describing events. Result of query execution should contain following columns:
    * OBJECT_ID - id of object where event occurred
    * OBJECT_TYPE_ID - id of object type of this object
    * ATTR_ID (optional) - id of attribute where "Modify object params" event occurred
    * ACTION_ID - event action id (0 - create object, 1 - modify object, 2 - delete object, 3 - modify object params)
    * SUBACTION_ID - event subaction id
    **/
    procedure apply_naming_by_events(event_query in varchar2);

    type hmap is table of number index by varchar2(64 /* Modified When */);
end;
/
