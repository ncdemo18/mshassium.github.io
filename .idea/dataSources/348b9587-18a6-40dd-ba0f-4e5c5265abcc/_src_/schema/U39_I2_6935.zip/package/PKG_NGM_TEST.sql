CREATE PACKAGE PKG_NGM_TEST AS

/*Node Search functions*/
FUNCTION search_nodes(node_spec_id IN NUMBER) RETURN ArrayOfNumbers;
FUNCTION search_actlz_db_rules(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_arguments(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_database_rules(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_actlz_rules(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_ports(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_paths(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_selectors(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_filters(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_parameters(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_edge_specs(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_functions_nodes(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_functions_edges(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_group_functions_nodes(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_group_functions_edges(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;
FUNCTION search_functions_and_groups(node_spec_id NUMBER) RETURN ARRAYOFNUMBERS;

FUNCTION search_ports(graph_id IN NUMBER, port_spec_id IN NUMBER) RETURN TABLEOF3NUMBERS;

FUNCTION get_graph_spec(node_spec_id IN NUMBER) RETURN ArrayOfNumbers;

FUNCTION search_wrappers(node_spec_id IN NUMBER) RETURN ArrayOfNumbers;
/*Edge Search functions*/
FUNCTION search_parents_for_arguments(v_graph_id IN NUMBER, nes_spec_id IN NUMBER) RETURN TableOf2Numbers;
FUNCTION search_parents_for_wrappers(v_graph_id IN NUMBER, nes_spec_id IN NUMBER) RETURN TableOf2Numbers;
FUNCTION search_using_parameters_nodes(edge_spec_id NUMBER, sources ArrayOfNumbers) RETURN TABLEOF3NUMBERS;
FUNCTION search_using_parameters_edges(edge_spec_id NUMBER, sources ArrayOfNumbers) RETURN TABLEOF3NUMBERS;
FUNCTION search_using_parameters_ports(edge_spec_id NUMBER, sources ArrayOfNumbers) RETURN TABLEOF3NUMBERS;
FUNCTION search_using_parameters_paths(edge_spec_id NUMBER, sources ArrayOfNumbers) RETURN TABLEOF3NUMBERS;
FUNCTION search_using_arguments(edge_spec_id NUMBER, sources ArrayOfNumbers) RETURN TABLEOF3NUMBERS;
FUNCTION search_using_port(edge_spec_id NUMBER, sources ArrayOfNumbers) RETURN TABLEOF3NUMBERS;

FUNCTION search_using_functions_by_node(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;
FUNCTION search_using_edges_by_node(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;
FUNCTION search_using_port_by_node(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;
FUNCTION search_using_argument_by_selec(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;
FUNCTION search_using_functions_by_path(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;
FUNCTION search_using_args_by_func(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;

FUNCTION get_edges(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS) RETURN TableOf3Numbers;

FUNCTION search_edges(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;
FUNCTION search_nested_edges(edge_spec_id IN NUMBER, node_sources IN ARRAYOFNUMBERS)RETURN TableOf3Numbers;
/* Parameters */
FUNCTION get_plsql_parameter(param_spec_id IN NUMBER, source_objects TableOf2Numbers) RETURN TableOf2Strings;
FUNCTION search_port_name(param_spec_id IN NUMBER, source_objects TableOf2Numbers) RETURN TableOf2Strings;
FUNCTION search_wrapper_name(param_spec_id IN NUMBER, source_objects TableOf2Numbers) RETURN TableOf2Strings;
FUNCTION get_argument_by_name(spec_id IN NUMBER, arg_name IN VARCHAR2) RETURN ARRAYOFSTRINGS;
procedure get_start_objects(spec_id IN NUMBER);
function echo_num(id_num number) return ArrayOfNumbers;


/* Expand and collapse function */
FUNCTION add_link_for_expand_node(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER) RETURN TABLEOFGE;
FUNCTION add_link_for_expand_depends_on(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER) RETURN TABLEOFGE;
FUNCTION expand_node(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER) RETURN TABLEOFGE;
FUNCTION expand_actlz_proc(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER) RETURN TABLEOFGE;
FUNCTION collapse_actlz_proc(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER) RETURN TABLEOFGE;
FUNCTION collapse_link(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER) RETURN TABLEOFGE;
FUNCTION collapse_link_node(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER) RETURN TABLEOFGE;
FUNCTION simple_test_actualize_expand(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER)RETURN TABLEOFGE;
FUNCTION simple_test_actualize_collapse(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER)RETURN TABLEOFGE;
FUNCTION selector_expand(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER)RETURN TABLEOFGE;
FUNCTION selector_collapse(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER)RETURN TABLEOFGE;
FUNCTION filter_expand(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER)RETURN TABLEOFGE;
FUNCTION filter_collapse(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER)RETURN TABLEOFGE;

/* Utility functions */
FUNCTION get_objects_by_parent_and_type(parent_ids IN ArrayOfNumbers , objecttypeids IN ArrayOfNumbers, is_hierarchical IN BOOLEAN DEFAULT FALSE) RETURN ARRAYOFNUMBERS;

/* Parameters */
FUNCTION can_expand(param_spec_id IN NUMBER, source_objects TableOf2Numbers) RETURN TableOf2Strings;
FUNCTION used_functions(param_spec_id IN NUMBER, source_objects TableOf2Numbers) RETURN TableOf2Strings;
FUNCTION used_parameters(param_spec_id IN NUMBER, source_objects TableOf2Numbers) RETURN TableOf2Strings;

/*Other*/
function get_path(graph_id IN NUMBER, path_spec_id IN NUMBER ) RETURN TableOfPE;

END PKG_NGM_TEST;
/
