CREATE PACKAGE pkgwsn
IS
   FUNCTION create_nc_ossj_subscriptions
      RETURN nc_ossj_subscriptions.subscription_id%TYPE;

   FUNCTION create_nc_ossj_subscriptions (
      tme        TIMESTAMP,
      consumer   VARCHAR2,
      topic      VARCHAR2,
      isActive   number
   )
      RETURN nc_ossj_subscriptions.subscription_id%TYPE;

   PROCEDURE update_nc_ossj_subscriptions (
      subscriptionid   NUMBER,
      tme              TIMESTAMP,
      consumer         VARCHAR2,
      topic            VARCHAR2,
      isActive   number
   );

   PROCEDURE delete_nc_ossj_subscriptions (subscriptionid NUMBER);

   PROCEDURE update_termination_time (subscriptionid NUMBER, tme TIMESTAMP);

   PROCEDURE update_consumer_reference (subscriptionid NUMBER, consumer VARCHAR2);

   PROCEDURE update_topic_expression (subscriptionid NUMBER, topic VARCHAR2);

   PROCEDURE update_is_active (subscriptionid NUMBER, isactive number);
END;
/
