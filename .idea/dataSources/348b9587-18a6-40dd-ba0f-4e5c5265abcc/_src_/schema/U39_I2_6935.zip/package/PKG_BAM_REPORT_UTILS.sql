CREATE package PKG_BAM_REPORT_UTILS is
  DEFAULT_DATE_FORMAT varchar2(10):='MM/dd/yyyy';

  /*
    Format date as char in default format ('MM/dd/yyyy') to quarter format.
    E.g. '01/20/2009'=>
  */
  function formatDateToQuarter(datevalue in varchar2) return varchar2;

  /*
    Parse formatted quarter string to date as char in default format
    E.g. 'Q1 2009'=>'01/20/2009'
  */
  function parseQuarterToDate(quarter in varchar2) return varchar2;

  function truncateToMinute(datevalue in date, minutes in number) return date;

end PKG_BAM_REPORT_UTILS;
/
