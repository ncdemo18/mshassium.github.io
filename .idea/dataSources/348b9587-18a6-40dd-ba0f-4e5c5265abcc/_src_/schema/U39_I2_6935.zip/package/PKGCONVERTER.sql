CREATE package PKGCONVERTER is

procedure convert_to_table_set(model_id number, config_id number, create_new number default 1);

function get_new_list_val_id(old_list_value_id number) return number;
function get_new_obj_type_id(old_obj_type_id number) return number;

end PKGCONVERTER;
/
