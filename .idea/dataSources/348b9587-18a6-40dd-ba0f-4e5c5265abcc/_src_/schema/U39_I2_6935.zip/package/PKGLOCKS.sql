CREATE PACKAGE pkglocks
IS
  lock_id_generator_base CONSTANT INT := POWER(2, 24 + 5); /* 536870912 = 32 * 16777216 */
  lock_id_generator_length CONSTANT INT := POWER(2, 24); /* 16777216 */
  lock_id_generator_buckets_size CONSTANT INT := POWER(2, 5); /* 32 */

    SUBTYPE componentname_t IS VARCHAR2 (40);

    TYPE componenttobucket_t IS TABLE OF INTEGER
                                    INDEX BY componentname_t;

    componenttobucket                componenttobucket_t;

    FUNCTION getlockid(componentname componentname_t, lock_name VARCHAR2)
        RETURN INTEGER;

  expiration_secs CONSTANT   INTEGER := 864000; /* 10 days */
  renewal_threshold CONSTANT INTEGER := 1; /* 1 day */

  SUBTYPE lock_name_t IS VARCHAR2(1500);
  SUBTYPE lock_handle_t IS VARCHAR2(120);

  TYPE lockhandle_timestamp_t IS RECORD
  (
    lockhandle lock_handle_t,
    TIMESTAMP DATE
  );
  TYPE lockname_to_lt_t IS TABLE OF lockhandle_timestamp_t INDEX BY lock_name_t;
  lockname_to_lt lockname_to_lt_t;

  /* Advantages:
    - gives unique lockhandle
    - minimizes calls to dbms_lock.allocate_unique
   */
  FUNCTION get_lock_handle(lock_name lock_name_t)
    RETURN lock_handle_t;

END pkglocks;
/
