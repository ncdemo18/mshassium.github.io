CREATE PACKAGE pkgcache
is
   type refcursor is ref cursor;

   function getobjectstoload
      return arrayofnumbers;

   -- ALFe0410 [Dec-24-2010] [ OptimizedNCLoadManager.loadCommonParametersInternal uses multi-object loader for single object loading ] - one row added
   function getsetobjectstoload (objectids in arrayofnumbers) return arrayofnumbers;


   procedure setobjectstoload (objectids in arrayofnumbers);

   procedure inittemptable (objectids in arrayofnumbers);

   function updateversion (objectid number)
      return number;

   function updateversionwithreferences (objectid number)
      return number;

   procedure updateversions (objectids arrayofnumbers);

--***DMMU0906 [07-04-07] [NCObject cache fails at parallel editing] Start
   function updateversions (objectids in arrayofnumbers)
      return tableof2numbers;
--***DMMU0906 [07-04-07] [NCObject cache fails at parallel editing] End


   procedure loadobjectsfromtable (
      objects   out   refcursor,
      params    out   refcursor,
      refs      out   refcursor
   );

   procedure loadobjectsfromcollection (
      objects   out   refcursor,
      params    out   refcursor,
      refs      out   refcursor
   );
end;
/
