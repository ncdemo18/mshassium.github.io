CREATE package pkg_cmt_ct is
  -- Package PKG_CMT_CT is part of the Configuration Management Tools project
  -- Author: GLBO
  -- Created: 20.12.2011

  DEFAULT_DOMAIN_ID constant number := 9137288153213290331;
  TS_FORMAT constant varchar2(100) := 'dd.mm.yyyy hh24:mi:ss';
  UNKNOWN_USER constant varchar2(100) := 'Unknown';

  procedure delete_activity(v_activity_id in number);
  procedure delete_modification(
    v_activity_id in number,
    v_ci_id in varchar2,
    v_ci_table in varchar2
  );
  PROCEDURE delete_modifications(v_activity_id IN NUMBER);

  function get_modifications_by_activity(
      v_all_modifs ModificationTypeWithNumTable,
      v_page_num in number,
      v_page_size in number,
      v_check_conflicts in integer
  ) return NC_CMT_Modification_Type_Table;

  function get_crs_by_user_and_domain(
    v_user_id in number,
    v_page_num in number,
    v_page_size in number,
    v_domain_id in number
  ) return NC_CMT_Activity_Table PIPELINED;
  function get_activity_by_id(
    v_activity_id in number
  ) return NC_CMT_Activity_Table PIPELINED;
  function get_dbtracking_activity
    return number;
  function get_user_enabled_activity(
    v_user_id in number
  ) return number;
  function get_user_dbtracking_activity(
    v_user_id in number
  ) return number;
  procedure set_export_flag( v_export_items NC_CMT_ExportItem_Type_Table);
  procedure update_hier_parent_for_tree(
    v_ci_id varchar2,
    v_ci_table_name varchar2
  );
  procedure update_hier_parent_for_trees(id_list arrayofstrings, tables_list arrayofstrings);
  procedure update_hier_parent_all;

  function get_modification_count(
    v_modifs ModificationTypeWithNumTable
  ) return number;

  function get_modifications (
      v_activity_id in number,
      v_use_part in number,
      v_ids in arrayofstrings,
      v_tables in arrayofstrings,
      v_filters in arrayofstrings default null,
      v_order in varchar2 default null
  ) return ModificationTypeWithNumTable;

  function get_detail_modifications(
    v_activity_id in number,
    v_ci_id in varchar2
  ) return NC_CMT_DetailModification_Tbl PIPELINED;
  procedure move_activity_items(
    v_activity_id      IN NUMBER
   ,v_dest_activity_id IN NUMBER
   ,v_ci_ids           IN ARRAYOFSTRINGS
   ,v_ci_tables        IN ARRAYOFSTRINGS
  );

  procedure init_items_filters(
    v_filters in arrayofstrings,
    v_package_filter out arrayofstrings,
    v_use_package_filter out number,
    v_full_filter out arrayofstrings,
    v_use_full_filter out number,
    v_etype_filter out arrayofstrings,
    v_use_etype_filter out number);

  PROCEDURE init_items_filters
  (
    p_filters              IN arrayofstrings
   ,out_package_filter     OUT arrayofstrings
   ,out_use_package_filter OUT NUMBER
   ,out_full_filter        OUT arrayofstrings
   ,out_use_full_filter    OUT NUMBER
   ,out_etype_filter       OUT arrayofstrings
   ,out_use_etype_filter   OUT NUMBER
   ,out_filter_sensitive   OUT NUMBER
   ,out_filter_contains    OUT VARCHAR2
  );

  function hash_record(name in varchar2, value in number) return NC_CMT_Hash_Type;
  function hash_record(name in varchar2, value in varchar2) return NC_CMT_Hash_Type;
  function hash_record(name in varchar2, value in date) return NC_CMT_Hash_Type;
  function hash_record(name in varchar2, value in clob) return NC_CMT_Hash_Type;
  function hash_record(name in varchar2, value in blob) return NC_CMT_Hash_Type;
  function hash_record(name in varchar2, value in timestamp) return NC_CMT_Hash_Type;

  function get_field(v_arr in NC_CMT_Hash_Table, v_field_name in varchar2) return varchar2;
  function get_user_id return number;

  function dbtrigger(
    v_is_inserting in boolean,
    v_is_updating in boolean,
    v_is_deleting in boolean,
    v_table_name in varchar2,
    v_old_ci_id in varchar2,
    v_old_row in NC_CMT_Hash_Table,
    v_new_ci_id in varchar2,
    v_new_row in NC_CMT_Hash_Table,
    v_ci_table_name in varchar2,
    v_ci_key in varchar2
  ) return varchar2;

  function get_resource(p_resource_id in number,
                        p_user_id in number,
                        p_binds in arrayofstrings default null) return varchar2;

  FUNCTION dbtriggerForListener(
    v_operation     IN CHAR,
    v_table_name    IN VARCHAR2,
    v_ci_id         IN VARCHAR2,
    v_ci_name       IN VARCHAR2,
    v_ci_table_name IN VARCHAR2,
    v_activity_id   IN NUMBER
  ) return varchar2;

end;
/
