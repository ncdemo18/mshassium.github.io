CREATE PACKAGE pkg_boe IS

  TYPE ref_cursor IS REF CURSOR;
  TYPE item_data IS RECORD(
     item_id            nc_objects.object_id%TYPE
    ,item_name          nc_objects.name%TYPE
    ,location_id        nc_objects.object_id%TYPE
    ,location_name      nc_objects.name%TYPE
    ,r_num              NUMBER(20)
    ,item_level         NUMBER(20)
    ,mrc_value          NUMBER(25, 5)
    ,mrc_original_value NUMBER(25, 5)
    ,nrc_value          NUMBER(25, 5)
    ,nrc_original_value NUMBER(25, 5)
    ,mrc_min_value      NUMBER(25, 5)
    ,mrc_max_value      NUMBER(25, 5)
    ,nrc_min_value      NUMBER(25, 5)
    ,nrc_max_value      NUMBER(25, 5)
    ,
    -- Next fields are only valid for OI
    bpi_id        nc_objects.object_id%TYPE
    ,mrc_old_value NUMBER(25, 5)
    ,mrc_delta     NUMBER(25, 5)
    ,item_action   VARCHAR2(200)
    ,result_action VARCHAR2(200)
    ,offerquantity NUMBER(25, 5));
  TYPE arrayofitems IS TABLE OF item_data;
  TYPE item_price_data IS RECORD(
     item_id    nc_objects.object_id%TYPE
    ,oi_prices  arrayofnumbers
    ,bpi_id     nc_objects.object_id%TYPE
    ,bpi_prices tableof2numbers
    ,price_plan nc_objects.object_id%TYPE);

  cn_dflt_sl_ordr_name_seq_size CONSTANT NUMBER := 10;

  PROCEDURE refresh_prod_price_components
  (
    v_sales_order_id IN nc_objects.object_id%TYPE
   ,p_change_date    IN nc_params.date_value%TYPE
   ,p_order_item_ids IN arrayofnumbers
   ,p_limit          IN NUMBER DEFAULT 500
  );

  FUNCTION has_mandatory_chars(p_order_item_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;
  FUNCTION has_empty_mandatory_chars(p_order_item_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;

  FUNCTION has_prices(p_order_item_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;
  FUNCTION count_prices(p_order_item_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;

  FUNCTION has_empty_prices(p_order_item_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;
  FUNCTION count_empty_prices(p_order_item_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;

  FUNCTION get_summary_prices_before
  (
    p_sales_order_id IN nc_objects.object_id%TYPE
   ,p_cbs            IN nc_objects.object_id%TYPE
  ) RETURN ref_cursor;
  FUNCTION get_summary_prices_after
  (
    p_sales_order_id IN nc_objects.object_id%TYPE
   ,p_cbs            IN nc_objects.object_id%TYPE
   ,p_oi_statuses    IN arrayofstrings
  ) RETURN ref_cursor;
  FUNCTION get_summary_prices_all
  (
    p_sales_order_id IN nc_objects.object_id%TYPE
   ,p_cbs            IN nc_objects.object_id%TYPE
   ,p_oi_statuses    IN arrayofstrings
  ) RETURN ref_cursor;
  FUNCTION get_summary_prices_so(p_sales_order_id IN nc_objects.object_id%TYPE)
    RETURN ref_cursor;

  FUNCTION get_items_data
  (
    p_scope_object_id  NUMBER
   , -- Top object - can be SO or CBS
    p_offering_attr_id NUMBER
   , -- attr_id of offering reference
    p_items_class_id   NUMBER
   , -- Item class_id (OI or BPI)
    p_location_attr_id NUMBER
   , -- attr_id of location reference
    p_status_attr_id   NUMBER
   , -- attr_id of status parameter
    p_allowed_statuses arrayofnumbers -- list of allowed list_value_ids for status parameter
  ) RETURN arrayofitems
    PIPELINED;

  PROCEDURE delete_bpi_offer_price_comp(p_instance_id IN nc_objects.object_id%TYPE);

  FUNCTION get_related_calculated_price(p_price_id IN nc_objects.object_id%TYPE)
    RETURN nc_objects.object_id%TYPE;

  FUNCTION get_ppc_id
  (
    p_instance_id IN nc_objects.object_id%TYPE
   ,p_spec_id     IN nc_objects.object_id%TYPE
  ) RETURN nc_objects.object_id%TYPE;

  PROCEDURE process_calculated_prices
  (
    v_sales_order_id IN nc_objects.object_id%TYPE
   ,p_change_date    IN nc_params.date_value%TYPE
   ,p_limit          IN NUMBER DEFAULT 500
  );

  PROCEDURE process_calculated_prices
  (
    v_sales_order_id IN nc_objects.object_id%TYPE
   ,p_change_date    IN nc_params.date_value%TYPE
   ,p_order_item_ids IN arrayofnumbers
   ,p_limit          IN NUMBER DEFAULT 500
  );

  PROCEDURE propagate_prices_to_instances
  (
    v_sales_order_id IN nc_objects.object_id%TYPE
   ,p_order_item_ids IN arrayofnumbers
   ,p_limit          IN NUMBER DEFAULT 500
  );

  FUNCTION is_nrc(p_specification_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;

  FUNCTION is_nrc_ppc(p_ppc_id IN nc_objects.object_id%TYPE) RETURN NUMBER;

  FUNCTION get_main_item_id(p_item_id IN nc_objects.object_id%TYPE)
    RETURN nc_objects.object_id%TYPE;

  FUNCTION get_available_locations(p_item_id IN nc_objects.object_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION get_items_used_by_locations
  (
    p_parent_id         IN nc_objects.object_id%TYPE
   ,p_location_ids      IN arrayofnumbers
   ,p_location_attr_ids IN arrayofnumbers
  ) RETURN SYS_REFCURSOR;

  FUNCTION is_bca_account_number_used(value_arg VARCHAR2) RETURN NUMBER;
  bca_account_num_gen_mode_mig NUMBER := 0;
  bca_account_num_mig_limit    NUMBER := 100000;

  FUNCTION get_new_bca_account_number
    RETURN NUMBER;

  FUNCTION lpad_safe
  (
    arg      VARCHAR2
   ,len      NUMBER
   ,pad_expr VARCHAR2 DEFAULT ' '
  ) RETURN VARCHAR2;

  default_order_item_separator VARCHAR2(100) := ' #';
  order_item_separator_key     VARCHAR2(100) := 'boe.order_item.separator';

  FUNCTION generate_order_item_name
  (
    NAME          VARCHAR2
   ,separator_arg VARCHAR2 DEFAULT NULL
  ) RETURN VARCHAR2;
  FUNCTION generate_sales_order_name RETURN VARCHAR2;
  FUNCTION generate_sales_order_name(pn_size IN NUMBER) RETURN VARCHAR2;

  cn_dflt_oi_name_seq_size CONSTANT NUMBER := 5;

  FUNCTION get_oi_naming_sequence RETURN VARCHAR2;
  FUNCTION get_oi_naming_sequence(pn_size IN NUMBER) RETURN VARCHAR2;

  FUNCTION getdatepatternsql(mask VARCHAR2) RETURN VARCHAR2;

  PROCEDURE propagate_values_to_offers
  (
    p_offer_ids           IN arrayofnumbers
   ,p_service_provider    IN nc_objects.object_id%TYPE
   ,p_currency            IN nc_objects.object_id%TYPE
   ,p_markets             IN arrayofnumbers
   ,p_customer_categories IN arrayofnumbers
   ,p_disribution_channel IN arrayofnumbers
  );

  PROCEDURE update_names
  (
    p_object_ids   IN arrayofnumbers
   ,p_name_prefix  IN VARCHAR2
   ,p_name_postfix IN VARCHAR2
  );

  PROCEDURE delete_reference_values
  (
    p_attr_id    IN nc_attributes.attr_id%TYPE
   ,p_object_ids IN arrayofnumbers
  );
  --  TYPE t_param_value IS TABLE OF nc_params.VALUE%TYPE;
  --  PROCEDURE replace_prices(p_ppc_ids        IN OUT NOCOPY arrayofnumbers,
  --                           p_price_ids      IN OUT NOCOPY arrayofnumbers,
  --                           p_price_values   IN OUT NOCOPY t_param_value);

  FUNCTION has_modified_prices(v_sales_order_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;
  FUNCTION get_actual_mrc_price_id
  (
    p_order_item_id IN nc_objects.object_id%TYPE
   ,p_date          IN nc_params.date_value%TYPE
  ) RETURN NUMBER;
  FUNCTION has_chars_to_propagate(p_order_item_id IN nc_objects.object_id%TYPE)
    RETURN NUMBER;

  PROCEDURE bulk_set_remove_parameters(p_params IN oe_tableofncparameters);
  PROCEDURE bulk_merge_remove_parameters(p_params IN oe_tableofncparameters);
  --  PROCEDURE remove_marked_parameters(p_params IN oe_tableofncparameters);
  PROCEDURE bind_characteristic_attributes
  (
    p_business_catalog_id         IN nc_objects.project_id%TYPE DEFAULT NULL
   ,p_business_customer_schema_id IN nc_attr_schemes.attr_schema_id%TYPE DEFAULT 9125737264713245962 /* Business Product Catalog Schema */
  );

  PROCEDURE unbind_char_attributes
  (
    p_business_catalog_id         IN nc_objects.project_id%TYPE
   ,p_business_customer_schema_id IN nc_attr_schemes.attr_schema_id%TYPE DEFAULT 9125737264713245962 /* Business Product Catalog Schema */
  );

  PROCEDURE copy_item_attr_char_values
  (
    p_copy_from nc_objects.object_id%TYPE
   ,p_copy_to   IN arrayofnumbers
  );

  PROCEDURE copy_so_attr_char_values
  (
    p_copy_from IN nc_objects.object_id%TYPE
   ,p_copy_to   IN nc_objects.object_id%TYPE
   ,attrs       IN arrayofnumbers
  );

  PROCEDURE copy_so_charvalues_to_oi_attrs;
  FUNCTION copy_so_charvalue_to_oi_attr
  (
    p_so_char_id             IN nc_objects.object_id%TYPE
   ,p_order_item_id          IN nc_objects.object_id%TYPE
   ,p_offer_char_id          IN nc_objects.object_id%TYPE
   ,p_offer_attr_id          IN nc_attributes.attr_id%TYPE
   ,p_offer_attr_type_id     IN nc_attributes.attr_type_id%TYPE
   ,p_offer_attr_type_def_id IN nc_attributes.attr_type_def_id%TYPE
   ,p_offer_attr_mask        IN nc_attributes.mask%TYPE
   ,p_source                 IN VARCHAR2
   ,p_offer_char_value       IN VARCHAR2
  ) RETURN VARCHAR2;

  FUNCTION resolve_ref_offer_char_value
  (
    p_char_value_id IN nc_objects.object_id%TYPE
   ,p_attr_type_id  IN nc_attributes.attr_type_id%TYPE
   ,p_mask          IN nc_attributes.mask%TYPE
  ) RETURN VARCHAR2;

  FUNCTION resolve_list_value
  (
    p_value            IN VARCHAR2
   ,p_attr_type_def_id IN nc_attributes.attr_type_def_id%TYPE
  ) RETURN nc_list_values.list_value_id%TYPE;

  PROCEDURE update_copied_order_items
  (
    p_copied_ids          IN tableof2numbers
   ,p_new_status          IN nc_params.list_value_id%TYPE
   ,p_new_action          IN nc_params.value%TYPE
   ,p_enable_bpi_for_edit IN NUMBER
  );

  PROCEDURE update_copied_oi_and_bpi
  (
    p_copied_ids              IN tableof2numbers
   ,delete_assigned_resources IN NUMBER
  );

  PROCEDURE update_copied_oi(p_copied_ids IN arrayofnumbers);

  PROCEDURE update_copied_sales_orders
  (
    p_copied_ids         IN OUT NOCOPY arrayofnumbers
   ,p_new_status         IN nc_params.list_value_id%TYPE
   ,ref_attrs_for_remove IN OUT NOCOPY arrayofnumbers
  );

  PROCEDURE delete_not_shared_phones(p_order_item_ids IN OUT NOCOPY arrayofnumbers);
  PROCEDURE delete_assigned_phones(p_order_item_ids IN OUT NOCOPY arrayofnumbers);

  FUNCTION get_char_attrs_by_item(p_item_id IN nc_objects.object_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION get_char_attrs_by_offering(p_offering_id IN nc_objects.object_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION get_catalog_attributes RETURN SYS_REFCURSOR;

  FUNCTION extract_numbers_array(p_cursor SYS_REFCURSOR)
    RETURN arrayofnumbers;

  FUNCTION extract_nubmers_array_pipe(p_cursor SYS_REFCURSOR)
    RETURN arrayofnumbers
    PIPELINED;
  FUNCTION collect_offers(category_id NUMBER) RETURN arrayofnumbers;
  FUNCTION get_top_oi_and_bpi(salesorderids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;
  FUNCTION get_oi_and_bpi_hierarchy(salesorderids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  PROCEDURE merge_items_prices
  (
    sourceitemid IN nc_objects.object_id%TYPE
   ,targetitemid IN nc_objects.object_id%TYPE
  );

  FUNCTION get_so_items_with_prices
  (
    p_sales_order_id IN nc_objects.object_id%TYPE
   ,p_order_items    IN arrayofnumbers
  ) RETURN SYS_REFCURSOR;

  PROCEDURE process_calculated_price
  (
    p_sales_order_id IN nc_objects.object_id%TYPE
   ,p_currentuser    IN VARCHAR2
   ,p_order_items    IN arrayofnumbers
   ,p_eventdate      IN VARCHAR2
  );

  PROCEDURE update_reference
  (
    p_attr_id   IN nc_attributes.attr_id%TYPE
   ,p_object_id IN nc_objects.object_id%TYPE
   ,p_value     IN nc_objects.object_id%TYPE
  );

  PROCEDURE set_references
  (
    p_attr_id   IN nc_attributes.attr_id%TYPE
   ,p_object_id IN nc_objects.object_id%TYPE
   ,p_values    IN arrayofnumbers
  );
  PROCEDURE set_references
  (
    p_attr_id    IN nc_attributes.attr_id%TYPE
   ,p_object_ids IN arrayofnumbers
   ,p_values     IN arrayofnumbers
  );

  PROCEDURE set_references
  (
    p_attr_id       IN nc_attributes.attr_id%TYPE
   ,p_object_values IN tableof2numbers
  );

  FUNCTION get_products(catalogue_id IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION load_offers_by_parent(parentofferid IN NUMBER) RETURN ref_cursor;
  FUNCTION get_mandatory_from_path
  (
    path  IN VARCHAR2
   ,delim IN VARCHAR2
  ) RETURN NUMBER;

  FUNCTION get_sales_order_items_cur
  (
    v_sales_order_id IN nc_objects.object_id%TYPE
   ,p_order_item_ids IN arrayofnumbers
  ) RETURN SYS_REFCURSOR;

  FUNCTION get_boe_order_items_cur
  (
    v_sales_order_id IN nc_objects.object_id%TYPE
   ,p_order_item_ids IN arrayofnumbers
  ) RETURN SYS_REFCURSOR;

  function get_bpi_ordered_by_count(bpi NUMBER) return NUMBER;

  PROCEDURE update_customer_locations(p_object_ids IN arrayofnumbers);

  PROCEDURE update_bpi_baselines
  (
    p_limit  IN NUMBER DEFAULT 1000
   ,p_commit IN NUMBER DEFAULT 1
  );

END pkg_boe;
/
