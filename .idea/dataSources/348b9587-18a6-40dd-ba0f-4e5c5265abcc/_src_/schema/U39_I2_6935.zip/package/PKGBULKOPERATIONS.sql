CREATE PACKAGE pkgBulkOperations
AS
	/*** DMNK 01-20-04 New package */
	PROCEDURE bulkCreateObjects(
		cardinality IN INTEGER,
		createNumberedObject IN NUMBER,
		spDelimiter IN VARCHAR2,
		fromN IN NUMBER,
		lngth IN NUMBER,
		spNameConv IN VARCHAR2,
		spName IN nc_objects.name%TYPE,
		parentID IN nc_objects.parent_id%TYPE,
		projectID IN nc_objects.project_id%TYPE,
		objectTypeID IN nc_objects.object_type_id%TYPE,
		attrSchemaID IN nc_objects.attr_schema_id%TYPE,
		spDescription IN nc_objects.description%TYPE,
		userName IN VARCHAR2,
		attrrefID IN nc_attributes.attr_id%TYPE,
		refID IN nc_objects.object_id%TYPE,
		showOrderIN IN NUMBER,
		orderAttrID IN nc_attributes.attr_id%TYPE,
		orderValue IN NUMBER
	);

	FUNCTION getNextID(
		name OUT NOCOPY nc_objects.name%TYPE
	)
	RETURN nc_objects.object_id%TYPE;

END pkgBulkOperations;
/
