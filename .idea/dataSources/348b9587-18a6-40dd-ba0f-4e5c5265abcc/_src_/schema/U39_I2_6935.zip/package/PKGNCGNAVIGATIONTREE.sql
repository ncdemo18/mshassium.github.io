CREATE package pkgNCGNavigationTree is
  function getNavigationPath(siteID NUMBER) return arrayofnumbers;
  function getNavigationTree(filterName VARCHAR2, siteID NUMBER) return arrayofnumbers;
  function getContainersBySite(filterName VARCHAR2, siteID NUMBER) return arrayofnumbers;
  function getChildren(filterName VARCHAR2, objectID NUMBER) return arrayofnumbers;
end pkgNCGNavigationTree;
/
