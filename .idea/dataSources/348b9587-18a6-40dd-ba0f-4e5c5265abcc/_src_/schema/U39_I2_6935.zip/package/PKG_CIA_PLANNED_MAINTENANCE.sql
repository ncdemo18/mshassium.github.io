CREATE PACKAGE pkg_cia_planned_maintenance IS

  --removes reference to MT from all maintenance impacted resources
  --and updates resource maintenance status
  --(removes 'In Maintenance' status if there are no other MT for current resource)
  PROCEDURE clear_resources_maintenance(mt_id in number);
  PROCEDURE clear_resources_maintenance(mt_id in arrayofnumbers);
  --adds reference to MT to all maintenance impacted resources
  --and updates resource maintenance status(sets 'In Maintenance' resource' status)
  PROCEDURE set_resources_maintenance(mt_id in number);
  PROCEDURE set_resources_maintenance(mt_id in number,full_mode in number);
  PROCEDURE set_resources_maintenance(mt_id in arrayofnumbers);
  PROCEDURE set_resources_maintenance(mt_id in arrayofnumbers,full_mode in number);

  --Similar to impact_monitor.jsp; doesn't take in count real network service level
  FUNCTION get_maintenance_what_if_jsp(object_id IN NUMBER, service_level IN NUMBER) RETURN nc_cia_imp_monitor_jsp_table;

  --return  that can ba caused by MT
  --full resources tree is returned when full_mode = 1
  --list of resources(MT:Resources) is returned when full_mode = 0
  function get_resource_ids(mt_id in number, full_mode number) return dep_resources;
  function get_resource_ids(mt_id in arrayofnumbers, full_mode number) return dep_resources;
  --return services that are based on resources caused by MT (MT:Resources)

  function get_service_ids(mt_id in number) return dep_resources;
  function get_service_ids(mt_id in arrayofnumbers) return dep_resources;

  PROCEDURE set_services_maintenance(mt_id in number);
  PROCEDURE set_services_maintenance(mt_id in arrayofnumbers);

  PROCEDURE clear_services_maintenance(mt_id in number);
  PROCEDURE clear_services_maintenance(mt_id in arrayofnumbers);

  function get_mts_for_resource(resource_id in number) return NC_CIA_NUMBER_TABLE;

  function CHILD_PARENT_RULE(resource_id in number) return NC_CIA_NUMBER_TABLE;

  function REFERENCE_RULE(resource_id in number) return NC_CIA_NUMBER_TABLE;

  -- Function searches for all active MTs for each resource in child-parent tree
  -- starting from input resource_id;
  -- on each resource from the tree function searches for active MTs on resource
  -- referenced by attribute "Network Element" from input resource_id
  function HIERARCHY_NE_RULE(resource_id in number) return NC_CIA_NUMBER_TABLE;


END pkg_cia_planned_maintenance;
/
