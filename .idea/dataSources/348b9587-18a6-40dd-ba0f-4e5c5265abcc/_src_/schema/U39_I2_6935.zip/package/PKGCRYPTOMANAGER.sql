CREATE PACKAGE pkgcryptomanager IS
    /*
      Sets key for encrypt/decrypt passed from application.
      Also sets algorithm (DES, 3DES, AES256 etc), mode of operation (ECB, CBC, OFB etc), padding (PKCS5, NONE).
	  Mode of operation and padding can be null. By default will be used CBC and PKCS5 respectively.
    */
    PROCEDURE set_key (key_hex IN VARCHAR2, algorithm_name in varchar2, operation_mode in varchar2, padding in varchar2);

    /*
      Clear crypto key.
      Should be ALWAYS called when all crypto operations complited in trancsation.
    */
    PROCEDURE remove_key;

    /*
      Decrypts string value.
      If key not set, returns value without decryption
    */
    FUNCTION decrypt_value (p_encrypted_value in varchar2) return varchar2;

    /*
      Encrypts string value.
      Key must be set before perform encrypt
    */
    FUNCTION encrypt_value (p_plain_value in varchar2) return varchar2;

    /*
      If key is already set return 'yes'
      Otherwise - return 'no'
    */
    FUNCTION is_key_already_set return varchar2;
END pkgcryptomanager;
/
