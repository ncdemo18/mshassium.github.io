CREATE package pkgMappingRules is

  /**
  * This function returns Connectors ID of connector card which was inserted into device.
  * Connector card should have one connector.
  * This function must be used in Port-Connector SQL Rule with get_ports_on_insrt_cons_card.
  *
  * @param card_to_insert - ID of card with connectors to insert.
  * @param card_source_ids - allowable source object IDs of this card.
  * @return number - id of connector.
  */
  function get_cons_on_insrt_cons_card(
    card_to_insert number,
    card_source_ids arrayofnumbers
  ) return number;

  /**
  * This function returns TableOf2Numbers of PairOfNumbers of Ports IDs and Connectors IDs
  * which should be connected after connector card with one connector insertion in device.
  * This function must be used in Port-Connector SQL Rule with get_cons_on_insrt_cons_card.
  *
  * @param connectors - Connectors of connector card. See get_cons_on_insrt_cons_card.
  * @param source_card_with_ports_ids - allowable source object IDs of interface card.
  * @param slot_map - TableOf2Numbers of slots mapping. E.g. TableOf2Numbers(PairOfNumbers(3, 21), PairOfNumbers(3, 22)).
  * @return tableof2numbers
  */
  function get_ports_on_insrt_cons_card(
    connectors arrayofnumbers,
    source_card_with_ports_ids arrayofnumbers,
    slot_map tableof2numbers
  ) return tableof2numbers;

  /**
  * This function returns Connectors IDs of connector card after interface card insertion in device.
  * Connector card should have one connector.
  * This function must be used in Port-Connector SQL Rule with get_ports_on_insrt_ports_card.
  *
  * @param card_to_insert - ID of interface card to insert.
  * @param port_card_source_ids - allowable source object IDs of interface card.
  * @param cons_card_source_ids - allowable source object IDs of connector card.
  * @param slot_map - TableOf2Numbers of slots mapping. E.g. TableOf2Numbers(PairOfNumbers(3, 21), PairOfNumbers(3, 22)).
  * @return number - id of connector.
  */
  function get_cons_on_insrt_ports_card(
    card_to_insert number,
    port_card_source_ids arrayofnumbers,
    cons_card_source_ids arrayofnumbers,
    slot_map tableof2numbers
  ) return number;

  /**
  * This function returns TableOf2Numbers of PairOfNumbers of Ports IDs and Connectors IDs
  * which should be connected after interface card insertion in device.
  * This function must be used in Port-Connector SQL Rule with get_cons_on_insrt_ports_card.
  *
  * @param card_to_insert - ID of interface card to insert.
  * @param source_card_with_ports_ids - IDs of source interface card.
  * @param connectors - Connectors of connector card. See get_cons_on_insrt_ports_card.
  *
  * @return tableof2numbers
  */
  function get_ports_on_insrt_ports_card(
    card_to_insert number,
    source_card_with_ports_ids arrayofnumbers,
    connectors arrayofnumbers
  ) return tableof2numbers;

  /**
  * This function returns Connectors IDs of SFP card which was inserted into connector-card.
  *
  * @param sfp_to_insert - ID of SFP which was inserted.
  * @param source_sfp_carriers_ids - IDs of source cards in which sfp_to_insert can be inserted.
  * @return arrayofnumbers
  */
  function get_connectors_on_insert_sfp(
    sfp_to_insert number,
    source_sfp_carriers_ids arrayofnumbers
  ) return arrayofnumbers;

  /**
  * This function returns TableOf2Numbers of PairOfNumbers of Ports IDs and Connectors IDs which should be connected after SFP card insertion.
  *
  * @param connectors - Connectors of SFP card. See get_connectors_on_insert_sfp.
  * @param source_card_with_ports_ids - IDs of source interface card.
  * @param slot_map - TableOf2Numbers of slots mapping. E.g. TableOf2Numbers(PairOfNumbers(3, 21), PairOfNumbers(3, 22)).
  * @return tableof2numbers
  */
  function get_ports_on_insert_sfp(
    connectors arrayofnumbers,
    source_card_with_ports_ids arrayofnumbers,
    slot_map tableof2numbers
  ) return tableof2numbers;

  /**
  * This function returns TableOf2Numbers of PairOfNumbers of Ports IDs and Connectors IDs which should be connected after SFP card insertion.
  * Note: It is used if order_number of SFP ports on the interface card is the same as order_number of SFP slots on the connector card.
  *
  * @param connectors - Connectors of SFP card. See get_connectors_on_insert_sfp.
  * @param source_card_with_ports_ids - IDs of source interface card.
  * @param slot_map - TableOf2Numbers of slots mapping. E.g. TableOf2Numbers(PairOfNumbers(3, 21), PairOfNumbers(3, 22)).
  * @return tableof2numbers
  */
  function get_ports_on_insert_sfp_card(
    connectors arrayofnumbers,
    source_card_with_ports_ids arrayofnumbers,
    slot_map tableof2numbers
  ) return tableof2numbers;

  /**
  * This function returns TableOf2Numbers of PairOfNumbers of Ports IDs and Connectors IDs which should be connected after SFP card deletion.
  * Note: Connectors in results will be nulls because there are not connectors for connect.
  *
  * @param card_to_delete - ID of SFP or connector-card which will be deleted.
  * @param source_sfp_carriers_ids - IDs of source cards in which sfp_to_insert can be inserted.
  * @param source_card_with_ports_ids - IDs of source cards which have ports to connect.
  * @return tableof2numbers
  */
  function get_ports_on_delete_sfp(
    card_to_delete number,
    source_sfp_carriers_ids arrayofnumbers,
    source_card_with_ports_ids arrayofnumbers
  ) return tableof2numbers;

  /**
  * This function returns Connectors IDs of SFP card which provide connectors for inserted card.
  *
  * @param card_to_insert - ID of card with ports which was inserted.
  * @param source_sfp_carriers_ids - IDs of source cards in which sfp_to_insert can be inserted.
  * @param source_card_with_ports_ids - IDs of source cards which have ports to connect.
  * @param slot_map - TableOf2Numbers of slots mapping. E.g. TableOf2Numbers(PairOfNumbers(3, 21), PairOfNumbers(3, 22)).
  * @return arrayofnumbers
  */
  function get_connectors_on_insert_card(
    card_to_insert number,
    source_sfp_carriers_ids arrayofnumbers,
    source_card_with_ports_ids arrayofnumbers,
    slot_map tableof2numbers
  ) return arrayofnumbers;

  /**
  * This function returns TableOf2Numbers of PairOfNumbers of Ports IDs and Connectors IDs which should be connected after insertion of card with ports.
  *
  * @param card_to_insert - ID of card with ports which was inserted.
  * @param connectors - Connectors of SFP card. See get_connectors_on_insert_card.
  * @param slot_map - TableOf2Numbers of slots mapping. E.g. TableOf2Numbers(PairOfNumbers(3, 21), PairOfNumbers(3, 22)).
  * @return tableof2numbers
  */
  function get_ports_on_insert_card(
    card_to_insert number,
    connectors arrayofnumbers,
    slot_map tableof2numbers
  ) return tableof2numbers;

  /**
  * This function returns Connectors IDs of SFP card which provide connectors for inserted card.
  *
  * Note: Ports in results will be nulls.
  * @param card_to_delete - ID of card with ports which will be deleted.
  * @param source_sfp_carriers_ids - IDs of source cards in which sfp_to_insert can be inserted.
  * @param source_card_with_ports_ids - IDs of source cards which have ports to connect.
  * @return arrayofnumbers
  */
  function get_connectors_on_delete_card(
    card_to_delete number,
    source_sfp_carriers_ids arrayofnumbers,
    source_card_with_ports_ids arrayofnumbers
  ) return arrayofnumbers;

  /**
  * This function returns ID of port which is related to connector of SFP card.
  *
  * @param sfpslot_num - Order number of parent slot of SFP.
  * @param ccardslot_num - Order number of parent slot of carrier card for SFP.
  * @param slot_map - TableOf2Numbers of slots mapping. E.g. TableOf2Numbers(PairOfNumbers(3, 21), PairOfNumbers(3, 22)).
  * @param pcard - ID of SFP card.
  * @return number
  */
  function get_port_on_ports_card(
    sfpslot_num number,
    ccardslot_num number,
    slot_map tableof2numbers,
    pcard number
  ) return number;

  /**
  * This function returns ID of port which is related to connector of SFP card.
  * Note: It is used if order_number of SFP ports on the interface card is the same as order_number of SFP slots on the connector card.
  *
  * @param sfpslot_num - Order number of parent slot of SFP.
  * @param pcard - ID of SFP card.
  * @return number
  */
  function get_port_on_ports_card_for_sfp(
    sfpslot_num number,
    pcard number
  ) return number;

  /**
  * This function returns TableOf2Numbers of PairOfNumbers of Ports IDs and Connectors IDs which should be connected after SFP card insertion.
  *
  * @param connectors - Connectors of SFP card. See get_connectors_on_insert_card.
  * @return tableof2numbers
  */
  function get_emb_ports_on_insert_sfp(
    connectors arrayofnumbers
  ) return tableof2numbers;

  /**
  * This function returns embedded port's ID by ID of slot of SFP card and ID of device. It used in get_emb_ports_on_insert_sfp.
  *
  * @param slot - ID of slot of SFP card
  * @param device - ID of device
  * @return number
  */
  function get_embedded_combo_port(
    slot number,
    device number
  ) return number;

end pkgMappingRules;
/
