CREATE package pkg_ossjfm_utils
as

  function getDelayedEventsCount(p_confID number) return number;

  FUNCTION READ_LOCK(p_name in varchar2, p_timeout in number default 0) return number;
  FUNCTION WRITE_LOCK(p_name in varchar2, p_timeout in number default dbms_lock.maxwait) return number;
  FUNCTION RELEASE_LOCK(p_name in varchar2) return number;
end;
/
