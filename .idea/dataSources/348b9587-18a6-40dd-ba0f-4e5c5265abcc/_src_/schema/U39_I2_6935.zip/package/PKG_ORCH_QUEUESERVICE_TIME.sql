CREATE package PKG_ORCH_QUEUESERVICE_TIME
is
  /**
    Inserts new record into table tracking queue time for messages.
  */
  procedure createQueueMsgTimeRecord (msg_id in number, process_id in number, family_id in number);

  /**
    Saves dequeue time of message in a table
  */
  procedure setDequeueTime (msg_id in number);

  /**
    Saves end handling time of message in a table
  */
  procedure setEndHandleTime (msg_id in number);

  /*
    Returns cumulative time (in ms) spent by messages of a process in the queue
    (if for_family = 0 - based on process_id, else based on family_id)
    old version, doesn't consider messages handling time
  */
  function getTimeSpentInQueue_old(id in number, for_family in int default 0) return number;

  /*
    Returns cumulative time (in ms) spent by messages of a process in the queue
    (if for_family = 0 - based on process_id, else based on family_id)
    excluding times when process' messages were handled
  */
  function getTimeSpentInQueue(id in number, for_family in int default 0) return number;

  /*
    Clears intermidiate data that stores tracked time spent by messages of a process in the queue
    (if for_family = 0 - based on process_id, else based on family_id)
  */
  procedure clearTimeSpentInQueueData(id in number, for_family in int default 0);

  /*
    getTimeSpentInQueue + clearTimeSpentInQueueData
  */
  function getTimeSpentInQueueAndClear(id in number, for_family in int default 0) return number;

  /*
  	Calculates sum of times from this process sub-processes
  */
  function getSubProcessesQueueTime(id in number) return number;

end PKG_ORCH_QUEUESERVICE_TIME;
/
