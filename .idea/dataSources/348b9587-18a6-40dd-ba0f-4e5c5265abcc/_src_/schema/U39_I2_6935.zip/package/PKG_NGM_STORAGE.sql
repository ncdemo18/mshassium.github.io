CREATE PACKAGE PKG_NGM_STORAGE
AS

PROCEDURE clear_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2);

PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data NUMBER);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data VARCHAR2);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data ArrayOfNumbers);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data TableOf2Numbers);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data TableOf3Numbers);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data NGM_TableOf4Numbers);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data ArrayOfStrings);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data TableOf2Strings);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data NGM_TableOf3Strings);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data NGM_TableOf4Strings);
PROCEDURE store_data(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2, p_data TableOfStorage);

FUNCTION get_number(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN NUMBER;
FUNCTION get_string(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN VARCHAR2;
FUNCTION get_ArrayOfNumbers(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN ArrayOfNumbers;
FUNCTION get_TableOf2Numbers(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN TableOf2Numbers;
FUNCTION get_TableOf3Numbers(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN TableOf3Numbers;
FUNCTION get_TableOf4Numbers(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN NGM_TableOf4Numbers;
FUNCTION get_ArrayOfStrings(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN ArrayOfStrings;
FUNCTION get_TableOf2Strings(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN TableOf2Strings;
FUNCTION get_TableOf3Strings(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN NGM_TableOf3Strings;
FUNCTION get_TableOf4Strings(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN NGM_TableOf4Strings;
FUNCTION get_TableOfStorage(p_graph_id IN NUMBER,  p_request_id IN NUMBER,  p_rev_num IN NUMBER, v_key VARCHAR2) RETURN TableOfStorage;

END PKG_NGM_STORAGE;
/
