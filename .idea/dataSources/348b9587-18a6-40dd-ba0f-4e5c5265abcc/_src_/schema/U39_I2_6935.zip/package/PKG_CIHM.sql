CREATE PACKAGE pkg_cihm IS

cn_dflt_sl_ordr_name_seq_size CONSTANT NUMBER := 10;

bca_account_num_mig_limit    NUMBER := 100000000;
bca_account_num_gen_mode_mig NUMBER := 0;

/**
*@deprecated - this function causes performance lacks due to synchronization.
*Use get_next_account_number instead
*/
FUNCTION get_new_bca_account_number(gen_mode NUMBER DEFAULT 1)
    RETURN NUMBER;

FUNCTION generate_sales_order_name RETURN VARCHAR2;
FUNCTION is_bca_account_number_used(value_arg VARCHAR2) RETURN NUMBER;

FUNCTION generate_sales_order_name(pn_size IN NUMBER) RETURN VARCHAR2;

FUNCTION get_next_account_number RETURN NUMBER;

END pkg_cihm;
/
