CREATE package pkg_ii_dependencies as
  procedure dependencies_to_objects (proj_id in number);
  procedure all_dependencies_to_references (proj_id in number);
  procedure fs_dependencies_to_references (proj_id in number);
end pkg_ii_dependencies;
/
