CREATE package pkg_capacity_management
is

  type cursorType is ref cursor;

  type bigarrayofnumbers is table of number(38);

  /*
   * Returns bandwidth values of "Interface" parameters (13) of objects in kbps
   * @objectIDs - object_ids of nc_objects which bandwidth values will be calculated
   *
   * @return - table that contains rows of 2 strings: (<object_id>,<bandwidth value measured in kbps>)
   */
  function getInterfaceBandwidthInKBPS(objectIDs in arrayofnumbers)
    return tableof2strings;

  function GetAvailableIpAddressesInRange(templateID in number, objectID in number)
    return capacity_instance_row;

  function GetAvailableIprangesInRange(templateID in number, objectID in number)
    return capacity_instance_row;

  function getLevelForInstance(parentID in number, templateID in number)
    return number;

  function getLevelForNCInstance(objectID in number)
    return number;

  function getPercantageForGeneric(templateID in number, objectID in number)
    return number;

  function getNotices
    return pkg_capacity_management.cursortype;

  function calcQuery(query in clob, objectID in number)
    return varchar2;

  procedure applyListenersForTemplate(templateID in number);

  procedure deleteTI (parentID in number, templateID in number);

  procedure markToRecalculateTI(parentID in number, templateID in number);

  procedure markToRecalculateTT(templateID in number);

  procedure createTI (templateID in number,parentID in number,nameTi in varchar2);

  procedure deactivateTT(templateID in number);

  procedure activateTT(templateID in number);

  procedure deactivateTI(parentID in number, templateID in number);

  procedure activateTI(parentID in number, templateID in number);

  procedure createNotice(objectID in number, noticeID in number);

  procedure deleteTT(templateID in number);

  procedure link_level_notif(objectID in number);

  function getCapacityObjects(resource_object_id in number, rule_id in number) return ARRAYOFNUMBERS;

  function getAffectedObjects(dependsOnObjectID in number, templateIDs in arrayofnumbers, attrValue in arrayofnumbers, oldParentID in number, newParentID in number)
    return arrayofnumbers;

  function getCalculatedReference(objectID in number,attrID in number)
    return number;

  function getCalculatedValue(objectID in number,attrID in number)
    return varchar2;

  function getEmailBySqlQuery(notification_id in number, capacity_object_id in number , query  varchar2)
    return pkg_capacity_management.cursortype;

  procedure apply_all_cm_thresolds;

  /*
	createdObjectsSubQuery in varchar2 - SQL QUERY that shoud return set of created objects to create Threshold Instances according to Threshold Specifications configuration.
  */
  procedure applyThresholds(createdObjectsSubQuery in varchar2);

  procedure  calculate_all(flag number, max_row_num number);

  function getLevelForNCInstanceByValue(objectID in number, val in number)
    return number;

  function getLevelByValueAndTemplate(templateID in number, val in number )
    return number;

  procedure create_all_listeners;

  function  executeFunctionCall(templateID in number,objectID  in number, query in varchar2)
    return number;

  procedure createParamForCardPropogation;

  function addValueToProperty(properties in varchar2, property_name in varchar2, value in varchar2, delimiter varchar2)
    return varchar2;

  function removeValueFromProperty(properties in varchar2, property_name in varchar2, value in varchar2, delimiter varchar2)
    return varchar2;

  procedure excludeRuleFromListeners(ruleID in number);

  procedure excludeTemplateFromListeners(templateID in number, property_name varchar2);

  procedure excludeTemplateFromListeners(templateID IN NUMBER, propertyName IN VARCHAR2, objectType IN NUMBER, listenerActions IN ArrayOfNumbers);

  function getValidAttrForTT(listenerID in number)
    return varchar2;

  procedure updateValidAttr(objectID in number);

  procedure createListenerForCreateTI(templateID in number);

  procedure excludeTempFromCreateListeners(templateID in number, property_name varchar2);

  procedure applyListenersForDependOn(docID IN NUMBER, dependentOT IN NUMBER);

  function calculateCapacity(templateID IN NUMBER, capacityIDs IN arrayofnumbers, flagNotify IN NUMBER) RETURN arrayofnumbers;

  function getInstanceLevelByValues(instanceID in number, perc_value in number, total_value in number,
                                      used_value in number, avail_value in number, planned_to_use_value in number)
    return number;

  function updateLevelsByValues(templateId IN NUMBER, capacityIds IN arrayofnumbers, flagNotify IN NUMBER, viewDate DATE) RETURN arrayofnumbers;

  procedure fillConsumersTable(templateId IN NUMBER, capacityIds IN ARRAYOFNUMBERS, queryAttrId NUMBER, consumerType INTEGER, viewDate DATE );

  procedure mergeListener(actionid in number, subactionid in number, depends_on_ot in number,	is_class_res in number, object_class_res in number, object_class_name_res in varchar2, prefix_name in varchar2, listener_type_name in varchar2, temp_id in number);

  /*
  * Enables Capacity Management component's listeners and jobs
  * Sets true value to the property 'cm.enabled'.
  */
  procedure enable_cm;


  /*
  * Disables Capacity Management component's listeners and jobs
  * Sets false value to the property 'cm.enabled'.
  */
  procedure disable_cm;

end pkg_capacity_management;
/
