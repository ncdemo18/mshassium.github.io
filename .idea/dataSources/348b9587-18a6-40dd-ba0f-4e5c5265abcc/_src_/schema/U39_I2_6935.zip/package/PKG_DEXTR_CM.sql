CREATE PACKAGE "PKG_DEXTR_CM" AS

  PROCEDURE extract_data (
    top_object_ids IN arrayofnumbers
  );

  PROCEDURE import_data(
    batch_num IN INTEGER
  );

  procedure set_dblink_name(name varchar2);

  PROCEDURE clear_extracted_data;

  procedure prepare_tables;

  procedure provide_import_report;

  procedure validate_metamodel;

END PKG_DEXTR_CM;
/
