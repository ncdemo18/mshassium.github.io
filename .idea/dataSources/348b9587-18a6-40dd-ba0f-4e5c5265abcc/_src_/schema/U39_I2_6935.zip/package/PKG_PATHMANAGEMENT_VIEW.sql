CREATE package pkg_pathmanagement_view is

  function plv_get_nodes(node_spec_id IN number)
  return arrayofnumbers;

  function plv_get_edges( p_edge_spec_id IN NUMBER, p_node_sources IN ARRAYOFNUMBERS)
  RETURN TableOf3Numbers;

  function plv_get_interconnect_nodes(node_spec_id IN number)
  return arrayofnumbers;

  function plv_icnode_device(v_graph_id IN NUMBER, nes_spec_id IN NUMBER)
  return TableOf2Numbers;

  function plv_get_locations(node_spec_id IN number)
  return arrayofnumbers;

  function plv_location_icnode(v_graph_id IN NUMBER, nes_spec_id IN NUMBER)
  return TableOf2Numbers;

  function plv_location_device(v_graph_id IN NUMBER, nes_spec_id IN NUMBER)
  return TableOf2Numbers;

  function plv_number_active_links(param_spec_id IN NUMBER, source_objects TableOf2Numbers)
  return TableOf2Strings;

  function plv_edge_color(param_spec_id IN NUMBER, source_objects TableOf2Numbers)
  return TableOf2Strings;

  function plv_is_end_point(param_spec_id IN NUMBER, source_objects TableOf2Numbers)
  return TableOf2Strings;

  function plv_physical_link_colors(param_spec_id IN NUMBER, source_objects TableOf2Numbers)
  return TableOf2Strings;

  function plv_link_name(param_spec_id IN NUMBER, source_objects TableOf2Numbers)
  return TableOf2Strings;

  function plv_link_ids(param_spec_id IN NUMBER, source_objects TableOf2Numbers)
  return TableOf2Strings;

end pkg_pathmanagement_view;
/
