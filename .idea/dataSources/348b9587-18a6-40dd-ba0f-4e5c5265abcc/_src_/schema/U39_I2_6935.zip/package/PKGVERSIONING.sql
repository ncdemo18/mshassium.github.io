CREATE package pkgVersioning is
   subtype t_objectid is nc_objects.object_id%type;
   subtype t_attrid   is nc_attributes.attr_id%type;
   subtype t_name     is nc_objects.name%type;
   subtype t_strvalue is nc_params.value%type;

   TYPE IDCollection IS TABLE OF number NOT NULL;

   ATTR_ADDED_OBJECTS   constant t_attrid := 8051303575013812423;
   ATTR_REMOVED_OBJECTS constant t_attrid := 8051303575013812424;
   ATTR_WIP             constant t_attrid := 8051258306013811226;
   --NIAL0712 [25-03-2013] ["Is WIP Object" attribute isn't deleted from added objects] One row added
   ATTR_IS_WIP_OBJECT   constant t_attrid := 8053017825013732489;

   function commitWIPContainer(wipContainerId number) return arrayofnumbers;
   procedure discardWIPContainer(wipContainerId number);
end pkgVersioning;
/
