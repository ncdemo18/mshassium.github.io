CREATE package PKG_HDS_QUEUE_SERVICE is

  -- Author  : MIKHEYEV
  -- Created : 14:03:2011
  -- Purpose : Contains operations for HDS queue messages store and access

  SUCCESS NUMBER(1) := 0;

  UNSUCCESS NUMBER(1) := 1;


  procedure acquireNextMessage(messageId OUT NUMBER, messageType OUT NUMBER, sessionId OUT NUMBER, commandId OUT NUMBER, contextId OUT NUMBER, data OUT CLOB);
  procedure getNextMessage(previousMessageId IN NUMBER, sessionId IN NUMBER, messageId OUT NUMBER, messageType OUT NUMBER, commandId OUT NUMBER, contextId OUT NUMBER, vdata OUT CLOB);
  
  function getWaitingMessageCount return int;

  function getMessageCountForSession(messageType IN NUMBER, sessionId IN NUMBER) return int;
  function getAllMessageCountForSession(sessionId IN NUMBER) return int;

  function acquireLockInternal(contextId IN NUMBER ,locktimeout IN INTEGER default 1) return NUMBER;

  procedure storeMessage(messageId IN NUMBER, messageType IN NUMBER, sessionId IN NUMBER, commandId IN NUMBER, contextId IN NUMBER, vdata in VARCHAR2, previousMessageId in NUMBER);
  procedure removeMessage(messageId IN NUMBER);

  procedure acquireLock(contextId IN NUMBER);
  procedure acquireLock(contextId IN NUMBER ,timeout IN INTEGER);
  procedure releaseLock(contextId IN NUMBER);

end PKG_HDS_QUEUE_SERVICE;
/*
 WITHOUT LIMITING THE FOREGOING, COPYING, REPRODUCTION, REDISTRIBUTION,
 REVERSE ENGINEERING, DISASSEMBLY, DECOMPILATION OR MODIFICATION
 OF THE SOFTWARE IS EXPRESSLY PROHIBITED, UNLESS SUCH COPYING,
 REPRODUCTION, REDISTRIBUTION, REVERSE ENGINEERING, DISASSEMBLY,
 DECOMPILATION OR MODIFICATION IS EXPRESSLY PERMITTED BY THE LICENSE
 AGREEMENT WITH NETCRACKER. 
 
 THIS SOFTWARE IS WARRANTED, IF AT ALL, ONLY AS EXPRESSLY PROVIDED IN
 THE TERMS OF THE LICENSE AGREEMENT, EXCEPT AS WARRANTED IN THE
 LICENSE AGREEMENT, NETCRACKER HEREBY DISCLAIMS ALL WARRANTIES AND
 CONDITIONS WITH REGARD TO THE SOFTWARE, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING WITHOUT LIMITATION ALL WARRANTIES AND
 CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 TITLE AND NON-INFRINGEMENT.
 
 Copyright (c) 1995-2015 NetCracker Technology Corp.
 
 All Rights Reserved.
*/
/
