CREATE PACKAGE pkgDomainSecurity
AS
    /**
     * Function returns the table with the found grants
     * on the passed objects (<object_id, grants>).
     * If the domain undefined for some objects its ids
     * will be omited in the result set. If some object has
     * the domain but no domain from its domain hierarchy has
     * defined grants then will be returned null grants.
     */
    FUNCTION getGrants(
        userID IN nc_objects.object_id%TYPE,
        objectIDs IN ARRAYOFNUMBERS,
        sqlRule IN nc_params.value%TYPE
    ) RETURN TABLEOF2NUMBERS;

    /**
     * Function returns the table with found
     * domains' ids for passed objects' ids.
     * Table row contains 2 number: <object_id, domain_id>
     */
    FUNCTION getObjectsDomains(
        p_objects_ids IN ARRAYOFNUMBERS,
        p_sql_rule IN nc_params.value%TYPE
    ) RETURN TABLEOF2NUMBERS;

    /**
     * Returns object's domain id.
     */
    FUNCTION getObjectDomain(
        p_object_id IN nc_objects.object_id%TYPE,
        p_sql_rule IN nc_params.value%TYPE
    ) RETURN nc_objects.object_id%TYPE;

END pkgDomainSecurity;
/
