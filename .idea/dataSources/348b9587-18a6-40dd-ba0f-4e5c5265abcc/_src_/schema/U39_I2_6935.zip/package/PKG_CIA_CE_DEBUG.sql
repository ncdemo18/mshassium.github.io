CREATE package pkg_cia_ce_debug is

    log_level_detail_debug CONSTANT PLS_INTEGER := 4;

    log_level_debug CONSTANT PLS_INTEGER := 3;
    log_level_error CONSTANT PLS_INTEGER := 2;

    log_level PLS_INTEGER := log_level_debug;

    PROCEDURE log(msg VARCHAR2, log_lvl PLS_INTEGER := pkg_cia_ce_debug.log_level);

    PROCEDURE log_exception;

    PROCEDURE clear_log;

    --Convert arrayofnumbers into comma delimited list
    FUNCTION get_list(SELF IN arrayofnumbers) RETURN VARCHAR2;

    --Helper procedure. It writes current state of
    --nc_cia_dependencies_temp, nc_cia_severities_temp tables
    PROCEDURE dump_temporary_tables(step IN VARCHAR2);



end pkg_cia_ce_debug;
/
