CREATE PACKAGE pkgNCDataObjectParams
AS
  TYPE objects_ids_arrray_type IS TABLE OF NUMBER;

  PROCEDURE processcollections_withlogging(
    param_coll_u      IN nc_params_object_table := NULL, --single parameters (Clob attribute types can be also saved throug it)
    param_coll_m      IN nc_params_object_table := NULL, --multiple parameters (Clob attribute types can be also saved throug it)
    ref_coll_u        IN nc_ref_object_table := NULL, --single references
    ref_coll_m        IN nc_ref_object_table := NULL, --multiple references
    mref_coll_u       IN NC_META_REFERENCE_OBJECT_TABLE := NULL, --single meta-referneces
    mref_coll_m       IN NC_META_REFERENCE_OBJECT_TABLE := NULL, --multiple meta-referneces
    param_coll_delete IN nc_params_object_table := NULL, --parameters
    ref_coll_delete   IN nc_ref_object_table := NULL, -- references
    mref_coll_delete  IN NC_META_REFERENCE_OBJECT_TABLE := NULL, --meta-references
    objects_ids_array IN arrayofnumbers DEFAULT NULL -- IDs array of objects to be locked for update
  );

  PROCEDURE clearErrLog(transaction_id IN VARCHAR2);

END;
/
