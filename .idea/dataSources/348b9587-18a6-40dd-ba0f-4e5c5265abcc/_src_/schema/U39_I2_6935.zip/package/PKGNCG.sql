CREATE PACKAGE          "PKGNCG" is
	type ArrayOfIDs is ref cursor;
	function getSiteSimpleObjects( site_id number, rx number, ry number, rw number, rh number ) return ArrayOfIDs; --depricated
	function getSiteSimpleLengthyObjects( site_id number, rx number, ry number, rw number, rh number ) return ArrayOfIDs; --depricated
	function getAllSiteSimpleObjects( site_id number, rx number, ry number, rw number, rh number ) return ArrayOfIDs;
    function getSiteOSPObjects( site_id number, rx number, ry number, rw number, rh number ) return ArrayOfIDs;
	function isIntersection(rx number, ry number, rw number, rh number, x number, y number, w number, h number) return number;
end;



/
