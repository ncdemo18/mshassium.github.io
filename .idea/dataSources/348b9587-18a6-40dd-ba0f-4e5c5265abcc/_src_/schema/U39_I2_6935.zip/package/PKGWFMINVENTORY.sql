CREATE package pkgwfminventory is
  FUNCTION get_skillset_leafs(skill_set_id NUMBER) RETURN arrayofnumbers;
  FUNCTION get_multi_emp_activities(employee_id NUMBER, rea_id NUMBER, act_date DATE) RETURN arrayofnumbers;
  FUNCTION get_activities_by_user_id(nc_user_id NUMBER) RETURN arrayofnumbers;

  PROCEDURE abstractUpdate(obj_id NUMBER, old_attr_id NUMBER, input_date_value date);

  FUNCTION prolongRG(rg_id NUMBER, prolonged_date date, from_date DATE, needSave NUMBER) RETURN DATE;
  FUNCTION prolongPos(pos_id NUMBER, prolonged_date date, from_date DATE, needSave NUMBER) RETURN DATE;
  FUNCTION prolongWC(wc_id NUMBER, prolonged_date date, from_date DATE, needSave NUMBER) RETURN DATE;

  FUNCTION getInitialProlongedDate(from_date DATE) RETURN DATE;

  PROCEDURE autoProlongationPosRG;

  FUNCTION prolongRG(rg_id NUMBER, from_date DATE) RETURN DATE;
  FUNCTION prolongPos(pos_id NUMBER, from_date DATE) RETURN DATE;
  FUNCTION prolongWC(wc_id NUMBER, from_date DATE) RETURN DATE;

  FUNCTION get_pos_max_to(rg_id NUMBER) RETURN DATE;
  PROCEDURE changeAutoProlongJob(jobInterval VARCHAR);
end pkgwfminventory;
/
