CREATE PACKAGE "GRAPHICS_STYLING"
IS
  COLOR_PROFILE_OBJECT_TYPE_ID CONSTANT NUMBER(20,0) := 9132691108213953990;
  LEGEND_PROFILE_OBJECT_TYPE_ID CONSTANT NUMBER(20,0) := 9132716896613958143;
  ABSTRACT_STYLING_PROFILE_OT_ID CONSTANT NUMBER(20,0) := 9134913313713681818;

  PROFILE_ENABLED_ATTR_ID CONSTANT NUMBER(20,0) := 9134964030013726513;
  PROFILE_ENABLED_YES_VALUE CONSTANT NUMBER(20,0) := 9134964696913727228;
  PROFILE_ENABLED_NO_VALUE CONSTANT NUMBER(20,0) := 9134964696913727229;

  COLOR_PROFILE_TABLE_ATTR_ID CONSTANT NUMBER(20,0) := 9133823731813230155;
  NEW_COLOR_PROFILE_ATTR_ID CONSTANT NUMBER(20,0) := 9133825470613233146;

  LEGEND_PROFILE_TABLE_ATTR_ID CONSTANT NUMBER(20,0) := 9133823731813230228;
  NEW_LEGEND_PROFILE_ATTR_ID CONSTANT NUMBER(20,0) := 9133825470613233137;

  STYLING_PROFILE_ATTR_NAME CONSTANT VARCHAR2(50) := 'Styling Profile';
  STYLING_PROFILES_ATTR_NAME CONSTANT VARCHAR2(50) := 'Styling Profiles';
  DELIMITER_BUTTON_NAME CONSTANT VARCHAR2(50) := '\-';

  ACTIVE_VALUE CONSTANT NUMBER(1,0) := 1;
  CREATE_ACTION_TYPE CONSTANT NUMBER(2,0) := 0;
  CREATE_PROFILE_CLASS CONSTANT VARCHAR2(100) := 'com.netcracker.styling.listener.CreateProfileListenerHome';

  PROCEDURE CREATE_AGGREGATION_GS_PROFILE(
    profile_id IN NUMBER,
    profile_name IN VARCHAR2,
    profile_description IN VARCHAR2,
    profile_container_id IN NUMBER,
    profile_type_id IN NUMBER,
    order_number IN NUMBER DEFAULT 0
  );

  PROCEDURE INIT_PROFILE_ENABLED(
    profileId number
  );

  PROCEDURE CREATE_GS_PROFILE(
    profile_id IN NUMBER,
    profile_name IN VARCHAR2,
    profile_description IN VARCHAR2,
    profile_container_id IN NUMBER,
    profile_type_id IN NUMBER,
    profile_configuration_id IN NUMBER,
    profile_configuration IN VARCHAR2
  );

  PROCEDURE CREATE_AGGREGATION_PROFILE_OT(
    objectTypeId number,
    aDesciption varchar2
  );

  PROCEDURE CREATE_COLOR_PROFILE_LISTENER(
    listenerId number,
    componentName varchar2,
    componentConfigurationId number,
    errorMessageResourceId number
  );

  PROCEDURE CREATE_LEGEND_PROFILE_LISTENER(
    listenerId number,
    componentName varchar2,
    componentConfigurationId number,
    errorMessageResourceId number
  );

  PROCEDURE ADD_COLOR_PROFILE_TABLE(
    objectTypeId number,
    newProfileButtonAttr varchar2
  );

  PROCEDURE ADD_LEGEND_PROFILE_TABLE(
    objectTypeId number,
    newProfileButtonAttr number
  );

  PROCEDURE ADD_STYLING_PROFILES_TABLE(
    tableGenerativeAttr number,
    objectType number,
    childrenObjectType number,
    tableGenerativeAttrTypeDef number,
    tableGenerativeAttrGroup number,
    aDesciption varchar2,
    showOrder number default 0
  );

  PROCEDURE CREATE_BUTTON_ON_TABLE(
    buttonAttrId number,
    objectTypeId number,
    tableGenerativeAttrTypeDef number,
    tableGenerativeAttrGroupId number,
    buttonName varchar2,
    buttonCommand varchar2,
    img varchar2,
    img_off varchar2,
    showOrder number,
    aDescription varchar2
  );

  PROCEDURE CREATE_DELIMITER_ON_TABLE(
    delimiterAttrId number,
    objectTypeId number,
    tableGenerativeAttrTypeDef number,
    tableGenerativeAttrGroupId number,
    showOrder number,
    aDescription varchar2
  );

END;
/
