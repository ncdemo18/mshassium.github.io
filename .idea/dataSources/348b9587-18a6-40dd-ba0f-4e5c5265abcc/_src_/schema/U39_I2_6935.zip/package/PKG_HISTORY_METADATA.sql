CREATE package pkg_history_metadata
as
/**
 * Author: VANO7040
 */
   subtype t_objectid       is nc_objects.object_id%type;
   subtype t_attrid         is nc_attributes.attr_id%type;
   subtype t_objectypetid   is nc_object_types.object_type_id%type;
   subtype t_name           is nc_objects.name%type;
   subtype t_table_name     is varchar(200);
   subtype t_field_name     is varchar(200);
   subtype t_strvalue       is nc_params.value%type;
   subtype t_strvaluebig    is varchar(32000);
   subtype t_number         is number;
   subtype t_entity_type    is varchar(50);
   subtype t_operation_type is number;
   subtype t_fire_flag      is number(1);
   subtype t_query          is varchar2(4000);

   subtype t_object_type    is nc_object_types%rowtype;
   subtype t_attribute      is nc_attributes%rowtype;
   subtype t_schema         is nc_attr_schemes%rowtype;
   subtype t_group          is nc_attr_groups%rowtype;
   subtype t_type_def       is nc_attr_type_defs%rowtype;
   subtype t_list_value     is nc_list_values%rowtype;
   subtype t_attr_type_link is nc_attr_object_types%rowtype;
   subtype t_event          is nc_history_metadata%rowtype;

   type t_rec_table_info is record
   (
      entity_type   t_entity_type,
      table_name    t_table_name,
      pk_field_name t_field_name
   );

   type t_ref_info is record
   (
      entity_type t_entity_type,
      entity_id t_name,
      name t_strvalue
   );

   type t_refs is table of t_ref_info;

   type t_table_info is table of t_rec_table_info;
   type t_strvalues  is table of t_strvalue index by binary_integer;
   type t_attrids    is table of t_attrid index by binary_integer;
   type t_events     is table of t_event;
   type t_cursor     is ref cursor;

   /**
    * Disable history logging for current transaction only
    */
   procedure disable;

   /**
    * Enable history logging for current transaction only
    */
   procedure enable;

   /**
    * Disable global history logging (affect all users)
    */
   procedure disable_global;

   /**
    * Enable global history logging (affect all users)
    */
   procedure enable_global;

   /**
    * Is local history enabled or not
    */
   function is_history_enabled return number;


   /**
    * Attribute events
    */
   procedure fire_insert_attribute(new_value t_attribute);
   procedure fire_update_attribute(old_value t_attribute, new_value t_attribute);
   procedure fire_delete_attribute(old_value t_attribute);

   /**
    * Attribute group events
    */
   procedure fire_insert_group(new_value t_group);
   procedure fire_update_group(old_value t_group, new_value t_group);
   procedure fire_delete_group(old_value t_group);

   /**
    * Attribute type def events
    */
   procedure fire_insert_type_def(new_value t_type_def);
   procedure fire_update_type_def(old_value t_type_def, new_value t_type_def);
   procedure fire_delete_type_def(old_value t_type_def);

   /**
    * ListValue events
    */
   procedure fire_insert_list_value(new_value t_list_value);
   procedure fire_update_list_value(old_value t_list_value, new_value t_list_value);
   procedure fire_delete_list_value(old_value t_list_value);

   /**
    * ObjectType events
    */
   procedure fire_insert_object_type(new_value t_object_type);
   procedure fire_update_object_type(old_value t_object_type, new_value t_object_type);
   procedure fire_delete_object_type(old_value t_object_type);

   /**
    * Attribute Schema events
    */
   procedure fire_insert_schema(new_value t_schema);
   procedure fire_update_schema(old_value t_schema, new_value t_schema);
   procedure fire_delete_schema(old_value t_schema);

   /**
    * Attribute type link events
    */
   procedure fire_insert_attr_type_link(new_value t_attr_type_link);
   procedure fire_update_attr_type_link(old_value t_attr_type_link, new_value t_attr_type_link);
   procedure fire_delete_attr_type_link(old_value t_attr_type_link);


   /**
    * Auxilary methods
    */
   procedure set_current_user_info(p_id t_strvalue, p_name t_strvalue);
   function get_current_user_info return t_strvalue;

   function isDifferent(a varchar2, b varchar2) return boolean;

end;
/
