CREATE package pkg_array_cache is
 p_array arrayofnumbers;
 function get_array return arrayofnumbers;
 procedure set_array(array_ in arrayofnumbers);
 function get_array(array_ arrayofnumbers) return arrayofnumbers;
 procedure clear_array;
end;
/
