CREATE PACKAGE "PKG_CAMPAIGN_MEMBERS_QUANTITY" as

FUNCTION computeCampaignMembersQuantity (tableName IN VARCHAR2) RETURN NUMBER;

end pkg_campaign_members_quantity;
/
