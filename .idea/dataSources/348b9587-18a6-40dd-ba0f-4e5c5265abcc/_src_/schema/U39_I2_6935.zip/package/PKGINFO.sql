CREATE PACKAGE pkginfo
IS
   ATTR_REFERENCE_TO_TOP_SITE constant nc_attributes.attr_id%type := 703;

   FUNCTION gettopsite (p_project_id     nc_objects.project_id%type,
                        p_object_type_id nc_objects.object_type_id%type := pkgObjectType.SITE_TYPE)
      RETURN nc_objects.object_id%type;

   FUNCTION getprojectbyobject (p_object_id NUMBER)
      RETURN NUMBER;

   --Added 03/24/05 by DMANSDG Issue:Ability to open reference explorer on specified search set
   FUNCTION getpropertyvalue (
      p_object_type_id   NUMBER,
      p_property         VARCHAR2,
      p_separator        VARCHAR2
   )
      RETURN VARCHAR2;
END;
/
