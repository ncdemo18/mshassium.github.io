CREATE package NLSFUNCTIONS is
  -- output data types
  --1
  type Objects is record(
    object_id NUMBER,
    name VARCHAR2(1000),
    description VARCHAR2(2000)
  );
  --2
  type Resources is record(
    resource_id NUMBER,
    name VARCHAR2(1000)
  );
  --3
  type AtribGroups is record(
    attr_group_id NUMBER,
    name VARCHAR2(1000),
    subgroup VARCHAR2(1000)
  );
  --4
  type AtribSchema is record(
    attr_schema_id NUMBER,
    name VARCHAR2(1000)
  );
  --5
  type Atributes is record(
    attr_id NUMBER,
    name VARCHAR2(1000),
    tooltip VARCHAR2(1000)
  );
  --6
  type ListValues is record(
    list_value_id NUMBER,
    name VARCHAR2(1000)
  );
  --7
  type ObjectTypes is record(
    object_type_id NUMBER,
    name VARCHAR2(1000)
  );

  -- Objects
  type resultTableObj is table of Objects;
  function check_nls_objects(lang_id number)
  return resultTableObj
  pipelined;

  -- Resources
  type resultTableRes is table of Resources;
  function check_nls_resources(lang_id number)
  return resultTableRes
  pipelined;

  -- attr_groups
  type resultTableAG is table of AtribGroups;
  function check_nls_attr_groups(lang_id number)
  return resultTableAG
  pipelined;

  -- Attribute Schemes
  type resultTableAS is table of AtribSchema;
  function check_nls_attr_schemes(lang_id number)
  return resultTableAS
  pipelined;

  --Attributes
  type resultTableAttr is table of Atributes;
  function check_nls_attributes(lang_id number)
  return resultTableAttr
  pipelined;

  -- list_values
  type resultTableLV is table of ListValues;
  function check_nls_list_values(lang_id number)
  return resultTableLV
  pipelined;

  -- object_types
  type resultTableOT is table of ObjectTypes;
  function check_nls_object_types(lang_id number)
  return resultTableOT
  pipelined;

end NLSFUNCTIONS;
/
