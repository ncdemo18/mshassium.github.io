CREATE package pkg_cmt_ct_dk is

  function dbtrigger(
    v_is_inserting in boolean,
    v_is_updating in boolean,
    v_is_deleting in boolean,
    v_table_name in varchar2,
    v_old_ci_id in varchar2,
    v_old_row in NC_CMT_Hash_Table,
    v_new_ci_id in varchar2,
    v_new_row in NC_CMT_Hash_Table,
    v_ci_table_name in varchar2,
    v_ci_key in varchar2
  ) return varchar2;

end pkg_cmt_ct_dk;
/
