CREATE package pkg_oe_BulkOperations is

 -- Author  : MISK0809
  -- Created : 19.01.2010 12:50:54
  -- Purpose : This package for bulck cration nc_objects and bulk setting parameters to nc_objects

  -- Public function and procedure declarations
    procedure create_nc_object(nc_obj in oe_nc_object,
                             in_order_number in nc_objects.order_number%type,
                             nc_object_id out nc_objects.object_id%TYPE);

  procedure update_nc_object(nc_obj in oe_nc_object, nc_obj_id in nc_objects.object_id%type);

  procedure bulk_create_nc_object (nc_objs in oe_table_of_nc_objects, nc_object_ids out Arrayofnumbers);

  procedure set_nc_parameter(param in oe_nc_parameter);

  procedure bulk_set_nc_parameters(params in oe_tableofncparameters);

  procedure bulk_merge_nc_parameters(params in oe_tableofncparameters);

  procedure bulk_get_nc_parameters(in_params in tableof2numbers, out_params out oe_tableofncparameters);

  procedure merge_nc_object(nc_obj in oe_nc_object,
                            in_obj_id in nc_objects.object_id%type,
                            in_order_number in nc_objects.order_number%type,
                            out_obj_id out nc_objects.object_id%type);

  procedure bulk_delete_nc_objects(nc_object_ids in arrayofnumbers);

  procedure bulk_get_params(in_params in tableof2numbers, out_params out oe_tableofncparameters);

  procedure bulk_get_references(in_params in tableof2numbers, out_params out oe_tableofncparameters);

  procedure bulk_get_meta_references(in_params in tableof2numbers, out_params out oe_tableofncparameters);

  FUNCTION bulk_load_params(in_params in tableof2numbers) RETURN SYS_REFCURSOR;

  FUNCTION bulk_load_references(in_params in tableof2numbers) RETURN SYS_REFCURSOR;

  FUNCTION bulk_load_meta_references(in_params in tableof2numbers) RETURN SYS_REFCURSOR;

  procedure bulk_clear_params(params in TABLEOF2NUMBERS);

  procedure bulk_clear_refs(params in TABLEOF2NUMBERS);

  procedure bulk_clear_meta_refs(params in TABLEOF2NUMBERS);

  procedure bulk_update_nc_object (nc_objs in oe_table_of_nc_objects);

  procedure merge_params(params in oe_tableofncparameters);

  procedure merge_params_for_mult_attrs(params in oe_tableofncparameters);

  procedure merge_refs(params in oe_tableofncparameters);

  procedure merge_refs_for_mult_attrs(params in oe_tableofncparameters);

  procedure merge_meta_refs(params in oe_tableofncparameters);

  procedure merge_meta_refs_for_mult_attrs(params in oe_tableofncparameters);

end pkg_oe_BulkOperations;
/
