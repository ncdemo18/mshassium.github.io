CREATE PACKAGE PKGRECONCILIATION is
--ANMI10050 [11-02-2007] [Reconciliation, DM: Removing AUTHID CURRENT_USER from package pkgreconciliation] end

--for skipping acceptable errors during resume
    handle_errors VARCHAR2(200) := NULL;

--for skipping excessive table reloads defined with threshold
    skip_table_reloading BOOLEAN := false;

--SESE0310 [08-17-2010][Reconciliation, DM: Temp tables and indexes names] start
     DOC_INV_TAB_PREFIX CONSTANT VARCHAR2(6) := 'NC_RCI';
     DOC_NET_TAB_PREFIX CONSTANT VARCHAR2(6) := 'NC_RCN';
     DOC_ERR_TAB_PREFIX CONSTANT VARCHAR2(6) := 'NC_RCE';
     DOC_MULT1_TAB_PREFIX CONSTANT VARCHAR2(8) := 'NC_RECM1';
     DOC_MULT2_TAB_PREFIX CONSTANT VARCHAR2(8) := 'NC_RECM2';
     DOC_TAB_CP_CON_PREFIX CONSTANT VARCHAR2(8) := 'NCRCPCON';
     DOC_TAB_CP_MAP_PREFIX CONSTANT VARCHAR2(10) := 'NC_RCP_MAP';
     DOC_TAB_CP_OBJ_PREFIX CONSTANT VARCHAR2(8) := 'NCRCPOBJ';
     DOC_TAB_CP_PAR_PREFIX CONSTANT VARCHAR2(8) := 'NCRCPPAR';
     DOC_TAB_CP_REF_PREFIX CONSTANT VARCHAR2(8) := 'NCRCPREF';
     DOC_TAB_REC_DEF_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_DEF';
     DOC_TAB_CP_IDS_PREFIX CONSTANT VARCHAR2(8):='NCRCPIDS';

     DOC_TAB_REC_PRI_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_PRI';
     DOC_TAB_REC_DEF_VAL CONSTANT VARCHAR2(10) := 'NC_REC_DFV';
     DOC_TAB_REC_DELTA_PREFIX CONSTANT VARCHAR2(8) := 'NCRECDLT';
     DOC_TAB_REC_ERR_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_ERR';
     DOCUMENT_TAB_NAMING_PREFIX CONSTANT VARCHAR2(8) := 'NC_RNAME';
     DOC_IND_REC_NAME_PREFIX CONSTANT VARCHAR2(8):= 'XRECNAME';
     DOCIND_REC_NAME_OBJ_PREFIX CONSTANT VARCHAR2(8):= 'XNAMEOBJ';
     DOC_IND_REC_NAME_PARENT_PREFIX CONSTANT VARCHAR2(8):= 'XNAMEPAR';
     DOC_XIFREIDS_R_IDX_PREFIX CONSTANT VARCHAR2(10) := 'XIFREIDS_R';
     DOC_XIFREIDS_O_IDX_PREFIX CONSTANT VARCHAR2(10) := 'XIFREIDS_O';
     DOC_XRCIDS_P_IDX_PREFIX CONSTANT VARCHAR2(10) := 'XRCIDS_P';
     NAMING_ERROR_TABLE_PREFIX CONSTANT VARCHAR2(10) := 'NC_RNERR';

     REC_MACROS_TABLE_INDEX CONSTANT VARCHAR(13) := '#$SET_INDEX$#';

--SESE0310 [08-17-2010][Reconciliation, DM: Temp tables and indexes names] end
     DOC_TAB_PARAMS_PREFIX CONSTANT VARCHAR2(7) := 'NC_RPAR';
     DOC_TAB_OBJECTS_PREFIX CONSTANT VARCHAR2(7) := 'NC_ROBJ';
     DOC_TAB_PATERNS_PREFIX CONSTANT VARCHAR2(7) := 'NC_RPAT';
     DOC_TAB_RESULTS_PREFIX CONSTANT VARCHAR2(7) := 'NC_RRES';
     DOC_TAB_HISTORY_PARAMS_PREFIX CONSTANT VARCHAR2(10) := 'NC_RPAR_HI';
     DOC_TAB_HISTORY_OBJECTS_PREFIX CONSTANT VARCHAR2(10) := 'NC_ROBJ_HI';
     DOC_TAB_REJECT CONSTANT VARCHAR2(10) := 'NC_REC_RJT';
     DOC_TAB_TYPES_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_TYP';

     DOC_SYN_PARAMS_TABLE_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_PAR';
     DOC_SYN_OBJECTS_TABLE_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_OBJ';
     DOC_SYN_RESULTS_TABLE_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_RES';
     DOC_SYN_PATERNS_TABLE_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_PAT';
     DOC_SYN_PARAMS_UI_TAB_PREFIX CONSTANT VARCHAR2(10) := 'NC_RPAR_UI';
     DOC_SYN_OBJECTS_UI_TAB_PREFIX CONSTANT VARCHAR2(10) := 'NC_ROBJ_UI';
     DOC_SYN_RESULTS_UI_TAB_PREFIX CONSTANT VARCHAR2(10) := 'NC_RRES_UI';
     DOC_SYN_PATERNS_UI_TAB_PREFIX CONSTANT VARCHAR2(10) := 'NC_RPAT_UI';
     DOC_SYN_PREVIOUS_OBJ_TAB_PREF CONSTANT VARCHAR2(10) := 'NC_PR_ROBJ';
--SEER0706 [7-14-2008] [Reconciliation, DM: Saving Discrepancies History]
     DOC_SYN_PREVIOUS_PAR_TAB_PREF CONSTANT VARCHAR2(10) := 'NC_PR_RPAR';
     --ALKH0608 [18-03-2009] [Reconciliation, DM: Bad perfomance of procedure prepareTable] one row modified
     DOC_TAB_INDEXES CONSTANT VARCHAR2(8) := 'NCRECIND';

     DOC_SYN_DS_TABLE_PREFIX CONSTANT VARCHAR2(9) := 'NC_REC_DS';
     DOC_TAB_DS_PREFIX CONSTANT VARCHAR2(7) := 'NC_RDS';
     DOC_TAB_ARC_DS_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCRDS';
     DOC_TAB_ARC_DS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RDS';

     DOC_RDSIDX_BY_ROOT_ID_PREF CONSTANT VARCHAR2(7) := 'XIF1RDS';
     DOC_RDSIDX_BY_OBJ_ID_PREF CONSTANT VARCHAR2(7) := 'XIF2RDS';
     DOC_RDSIDX_BY_TABLE_ID_PREF CONSTANT VARCHAR2(7) := 'XIF3RDS';

--ALKH0608[26-03-2009] [Reconciliation, DM: Implement archivation functionality] start
     DOC_TAB_ARC_COLUMNS CONSTANT VARCHAR2(22) := 'NC_REC_ARC_TAB_COLUMNS';
     DOC_TAB_ARC_MAPS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_MAP';
     DOC_TAB_ARC_OBJECTS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_ROBJ';
     DOC_TAB_ARC_PARAMS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RPAR';
     DOC_TAB_ARC_HISTORY_OBJECTS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_ROBJHI';
     DOC_TAB_ARC_HISTORY_PARAMS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RPARHI';
     DOC_TAB_ARC_PATTERNS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RPAT';
     DOC_TAB_ARC_RESULTS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RRES';
     DOC_TAB_ARC_REJECTED CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RJT';
     DOC_TAB_ARC_DEFS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_DEF';
     DOC_TAB_ARC_RCN CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RCN';
     DOC_TAB_ARC_RCPIDS CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RCPIDS';

     DOC_TAB_ARC_PARAMS_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCPAR';
     DOC_TAB_ARC_OBJECTS_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCOBJ';
     DOC_TAB_ARC_PATERNS_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCPAT';
     DOC_TAB_ARC_RESULTS_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCRES';
     DOC_TAB_ARC_REJECT CONSTANT VARCHAR2(20) := 'NC_RARCRJT';
     DOC_TAB_ARC_HIST_OBJ_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCOHI';
     DOC_TAB_ARC_HIST_PAR_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCPHI';
     DOC_TAB_ARC_CP_MAP_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCMAP';
     DOC_TAB_ARC_REC_DEF_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCDEF';
     DOC_TAB_ARC_RCN_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCRCN';
     DOC_TAB_ARC_RCPIDS_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCRCP';

     DOC_TAB_ARC_ERR CONSTANT VARCHAR2(20) := 'NC_REC_ARC_RNERR';
     DOC_TAB_ARC_ERR_PREFIX CONSTANT VARCHAR2(20) := 'NC_RARCNER';
--ALKH0608[26-03-2009][Reconciliation, DM: Create procedure in pkgreconciliation for creating archived tables] end

     DOC_TB_PAR_IDX_BY_DISCR_ID_PRF CONSTANT VARCHAR2(8) := 'X112RPAR';
     DOC_TAB_PAR_IDX_BY_OBJ_ID_PREF CONSTANT VARCHAR2(8) := 'X113RPAR';
     DOC_TAB_PAR_IDX_BY_ACTION_PREF CONSTANT VARCHAR2(8) := 'X114RPAR';
     DOC_TAB_PAR_IDX_BY_TAB_ID_PREF CONSTANT VARCHAR2(8) := 'X117RPAR';
     DOC_TAB_PAR_IDX_BY_FLD_ID_PREF CONSTANT VARCHAR2(8) := 'X118RPAR';
     DOC_TB_PAR_IDX_BY_MAP_TYPE_PRF CONSTANT VARCHAR2(8) := 'X119RPAR';
     --DOC_TB_P_IDX_BY_OBJID_MP_T_PRF CONSTANT VARCHAR2(8) := 'X120RPAR';
     DOC_TAB_PARAMS_IDX_BY_ISPK     CONSTANT VARCHAR2(8) := 'X121RPAR';
     DOC_TAB_PARAMS_IDX_BY_STATUS   CONSTANT VARCHAR2(8) := 'X122RPAR';
     DOC_TAB_PARAMS_IDX_BY_TMP_MARK CONSTANT VARCHAR2(8) := 'X123RPAR';
     DOC_TAB_PARAMS_IDX_BY_NET_ID   CONSTANT VARCHAR2(8) := 'X124RPAR';
     DOC_TB_OBJ_IDX_BY_OBJTP_ID_PRF CONSTANT VARCHAR2(8) := 'X121ROBJ';
     DOC_TAB_OBJ_IDX_BY_OBJ_ID_PREF CONSTANT VARCHAR2(8) := 'X122ROBJ';
     DOC_TAB_OBJ_IDX_BY_ACT_PREF    CONSTANT VARCHAR2(8) := 'X123ROBJ';
     DOC_TAB_OBJ_IDX_BY_PAR_ID_PREF CONSTANT VARCHAR2(8) := 'X124ROBJ';
     DOC_TB_OBJ_IDX_BY_ALT_P_ID_PRF CONSTANT VARCHAR2(8) := 'X125ROBJ';
     DOC_TB_OBJ_IDX_BY_TB_ID_PK_PRF CONSTANT VARCHAR2(8) := 'X126ROBJ';
     DOC_TB_OBJ_IDX_BY_PK_INT_PRF   CONSTANT VARCHAR2(8) := 'X127ROBJ';
     DOC_TAB_OBJ_IDX_BY_T_ID_AC_PRF CONSTANT VARCHAR2(8) := 'X128ROBJ';
     DOC_TAB_OBJ_IDX_BY_R_F_PAR_PRF CONSTANT VARCHAR2(8) := 'X129ROBJ';
     DOC_TAB_OBJ_IDX_BY_IS_ROOT_PRF CONSTANT VARCHAR2(8) := 'X130ROBJ';

     DOC_TB_PAT_IDX_BY_DISCR_ID_PRF CONSTANT VARCHAR2(8) := 'X126RPAT';
     DOC_TAB_PAT_IDX_BY_CASE_ID_PRF CONSTANT VARCHAR2(8) := 'X127RPAT';

--SEER 0706 [8-6-2008] [Reconciliation: Add posibility to clear rec history and add indexes on some columns in history tables] start
     DOC_TBPARHIIDX_BY_DISCR_ID_PRF CONSTANT VARCHAR2(10) := 'X112_PARHI';
     DOC_TABPARHIIDX_BY_OBJ_ID_PREF CONSTANT VARCHAR2(10) := 'X113_PARHI';
     DOC_TABOBJHIIDX_BY_OBJ_ID_PREF CONSTANT VARCHAR2(10) := 'X122_OBJHI';
     DOC_TABOBJHIIDX_BY_PAR_ID_PREF CONSTANT VARCHAR2(10) := 'X124_OBJHI';
     DOC_TBOBJHIIDX_BY_ALT_P_ID_PRF CONSTANT VARCHAR2(10) := 'X125_OBJHI';

     DOC_TB_PR_OBJIDX_BY_OBJTPIDPRF CONSTANT VARCHAR2(10) := 'X121PR_O';
--SEER 0706 [8-6-2008] [Reconciliation: Add posibility to clear rec history and add indexes on some columns in history tables] end

     DOC_TB_PR_OBJIDX_BY_OBJID_PREF CONSTANT VARCHAR2(10) := 'X122PR_O';
     DOC_TB_PR_OBJIDX_BY_PARID_PREF CONSTANT VARCHAR2(10) := 'X124PR_O';
     DOC_TB_PR_OBJIDX_BY_ALPAR_PREF CONSTANT VARCHAR2(10) := 'X125PR_O';
     DOC_TB_PR_OBJIDX_BY_TBIDPK_PRF CONSTANT VARCHAR2(10) := 'X126PR_O';
--SEER0706 [7-14-2008] [Reconciliation, DM: Saving Discrepancies History]
     DOC_TB_PR_PARIDX_BY_OBJID_PREF CONSTANT VARCHAR2(10) := 'X113PR_P';
     DOC_TB_PR_PARIDX_BY_DISCR_PREF CONSTANT VARCHAR2(10) := 'X112PR_P';
     DOC_TB_PR_PARIDX_BY_ISPK_PREF CONSTANT VARCHAR2(10) := 'X121PR_P';
     DOC_TB_PR_PARIDX_BY_TMPM_PREF CONSTANT VARCHAR2(10) := 'X123PR_P';
     DOC_TB_PR_PARIDX_BY_NETID_PREF CONSTANT VARCHAR2(10) := 'X124PR_P';
     DOC_TB_PR_PARIDX_BY_FL_ID_PREF CONSTANT VARCHAR2(8) := 'X118PR_P';


     DOC_TAB_RES_IDX_BY_RES_ID_PREF CONSTANT VARCHAR2(8) := 'X128RRES';
     DOC_TAB_RJT_IDX_BY_PK_F_ID     CONSTANT VARCHAR2(10) := 'X111_RJT_';
     DOC_TAB_RJT_IDX_BY_OBJ_ID_F_ID CONSTANT VARCHAR2(10) := 'X112_RJT_';
     TABLE_PREFIX_RCVC CONSTANT VARCHAR2(8) := 'NC_RCVC_';
     TABLE_PREFIX_RCV CONSTANT VARCHAR2(7) := 'NC_RCV_';
     TABLE_PREFIX_REC_IDS CONSTANT VARCHAR2(10) := 'NC_REC_IDS';
     NC_REC_REP_SEQUENCE CONSTANT VARCHAR(8) := 'NCRREPSQ';
     NC_RRESSQN_SEQUENCE CONSTANT VARCHAR(8) := 'NCRRESSQ';

     DOC_TAB_RDS_PREFIX CONSTANT VARCHAR2(7) := 'NC_RDS';
     DOC_SYN_RDS_TABLE_PREFIX CONSTANT VARCHAR2(10) := 'NC_REC_DS';
     DOC_SYN_RDS_UI_TAB_PREFIX CONSTANT VARCHAR2(10) := 'NC_RDS_UI';
     DOC_SYN_PREVIOUS_RDS_TAB_PREF CONSTANT VARCHAR2(10) := 'NC_PR_RDS';
     DOC_TAB_PAR_IDX_BY_DS_ID_PREF CONSTANT VARCHAR2(8) := 'XIF1RDS';
     DOC_TAB_RDS_IDX_BY_OBJ_ID_PREF CONSTANT VARCHAR2(8) := 'XIF2RDS';

     NOT_RECONCILED_YET_STATUS    CONSTANT NUMBER := 0;
     SUCCESSFUL_RECONCILED_STATUS CONSTANT NUMBER := 1;
     SUCCESSFUL_TEMPORARY_STATUS  CONSTANT NUMBER := 3;
     ERROR_RECONCILED_STATUS      CONSTANT NUMBER := 2;
     PARTLY_RECONCILED_STATUS     CONSTANT NUMBER := 4;
     REJECTED_STATUS              CONSTANT NUMBER := 5;
     --SESE0310 [9-15-2010][Reconciliation, DM: Check parent existence before objects inserting] one row added
     MISSED_RECONCILED_STATUS     CONSTANT NUMBER := 6;
     IGNORED_STATUS               CONSTANT NUMBER := 7;
     UNREJECTED_STATUS            CONSTANT NUMBER := 8;
     --ALBU0210[3-18-2011][Reconciliation, DM: Remove usage of 7 status from pkgreconciliation.move_discrepancies] one row add
     REMOVING_BTWN_REPORTS_STATUS  CONSTANT NUMBER := 9;

     UNABLE_TO_RECONCILE_STATUS   CONSTANT NUMBER := 10;
     RECON_NOT_REQUIRED_STATUS    CONSTANT NUMBER := 11;
     RECON_ALREADY_EXIST_STATUS   CONSTANT NUMBER := 12;

     ACTION_NO_ACTION        CONSTANT NUMBER := 1;
     ACTION_UPDATE           CONSTANT NUMBER := 2;
     ACTION_INSERT           CONSTANT NUMBER := 3;
     ACTION_DELETE           CONSTANT NUMBER := 4;
     ACTION_DUPLICATE_PK     CONSTANT NUMBER := 5;
     ACTION_DUPLICATE_INT_PK CONSTANT NUMBER := 8;
     ACTION_MULTIPLE_ENTRIES CONSTANT NUMBER := 6;
     ACTION_INCORRECT_PARENT CONSTANT NUMBER := 7;
     ACTION_WRONG_MOVED      CONSTANT NUMBER := 9;
--DMSA0707 [7-21-2008] [Reconciliation, DM: Support pl/sql api for reconciliation info] start
     MODE_GET_REPORT_DATE           CONSTANT NUMBER := 1;
     MODE_GET_ALL_DISCREPANCIES     CONSTANT NUMBER := 2;
     MODE_GET_PARENT_DISCREPANCY    CONSTANT NUMBER := 3;
     MODE_GET_ALTPARENT_DISCREPANCY CONSTANT NUMBER := 4;
--DMSA0707 [7-21-2008] [Reconciliation, DM: Support pl/sql api for reconciliation info] end
--DMSA0707 [8-19-2008] [Reconciliation, DM: Improve pl/sql api for reconciliation info] one row added
     MODE_LAST_RECONCILED_DISCR     CONSTANT NUMBER := 5;
--ALKH0608 [1-04-2009] [Reconciation, DM: pkgReconciliation.get_rec_info() information for CapacityManagement] start
     MODE_LAST_RECONCILED_OBJECTS CONSTANT NUMBER := 6;
     MODE_LAST_CHANGED_PARENT CONSTANT NUMBER := 7;
     MODE_LAST_DELETED_OBJ_PARENTS CONSTANT NUMBER := 8;
--ALKH0608 [1-04-2009] [Reconciation, DM: pkgReconciliation.get_rec_info() information for CapacityManagement] end
     MODE_DISPLAYED_TRANSACTION_ID CONSTANT NUMBER := 9;
     MODE_LATEST_TRANSACTION_ID CONSTANT NUMBER := 10;

--DMPO0807 [Reconciliation, DM: Add filters to Action and Table columns on Report tab] one row added
     PROPERTY_DELIMETER      CONSTANT VARCHAR2(10) := '^';
--ALKH0608 [03-16-2009] [Reconciliation, DM: Bad perfomance of check table and column existance] start
     INVALID_IDENTIFIER_ERR_CODE CONSTANT NUMBER := -904;
     TABLE_DOES_NOT_EXIST_ERR_CODE CONSTANT NUMBER := -942;
     SYN_NO_LONGER_VALID_ERR_CODE CONSTANT NUMBER := -980;
--ALKH0608 [03-16-2009] [Reconciliation, DM: Bad perfomance of check table and column existance] end

--SESE0310 [08-13-2010][Reconciliation, DM: Temp tables and indexes names] start
     REC_MACROS_BUSINESS_SESSION_ID CONSTANT VARCHAR2(23) := '#$BUSINESS_SESSION_ID$#';
--SESE0310 [08-13-2010][Reconciliation, DM: Temp tables and indexes names] end

--ALKH0608[08-17-2010] Support locks for multiple sessions start
     MAX_TABLE_SUFFIX CONSTANT NUMBER := 36;
     LOCK_TYPE_SYNCRONIZE CONSTANT NUMBER := 0;
     LOCK_TYPE_DOC_SESSION CONSTANT NUMBER := 1;
     LOCK_TYPE_DOC_CASE CONSTANT NUMBER := 2;
     LOCK_TYPE_TABLE_SESSION CONSTANT NUMBER := 3;
     LOCK_TYPE_DOC_PROCESS CONSTANT NUMBER := 4;
     LOCK_TYPE_RCN CONSTANT NUMBER := 10;
     PARALLEL_FEATURE constant varchar2(30) := 'parallel_reconciliation';
     PSE_FEATURE constant varchar2(30) := 'parallel-script-executor';
--ALKH0608[08-17-2010] Support locks for multiple sessions end

--ALCH0214[15-10-2014] Check results after terminate for correct interruptAttribute calculation start
     RESULT_ERROR_ID constant number := 2;
--ALCH0214[15-10-2014] Check results after terminate for correct interruptAttribute calculation end

-- User defined statuses
     USER_STATUS_QUESTION        CONSTANT NUMBER := NULL;
     USER_STATUS_V        CONSTANT NUMBER := 1;
     USER_STATUS_X           CONSTANT NUMBER := 2;
     USER_STATUS_I           CONSTANT NUMBER := 3;
     USER_STATUS_N           CONSTANT NUMBER := 4;
     USER_STATUS_VV     CONSTANT NUMBER := 5;
     USER_STATUS_VV_QUESTION     CONSTANT NUMBER := 6;

     DOCUMENT_VIA_SQL_OBJECT_TYPE CONSTANT NUMBER := 5071159113013622767;
     DOCUMENT_VIA_API_OBJECT_TYPE CONSTANT NUMBER := 6000000010002;

     SESSION_VIA_SQL_OBJECT_TYPE CONSTANT NUMBER := 9126497959913849422;
     SESSION_VIA_API_OBJECT_TYPE CONSTANT NUMBER := 9126497959913849417;

     REPORT_CREATE_INDEX_PARALLEL CONSTANT VARCHAR2(50):= 'reconciliation.report.create_index.parallel';
     RECONCILIATION_RES_XMLSCHEMA CONSTANT VARCHAR2(60) := 'http://www.netcracker.com/reconciliation/results_v.2.xsd';
	 RECONCILIATION_NAM_MAX_FETCH CONSTANT VARCHAR2(50) := 'reconciliation.reconcile.naming.max_fetch';
     RECONCILIATION_NAM_SKIP_ERRORS CONSTANT VARCHAR2(100) := 'reconciliation.reconcile.naming.skip_objects_with_errors';
     BYTES_THRESHOLD_FOR_DELETE CONSTANT VARCHAR2(100) := 'reconciliation.table.bytes_threshold_for_delete';
     COUNT_THRESHOLD_FOR_DELETE CONSTANT VARCHAR2(100) := 'reconciliation.table.count_threshold_for_delete';

     REPORT_ARCHIVING_FAILED_RES_ID     NUMBER := 8243448612951751;
     REPORT_ARCHIVED_RES_ID CONSTANT    NUMBER := 9040273049013867913;
     REPORT_EXTRACTED_RES_ID CONSTANT   NUMBER := 9040273073013867914;
     REPORT_EXTRACT_FAILED_RES_ID CONSTANT   NUMBER := 8230043288999503;

     /*Reconciliation View*/
     REC_VIEW_OBJECT_TYPE CONSTANT NUMBER := 7042253753013515745;
     REC_SESSION_VIEW_OBJECT_TYPE CONSTANT NUMBER := 8237928801336479;
     REC_SESSION_REF_TO_VIEW_ATTR CONSTANT NUMBER := 8237928801336480;

     DOC_PERCENT_COMPLETE_ATTR_ID CONSTANT NUMBER := 6070737610021511850;
     DOC_STATUS_ADMIN_ATTR_ID CONSTANT NUMBER := 9133823816713544843;

     DEFAULT_NAVIGATION_VALUE CONSTANT NUMBER(1) := 0;
     NETWORK_REPORT_REF_VAL CONSTANT NUMBER(1) := 1;
     INVENTORY_REPORT_REF_VAL CONSTANT NUMBER(2) := 2;

     DEFAULT_SESSION_EXP_INTERVAL CONSTANT NUMBER := 180;
     --property with reconciliation session expire interval (in days):
     SESSION_EXPIRATION_INT_KEY CONSTANT VARCHAR2(100) := 'reconciliation.sessions.expire.interval';

     NAMING_REP_OBJ_NAMES_ERR_CODE CONSTANT NUMBER := -20519;
     RECONC_REP_OBJ_NAMES_ERR_CODE CONSTANT NUMBER := -20520;
     NAMING_OBJECT_NAMES_ERR_CODE CONSTANT NUMBER := -20518;

     SET_FILTER_MASKS_OBJ_ERR_CODE CONSTANT NUMBER := -20522;
     SET_FILTER_MASKS_PAR_ERR_CODE CONSTANT NUMBER := -20521;

     HDS_GARBAGE_OBJECT_TYPE CONSTANT NUMBER := 9140034982713220707;

     RECONCILIATION_IS_WARNING_ATTR CONSTANT NUMBER := 9142516024413521494;
     REC_RES_ATTR_PERCENT_COMPLETE CONSTANT NUMBER := 6070737610021511850;
     REC_RES_ATTR_STARTED_WHEN CONSTANT NUMBER := 6071036418021512076;
     REC_RES_ATTR_PHASE CONSTANT NUMBER := 6071159620013949973;

     REC_PHASE_EXECUTE_REPORT CONSTANT NUMBER := 6071159620013949971;
     REC_PHASE_EXECUTE_MIGRATION CONSTANT NUMBER := 6071159620013949970;
     REC_PHASE_RECONCILE CONSTANT NUMBER := 6071159620013949968;
     REC_PHASE_CHECK_DATA CONSTANT NUMBER := 6071159620013949972;
     REC_PHASE_UPDATE_DS CONSTANT NUMBER := 6122652902013723325;
     REC_PHASE_GENERATE_SCRIPTS CONSTANT NUMBER := 5121954430013475319;

    TYPE nc_rec_params_rec IS RECORD
    (
        transaction_id                 NUMBER(20),
        table_id                       NUMBER(20),
        object_id                      NUMBER(20),
        mapping_type                   NUMBER(2),
        mapping_attribute              NUMBER(20),
        field_id                       NUMBER(20),
        ispk                           NUMBER(1),
        network_value                  VARCHAR2(4000),
        inventory_value                VARCHAR2(4000),
        action                         NUMBER(2),
        reconcile                      NUMBER(1),
        discrepancy_id                 NUMBER(20),
        setting_type                   NUMBER(1),
        field_number                   NUMBER(3),
        result_id                      NUMBER(10),
        show_order                     NUMBER(10)
    );
    TYPE nc_rec_objects_rec IS RECORD
    (
        transaction_id                 NUMBER(20,0),
        name                           VARCHAR2(200),
        object_id                      NUMBER(20,0),
        parent_id                      NUMBER(20,0),
        object_type_id                 NUMBER(20,0),
        action                         NUMBER(2,0)
    );
    TYPE nc_rec_patterns_rec IS RECORD
    (
        transaction_id                 NUMBER(20,0),
        case_id                        NUMBER(20,0),
        pattern_id                     NUMBER(20,0),
        discrepancy_id                 NUMBER(20,0)
    );
    TYPE nc_rec_results_rec IS RECORD
    (
        transaction_id                 NUMBER(20,0),
        result                         NUMBER(1,0),
        result_notes                   VARCHAR2(4000),
        result_id                      NUMBER(10,0)
    );
    TYPE nc_rec_params_table IS TABLE OF nc_rec_params_rec;
    TYPE nc_rec_objects_table IS TABLE OF nc_rec_objects_rec;
    TYPE nc_rec_patterns_table IS TABLE OF nc_rec_patterns_rec;
    TYPE nc_rec_results_table IS TABLE OF nc_rec_results_rec;

--SEER0706 [7-14-2008] [Reconciliation, DM: Saving Discrepancies History]
    TYPE columns_array IS varray(10) of varchar2(30);

    PROCEDURE setResultId(docId number, set_index varchar2 DEFAULT '00');
    function getResultId return number;

    function GETRECPATH(doc_id in number, oid in number, set_index in varchar2 := '00') return varchar2;
    function GETSUBSTRING(string in varchar2, num in number) return varchar2;
    function GETRECPATH(doc_id in number, oid in number, method in varchar2, isDesc in number, set_index in varchar2 := '00') return varchar2;
    FUNCTION getReferenceValue(obj_id in number,attr in number) return varchar2;
    procedure TRUNCATEALLRECTABLES;
    PROCEDURE TRUNCATEDOCRECTABLES(doc_id in NUMBER);
--DIMY0709[11-27-2009][Reconciliation, DM: Drop temporary tables] one line modified
    procedure DELETEDATAFORDOC(doc_id in number,param in VARCHAR2 := null);
    procedure DELETEDATAFORTRANSACTION(tr_id in number);
    procedure CHPACTIONUPDATE(doc_id in number, set_index in varchar2 := '00');
--    procedure COPYFROMREPOSITORY(obj_ID in number, src_obj_ID in number, new_obj_ID in number, dest in number, tr_id in number, username in varchar2, cr_date in varchar2, withLink in number);
--    procedure UPDATECHILDREN(obj_ID in number, dest in number, tr_id in number, username in varchar2, cr_date in varchar2, withLink in number);
    procedure COLLECTSTATISTIC(doc_id in number, set_index in varchar2 := '00');
    procedure REMOVEMIGRATEDDATA(tr_id in number);
    PROCEDURE initiatesequence(sequence_name VARCHAR2, sqn_cache VARCHAR2 := 'CACHE 10000');
    --ALBI0407 [05-03-09] [Reconciliation, DM: Provide ability to restore sequences in Datastructure Script]
    PROCEDURE initiatesequencefromtable(table_name VARCHAR2, field_name VARCHAR2,sequence_name VARCHAR2, sqn_cache VARCHAR2 := 'CACHE 10000');
    PROCEDURE setsequencevalue(sequence_name VARCHAR2, VALUE NUMBER);
    function isObjectExists(objectID number) return number;
--DIMY0709[11-27-2009][Reconciliation, DM: Drop temporary tables] one line commented
--    FUNCTION DROP_TEMPORARY_TABLE(objectID IN NUMBER) return NUMBER;
-- VIKOSDG[29.03.2005] Reconciliation: performance problems (FULL SCAN), when doing reconcile. begin
    procedure CREATERECIDS(doc_id in number);

    --PROCEDURE DROP_RECIDS (doc_id in NUMBER);
    --PROCEDURE TRUNCATE_RECIDS (doc_id in NUMBER);
    --PROCEDURE CREATE_RECIDS (doc_id in NUMBER);

    procedure TRUNCATERECIDS(doc_id in number);
    procedure INSERTRECIDS(doc_id in number, rec_id in number, object_id in number);
    procedure INSERTRECIDS(doc_id in number, rec_id in number, object_id in number, set_index in number);
    function FINDRECOBJECT(doc_id in number, p_rec_id in number) return number;
-- VIKOSDG[29.03.2005] Reconciliation: performance problems (FULL SCAN), when doing reconcile. end
--    procedure prepareTable(tab_name in varchar2);
--ALKH0608 [18-03-2009] [Reconciliation, DM: Bad perfomance of procedure prepareTable] one row modified
    procedure prepareTable(tab_name in varchar2, document_id in number, set_index in varchar2 := '00');
    PROCEDURE checkTableExistence(tab_name in varchar2);
    PROCEDURE checkSynonymExistence(syn_name in varchar2);
    PROCEDURE checkColumnExistence(tab_name in varchar2, field_name IN VARCHAR2);
    PROCEDURE checkColumnExistence(tab_name in varchar2, fields_names IN ARRAYOFSTRINGS);
    PROCEDURE CREATE_REC_INDEXES(doc_id IN NUMBER, syn_prefix IN VARCHAR2, index_space IN VARCHAR2, curr_num in number, set_index in varchar2);
    PROCEDURE DROP_INDEXES(doc_id in NUMBER, syn_prefix IN VARCHAR2, set_index in varchar2 := '00');
    FUNCTION get_table_index(doc_id IN NUMBER, reports_no IN NUMBER) return NUMBER;
--DMSA0707 [10-31-2007] [Reconciliation. FR: Assignment Savings] start
--    procedure initiate_recon_synonym(doc_id in number, table_index in number, index_space in varchar2, truncateFlag in number);
    procedure initiate_recon_synonym(doc_id in number, table_index in number, index_space in varchar2, truncateFlag in number, existsPreviousObjTableFlag in number :=0);
--DMSA0707 [10-31-2007] [Reconciliation. FR: Assignment Savings] end
    FUNCTION GET_NC_REC_PARAMS RETURN nc_rec_params_table PIPELINED;
    FUNCTION GET_NC_REC_OBJECTS RETURN nc_rec_objects_table PIPELINED;
    FUNCTION GET_NC_REC_PATTERNS RETURN nc_rec_patterns_table PIPELINED;
    FUNCTION GET_NC_REC_RESULTS RETURN nc_rec_results_table PIPELINED;
    PROCEDURE CLEAR_HISTORY(doc_id IN NUMBER, reports_to_remain in NUMBER);
    function getpriority(in_attr_id number, in_ot_id number, in_schema_id number) return number;
    PROCEDURE UPDATE_OBJECT_VERSION(obj_id IN NUMBER);
    --IRBA0906 [08-16-2007] [Reconciliation: The possibility of COLLECTSTATISTIC disabling]
    function getColumnExistence(tab_name in varchar2, field_name IN VARCHAR2) return number;
 --SEER0706 [08-20-2007] [Reconciliation: Exclude objects with empty referenced PK]
 procedure exclude_with_empty_reference(doc_id IN NUMBER, script_type IN NUMBER, set_index in varchar2 := '00');
 --SEER0706 [09-19-2007] [Reconciliation: XA Support in 7.1]
    procedure autonomouslyExecuteDDL(ddl_query varchar2);
    --DMSA0707 [10-29-2007] [Reconciliation. FR: Assignment Savings] start
    procedure initiate_prev_robj_synonym(doc_id IN number);
    --DMSA0707 [10-29-2007] [Reconciliation. FR: Assignment Savings] end
 --DMSA0707 [11-06-2007] [Reconciliation, DM. FR: Exclusion Patterns] one row added
    PROCEDURE unmark_objects(documentId IN number, set_index in varchar2 := '00', update_obj_statuses number :=0, only_ignored number := 0, ui_update number := 0);
-- ANMI10050 [11-19-07] [Reconciliation, DM. FR: Reconcile Status] one row added
    procedure propagate_rec_status(document_id in number, set_index in varchar2 := '00');
-- ANMI10050 [07-15-2008] [Reconciliation: Support rejecting discrepancies] one row added
    procedure propagate_reject(document_id in number, tableIndex in varchar2 := '00');
    procedure save_rejected(document_id in number, save_in_history_flag in number, saved_by in varchar2, tableIndex varchar2 := '00');
    procedure cancel_rejected(document_id in number, object_pk in varchar2, table_id in number, field_id in number, show_order in number, tableIndex varchar2 := '00');
-- ANMI10050 [01-31-08] [Reconciliation: Exportimport conversion scripts] one row added
    function get_attr_id(attr_name in varchar2,table_id in number) return number;
--DMSA0707 [2-7-2008] [Reconciliation, DM: ReadOnly discrepancy] start
    procedure CHPREADONLYUPDATE(doc_id in number, set_index in varchar2 := '00');
    procedure CHPREADONLYUPDATE(doc_id in number, is_first in number, set_index in varchar2 := '00');
    --procedure checkComplexPks(doc_id IN NUMBER);
--DMSA0707 [2-7-2008] [Reconciliation, DM: ReadOnly discrepancy] end

--NIVI1006 [06-03-2008] [Reconciliation, DM: Provide abbility to make buttons grey and rename columns on EditReportSheet] start
    FUNCTION encode (what VARCHAR2) RETURN VARCHAR2;
    FUNCTION encodeClob (what CLOB) RETURN CLOB;
--SEER 0706 [8-6-2008] [Reconciliation: Add posibility to clear rec history and add indexes on some columns in history tables]
    FUNCTION getlink (value_ VARCHAR2, what VARCHAR2, doc_id NUMBER, field_id NUMBER, set_index varchar2 :='00') RETURN VARCHAR2;
    FUNCTION getlink2 (value_ VARCHAR2, what VARCHAR2, doc_id NUMBER, field_id NUMBER, set_index varchar2 :='00', addReportParams VARCHAR2 := null) RETURN VARCHAR2;
    FUNCTION getlink_for_param_values (value_ VARCHAR2, what VARCHAR2, real_doc_id NUMBER, field_id NUMBER, doc_id NUMBER, set_index varchar2 :='00') RETURN VARCHAR2;
    FUNCTION getlink_for_param_values2 (value_ VARCHAR2, what VARCHAR2,
        real_doc_id NUMBER, field_id NUMBER, doc_id NUMBER, set_index varchar2 :='00',
        addReportParams VARCHAR2 := null, referencesNavigationMode NUMBER := 0) RETURN VARCHAR2;
--NIVI1006 [06-03-2008] [Reconciliation, DM: Provide abbility to make buttons grey and rename columns on EditReportSheet] end

--ANMI10050 [06-06-08] [Reconciliation, DM: Incorrect mapping after conversion Mapping Models] one row added
    function get_attr_id(attr_name in varchar2, obj_types sys_refcursor, schema_id in number, look_in_whole_system_flag in number) return number;
--DMSA0707 [7-21-2008] [Reconciliation, DM: Support pl/sql api for reconciliation info] one row added
    function GET_REC_INFO(doc_id in NUMBER, mode_type IN NUMBER, param IN VARCHAR2 default null,set_index in varchar2 := '00') return VARCHAR2;

--SEER0706 [7-14-2008] [Reconciliation, DM: Saving Discrepancies History]
--SEER0706 [8-18-2008] [Reconciliation: Support save in history and move discrepancies functionalities]
    --procedure merge_discrepancies(source_document_id in integer, destination_document_id in integer, activity_type in integer);
    function get_merge_statement(tab_name in varchar2, exclude_insert_columns in columns_array, exclude_set_columns in columns_array, select_stm in varchar2, on_stm in varchar2, add_insert1 in varchar2, add_insert2 in varchar2, add_set in varchar2) return varchar2;
--DMPO0807 [Reconciliation, DM: Add filters to Action and Table columns on Report tab] start
    FUNCTION get_property_from_string(str in varchar2,prop in varchar2) RETURN varchar2;
    FUNCTION get_decode_expression(aid IN number, for_objects IN varchar2) RETURN varchar2;
    FUNCTION getBitMask(bit_position IN number, revers in number default null, from_byte in number default null, to_byte in number default null) RETURN RAW;
    PROCEDURE set_filter_Masks(documentID IN NUMBER, set_index in varchar2 := '00', flagged_mode number default null);
    FUNCTION bit_AND(R1 IN RAW,R2 IN RAW) RETURN RAW;
--DMPO0807 [Reconciliation, DM: Add filters to Action and Table columns on Report tab] end
--DMSA0707 [7-29-2008] [Reconciliation, DM:  Support hide ignored discrepancies] one row added
    procedure update_ignored_action(document_id in number, set_index varchar2 :='00');

--SEER 0706 [8-6-2008] [Reconciliation: Add posibility to clear rec history and add indexes on some columns in history tables] start
    procedure clear_history(document_id in number, delete_before in date);
    function is_display_summary_history(document_id in number) return number;
    FUNCTION getlinkforhistory (value_ VARCHAR2, what VARCHAR2, doc_id NUMBER,field_id NUMBER, tableIndex VARCHAR2 := '00') RETURN VARCHAR2;
    FUNCTION getlink_for_history_and_recobj (value_ VARCHAR2,what VARCHAR2, doc_id NUMBER, field_id NUMBER,object_table VARCHAR2) return varchar2;
    FUNCTION getlink_for_history_and_rcobj2 (value_ VARCHAR2,what VARCHAR2, real_doc_id NUMBER, field_id NUMBER,object_table VARCHAR2, params_table VARCHAR2, doc_id NUMBER) return varchar2;
    FUNCTION getlink_for_history_and_rcobj3 (value_ VARCHAR2,what VARCHAR2, real_doc_id NUMBER, field_id NUMBER,
        object_table VARCHAR2, params_table VARCHAR2, doc_id NUMBER,
        addReportParams VARCHAR2, referencesNavigationMode NUMBER) return varchar2;
--SEER 0706 [8-6-2008] [Reconciliation: Add posibility to clear rec history and add indexes on some columns in history tables] end
--SEER0706 [8-18-2008] [Reconciliation: Support save in history and move discrepancies functionalities] start
    procedure move_discrepancies(source_document_id in number, destination_document_id in number);
    procedure update_history(report_document_id in number, history_document_id in number);
    procedure save_missed_discrepancies(old_document_id in number, new_document_id in number, history_document_id in number);
--SEER0706 [8-18-2008] [Reconciliation: Support save in history and move discrepancies functionalities] end
    procedure cancel_rejected_parents(document_id in number, tableIndex varchar2 := '00');
    procedure cancel_rejected_from_rjt(document_id in number, tableIndex varchar2 := '00');
--VIKO0605 [10-21-2008] [Reconciliation, DM: Summary history doesn't display] 1 procedure added
    procedure add_summary_history_fake_pars(document_id in number);
    procedure create_naming_conventions (document_id in number, set_index in varchar2 := '00');
    procedure apply_naming_conventions(document_id in number, set_index in varchar2 := '00');
    procedure update_object_names_by_query(document_id in number, set_index in varchar2 := '00', count_limit in number);
    procedure SET_LEVEL_FOR_NAMING (document_id in number, set_index in varchar2 := '00');
--ALKH0608 [12-24-2008][Reconciliation, DM: Localization. (Report) Object Types and Attributes] 2 functions added
    function get_localized_object_type_name(ot_id in number, lang_id in number) return varchar2;
    function get_localized_attr_name(at_id in number, lang_id in number, do_encode in number := 1) return varchar2;
    function get_loc_attr_name_mapping_type(mapping_type in number, mapping_attribute in number, lang_id in number, do_encode in number := 1) return varchar2;
    function get_loc_attr_name_for_field(mapping_type in number, field_id in number, lang_id in number, do_encode in number := 1) return varchar2;
    function get_localized_value(res_id number, lang_id number) return varchar2;
    function getMessageByXML(col in XMLType,lang_id in number, max_result_length in number := 200, imgTag in varchar2 := null) return varchar2;
    function getMessageByXMLImpl(col in XMLType,lang_id in number, imgTag in varchar2 := null, max_result_length in number := 200) return varchar2;
    function get_localized_list_value(lv_id in number, lang_id in number) return varchar2;
    function get_localized_lv_by_sel_val(at_id in number, lang_id in number,sel_val in varchar2) return varchar2;
--ALSH0208 [10-29-2008] [Reconciliation, DM: ORA-00980 in pkgReconciliation.get_rec_info(?,2)]
    function is_report_complete(doc_id number, set_index in varchar2 := '00') return boolean;
    procedure storeResult(tableName varchar2, doc_id in number, resource_id in number, xml in XmlType, rec_num in number default null, set_index in varchar2, errorMsg in varchar2, result in number, result_id in number, updated_cnt in number, queries_cnt in number, unit_number in number default null, unit in CLOB default null);
    procedure storeResult(doc_id in number, resource_id in number, marcoses_xml in varchar2, rec_num in number default null, set_index in varchar2 );
    function getSingleRowResult(query_ varchar2) return varchar2;
    PROCEDURE checkTableAndColumnsExistence(tab_name in varchar2, col_list in varchar2);
    FUNCTION getTableExistence(tab_name in varchar2) return number;

    --ALKH
     FUNCTION isIndexExists(indexName in varchar2) return NUMBER;
    procedure setLockForDocument(doc_id number, session_id varchar2, option_str varchar2 := '');
    procedure checkLockForDocument(doc_id number, session_id varchar2, option_str varchar2 := '');
    function setLockForDocumentTable(doc_id number, sessionid varchar2, table_index number default null) return number;
    function isFeatureSupported(doc_id number, feature varchar2) return number;
    --ALKH
--SESE0310 [08-17-2010][Reconciliation, DM: Temp tables and indexes names] 4 functions added
    --function getTempTableName(prefix in varchar2, table_id in number) return varchar2;
    function getTempName(prefix in varchar2, doc_id in number, set_index in number) return varchar2;
    function getTempName(p_prefix in varchar2, doc_id in number, set_index in varchar2) return varchar2;
    function getTempName(prefix in varchar2, doc_id in number) return varchar2;
    function getTempName(prefix in varchar2, doc_id in number, order_number in varchar2, set_index in varchar2) return varchar2;
    function getIndexByNumber(num in number, numchars in number) return varchar2;
    function initLock(lockType number, objectId varchar2, lockObj varchar2 := null, isReloadThreshold boolean := false) return NUMBER;
    procedure synchronizeIDforRCN(tableName varchar2, doc_Id number, tab_id number, currentSet number, synchronizeID varchar2 := null);
    procedure synchronizeIDforRCNCross(tableName varchar2, doc_Id number, tab_id number, synchronizeID varchar2 := null);
    procedure synchronizeIDforIDS(doc_Id number, currentSet number, iter number, synchronizeID varchar2 := null, tab_id number := null);
    procedure synchronizeIDforIDSCross(doc_Id number, currentSet number, synchronizeID varchar2, tab_id number);
    procedure purgeExcessTables(genTblName varchar2, lastSetIndex number := 0);
    procedure purgeExcessIndexes(documentId number);
    procedure initRecInfo(documentID number, modelID number, reportsNumber number, operationID number);
    procedure initRecInfo(documentID number, modelID number, reportsNumber number, operationID number, sessionId varchar2, bSessionId varchar2);

    function initRecInfo(documentID number, modelID number, userName varchar2, tabNum number, reportsNumber number, sessionId varchar2, bSessionId varchar2, SessionName varchar2) return NUMBER;
    function initRecInfo(documentID number, modelID number, userName varchar2, tabNum number, reportsNumber number, sessionId varchar2, bSessionId varchar2, SessionName varchar2, transactionId number) return NUMBER;
    function initRecInfo(documentID number, modelID number, userName varchar2, tabNum number, reportsNumber number, sessionId varchar2, bSessionId varchar2, SessionName varchar2, transactionId number, operationID number) return NUMBER;

	procedure gather_additional_stat (doc_id in number, set_index in varchar2 DEFAULT '00');

    function concat_strings (varchar_table in arrayofstrings, delimiter in  varchar2 default '<br>') return varchar2;
    function replace_macroses (str in varchar2, macros in tableof2strings) return varchar2;
    function cutResultsMessage (message in varchar2, imgTag in varchar2 DEFAULT null, max_result_length in number DEFAULT 200) return varchar2;

    function calculateIterruptedAttribute (documentId in number) return number;

--VIRU0310[06-10-2011] [Reconciliation, DM: Implement archivation functionality] start
   FUNCTION get_archive_table_name (table_name IN VARCHAR2) RETURN VARCHAR2;

   PROCEDURE create_tables_from_archive (doc_id IN NUMBER, table_no NUMBER);

   PROCEDURE archive_document (doc_id NUMBER);

   PROCEDURE archive_session (transactionId NUMBER);

   PROCEDURE extract_report (docId NUMBER, transactionId number default null, tableNo number default null);
   procedure extract_session(docId number, transactionId number);

   PROCEDURE archive_expired_reports;
--VIRU0310[06-10-2011] [Reconciliation, DM: Implement archivation functionality] end
   function getParallelClause return varchar2;
   function getArchivingMode(doc_id number) return NUMBER;
   procedure remove_session_from_archive(transactionid number, document_id number);
   procedure setHandleErrors (h_errors varchar2);

   function get_current_pse_exec_id return NUMBER;
--deprecated
--   function get_current_percent(documentID number, transactionID number := null, businessSessionID varchar2 := null, calc_param number := null) return VARCHAR2;
   function get_current_operation_attr(attrID number, documentID number, transactionID number := null) return VARCHAR2;
   procedure unmark_ref_objects(documentId IN number,set_index in varchar2 := '00', update_obj_statuses number :=0, ui_update number := 0);

   PROCEDURE set_obj_total_values(doc_id IN NUMBER, ids_subquery varchar2, set_index in varchar2 := '00', ui_update number := 0);
   PROCEDURE update_parent_pks(doc_id IN NUMBER, trans_id IN NUMBER, user_id varchar2, user_roles arrayofnumbers, set_index in varchar2 := '00', user_name varchar2 := null);
   PROCEDURE set_children_on(doc_id IN NUMBER, trans_id IN NUMBER, user_id varchar2, user_roles arrayofnumbers, alt_ varchar2, set_index in varchar2 := '00', user_name varchar2 := null);
   PROCEDURE set_children_off(doc_id IN NUMBER, trans_id IN NUMBER, user_id varchar2, user_roles arrayofnumbers, alt_ varchar2, set_index in varchar2 := '00');
   PROCEDURE set_attr_rec_status(doc_id IN NUMBER, trans_id IN NUMBER, user_id varchar2, user_roles arrayofnumbers, set_index in varchar2 := '00');
   PROCEDURE propagate_on_relative_obj(doc_id IN NUMBER, trans_id IN NUMBER, user_id varchar2, /*user_roles varchar2,*/ set_index in varchar2 := '00');

   function get_discrepancies_cnt_in_ds(ds_id IN NUMBER) return NUMBER;

    function get_report_ref_value(reportObjects varchar2, nvValue varchar2, mappingType varchar2)
        return varchar2;

    function get_rec_backurl(realDocId number, transactionId number, recNumber number, operationID number)
        return varchar2;

  PROCEDURE cleanup_obj_tmp_column(doc_id IN NUMBER, set_index in varchar2 := '00');

  function compare_bit_masks(b1 RAW, b2 RAW) return number;
  procedure update_temp_status_marks(doc_id IN NUMBER, set_index in varchar2 := '00');
  function get_report_object_name(real_doc_id number, object_table varchar2, obj_id number)
    return varchar2;

  PROCEDURE propagate_rec_parents(documentId IN number, set_index in varchar2 := '00', update_obj_statuses number := 0);

  function getAttrDefValue(attr_id in number, schema_id in number, otype_id in number) return varchar2;
  procedure update_ui_recon_synonyms(doc_id in number, tran_id number := null, prev_transaction_id number := null);
  procedure switch_upd_ui_rec_syn_set_cur(doc_id in number, is_set_cur in boolean := false, tran_id number := null, prev_transaction_id number := null);

  procedure dropUnnecessaryRecTables(doc_id in number);

  procedure autonomouslyExecuteDDL_LOB(ddl_query CLOB);

  function convertValueToDate(value_to_convert in varchar2, mask in varchar2) return  date;

  PROCEDURE pushOutExcessSessions(i_doc_id IN NUMBER, i_reports_to_remain in NUMBER);
  function check_procedure_existence (procedure_name in varchar2) return number;
  procedure update_object_names_by_array(document_id in number, set_index in varchar2 := '00', count_limit in number);
end;
/
