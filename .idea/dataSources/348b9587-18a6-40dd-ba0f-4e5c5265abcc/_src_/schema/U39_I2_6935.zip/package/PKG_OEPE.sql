CREATE PACKAGE pkg_oepe IS

  FUNCTION get_quote_id RETURN VARCHAR2;

  /* Return quote with all attributes table*/
  FUNCTION get_quote(quote_id IN NUMBER) RETURN SYS_REFCURSOR;

  /* Return quote nodes with all attributes table*/
  FUNCTION get_quote_nodes(parent_node_id IN NUMBER) RETURN SYS_REFCURSOR;

/* Return id of a quote for given composite order id and status */
  FUNCTION check_composite_order_status(order_id IN NUMBER, order_statuses IN arrayofnumbers)
    RETURN NUMBER;

  /* Return quote nodes with all attributes table*/
  FUNCTION get_applied_discounts(quote_nodes IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  /* Return completed to-do item id's of the given quote node*/
  FUNCTION get_completed_todo_items(quote_node IN NUMBER)
    RETURN SYS_REFCURSOR;

  FUNCTION get_appointment(appointment_id IN NUMBER) RETURN SYS_REFCURSOR;

  /* Return list of active product instances for given quote */
  FUNCTION get_purchased_products(customer_id          IN NUMBER,
                                  customer_location_id IN NUMBER)
    RETURN SYS_REFCURSOR;

  FUNCTION get_existing_features(products IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION get_existing_products(customer_id          IN NUMBER,
                                 customer_location_id IN NUMBER)
    RETURN SYS_REFCURSOR;

  FUNCTION get_products(Catalogue_id IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION find_offer(offer_compnent_id IN NUMBER) RETURN NUMBER;

  FUNCTION get_offers(Offer_id            IN NUMBER,
                      Status_ids          IN arrayofnumbers,
                      Market_id           IN NUMBER,
                      Customer_category   IN NUMBER,
                      Distributed_channel IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION get_offerings(Offering_id         IN NUMBER,
                         Status_ids          IN arrayofnumbers,
                         Market_id           IN NUMBER,
                         Customer_category   IN NUMBER,
                         Distributed_channel IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION get_taxes_by_offer_price_id(Offering_ids IN arrayofnumbers,
                                       Market_id    IN NUMBER)
    RETURN SYS_REFCURSOR;

  FUNCTION get_time_periods(Offering_ids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION get_offer_chars(Offering_ids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION get_fees_for_offerings(Offering_ids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION get_suggestions_for_offerprice(Offering_ids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION get_sugg_preconditions(Suggestion_ids      IN arrayofnumbers,
                                  Market_id           IN NUMBER,
                                  Customer_category   IN NUMBER,
                                  Distributed_channel IN NUMBER)
    RETURN SYS_REFCURSOR;

  FUNCTION get_sugg_proposals(Suggestion_ids      IN arrayofnumbers,
                              Market_id           IN NUMBER,
                              Customer_category   IN NUMBER,
                              Distributed_channel IN NUMBER)
    RETURN SYS_REFCURSOR;

  FUNCTION get_rules_by_offers(Offering_ids      IN arrayofnumbers,
                               Market_id         IN NUMBER,
                               Customer_category IN NUMBER)
    RETURN SYS_REFCURSOR;

  FUNCTION get_bundle_offer(Price_ids           IN arrayofnumbers,
                            Market_id           IN NUMBER,
                            Customer_category   IN NUMBER,
                            Distributed_channel IN NUMBER)
    RETURN SYS_REFCURSOR;

  /* Return list of offer prices for given market by offer prices for another market */
  FUNCTION get_new_prices_for_new_market(market_id  IN NUMBER,
                                         price_list IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  /* Return last customer quotation for given customer id and customer location id*/
  FUNCTION get_last_customer_quote(customer_id          IN NUMBER,
                                   customer_location_id IN NUMBER)
    RETURN NUMBER;

  FUNCTION get_address_by_location_id(location_id IN NUMBER)
    RETURN NUMBER;

  FUNCTION get_market_id(address_entity IN NUMBER)
    RETURN NUMBER;

  FUNCTION get_market_id(zip_code IN VARCHAR2,
                         city     IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION load_conditions(id IN nc_objects.object_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION get_existing_offers(customer_id IN nc_objects.object_id%TYPE)
    RETURN arrayofnumbers;

  FUNCTION get_products_with_pi(customer_id IN nc_objects.object_id%TYPE)
    RETURN arrayofnumbers;

  FUNCTION find_offer_entities(pc_id IN nc_objects.object_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION find_prices(pc_id IN nc_objects.object_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION find_component_entities(Offer_ids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION find_oc_section_prices(Filters  IN arrayofstrings,
                                  Offer_id IN nc_objects.object_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION find_entities_by_class(Parent_ids IN arrayofnumbers,
                                  Class_id   IN nc_objects.object_class_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION find_entities_by_type(Parent_ids IN arrayofnumbers,
                                 Type_id    IN nc_objects.object_type_id%TYPE)
    RETURN SYS_REFCURSOR;

  FUNCTION check_price(Price_id IN nc_objects.object_id%TYPE,
                       Filters  IN arrayofstrings) RETURN NUMBER;

  /* Returns price id for given offer id, market, customer category and distribution channel*/
  FUNCTION find_price_for_offer(offer_id                IN NUMBER,
                                market_id               IN NUMBER,
                                customer_category_id    IN NUMBER,
                                distribution_channel_id IN NUMBER)
    RETURN NUMBER;

  FUNCTION load_categories(offer_category_ids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION load_historic(offering_id IN NUMBER,
                         price_id    IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION load_quote_nodes(parent_node_id IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION load_characteristic(Parent_ids IN arrayofnumbers)
    RETURN SYS_REFCURSOR;

  FUNCTION find_active_prices(Offering_id IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION load_entity(entity_id IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION is_new_customer(object_id_customer_account IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION get_customer_locations(parent_id_ca IN NUMBER, object_id_ca2sl IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION get_customer_accounts(object_id_c IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION get_customer_by_id(object_id_c IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION get_location_by_id(object_id_l IN NUMBER) RETURN SYS_REFCURSOR;

  FUNCTION get_markets RETURN SYS_REFCURSOR;

  FUNCTION get_taxation_schemas_ids RETURN SYS_REFCURSOR;

  FUNCTION get_active_catalog_id RETURN NUMBER;

  FUNCTION get_active_res_category_id RETURN NUMBER;

  FUNCTION get_current_catalog_id (cur_object_id IN NUMBER) RETURN NUMBER;

  FUNCTION load_historic_offering(Offering_id IN NUMBER,
                                 Price_id    IN NUMBER) RETURN SYS_REFCURSOR;
  PROCEDURE lock_customer(customer_id IN NUMBER, username IN VARCHAR2);

END pkg_oepe;
/
