CREATE package DeviceSummaryUtils is
  procedure init(cardID NUMBER, frontierDate DATE);
  function getCardsArray return arrayofnumbers;
  procedure clear;
end DeviceSummaryUtils;
/
