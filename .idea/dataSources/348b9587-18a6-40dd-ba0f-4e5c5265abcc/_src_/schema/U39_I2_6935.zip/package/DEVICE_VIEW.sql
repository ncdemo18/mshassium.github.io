CREATE PACKAGE "DEVICE_VIEW"
IS

PROCEDURE ADD_START_DEVICE_VIEW_BUTTON(
    buttonAttrId number,
    objectTypeId number,
    attrGroupId number,
    attrSchemaId number,
    dispDevicesProfileId number,
    showOrder number
);

END;
/
