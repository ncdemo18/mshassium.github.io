CREATE PACKAGE PKGOM is

	TEMPLATE_OBJECT_TYPE_ID NUMBER(20) := 90000120;
	VERSION_OBJECT_TYPE_ID NUMBER(20) := 90000130;
	REFERENCE_ATTR_ID NUMBER(20) := 90000720;
	PERS_DESTINATION_ID NUMBER(20) := 70004001;
	VER_REFERENCE_ATTR_ID INTEGER := 70002004;
	PROCESS_MANAGEMENT_ID INTEGER := 91000000;
	DELETED_ITEMS_CONTAINER_ID NUMBER(20) := 1900010010;

	TYPE tcursor IS REF CURSOR;

	ROUND_TO                   number := 4;

    function getVersion( activity_id number) return number;

	function addToUsed( uTasks varchar2, taskID number, value number ) return varchar2;

	function addToParents( parents varchar2, taskID number ) return varchar2;

	function containsInUsed( uTasks varchar2, taskID number ) return number;

	function containsInParents( parents varchar2, taskID number ) return number;

	function getValue( uTasks varchar2, taskID number ) return number;

	function getTaskDelay(taskID number) return number;

	function getTaskDelay(taskID number, version_id number) return number;

	function getTaskStandardInterval(taskID number) return number;

	function getTaskStandardInterval(taskID number,version_id number) return number;

	function showInDiagram(taskID number) return number;

	function getStartPoint( taskID number ) return number;

	function getEndPoint( taskID number ) return number;

	function getBaseline( taskID number ) return date;

	procedure getTaskStartPoint(
                taskID                	in number,
                target           		in number,
                version              	in number,
                usedIN             		in varchar2,
                usedOUT            		out varchar2,
                parents    				in varchar2,
                point 					out number );

	function getDate( taskID number, days number, flag number ) return date;

	function getDateAfterInterval( baseline date, days number, wh_from number, wh_to number, flag number ) return date;

	function isReusable( p_object_id number) return number;

	function getProcessLength( process_id number) return number;

	function getAllDiagramTasks( version_id number) return varchar2;

	procedure getNextDiagramTasks( task_id in number, used in varchar2, used_out out varchar2, diagram_tasks in varchar2, diagram_tasks_out out varchar2 );

	FUNCTION getPoint(value in VARCHAR2, version_id in NUMBER)  RETURN NUMBER;

	PROCEDURE calculateEndPointsForTemplate(version_id IN NUMBER);
end;
/
