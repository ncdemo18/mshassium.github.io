CREATE package pkg_baip_catalog_synch as

  /*
    Adds a message to journal table
   */

  /*Write message to journal*/
  procedure journal(sess_id varchar2,
                    message varchar2,
                    obj_id varchar2 default NULL, message_type number default pkg_baip_catalog_const.MESSAGE_TYPE_INFO_ID);

  /* Write number of objects for synchronization to message journal */
  procedure add_cursor_count_to_journal(sess_id varchar2,
                                        row_count number
  );

/*
    Updates RBM ID (rbm_id),
    saving it to specified parameter (defined by attrid, objid).
*/
  procedure update_rbm_id_parameter(objid  number,
                                    rbm_id number,
                                    attrid number);

  /*
      Updates RBM ID (rbm_id),
      saving it to specified SDB table column (defined by table_name, column_name, objid, session_id).
  */
  procedure update_rbm_id_column(objid       number,
                                 rbm_id      number,
                                 table_name  varchar2,
                                 column_name varchar2,
                                 session_id  varchar2);

  procedure update_rbm_id_column_by_rowid(row_id       rowid,
                                 rbm_id      number,
                                 table_name  varchar2,
                                 column_name varchar2);

  procedure update_price_plan_rbm_id(price_plan_id number,
                                      rbm_id      number);

  /* Set successful status for specified object (objid) */
  procedure update_success_status(objid number,
                                  sess_id varchar2,
                                  provStatusAttrId number default pkg_baip_catalog_const.PROVISIONING_STATUS_ATTR_ID
);

  /* Set successful status for specified Offering Price Details object (objid) */
  procedure update_opd_success_status(objid number, sess_id varchar2);

  /* Set error status for specified object (objid) */
  procedure update_error_status(objid       number,
                                sess_id     varchar2,
                                err_message varchar2,
                                err_code    number,
                                stacktrace  varchar2,
                                df_session_id varchar2 default '',
                                provStatusAttrId number default pkg_baip_catalog_const.PROVISIONING_STATUS_ATTR_ID
);

  /* Set error status for specified Offering Price Details object (objid) */
  procedure update_opd_error_status(objid       number,
                                sess_id     varchar2,
                                err_message varchar2,
                                err_code    number,
                                stacktrace  varchar2,
                                df_session_id varchar2 default '');

  /* Set error status for specified object (objid) - version 2 without getting stacktrace and other values*/
  procedure update_error_status_mod(objid       number,
                                    sess_id     varchar2,
                                    err_message varchar2 default null,
                                    err_code    number default null,
                                    stacktrace  varchar2 default null);

  /* Sets status, end date, error_message (if not empty) for external operation */
  procedure finish_external_operation(operation_id number);
  /* Sets status for external operation */
  procedure start_external_operation(operation_id number);
  /* Promotes a catalog with a status of Design to a status of Test */
  procedure promote_to_test(catalog_version_id number);
  /* Demotes a catalog from a status of Test to a status of Design */
  procedure demote_to_design(catalog_version_id number);
  /* Publishes a billing and/or rating catalog, thus changing its/their status from Test to Live */
  procedure publish_to_live(catalog_version_id number);
  /* Deletes a catalog, thus changing its status from Rejected or Superseded to Deleted */
  procedure delete_catalog(catalog_version_id number);
  /* Creates a CATALOGUECHANGE record. The catalog is created with a status of Design and no links to other catalogs*/
  procedure create_catalog(parent_object_id    in number,
                           new_object_id       out number,
                           catalog_name        in varchar2,
                           catalog_description in varchar2);
  /* Creates a new record by taking a copy of an existing catalog */
  procedure copy_catalog(catalog_version_id  in number,
                         new_object_id       out number,
                         catalog_name        in varchar2,
                         catalog_description in varchar2);
  /* Linking to a rating catalog*/
  procedure link_rating_catalog(catalog_version_id in number,
                                rating_catalog_id  in number);
  /* Unlinking from a rating catalog */
  procedure unlink_rating_catalog(catalog_version_id in number);
  /*Get error message RBM API*/
  function get_gapi_error(p_err in varchar2, language_id in varchar2 default null) return varchar2;
/*Calculate the mantissa for aggregate discount step rate */
  function get_aggr_rate_mantissa(rate in number) return number;
/*Calculate the exponent for aggregate discount step rate */
  function get_aggr_rate_exponent(rate in number, currency_id in number) return number;

  function f$decode_filter_elem_attr_val(input_value in varchar2,
                                         event_attribute_number in varchar2,
                                         currency_id in number)
   return varchar2;

  function f$transform_discount_threshold(vp_input_value           in varchar2,
                                          vp_threshold_attr_type   in number,
                                          vp_capture_units_lv      in number,
                                          vp_event_spec_attr_type  in number,
                                          vp_minor_dec_places_mult in number)
    return NUMBER;

  function get_offer_level(offer_id in number) return number;

  function has_subscription(offer_id in number) return number;

  function get_current_family(offer_id in number) return number;

  function add_almost_a_day(d DATE) RETURN TIMESTAMP;

  function calculate_provisioning_status(obj_id in number) return number;

  function get_object_type(obj_id in number) return number;

  function is_ext_pp_filled_for_po(po_id number) return boolean;

  function is_ext_pp_filled_for_pn(po_id number, node_id number) return boolean;

  function is_deactivation_fee(opc_id in number) return boolean;

  function is_po_in_live_catalogue(po_id in number) return boolean;

  function get_ots_id(pv_id in number) return number;

  function is_ots_id_in_otc_tariff(ots_id in number) return boolean;

  function is_ots_in_live_catalogue(ots_id in number) return boolean;

  function is_no_charge(pv_id in number) return boolean;

end;
/
