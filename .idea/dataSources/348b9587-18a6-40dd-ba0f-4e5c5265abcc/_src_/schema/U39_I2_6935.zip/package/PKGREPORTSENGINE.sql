CREATE PACKAGE "PKGREPORTSENGINE"
  IS
    varchar2_type               CONSTANT PLS_INTEGER := 1;
    number_type                 CONSTANT PLS_INTEGER := 2;
    char_type                   CONSTANT PLS_INTEGER := 96;
    date_type                   CONSTANT PLS_INTEGER := 12;
    clob_type                   CONSTANT PLS_INTEGER := 112;
    GLOBAL_TEMPORARY_TABLE_FLAG CONSTANT PLS_INTEGER := 1;
    NO_LOGGING_FLAG             CONSTANT PLS_INTEGER := 2;
    BUFFER_POOL_RECYCLE_FLAG    CONSTANT PLS_INTEGER := 4;

    CACHE_PREFIX                CONSTANT VARCHAR2(20):='NC_REP_C_';

	FUNCTION isNewHistoryTableNeeded (
    table_name    VARCHAR2,
    report_query  CLOB
 	) RETURN INTEGER;

  FUNCTION queryToVarchar2S (
    query CLOB
  ) RETURN DBMS_SQL.VARCHAR2S;

  FUNCTION queryToVarchar2A (
    query CLOB
  ) RETURN DBMS_SQL.VARCHAR2A;

  function getColumnNames (
    report_query CLOB
  ) return ARRAYOFSTRINGS;

  function typeCodeToTypeName(
    code number
  ) return varchar2 deterministic;

  procedure createHistoryTable(
    source_query CLOB,
    table_name in varchar2
  );

  function getColumnTypes (
    report_query CLOB
  ) return ARRAYOFNUMBERS;

  procedure createHistoryTableExtended(
    source_query CLOB,
    table_name in varchar2,
    flags number default 0
  );

  function   GET_LOCALIZED_OBJECT_NAME(
    OBJECT_ID_IN IN nc_objects.object_id%TYPE,
    LANGUAGE_ID_IN IN nc_nls_objects.language_id%TYPE
  ) RETURN nc_objects.name%TYPE;

  function getColumnNamesAndTypes (
    report_query CLOB
 	) return ArrayOfStrings;

  FUNCTION dropCache(
    cache_id VARCHAR2
  ) return VARCHAR2;

  FUNCTION truncateOrCreateCache(
    source_query CLOB,
    cache_table VARCHAR2
  ) return NUMBER;

  FUNCTION GET_UNIT_ORDER_BY_ADD (
    ADDITIONAL_ IN nc_list_values.ADDITIONAL%TYPE
  ) RETURN nc_list_values.SHOW_ORDER%TYPE;

  FUNCTION is_deletion_scheduled(
    p_table_name  IN  VARCHAR2
  ) RETURN INT;

  PROCEDURE cleanup_history_tables(
    tables        IN  arrayofstrings
  );

END;
/
