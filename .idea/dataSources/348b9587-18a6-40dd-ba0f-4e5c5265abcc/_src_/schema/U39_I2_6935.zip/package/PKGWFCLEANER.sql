CREATE package pkgWFCleaner
  authid current_user
is
  PROCESS_CODE constant varchar2(100) := 'PKGWFCLEANER';
  DEFAULT_EXEC_PREDICTED_TIME constant number := 0.2; --Forecast or time execution for all Procedures

  -- these constants define allowed levels of logging severity
  LOG_SEVERITY_DEBUG   constant NUMBER := 1;
  LOG_SEVERITY_INFO    constant NUMBER := 2;
  LOG_SEVERITY_WARNING constant NUMBER := 3;
  LOG_SEVERITY_ERROR   constant NUMBER := 4;
  LOG_SEVERITY_FATAL   constant NUMBER := 5;

  -- You can limit amount of logging by setting this variables.
  -- Only logs with severiry greater than this will be written.
  LOG_SEVERITY_FILTER NUMBER := LOG_SEVERITY_DEBUG;

  procedure delete_unused_hierarchy(max_duration in number,bulk_size in number default 500);

  procedure define_entities_set(max_duration in number default 2);

  procedure delete_other_entities(max_duration in number);

/*  procedure clear_wf_integration_events;

  procedure clear_wf_integration_events_v1 (bulk_size in number);
*/
  procedure delete_processes_parallel (
    dop in number default 1, --"Degree of parallelism". Number of parallel jobs, deleting processes
    bulk_size in number default 100, --Number of processes deleted by one time.
    max_duration in number default 2 --Delete procedure length in hours
  );

  procedure delete_processes ( --Should be visible so that jobs could see it.
    current_chunk_id number, --Numbers should be 1,2,3...
    process_range_start number, --Borders of IDs' range to delete
    process_range_finish number
  );

  procedure delete_wf_events_parallel (
    dop in number default 1, --"Degree of parallelism". Number of parallel jobs, deleting events
    bulk_size in number default 100, --Number of events deleted by one time.
    max_duration in number default 2 --Delete procedure length in hours
  );

  procedure delete_wf_events ( --Should be visible so that jobs could see it.
    current_chunk_id number, --Numbers should be 1,2,3...
    event_range_start number, --Borders of IDs' range to delete
    event_range_finish number
  );


 /**
   Start Collection
  */
  procedure do_clean(
    hours_limit number,      --Execution hours limit
    dop in number default 1, --"Degree of parallelism". Number of parallel jobs, deleting wf objects
    bulk_size in number default 100, --Number of events deleted by one time.
    LOGS_RETENTION_DAYS in NUMBER default 30
 );

end pkgWFCleaner;
/
