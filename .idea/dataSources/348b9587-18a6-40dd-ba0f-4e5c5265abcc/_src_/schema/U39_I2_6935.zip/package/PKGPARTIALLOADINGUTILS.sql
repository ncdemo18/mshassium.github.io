CREATE PACKAGE          "PKGPARTIALLOADINGUTILS" 
is

	DEFAULT_X0 constant pls_integer := 0;
	DEFAULT_Y0 constant pls_integer := 2400;

	DEFAULT_XGAP constant pls_integer := 30;
	DEFAULT_YGAP constant pls_integer := -30;

        procedure align(
        	site in number,
        	x_gap in number default DEFAULT_XGAP,
        	y_gap in number default DEFAULT_YGAP,
		x0 in number default null,
		y0 in number default null
        );


	procedure alignToGridRows(
		site in number,
		num in number,
		x_gap in number default DEFAULT_XGAP,
		y_gap in number default DEFAULT_YGAP,
		x0 in number default null,
		y0 in number default null
	);

	procedure alignToGridCols(
		site in number,
		num in number,
		x_gap in number default DEFAULT_XGAP,
		y_gap in number default DEFAULT_YGAP,
		x0 in number default null,
		y0 in number default null
	);

	--- partial loading configuration facilities go hereafter

	MONITOR_SIZE constant pls_integer := sqrt(1280*1024);

	OBJECTS_TOO_DENSE exception;
	FILTER_MISCONFIGURATION exception;

	-- filters objects (actually, object types) from queries.
	-- if 'all_inclusive' is 1, the 'special' collection contains
	-- object types to be EXcluded, otherwise - types to be INcluded.
	type TFilter is record (
		all_inclusive integer,
		special arrayofnumbers
	);

	type TRectangle is record (
		xmin float,
		ymin float,
		xside float,
		yside float
	);

	type TSquare is record(
		xmin float,
		ymin float,
		side float
	);

	function createFilter(incl integer, spec arrayofnumbers) return TFilter;
	function rectIsNull(rect TRectangle) return boolean;

	-- how many objects are there in the specified rectangle.
	function objectsIn(site in integer, area in TRectangle, filt in TFilter default null) return integer;

	-- the smallest rectangle containing all (or some if filtered) objects on a site.
	-- returns null (what is qualified as null by rectIsNull(...)) when no objects
	-- are at the site or all are filtered out.
	function objectsRect(site in integer, filt in TFilter default null) return TRectangle;

	-- this function is for convenience, it doesn't take part in scale computing, but you
	-- can check the results of scale computing using it (just set 'escale' to whatever has been
	-- given by the maxScale(...) function).
	function maxObjectsAt(site in integer, escale in float, filt in TFilter default null) return integer;

	-- this actually gives the maximal effective scale, at which the condition of
	-- no more than 'num' objects entering the workspace is still held.
	-- returns null when there is no need to set maxScale for a layer (no objects,
	-- the total number of objects is less than the limit, all objects are filtered out etc.)
	function maxScale(site in integer, num in integer, filt in TFilter default null) return float;
end;



/
