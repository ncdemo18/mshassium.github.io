CREATE package PKG_BAM_LOCK is

  LOCK_SUCCESS constant integer := 1;
  LOCK_FAIL constant integer := 0;

  MAX_WAIT_TIMEOUT constant integer := 32767;

  function lock_exclusive(object_name varchar2, timeout in integer default MAX_WAIT_TIMEOUT) return integer;

  function lock_shared(object_name varchar2, timeout in integer default MAX_WAIT_TIMEOUT) return integer;

  procedure unlock(object_name varchar2);

end PKG_BAM_LOCK;
/
