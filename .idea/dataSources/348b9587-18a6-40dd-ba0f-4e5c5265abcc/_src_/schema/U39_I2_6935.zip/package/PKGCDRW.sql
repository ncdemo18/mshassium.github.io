CREATE package pkgCDRW is
  type ref_cursor is ref cursor;

--ANAR0707 [10.31.08] [CDRW: Planned cards should not be in scope of CDRW] Start
  function find_cards_hierarchically(
    p_src_device number
  )
  return arrayofnumbers;

  function find_resources(
    p_src_device number
  )
  return arrayofnumbers;

  function find_resources_ret_cur(
    p_src_device number
  )
  return ref_cursor;

  function arrayofnumbers_to_cursor(
    param arrayofnumbers
  )
  return ref_cursor;
--ANAR0707 [10.31.08] [CDRW: Planned cards should not be in scope of CDRW] End

  function filter_existent_resources(
    v_potential_resources arrayofnumbers,
    p_ref_attrs arrayofnumbers,
    p_backref_attrs arrayofnumbers,
    p_child_ref_attrs arrayofnumbers,
    p_child_backref_attrs arrayofnumbers,
    p_child_types arrayofnumbers
  )
  return ref_cursor;

  function find_existent_resources(
    p_src_device number,
    p_ref_attrs arrayofnumbers,
    p_backref_attrs arrayofnumbers,
    p_child_ref_attrs arrayofnumbers,
    p_child_backref_attrs arrayofnumbers,
    p_child_types arrayofnumbers
  )
  return ref_cursor;


--ALKA0812 [08.17.2012] [Issue [PROD.INT.PH1_QA_CDRW] - [PI Ph4].[Card Device Replacement Wizard].[MPLSME1.44] tables do not contain all of the columns] [start]

  function add_unique_values
  (
    i_main_string IN VARCHAR2,
    i_add_values IN VARCHAR2,
    i_separator IN VARCHAR2
  )
  return varchar2;

--ALKA0812 [08.17.2012] [Issue [PROD.INT.PH1_QA_CDRW] - [PI Ph4].[Card Device Replacement Wizard].[MPLSME1.44] tables do not contain all of the columns] [end]

  FUNCTION add_unique_values
    (
      i_main_string IN VARCHAR2,
      i_add_values  IN VARCHAR2,
      i_delimetor   IN VARCHAR2,
      i_add_to_begin CHAR  /* 'Y' stands for adding to the begin, something else stands for addning to the end*/
    )
  RETURN VARCHAR2;

  procedure remap_resources(
    p_src_device number,
    p_dst_device number,
    p_src_res arrayofnumbers,
    p_dst_res arrayofnumbers,
    p_ref_attrs arrayofnumbers,
    p_backref_attrs arrayofnumbers,
    p_child_ref_attrs arrayofnumbers,
    p_child_backref_attrs arrayofnumbers,
    p_child_types arrayofnumbers
  );
end pkgCDRW;
/
