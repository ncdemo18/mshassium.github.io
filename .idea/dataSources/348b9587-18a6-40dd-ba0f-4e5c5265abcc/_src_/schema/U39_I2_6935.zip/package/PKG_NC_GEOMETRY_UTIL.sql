CREATE PACKAGE PKG_NC_GEOMETRY_UTIL is
  TYPE Varchar2NumberHashTable IS TABLE of NUMBER(20)
   INDEX BY VARCHAR2(20);
  TYPE Varchar2GeomHashTable IS TABLE of MDSYS.SDO_GEOMETRY
   INDEX BY VARCHAR2(20);
  TYPE PairOfNumbersTable IS TABLE of pairofnumbers;

  function getSegmentsIntersection(segA_x1 IN number, segA_y1 IN number, segA_x2 IN number, segA_y2 IN number,
                                   segB_x1 IN number, segB_y1 IN number, segB_x2 IN number, segB_y2 IN number) return MDSYS.SDO_POINT_TYPE;

  function calculateCircuitGeometry(circuit_id IN NUMBER, srid IN NUMBER) return MDSYS.Sdo_Geometry;
  function getCircuitCarriers(circuit_id IN NUMBER) return arrayofnumbers;
  function getCircuitCarriersRec(circuit_id IN NUMBER, ringsClosures IN OUT Varchar2NumberHashTable) return PairOfNumbersTable;
  function getCircuitAllowedTypeIds return arrayofnumbers;
  function centroidOfMultipolygon(geom IN MDSYS.SDO_GEOMETRY) return MDSYS.SDO_POINT_TYPE;
  function centroidOfPolygon(geom IN MDSYS.SDO_GEOMETRY) return MDSYS.SDO_POINT_TYPE;
  function centroidOfOrdinates(ordinates IN MDSYS.SDO_ORDINATE_ARRAY) return MDSYS.SDO_POINT_TYPE;
  function getLongitudeInDMS(obj_id IN NUMBER) return VARCHAR2;
  function getLatitudeInDMS(obj_id IN NUMBER) return VARCHAR2;

  procedure circuitCarriersRec_inner(
      parent_circuit_id in number,
       allowedTypes in arrayofnumbers,
       carriersToCircuits in out PairOfNumbersTable,
       nowPerformingCircuits IN OUT Varchar2NumberHashTable,
       ringsClosures IN OUT Varchar2NumberHashTable);
  function isCircuit_inner(obj_id in number) return boolean;
  function isOneOfTypes_inner(obj_id in number, types arrayofnumbers) return boolean;
  function isRing_inner(obj_id in number) return boolean;
  procedure modifyGeometryDatas_inner(
      ordinatesData IN OUT SDO_ORDINATE_ARRAY,
      infoData IN OUT SDO_ELEM_INFO_ARRAY,
      curr_geom IN MDSYS.SDO_GEOMETRY,
      prev_geom IN MDSYS.SDO_GEOMETRY,
      jumpToNextCircuit boolean);
  procedure updateCircuitGeometry(circuit_id IN NUMBER, srid IN NUMBER);
  procedure updateCircuitsGeometries(circuit_ids IN arrayofnumbers, srid IN NUMBER);
  function updateCircuitsGeometriesByOT(object_types IN arrayofnumbers, srid IN NUMBER, min_rownum IN NUMBER, block_size IN NUMBER) return NUMBER;
  function updateCircWithoutGeomByOT(object_types IN arrayofnumbers, srid IN NUMBER, min_rownum IN NUMBER, block_size IN NUMBER) return NUMBER;
  function sdoGeometryCost(OBJ IN MDSYS.SDO_ORDINATE_ARRAY) return NUMBER;
end PKG_NC_GEOMETRY_UTIL;
/
