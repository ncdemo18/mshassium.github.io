CREATE PACKAGE          "PKG_NCG_NC_COORDS" IS
    /* Adds 'exclude_from_nc_coords=true' property to specified object types
       and then removes NC_COORDS records for objects of those types */
    procedure set_exclude_from_nc_coords (ot_ids in arrayofnumbers);

    /* Removes 'exclude_from_nc_coords=true' property from specified object types.
       NOTE: currently it does NOT restore NC_COORDS records for affected objects */
    procedure unset_exclude_from_nc_coords (ot_ids in arrayofnumbers);
END;



/
