CREATE PACKAGE pkg_lmgt IS

FUNCTION generate_lpv_name(pn_size IN NUMBER) RETURN VARCHAR2;

FUNCTION generate_loi_name(pn_size IN NUMBER) RETURN VARCHAR2;

FUNCTION generate_transitions_name(pn_size IN NUMBER) RETURN VARCHAR2;

FUNCTION get_market_hierarchy (program_id in number) RETURN arrayofnumbers;

FUNCTION get_ccategory_hierarchy (program_id in number) RETURN arrayofnumbers;

FUNCTION get_offering_currencies(offering_ids in arrayofnumbers) RETURN tableof2numbers;

FUNCTION get_currency_for_offering(offering_id in number) RETURN NUMBER;

FUNCTION get_no_parent(objectid IN NUMBER) RETURN NUMBER;

FUNCTION get_suitable_loyalty_programs(objectid IN NUMBER) RETURN tableofnumandstr;

END pkg_lmgt;
/
