CREATE PACKAGE pkg_cia_debug AUTHID CURRENT_USER IS

    -----------------Logging engine----------------
    --This debug level can change normal execution
    --Must be used only for manual debug during development
    trace_level_detail_debug CONSTANT PLS_INTEGER := 4;

    trace_level_debug CONSTANT PLS_INTEGER := 3;
    trace_level_error CONSTANT PLS_INTEGER := 2;
    trace_level PLS_INTEGER := trace_level_error;

    PROCEDURE log_debug(msg IN VARCHAR2);

    PROCEDURE log_error(msg IN VARCHAR2);

    PROCEDURE log_exception;

    PROCEDURE clear_log;
    ---------------End of logging engine------------

    --Convert arrayofnumbers into comma delimited list
    FUNCTION get_list(SELF IN arrayofnumbers) RETURN VARCHAR2;

    --Helper procedure. It creates temporary tables for logging
    --nc_cia_dependencies_temp, nc_cia_severities_temp tables
    PROCEDURE init_debug;

    --Helper procedure. It dropes temporary tables for logging
    --nc_cia_dependencies_temp, nc_cia_severities_temp tables
    PROCEDURE finish_debug;

    --Helper procedure. It writes current state of
    --nc_cia_dependencies_temp, nc_cia_severities_temp tables
    PROCEDURE dump_temporary_tables(step IN VARCHAR2);

    --Helper procedure. It writes result of <query> into table <table_name>
    PROCEDURE dump_query(table_name IN VARCHAR2, query IN VARCHAR2);

END pkg_cia_debug;
/
