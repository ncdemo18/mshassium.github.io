CREATE PACKAGE "GEOGRAPHICAL_VIEW_WEB_API"
IS
  PROCEDURE ADD_OOB_SHEET_TO_TYPE(
    attr_schema_id     IN NUMBER,
    attr_group_id      IN NUMBER,
    attr_id            IN NUMBER,
    object_type_id     IN NUMBER,
    tab_name           IN VARCHAR2,
    tab_order          IN NUMBER,
    policy_id          IN NUMBER
  );
END;
/
