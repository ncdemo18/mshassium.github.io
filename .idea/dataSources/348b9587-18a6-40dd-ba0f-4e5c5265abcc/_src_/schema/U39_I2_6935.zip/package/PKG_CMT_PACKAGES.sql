CREATE PACKAGE PKG_CMT_PACKAGES AS

    -- Functionality of working with CMT packages
    -- Creation date: 2012-01-16 13:01
    -- Created by PAFE0910

    -- Adds entities from given list to package with type given in entity_type_arg.
    -- If only_unpackaged_arg = 1 then saves only elements that are not assigned to a package.
    function add_entities2package(package_name_arg varchar2, id_list_arg arrayofstrings, entity_type_arg varchar2, entity_group_arg varchar2, only_unpackaged_arg number default 0) return arrayofstrings;

    -- Extracts entities from given id_list_str (they should be separated by commas) and adds them to package with type given in entity_type_arg.
    -- -- If only_unpackaged_arg = 1 then saves only elements that are not assigned to a package.
    function add_entities2package(package_name_arg varchar2, id_list_str varchar2, entity_type_arg varchar2, entity_group_arg varchar2, only_unpackaged_arg number default 0) return arrayofstrings;

    -- Extracts entities using given query in query_str argument and adds them to package with type given in entity_type_arg.
    -- Query result should contain only one column.
    -- If only_unpackaged_arg = 1 then saves only elements that are not assigned to a package.
    function add_entities2package_by_query(package_name_arg varchar2, query_str varchar2, entity_type_arg varchar2, entity_group_arg varchar2, only_unpackaged_arg number default 0) return arrayofstrings;

    -- returns package name separator
    function get_package_name_separator return varchar2;

    -- removes entities bound to given package. If 'is_recursive' argument is not 0 (for example, 1), then also removes entities from child packages
    -- for example, when called as remove_package_content('cmtools', 1), the procedure will remove all entities from packages 'cmtools', 'cmtools.test_project', 'cmtools.test_project.top', etc.
    procedure remove_package_content(package_name_arg varchar2, is_recursive number default 0);

    -- creates a package with given name and description
    function create_package(package_name varchar2, package_description varchar2 default null, package_config clob default null) return integer;

    -- returns 1 when given entity_type is hierarchical, 0 otherwise
    function is_entity_type_hierarchical(entity_type_arg varchar2) return number;

    function is_parent_hierarchical(v_object_id varchar2) return number;

    DEFAULT_NC_OBJECT_ENTITY_TYPE varchar2(50) := 'atom_nc_object';

    -- /* tries to immediately lock table NC_CMT_PACKAGE_ENTITIES.
    -- returns 1 if lock was successful, 0 if locking failed. */
    -- currently waits until a lock is acquired (the "nowait" has been removed)
    function lock_table_package_elements return number;

    AUTOASSIGN_LOCK_OT_ID number := 9132026664313295844 /* AutoAssign Lock OT */;

    -- called by autoassign to acquire a lock
    function acquire_autoassign_lock(
      is_nowait in number default 0
    ) return number;

    FUNCTION get_items_by_package_cur
    (
      p_domain_id IN nc_objects.object_id%TYPE
     ,p_packages  IN arrayofstrings
     ,p_recursive IN NUMBER
     ,p_num  IN NUMBER
     ,p_size IN NUMBER
     ,p_use_part  IN NUMBER
     ,p_ids       IN arrayofstrings
     ,p_tables    IN arrayofstrings
     ,p_filters   IN arrayofstrings DEFAULT NULL
     ,p_order in varchar2 default null
    ) RETURN SYS_REFCURSOR;

    function get_items_by_package(
      p_domain_id IN nc_objects.object_id%TYPE,
      v_packages in arrayofstrings,
      v_recursive in number,
      v_page_num in number,
      v_page_size in number,
      v_use_part in number,
      v_ids in arrayofstrings,
      v_tables in arrayofstrings,
      v_filters in arrayofstrings default null
    ) return NC_CMT_PKG_ENTITIES_TYPE_TABLE pipelined;

    function get_items_by_package_count(
      p_domain_id IN nc_objects.object_id%TYPE,
      v_packages in arrayofstrings,
      v_recursive in number,
      v_filters in arrayofstrings default null
    ) return number;

    function get_entities_key_array (
      v_ids in arrayofstrings,
      v_tables in arrayofstrings
    ) return tableof2strings;

    function add_entities2package_cache(
      cache_arg NC_CMT_PKG_ENTITIES_TYPE_TABLE,
      package_name_arg varchar2,
      id_list_arg arrayofstrings,
      entity_type_arg varchar2,
      entity_group_arg varchar2,
      only_unpackaged_arg number default 0
    ) return NC_CMT_PKG_ENTITIES_TYPE_TABLE;

    procedure apply_entities2package_cache(
      v_cache in NC_CMT_PKG_ENTITIES_TYPE_TABLE);

    function get_entities2package_cache
      return NC_CMT_PKG_ENTITIES_TYPE_TABLE;

    FUNCTION get_tree_child_packages_cur(p_domain_id IN nc_objects.object_id%type, p_package_name IN VARCHAR2)
      RETURN SYS_REFCURSOR;

    FUNCTION domain_package_exists(p_domain_id IN nc_objects.object_id%type, p_package_name IN VARCHAR2)
      RETURN NUMBER;

      -- TODO: move from java
    FUNCTION get_ci_name(p_ci_id IN VARCHAR2, p_ci_type IN VARCHAR2, p_entity_type_id IN VARCHAR2) RETURN VARCHAR2;

  ATTR_PROJECT_PACKAGES CONSTANT NUMBER:= 9132736086513050914;


END PKG_CMT_PACKAGES;
/
