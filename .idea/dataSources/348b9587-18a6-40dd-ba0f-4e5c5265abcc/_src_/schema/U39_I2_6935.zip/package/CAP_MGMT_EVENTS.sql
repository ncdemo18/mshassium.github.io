CREATE package CAP_MGMT_EVENTS as

  ASYNC_MODE constant number(1) := 0;
  SYNC_MODE constant number(1) := 1;
  -- ??? IMMEDIATE_MODE constant number(1) := 2;

  ACTION_CREATE constant number(1) := 1;
  ACTION_MOVE constant number(1) := 2;
  ACTION_MODIFY constant number(1) := 3;
  ACTION_DELETE constant number(1) := 4;

  /*Comment for registerObjectsCreation*/
  procedure registerObjectsCreation(createdObjectsIDs in arrayofnumbers,
                                    opMode in number default ASYNC_MODE);

  /*Comment for registerObjectsMove*/
  procedure registerObjectsMove(movedObjectsIDs in arrayofnumbers);

  /*Comment for registerObjectsMove*/
  procedure confirmObjectsMove(movedObjectsIDs in arrayofnumbers,
                               opMode in number default ASYNC_MODE);

  /*Comment for registerObjectsModifications*/
  procedure registerObjectsModifications(oldParamsInfo in cmi_objects_params_table,
                                         opMode in number default ASYNC_MODE);

  /*Comment for registerObjectsDeletion*/
  procedure registerObjectsDeletion(deletedObjectsIDs in arrayofnumbers);

  /*Comment for confirmObjectsDeletion*/
  procedure confirmObjectsDeletion(deletedObjectsIDs in arrayofnumbers,
                                   opMode in number default ASYNC_MODE);

  /*Comment for clearRegisteredDeletions*/
  procedure clearRegisteredDeletions(objectIDs in arrayofnumbers default null);

  /*Comment for processRegisteredEvents*/
  procedure processRegisteredEvents(maxEventsToProcess in number default null);

end CAP_MGMT_EVENTS;
/
