CREATE package pkgcore is

    -- Deletes old records from nc_history
    procedure delete_old_history;

    -- Gets job info from user_jobs. p_job - part of 'what' job parameter, p_type = {html|text}
    function get_job_info(p_job varchar2, p_type varchar2 default 'html') return varchar2;

    -- Analogue of printf in C. Does not do output.
    -- Grabbed at http://www.adp-gmbh.ch/blog/2007/04/14.php
    -- Added '\n' support
    function sprintf(format in varchar2, params in arrayofstrings) return varchar2;

end pkgcore;
/
