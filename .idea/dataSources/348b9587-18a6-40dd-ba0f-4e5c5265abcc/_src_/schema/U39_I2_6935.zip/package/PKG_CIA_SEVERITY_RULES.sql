CREATE PACKAGE pkg_cia_severity_rules IS

    --Default severity rule (maximum impact propagation)
--    FUNCTION get_default_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard Port Severity calculation function
    FUNCTION port_service_level(object_id IN NUMBER) RETURN NUMBER ;

    -- Standard Network Element Severity calculation function
    FUNCTION ne_service_level(object_id IN NUMBER) RETURN NUMBER ;

    -- Standard SubInterface Severity calculation function
    FUNCTION subinterface_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard Card Severity calculation function
    FUNCTION card_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard NodePathElement Severity calculation function
    FUNCTION npe_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard LinkPathElement Severity calculation function
--    FUNCTION lpe_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard CircuitPathElement Severity calculation function
--    FUNCTION cpe_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard Circuit Severity calculation function
    FUNCTION circuit_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard Resource Facing Service Instance Severity calculation function

--    FUNCTION rfsi_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard Customer Facing Service Instance Severity calculation function
--    FUNCTION cfsi_service_level(object_id IN NUMBER) RETURN NUMBER;

    -- Standard Customer Facing Service Instance Severity calculation function
    FUNCTION device_service_level(object_id IN NUMBER) RETURN NUMBER;

END pkg_cia_severity_rules;
/
