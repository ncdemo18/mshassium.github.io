CREATE package PKGSCHED as
    SUBTYPE lockname_t IS VARCHAR2 (40);

    SUBTYPE lockid_t IS INTEGER;

    FUNCTION ensurelock(lockname    lockname_t,
                         lockid      lockid_t,
                         lockmode    INTEGER,
                         bucket pkglocks.componentname_t)
        RETURN lockname_t;

    FUNCTION convertlock(lockname      lockname_t,
                          currmode    INTEGER,
                          nextmode    INTEGER)
        RETURN lockname_t;

    PROCEDURE releaselock(lockname lockname_t, currmode INTEGER);

    PROCEDURE mkjob(jobid       NUMBER,
                     cronex      VARCHAR2,
                     crontz      VARCHAR2,
                     jobname     VARCHAR2,
                     trans       NUMBER := 0,
                     duration    NUMBER := 0,
                     misfire     NUMBER := 0,
                     parent      NUMBER := 6092066043013856097,
                     userid      NUMBER := 111,
                     SYSTEM      NUMBER := NULL,
                     url         VARCHAR2 := NULL,                  -- url job
                     class       VARCHAR2 := NULL,
                     method      VARCHAR2 := NULL,
                     params      arrayofstrings := NULL    -- class / bean job
    );

    FUNCTION delete_objects_with_black_spot(batch_size     IN INTEGER,
                                            xml_file_infos OUT arrayofstrings)
        RETURN INTEGER;

end PKGSCHED;
/
