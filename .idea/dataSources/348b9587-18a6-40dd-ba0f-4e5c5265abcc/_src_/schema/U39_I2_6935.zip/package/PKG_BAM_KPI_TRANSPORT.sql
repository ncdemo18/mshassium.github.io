CREATE package PKG_BAM_KPI_TRANSPORT is

  /**
   * Locks LOG-table of given activity definition in shared-mode.
   * Lock will be released automatically on transaction commit or rollback.
   * Multiple tramnsactions simultaneously can lock LOG-table in shared mode.
   * While LOG-table is locked, no one another transaction can lock LOG-table to transform it
   * to QUEUE-table. Transaction which tries to transform LOG-table to QUEUE-table will wait while
   * lock will be released.
   * @param "activity_definition_id" ID of activity configuration which LOG-table must be locked.
   */
  procedure lock_log_table_shared(activity_definition_id in number);

  /**
   * Transport data to KPI-schema.
   * Only one session at a time can transport data of the same activity definition.
   * If some session is already transporting data then functions tries to wait given time and
   * if another session is still transporting data then function raises exception.
   * If some internal exception occures while transporting data then it is raised up.
   * @param "activity_id" ID of activity configuration which data should be transported to KPI-schema.
   * @param "max_records" maximum count of data records which might be transported.
   * @param "timeout" time to wait while another sessions completes transporting data.
   * @return true - if function transported all data of activity, false - if some data left non-transported.
   */
  function transport_activity(
    activity_definition_id in number,
    max_records in integer default -1,
    timeout in integer default 60
  ) return integer;

  /**
   * Try transport data for all registered activity definitions.
   * Function selects all activity definitions registered in BAM_KPI_TRANSPORT_STATES-table, which state is enabled
   * (ENABLED = 'YES'), and tries transport them data one by one using function "try_transport_activity".
   * If data of some activity definition cannot be transported due to
   * it is transporting by another session at the same time then that activity definition is skipped.
   * If some internal exception occures while transporting data of some activity definition then
   * it is logged in BAM_KPI_TRANSPORT_STATES-table.
   * Parameters "max_records" and "timeout" passed to function "try_transport" are resolved using NC_DIRECTORY-properties.
   * @param "max_working_time" defines maximum working time in seconds, after exceeding the time, working is interrupted.
   */
  procedure transport_all_activities(max_working_time in integer default -1);

  procedure disable_transport_activity(
    activity_definition_id in number,
    timeout in integer default 60,
    force in boolean default false
  );

  procedure enable_transport_activity(
    activity_definition_id in number,
    timeout in integer default 60,
    force in boolean default false
  );

  procedure reschedule_transport_job(job_interval in integer default -1, force_enable boolean default false);

  procedure disable_transport_job;

  procedure enable_transport_job;

end PKG_BAM_KPI_TRANSPORT;
/
