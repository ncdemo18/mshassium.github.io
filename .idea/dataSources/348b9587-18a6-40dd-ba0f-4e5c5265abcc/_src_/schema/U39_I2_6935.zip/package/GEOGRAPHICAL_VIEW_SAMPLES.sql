CREATE PACKAGE "GEOGRAPHICAL_VIEW_SAMPLES"
IS
  PROCEDURE CREATE_GV_SAMPLE_POLICY(
    policy_id          IN NUMBER,
    policy_name        IN VARCHAR2,
    policy_provider_id IN NUMBER,
    impl_class         IN VARCHAR2,
    launch_url         IN VARCHAR2,
    policy_description IN VARCHAR2,
    provider_type_id   IN NUMBER DEFAULT 9139449589513204748
  );

  PROCEDURE CREATE_GV_SAMPLE_PROJECTS;

  PROCEDURE CREATE_GV_SAMPLE_POINT_OBJECT(
    project_id     IN NUMBER,
    object_type_id IN NUMBER,
    latitude       IN DECIMAL,
    longitude      IN DECIMAL,
    object_id      IN NUMBER DEFAULT -1
  );

  PROCEDURE CREATE_OBJECT_WITH_REFERENCES(
    project_id     IN NUMBER,
    object_type_id IN NUMBER,
    latitude       IN DECIMAL,
    longitude      IN DECIMAL,
    references     IN tableof2numbers
  );

  PROCEDURE CLEAR_GV_TEST_DATA;
END;
/
