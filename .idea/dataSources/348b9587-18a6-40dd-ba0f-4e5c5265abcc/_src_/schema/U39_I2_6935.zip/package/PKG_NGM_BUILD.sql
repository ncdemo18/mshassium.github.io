CREATE PACKAGE PKG_NGM_BUILD
IS
TYPE ref_cursor IS REF CURSOR;

/*Interface of Graph Manager*/
PROCEDURE set_log_level(log_level int);
FUNCTION init(graph_spec_id IN NUMBER) RETURN NUMBER;
FUNCTION init(graph_spec_id IN NUMBER, request_id IN NUMBER) RETURN NUMBER;
FUNCTION prepare_graph(graph_spec_id IN NUMBER, context_keys IN ARRAYOFSTRINGS, context_values IN ARRAYOFSTRINGS) RETURN INT;

FUNCTION get_nodes  														RETURN ref_cursor;
FUNCTION get_edges  														RETURN ref_cursor;
FUNCTION get_ports                              RETURN ref_cursor;
FUNCTION get_paths 															RETURN ref_cursor;
FUNCTION get_path_elements(path_id IN NUMBER) 				RETURN ref_cursor;
FUNCTION get_paths_sources                                              RETURN ref_cursor;
FUNCTION get_source_objects  												RETURN ref_cursor;
FUNCTION get_log 															RETURN ref_cursor;
FUNCTION get_errors 														RETURN ref_cursor;
FUNCTION get_last_state(request_id IN NUMBER) 								RETURN ref_cursor;
FUNCTION get_params(element_ids ARRAYOFNUMBERS, param_specs ARRAYOFNUMBERS) RETURN ref_cursor;
FUNCTION get_params(param_specs ARRAYOFNUMBERS) 							RETURN ref_cursor;
FUNCTION get_params  														RETURN ref_cursor;
FUNCTION get_path_params                                                 RETURN ref_cursor;
FUNCTION get_lazy_params(element_ids ARRAYOFNUMBERS) 						RETURN ref_cursor;
FUNCTION get_actualize_rules_by_class                         RETURN ref_cursor;

FUNCTION get_state_of_graph_spec(graph_spec_id IN NUMBER) RETURN ARRAYOFSTRINGS;

FUNCTION get_graph_id RETURN NUMBER;

procedure remove_graph(p_graph_id NUMBER);

FUNCTION actualize_graph(p_request_id IN NUMBER, p_graph_id IN NUMBER, p_graph_spec_id IN NUMBER, context_keys IN ARRAYOFSTRINGS, context_values IN ARRAYOFSTRINGS) RETURN NUMBER;
FUNCTION get_incremental_graph_elements(p_request_id IN NUMBER, p_graph_id IN NUMBER, current_rev_num IN NUMBER, requested_rev_num IN NUMBER) RETURN ref_cursor;
FUNCTION get_incremental_graph_sources(p_request_id IN NUMBER, p_graph_id IN NUMBER, current_rev_num IN NUMBER, requested_rev_num IN NUMBER) RETURN ref_cursor;
FUNCTION get_actualized_params(p_request_id IN NUMBER, p_graph_id IN NUMBER, current_rev_num IN NUMBER, requested_rev_num IN NUMBER) RETURN ref_cursor;



/*debug*/
PROCEDURE calculate_params_by_spec;

END PKG_NGM_BUILD;
/
