CREATE PACKAGE "PKG_MSEGMENT" as

PROCEDURE createSnapMembersBySearchQuery (searchQuery VARCHAR2, segment_ref NUMBER, project_id NUMBER, validation_flag_val NUMBER, object_type_id NUMBER,sp_id NUMBER);

end pkg_msegment;
/
