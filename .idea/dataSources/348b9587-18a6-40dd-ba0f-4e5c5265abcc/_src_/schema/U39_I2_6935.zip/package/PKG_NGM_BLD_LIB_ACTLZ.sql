CREATE PACKAGE PKG_NGM_BLD_LIB_ACTLZ
AS

FUNCTION remove_nodes(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,nodes TableOf3Numbers, additional_removed TABLEOFGE)  RETURN TABLEOFGE;
FUNCTION remove_nodes(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,nodes TableOf3Numbers)  RETURN TABLEOFGE;
FUNCTION remove_nodes(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,nodes_ids ArrayOfNumbers, additional_removed TABLEOFGE)  RETURN TABLEOFGE;
FUNCTION remove_nodes(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,nodes_ids ArrayOfNumbers)  RETURN TABLEOFGE;
FUNCTION remove_nodes_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, node_spec_id NUMBER, nodes_ids ArrayOfNumbers, additional_removed TABLEOFGE)  RETURN TABLEOFGE;
FUNCTION remove_nodes_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, node_spec_id NUMBER, nodes_ids ArrayOfNumbers)  RETURN TABLEOFGE;

FUNCTION remove_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_ids TableOf3Numbers, edges TableOf3Numbers, additional_removed TABLEOFGE)  RETURN TABLEOFGE;
FUNCTION remove_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_ids TableOf3Numbers, edges TableOf3Numbers)  RETURN TABLEOFGE;
FUNCTION remove_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_src TableOf3Numbers, additional_removed TABLEOFGE)  RETURN TABLEOFGE;
FUNCTION remove_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_src TableOf3Numbers)  RETURN TABLEOFGE;
FUNCTION remove_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_ids ArrayOfNumbers, additional_removed TABLEOFGE)  RETURN TABLEOFGE;
FUNCTION remove_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_ids ArrayOfNumbers)  RETURN TABLEOFGE;
FUNCTION remove_edges_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, edge_spec_id NUMBER, edges_ids ArrayOfNumbers, additional_removed TABLEOFGE)  RETURN TABLEOFGE;
FUNCTION remove_edges_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER, edge_spec_id NUMBER, edges_ids ArrayOfNumbers)  RETURN TABLEOFGE;

FUNCTION merge_TABLEOFGE(set1 TABLEOFGE, set2 TABLEOFGE) RETURN TABLEOFGE;

FUNCTION add_nodes(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,nodes TableOf3Numbers)  RETURN TABLEOFGE;
FUNCTION add_nodes_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,nodes_ids ArrayOfNumbers, node_spec_id NUMBER, start_id IN OUT NUMBER )  RETURN TABLEOFGE;
FUNCTION add_nodes_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,nodes_ids ArrayOfNumbers, node_spec_id NUMBER)  RETURN TABLEOFGE;

FUNCTION add_edges(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_ids TableOf3Numbers, edges TableOf3Numbers)  RETURN TABLEOFGE;
FUNCTION add_edges_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_src TableOf3Numbers, edge_spec_id NUMBER , start_id IN OUT NUMBER)  RETURN TABLEOFGE;
FUNCTION add_edges_by_sources(v_graph_id NUMBER, v_request_id NUMBER, v_rev_num NUMBER,edges_src TableOf3Numbers, edge_spec_id NUMBER )  RETURN TABLEOFGE;

END PKG_NGM_BLD_LIB_ACTLZ;
/
