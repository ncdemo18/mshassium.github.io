CREATE PACKAGE PKGCTCOM is

  procedure create_components( src_id_in number, dest_id_in number, current_user_name_in varchar2 );

end;
/
