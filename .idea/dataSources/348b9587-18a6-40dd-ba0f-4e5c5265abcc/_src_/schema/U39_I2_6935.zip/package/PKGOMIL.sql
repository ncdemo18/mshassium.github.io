CREATE PACKAGE PKGOMIL as

    procedure getdeltarefparams   (old_object_id in number, new_object_id in number);
    procedure getdeltaobjects     (old_object_id in number, new_object_id in number);
    procedure getdeltaparams      (old_object_id in number, new_object_id in number);
    procedure getdeltalistparams  (old_object_id in number, new_object_id in number);
    procedure getdeltadateparams  (old_object_id in number, new_object_id in number);
    procedure getdeltaproperties  (old_object_id in number, new_object_id in number);
    procedure getfiltereddelta    (new_object_id in number);
    procedure setdelta            (new_object_id in number);
    PROCEDURE calculateDeltaForComponent(prevOrderID in number, orderID in number);

    PROCEDURE fillParameters (om_session_id nc_objects.object_id%TYPE);
    procedure calculateDeltaForComponents(components tableof2numbers);
    procedure setdeltaparams (new_object_id in number);
    function buildDelta(p_old_object_id number, p_new_object_id number) return tableof2numbers;
    function legacy_inflight_link(old_list arrayofnumbers, new_list arrayofnumbers, new_interactions arrayofnumbers) return order_array pipelined;
    function propagation_participants(source_dest_orders tableof2numbers) return propagation_array;
    function get_hierarchy_of_orders(orderids in arrayofnumbers) return arrayofnumbers;
    procedure createFlowItemForOrder (session_id in number, flow_item_2_so in number,
        flow_item_2_interaction_item in number, estimated_duration in number,
        flow_item_state in number, serial_processing in number, not_started_list_value in number);
    procedure createFlowItemsWithoutOrder(session_id in number, flow_item_2_interaction_item in number,
        estimated_duration in number, flow_item_state in number, serial_processing in number,
        not_started_list_value in number);

    function collectFisForRescheduling (ef_id in number) RETURN arrayofnumbers;

end pkgomil;
/
