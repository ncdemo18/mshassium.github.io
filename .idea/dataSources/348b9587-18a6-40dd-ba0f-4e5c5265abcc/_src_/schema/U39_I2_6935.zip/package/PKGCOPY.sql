CREATE PACKAGE PKGCOPY
AS
TYPE IDCollection IS  TABLE OF  NUMBER NOT NULL;
  Source_is_null             EXCEPTION;
  Dest_is_null               EXCEPTION;
  Source_equals_Dest         EXCEPTION;
  Incorrect_parameter_class  EXCEPTION;
  Wrong_project              EXCEPTION;
  Cant_find_obj_site         EXCEPTION;
  src_size_not_equ_dest_size EXCEPTION;
  p_is_null                  EXCEPTION;
  src_already_has_wip        EXCEPTION;

  pragma exception_init(src_already_has_wip, -20430);

  v_Transaction_ID VARCHAR2(32);
  v_SourceIDs IDCollection;
  v_OuterCableIDs IDCollection;
  v_NewIDs IDCollection;
  v_DestinationIDs IDCollection;
  allDestObjects IDCollection;

  ITEMS_DELIMITER                CHAR(1) := ';';
  reference_to_wip               NUMBER  := 8051258306013811226;
  is_wip_attr_id                 NUMBER  := 8053017825013732489;
  is_ref_mod_attr_id             NUMBER  := 9133201016213930903;
  USER_CLASS_ID                  NUMBER  := 1;
  GROUP_CLASS_ID                 NUMBER  := 2;
  CONTAINER_CLASS_ID             NUMBER  := 173;
  SITE_CLASS_ID                  NUMBER  := 300;
  FLOOR_CLASS_ID                 NUMBER  := 300;
  DEVICE_CLASS_ID                NUMBER  := 301;
  ROUTER_CLASS_ID                NUMBER  := 301;
  SWITCH_CLASS_ID                NUMBER  := 301;
  CABLE_CLASS_ID                 NUMBER  := 174;
  THICK_CABLE_CLASS_ID           NUMBER  := 174;
  THIN_CABLE_CLASS_ID            NUMBER  := 174;
  OUTER_CABLE_CLASS_ID           NUMBER  := 175;
  PORT_CLASS_ID                  NUMBER  := 600;
  SLOT_CLASS_ID                  NUMBER  := 601;
  CONNECTOR_CLASS_ID             NUMBER  := 176;
  PROJECT_CLASS_ID               NUMBER  := 7;
  REPOSITORY_PROJECT_CLASS_ID    NUMBER  := 72;
  INVENTORY_PROJECT_CLASS_ID     NUMBER  := 71;
  TEMPLATE_PROJECT_CLASS_ID      NUMBER  := 710;
  WORKFLOW_PROJECT_CLASS_ID      NUMBER  := 90001072;
  ASSIGNMENT_PROJECT_CLASS_ID    NUMBER  := 280320034;
  PRODUCT_PROJECT_CLASS_ID       NUMBER  := 99100100;
  CIRCUIT_CLASS_ID               NUMBER  := 8;
  PATH_ELEMENT_CLASS_ID          NUMBER  := 9;
  OM_TASK_PROJECT_CLASS_ID       NUMBER  := 740001;
  PLUGIN_TYPE_ID                 NUMBER  := 116328;
  PARENT_SLOT_ATTR_ID            NUMBER  := 11;
  ACCESS_POINT_ATTR_ID           NUMBER  := 12;
  PATH_ELEMENT_CARRIER_ATTR_ID   NUMBER  := 14;
  RESOURCES_ATTR_ID              NUMBER  := 15;
  OCCUPIED_SUBCONNECTORS_ATTR_ID NUMBER  := 16;
  CREATED_BY_ATTR_ID             NUMBER  := 61;
  CREATED_WHEN_ATTR_ID           NUMBER  := 62;
  MODIFY_BY_ATTR_ID              NUMBER  := 63;
  MODIFY_WHEN_ATTR_ID            NUMBER  := 64;
  ATTR_ACCESS_NORMAL             NUMBER  := 0;
  DEVICE_CABLE_CONNECTION_TYPE   NUMBER  := 0;
  CABLE_DEVICE_CONNECTION_TYPE   NUMBER  := 0;
  INNER_CABLE_CONNECTION_TYPE    NUMBER  := 1;
  INNER_DEVICE_CONNECTION_TYPE   NUMBER  := 2;
  CONNECTOR_PORT_CONNECTION_TYPE NUMBER  := 3;
  PORT_PORT_CONNECTION_TYPE      NUMBER  := 4;
  PATH_ELEMENT_CONNECTION_TYPE   NUMBER  := 5;
  DEVICE_DEVICE_CONNECTION_TYPE  NUMBER  := 6;
  CABLE_CABLE_CONNECTION_TYPE    NUMBER  := 7;
  SLOT_SLOT_CONNECTION_TYPE      NUMBER  := 8;
  OSP_CABLE_OBJECT_TYPE_ID       NUMBER  := 18116;

  FUNCTION findID(
      p_Object_ID NUMBER)
    RETURN NUMBER;

  FUNCTION findRef(
      attrid                  NUMBER,
      refer                   NUMBER,
      p_PointRefsToNewObjects INTEGER)
    RETURN NUMBER;

  FUNCTION isAttrBind(
      attrid                  NUMBER,
      typeid                  NUMBER,
      destattrschema          NUMBER)
    RETURN NUMBER;

  FUNCTION isIdInCollection(
      id                      NUMBER,
      coll                    IDCollection)
    RETURN BOOLEAN;

  FUNCTION getContainer(
      cable                   NUMBER,
      container               NUMBER,
      destination             NUMBER,
      type_id                 NUMBER,
      direct_copy             NUMBER,
      TransactionID           VARCHAR2)
    RETURN NUMBER;

  FUNCTION getSourceID(
      source                  NUMBER,
      object_source           NUMBER,
      p_CopyFromRepository    INTEGER)
    RETURN NUMBER;

  FUNCTION getCopyForProjectSourceID(
      source                  NUMBER,
      object_source           NUMBER,
      prjClass                NUMBER)
    RETURN NUMBER;

  /*
  Copies object given by p_Source to p_Destination and returns id of created object as ret.
  p_CopyWithLinks - copy cables connected to device.
  PointRefsToNewObjects - if 1 then references between source objects are changed to references between copies.
  */
  PROCEDURE copyObjects(
      p_Source                IN  VARCHAR2,
      p_Destination           IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      p_CopyWithLinks         IN  INTEGER,
      ret                     OUT VARCHAR2);

  --deprecated
  PROCEDURE copyObjects(
      p_Source                IN  VARCHAR2,
      p_Destination           IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      p_CopyWithLinks         IN  INTEGER,
      ret                     OUT VARCHAR2,
      retCol                  OUT ARRAYOFSTRINGS);

  PROCEDURE copyObjectsSimple(
      p_Source                IN  VARCHAR2,
      p_Destination           IN  VARCHAR2,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT VARCHAR2);

  PROCEDURE copyObjectsSimple(
      p_Source                IN  VARCHAR2,
      p_Destination           IN  VARCHAR2,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT VARCHAR2,
      retCol                  OUT ARRAYOFSTRINGS);

  PROCEDURE copyProjects(
      p_Source                IN  VARCHAR2,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT VARCHAR2);

  PROCEDURE copyProjects(
      p_Source                IN  VARCHAR2,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT VARCHAR2,
      retCol                  OUT ARRAYOFSTRINGS);

  PROCEDURE replaceCable(
      sourceID                IN  NUMBER,
      catalogObjectID         IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT NUMBER);

  PROCEDURE copyCircuits(
      p_Source                IN  VARCHAR2,
      p_DestProject           IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT VARCHAR2);

  PROCEDURE copyCircuits(
      p_Source                IN  VARCHAR2,
      p_DestProject           IN  NUMBER,
      p_DestObject            IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT VARCHAR2);

  PROCEDURE copyCircuits(
      p_Source                IN  VARCHAR2,
      p_DestProject           IN  NUMBER,
      p_DestObject            IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      ret                     OUT VARCHAR2,
      retCol                  OUT ARRAYOFSTRINGS);

  PROCEDURE moveObject(
      p_Source                IN  NUMBER,
      p_Destination           IN  NUMBER,
      ret                     OUT VARCHAR2);

  PROCEDURE moveObject(
      p_Source                IN  NUMBER,
      p_Destination           IN  NUMBER,
      ret                     OUT CLOB,
      retCol                  OUT ARRAYOFSTRINGS);

  PROCEDURE moveObject(
      p_Source                IN  NUMBER,
      p_Destination           IN  NUMBER,
      ret                     OUT CLOB);

  /*
  This method works same as simple_copy(source_id, destination_id, new_id, set_source_id=1)
  */
  PROCEDURE SIMPLE_COPY(
      source_id               IN  NUMBER,
      destination_id          IN  NUMBER,
      new_id                  OUT NUMBER);

  /*
  Copies object given by source_id to destination_id and returns id of created object as new_id.
  If set_source_id = 1 then source_object_id of all created objects are set to object_id of their source objects, if it is 0 then source_object_id is set to null.
  Objects hierarchy under source_id are also copied.
  References between source objects are changed to references between copies.
  References to objects not belonging to hierarchy are copied.
  */
  PROCEDURE cox_simple_copy (
    source_id        IN       NUMBER,
    destination_id   IN       NUMBER,
    new_id           IN      NUMBER
  );

  PROCEDURE SIMPLE_COPY(
      source_id               IN  NUMBER,
      destination_id          IN  NUMBER,
      new_id                  OUT NUMBER,
      set_source_id           IN  NUMBER);

  PROCEDURE SIMPLE_COPY(
      source_id               IN  NUMBER,
      destination_id          IN  NUMBER,
      new_id                  OUT NUMBER,
      set_source_id           IN  NUMBER,
      retCol                  OUT ARRAYOFSTRINGS);

  PROCEDURE fillDefaultValues(
      newobjectid             IN NUMBER);

  PROCEDURE replaceRefAndConn(
      source_id               IN NUMBER,
      destination_id          IN NUMBER );

  PROCEDURE replacePortsRefs(
      source_id               IN NUMBER,
      destination_id          IN NUMBER );

  PROCEDURE replaceConnectorsConns(
      source_id               IN NUMBER,
      destination_id          IN NUMBER );

  PROCEDURE occupyNextResources(
      circuit_ids             IN VARCHAR2 );

  FUNCTION getSimilarAvailableResource(
      resource_id             IN NUMBER )
    RETURN NUMBER;

  FUNCTION getSimilarAvailablePort(
      port_id                 IN NUMBER,
      device_id               IN NUMBER,
      used_ports              IN VARCHAR2 )
    RETURN NUMBER;

  FUNCTION getSimilarAvailableConnector(
      connector_id            IN NUMBER,
      device_id               IN NUMBER,
      used_connectors         IN VARCHAR2 )
    RETURN NUMBER;

  -------------------------------------------------------------------------------
  -- Copy objects p_numcopies times (deprecated)
  --
  PROCEDURE bulkCopy(
      p_source                IN  VARCHAR2,
      p_destination           IN  NUMBER,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_copywithlinks         IN  INTEGER,
      p_numcopies             IN  INTEGER,
      result                  OUT VARCHAR2 );

  PROCEDURE bulkCopy(
      p_source                IN  VARCHAR2,
      p_destination           IN  NUMBER,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_copywithlinks         IN  INTEGER,
      p_numcopies             IN  INTEGER,
      result                  OUT VARCHAR2,
      resultCol               OUT ARRAYOFSTRINGS );

  -------------------------------------------------------------------------------
  -- Copy objects p_numcopies times
  --
  PROCEDURE bulkCopy(
      p_source                IN  ARRAYOFSTRINGS,
      p_destination           IN  NUMBER,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_copywithlinks         IN  INTEGER,
      p_numcopies             IN  INTEGER,
      result                  OUT VARCHAR2 );

  PROCEDURE bulkCopy(
      p_source                IN  ARRAYOFSTRINGS,
      p_destination           IN  NUMBER,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_copywithlinks         IN  INTEGER,
      p_numcopies             IN  INTEGER,
      result                  OUT VARCHAR2,
      resultCol               OUT ARRAYOFSTRINGS );

  -------------------------------------------------------------------------------
  -- Copy objects for multiply destination
  --
  PROCEDURE bulkCopy(
      p_source                IN  VARCHAR2,
      p_destination           IN  VARCHAR2,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_copywithlinks         IN  INTEGER,
      result                  OUT VARCHAR2 );
  -------------------------------------------------------------------------------

  PROCEDURE copy_history(
      i_source_ids            IN VARCHAR2,
      i_dest_ids              IN VARCHAR2);

  PROCEDURE move_history(
      i_source_ids            IN VARCHAR2,
      i_dest_ids              IN VARCHAR2);

  PROCEDURE copyobjectforsite(
      sourceid                IN NUMBER,
      destination             IN NUMBER,
      p_copyfromrepository    IN INTEGER,
      transactionid              VARCHAR2,
      is_hierarchical         IN INTEGER );

  PROCEDURE copyobjects(
      p_source                IN VARCHAR2,
      p_destination           IN NUMBER,
      p_username              IN VARCHAR2,
      p_eventdate             IN VARCHAR2,
      p_copywithlinks         IN INTEGER,
      p_copyfromrepository    IN INTEGER,
      p_pointrefstonewobjects IN INTEGER,
      p_is_hierarchical       IN INTEGER,
      p_is_delete_temp_table  IN INTEGER,
      ret OUT VARCHAR2 );

  FUNCTION copy_wip_object(
      p_wip_container_id      IN NUMBER,
      p_source                IN VARCHAR2,
      p_destination           IN VARCHAR2,
      p_username              IN VARCHAR2,
      p_eventdate             IN VARCHAR2,
      p_is_hierarchical       IN INTEGER)
    RETURN VARCHAR2;

  FUNCTION is_parent_schema(
      destattrschema          IN NUMBER,
      fromattrschema          IN NUMBER)
    RETURN BOOLEAN;

  FUNCTION copy_wip_object(
      p_wip_container_id      IN  NUMBER,
      p_source                IN  VARCHAR2,
      p_destination           IN  VARCHAR2,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_is_hierarchical       IN  INTEGER,
      retCol                  OUT ARRAYOFSTRINGS)
    RETURN VARCHAR2;

  FUNCTION copy_wip_object(
      p_wip_container_id      IN  NUMBER,
      p_source                IN  VARCHAR2,
      p_destination           IN  VARCHAR2,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_is_hierarchical       IN  INTEGER,
      p_is_ref_mod            IN  VARCHAR2,
      retCol                  OUT ARRAYOFSTRINGS)
    RETURN VARCHAR2;

  PROCEDURE copyObjects(
      p_Source                IN  ARRAYOFNUMBERS,
      p_Destination           IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      p_CopyWithLinks         IN  INTEGER,
      ret                     OUT ARRAYOFNUMBERS,
      retCol                  OUT ARRAYOFSTRINGS,
      error                   OUT VARCHAR2 );

  PROCEDURE copyobjects(
      p_source                IN  ARRAYOFNUMBERS,
      p_destination           IN  NUMBER,
      p_username              IN  VARCHAR2,
      p_eventdate             IN  VARCHAR2,
      p_copywithlinks         IN  INTEGER,
      p_pointrefstonewobjects IN  INTEGER,
      p_is_hierarchical       IN  INTEGER,
      ret                     OUT ARRAYOFNUMBERS,
      retCol                  OUT ARRAYOFSTRINGS,
      error                   OUT VARCHAR2 );

  PROCEDURE copyObjects(
      p_Source                IN  ARRAYOFNUMBERS,
      p_Destination           IN  NUMBER,
      p_UserName              IN  VARCHAR2,
      p_EventDate             IN  VARCHAR2,
      p_CopyWithLinks         IN  INTEGER,
      p_NotCopiedAttrs        IN  ARRAYOFNUMBERS,
      ret                     OUT ARRAYOFNUMBERS,
      retCol                  OUT ARRAYOFSTRINGS,
      error                   OUT VARCHAR2 );
END;
/
