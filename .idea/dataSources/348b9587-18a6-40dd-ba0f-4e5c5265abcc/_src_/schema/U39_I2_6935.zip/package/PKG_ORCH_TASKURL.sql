CREATE PACKAGE PKG_ORCH_TASKURL
AS
  FUNCTION getTaskURLbyID(v_task_id nc_po_tasks.task_id%TYPE)
  RETURN VARCHAR2;
  FUNCTION getTaskURLbyID(v_task_id nc_po_tasks.task_id%TYPE, v_language_id nc_nls_po_tasks.language_id%TYPE)
  RETURN VARCHAR2;
END PKG_ORCH_TASKURL;
/
