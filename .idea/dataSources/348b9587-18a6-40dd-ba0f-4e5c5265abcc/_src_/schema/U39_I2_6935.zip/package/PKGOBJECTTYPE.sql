CREATE PACKAGE pkgObjectType
AS

	SITE_TYPE CONSTANT NUMBER(3) := 300;

	TYPE object_type_id_rec IS RECORD (
		object_type_id nc_object_types.object_type_id%TYPE
	);

	TYPE object_type_cur_id IS REF CURSOR RETURN object_type_id_rec;

	PROCEDURE ejbRemove(
		objectTypeID IN nc_object_types.object_type_id%TYPE
	);

	PROCEDURE doStore(
		objectTypeID nc_object_types.object_type_id%TYPE,
		parentID nc_object_types.parent_id%TYPE,
		pictureID nc_object_types.picture_id%TYPE,
		aName nc_object_types.name%TYPE,
		aDescription nc_object_types.description%TYPE,
		aIsClass nc_object_types.isclass%TYPE,
		aIsSystem nc_object_types.issystem%TYPE,
		iconID nc_object_types.icon_id%TYPE,
		aAlias nc_object_types.alias%TYPE,
		aFlags nc_object_types.flags%TYPE,
		aProperties nc_object_types.properties%TYPE
	);

	FUNCTION getObjectClass(
		objectTypeID IN nc_object_types.object_type_id%TYPE
	) RETURN nc_object_types.object_type_id%TYPE;

	FUNCTION getPicture(
		objectTypeID IN nc_object_types.object_type_id%TYPE
	) RETURN nc_object_types.picture_id%TYPE;

	FUNCTION definePriority(
		accessType IN nc_attributes.attr_access_type%TYPE,
		flags IN nc_attributes.flags%TYPE,
		isdisplayed IN nc_attr_object_types.isdisplayed%TYPE
	) RETURN nc_params.priority%TYPE;

END pkgObjectType;
/
