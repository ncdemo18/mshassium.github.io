CREATE PACKAGE pkg_dextr_logger AS

  PROCEDURE LOG(log_level IN VARCHAR2, message IN VARCHAR2);
  PROCEDURE FLUSH;
  PROCEDURE CLEAR;

END pkg_dextr_logger;
/
