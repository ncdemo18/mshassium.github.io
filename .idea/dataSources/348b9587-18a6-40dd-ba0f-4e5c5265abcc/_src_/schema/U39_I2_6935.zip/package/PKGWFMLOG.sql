CREATE package pkgwfmlog is

  -- Author  : KONNOV
  -- Created : 06.04.2010 10:56:22
  -- Purpose : For WFM DB logging

  TYPE collection IS TABLE OF CLOB INDEX BY BINARY_INTEGER;

  -- Public function and procedure declarations
  PROCEDURE log(message CLOB);

  FUNCTION tokenize(p_str IN CLOB, p_delim IN VARCHAR2) RETURN collection;

  --Functions for WFM DB log report
  function getURL(str in varchar2) return varchar2;
  function getUrlResult(p_code in varchar2, str in clob) return clob;

end pkgwfmlog;
/
