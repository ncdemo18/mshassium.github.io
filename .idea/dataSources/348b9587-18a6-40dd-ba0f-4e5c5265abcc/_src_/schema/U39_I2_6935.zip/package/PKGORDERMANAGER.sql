CREATE package pkgOrderManager AS

    FUNCTION createObject(obj_name NC_OBJECTS.name%TYPE,
                          obj_description NC_OBJECTS.description%TYPE,
                          obj_type NC_OBJECT_TYPES.object_type_id%TYPE,
                          obj_parent NC_OBJECTS.parent_id%TYPE)
        RETURN NC_OBJECTS.OBJECT_ID%TYPE;

    PROCEDURE populateAttrs(om_session_id nc_objects.object_id%TYPE);

    PROCEDURE copyParams(om_session_id nc_objects.object_id%TYPE,
                         copyNameAndDescr NUMBER);

    FUNCTION createObjects(om_session_id nc_objects.object_id%TYPE)
        RETURN TABLEOF2NUMBERS;

    PROCEDURE cleanup(om_session_id nc_objects.object_id%TYPE);

    PROCEDURE fillParameters(om_session_id nc_objects.object_id%TYPE);

END;
/
