CREATE package pkg_ncdopl_tbl_metadata is

  /*
    returns array of strings with the following structure:
    [col_name1, attr_id1, attr_name1, col_type1, ordernum1, ... , col_nameN, attr_idN, attr_nameN, col_typeN, ordernumN]
  */
  function   preview_table(schema_id       number,
                           object_type_id  number,
                           attr_ids        arrayofnumbers,
                           schema_ids      arrayofnumbers,
                           object_type_ids arrayofnumbers,
                           attr_id_then_col_name arrayofstrings) return arrayofstrings;

end pkg_ncdopl_tbl_metadata;
/
