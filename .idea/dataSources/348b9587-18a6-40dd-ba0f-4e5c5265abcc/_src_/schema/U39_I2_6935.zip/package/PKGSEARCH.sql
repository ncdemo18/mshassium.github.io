CREATE package pkgsearch as

  /*----------------------------------------------------------------------------
  NAME
    convertAll
  FUNCTION
    Converts all Search profiles in system from their current version to final
    version
  PARAMETERS
    replaceProfiles (IN) - if TRUE then profiles will be replaced by their elder
                           analogues if necessary
  ----------------------------------------------------------------------------*/
  procedure convertall(replaceprofiles in boolean default false);

  /*----------------------------------------------------------------------------
  NAME
    convertProfile()
  FUNCTION
    Converts desired profile from current version (7.0 and higher) to the
    final version defined by FINAL_VERSION constant
  PARAMETERS
    profileId (IN) - nc_object_id of converting Search profile
  NOTES
  ----------------------------------------------------------------------------*/
  procedure convertprofile(profileid in varchar2);

  /*--------------------------------------------------------------------------
   NAME
     setVersionParameter
   PROCEDURE
     Add version parameter to search profile
   NOTES
     Used in procedure of importing profile
  -------------------------------------------------------------------------*/
  procedure setversionparameter;

  /*----------------------------------------------------------------------------
  NAME
    getObjectPath()
  FUNCTION
    language_id of specific locale in nc_nls_object_types
  PARAMETERS
    id (IN) - nc_object_id of any object
  NOTES
  ----------------------------------------------------------------------------*/
  function getobjectpath(id in varchar2) return varchar2;

  /*----------------------------------------------------------------------------
    NAME
      flag_at()
    FUNCTION
      Calculates and returns attribute flag in specified position. Position
      defines attribute property (ex: hidden, required, calculable and etc.)
    PARAMETERS
      attribute_id (IN) - ID of attribute for which flag should be checked
      idx (IN) - index of flag's bit which represents appropriate attribute
      property
  ----------------------------------------------------------------------------*/
  function flag_at(attribute_id in integer, idx in number) return varchar2;

  /*----------------------------------------------------------------------------
  NAME
    getObjectPath()
  FUNCTION
    Calculates Object Path for specified object
  PARAMETERS
    id (IN) - nc_object_id of any object
    lang_id - language_id of specific locale in nc_nls_object_types
  NOTES
  ----------------------------------------------------------------------------*/
  function getobjectpath(obj_id  in number, lang_id in number) return varchar2;

end pkgsearch;
/
