CREATE package pkgnwpl
is
   subtype number20 is nc_objects.object_id%type;

   type dates is table of date
      index by binary_integer;

/*
 * returns Actual Activation date of circuit PE
 */
   function get_actual_act_date (obj_id in number20)
      return date;

/*
 * returns Actual Disconnection date of circuit PE
 */
   function get_actual_disc_date (obj_id in number20)
      return date;

/*
 * returns '1' if number of objects, referencing object 'refer' by attr_id 'at_id'
 * within period [act_date; disc_date] of object 'obj_id' is smaller than n, and
 * '0' otherwise
*/
   function is_use_count_less (
      obj_id   in   number20,
      at_id    in   number20,
      refer    in   number20,
      n             int
   )
      return int;

/*
 * returns number of objects, referencing object 'reference' by attr_id 'at_id'
 * within date period [act_date;disc_date]
*/
   function get_use_count (
      act_date    in   date,
      disc_date   in   date,
      at_id       in   number20,
      refer       in   number20
   )
      return int;

/*
 * returns number of objects, referencing object 'reference' by attr_id 'at_id'
 * within life period [act_date;disc_date] of object 'obj_id'
*/
   function get_use_count_by_obj_id (
      obj_id   in   number20,
      at_id    in   number20,
      refer    in   number20
   )
      return int;

/*
 * fromats given string to date according specified mask
 * if sting is not an appropriate one, returns null
*/

function str_to_date(str varchar2, mask varchar2)
    return date;

--=========Functions for channel ocupation check functions============--
/*
* main function. Returns object_id of most up object, which will change its status
* returns -1 if no object will change its status
* NOTE: to find out, which status it will change to, it's necessary to use st_changes_to_piu variable
*     if st_changes_to_piu==true, then status will be changed: IU->PIU. Overwise: IU, PIU->Available
*/
   function get_last_changed_channel (obj_id in number20)
      return number20;

/*
 * returns new Usage Status of obj_id. Returns -1 if no changes need to be made
 * Should be used with get_last_changed_channel function, which finds this obj_id
*/
   function get_new_status (obj_id in number20)
      return number20;
end;
/
