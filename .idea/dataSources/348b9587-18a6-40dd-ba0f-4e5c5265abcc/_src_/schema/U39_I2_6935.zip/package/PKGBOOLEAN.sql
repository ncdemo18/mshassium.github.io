CREATE PACKAGE PKGBOOLEAN is
    FUNCTION BITOR(left IN INTEGER, right IN INTEGER) RETURN INTEGER;
    FUNCTION BITXOR(left IN INTEGER, right IN INTEGER) RETURN INTEGER;
    FUNCTION setBit(data IN INTEGER, bitNumber IN INTEGER) RETURN INTEGER;
    FUNCTION togleBit(data IN INTEGER, bitNumber IN INTEGER) RETURN INTEGER;
    FUNCTION clearBit(data IN INTEGER, bitNumber IN INTEGER) RETURN INTEGER;

--*** DMSM0410 [29.04.10][Unroll metamodel] Start
    FUNCTION overlayBits(source IN INTEGER, overlay IN INTEGER, mask IN INTEGER) RETURN INTEGER;
--*** DMSM0410 [29.04.10][Unroll metamodel] End

-- EVLA1010 [21.01.11] [Not correct import 'priority' from references] Start
    FUNCTION bitNumberToInt(bitNumber IN INTEGER) RETURN INTEGER;
-- EVLA1010 [21.01.11] [Not correct import 'priority' from references] Start

end PKGBOOLEAN;
/
