CREATE package pkg_baip_rbm_facade as

  procedure deleteProductFamily(object_id in number);

  procedure deleteProduct(object_id in number);

  procedure deletePaymentPlan(payment_plan_id in number, catalogue_id in number);

  procedure deleteFilter(filter_id in number, catalogue_id in number);

  procedure deleteLateFeeRule(p_catalogue_change_id in number, p_late_fee_rule_id in number);

  procedure deleteLateFeeCreditClass(p_catalogue_change_id in number, p_late_fee_rule_id in number, p_credit_class_id in number);

  procedure deleteLateFeeMarket(p_catalogue_change_id in number, p_late_fee_rule_id in number, p_market_segment_id in number);

  function deleteBillingSpecification(p_billing_specification_id in nc_objects.object_id%type) return varchar2;

end pkg_baip_rbm_facade;
/
