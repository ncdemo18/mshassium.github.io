CREATE PACKAGE PKG_ASSET_MANAGEMENT AS

  FUNCTION getCurrentUserWhId(userId NUMBER) RETURN NUMBER;
  FUNCTION getLocToFromWhForMo(objectId NUMBER
                          , userId NUMBER, isFrom NUMBER) RETURN ARRAYOFNUMBERS;
  FUNCTION getItemModels(moveOrderId NUMBER) RETURN ARRAYOFNUMBERS;

  procedure lockStockItem(objectId number);
  function getAvailableAndLockStockItems(
    warehouseId number, modelId number, requestedQty int) return number;

END PKG_ASSET_MANAGEMENT;
/
