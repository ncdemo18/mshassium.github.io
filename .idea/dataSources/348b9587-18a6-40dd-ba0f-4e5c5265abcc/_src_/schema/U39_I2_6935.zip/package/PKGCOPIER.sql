CREATE PACKAGE          "PKGCOPIER" 
AS

	TYPE ref_cur IS REF CURSOR;

	TYPE objidstable IS TABLE OF nc_objects.object_id%TYPE INDEX BY BINARY_INTEGER;

	PROCEDURE cleanUp;

	PROCEDURE addCollectionElement(
		id IN nc_objects.object_id%TYPE
	);

	PROCEDURE removeSystemUniqueParmsSimple;

	PROCEDURE removeProjectUniqueParmsSimple;

	PROCEDURE removeSiteUniqueParmsSimple(
		startobject IN nc_objects.object_id%TYPE
	);

	PROCEDURE removeUniqueParmsSimple(
		start_id IN nc_objects.object_id%TYPE
	);

	FUNCTION getDeviceCables(
		objectid IN nc_objects.object_id%TYPE
	) RETURN ref_cur;

END pkgCopier;




/
