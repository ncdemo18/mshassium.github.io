CREATE package pkgRIOF is

RESOURCE_ID_OF_MESSAGE_ATTR_ID constant number := 9135777170113379459;

procedure set_new_operation_message(spec_id number, name varchar2);

end pkgRIOF;
/
