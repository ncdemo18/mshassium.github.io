CREATE package BAM_QUE_NC_OMD_ORDERS is

	function continue_transport(transport_from_log in integer, last_record in out number, max_records in number, skip_dispatcher_errors in boolean, success_records out number, fail_records out number) return integer;

end BAM_QUE_NC_OMD_ORDERS;
/
