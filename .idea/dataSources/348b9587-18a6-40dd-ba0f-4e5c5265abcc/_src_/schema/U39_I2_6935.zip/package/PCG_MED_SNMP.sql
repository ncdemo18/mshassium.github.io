CREATE PACKAGE pcg_med_snmp IS
	-- return OID of SNMP Node with pointed ID as word sequence
    function get_char_oid (node_object_id IN NUMBER)  RETURN VARCHAR2;
   	-- return OID of SNMP Node with pointed ID as number sequence
    function get_digit_oid (node_object_id IN NUMBER) RETURN VARCHAR2;
    -- find SNMP node by full OID in any view. node_parent_id shows ID of SNMP Root
    -- if node_parent_id is null this id will be looked for in nc_directory by key 'netcracker.parsing.snmp_mib_root_id'
    function get_snmp_node (full_oid in varchar2, node_parent_id in number) RETURN number;
    -- search SNMP Node as child of setted parent by part OID (digit or character)
    function get_snmp_node_by_part (part_oid in varchar2, node_parent_id in number)  RETURN number;
    -- return OID of setted node in character view. root_id can be null
    function to_char_oid(full_oid in varchar2, root_id in number) RETURN VARCHAR2;
    -- return OID of setted node in digit view. root_id can be null
    FUNCTION to_digit_oid(full_oid in varchar2, root_id in number) RETURN VARCHAR2;
    -- correctly removes mib with setted ID
    procedure remove_mib(mib_id in number);
end pcg_med_snmp;
/
