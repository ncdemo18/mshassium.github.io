CREATE PACKAGE PKG_PLM_CR_UTILS AS
/******************************************************************************
   NAME:       PKG_PLM_CR_UTILS
******************************************************************************/
  v_product_offering_type nc_object_types.object_type_id%type := 9125737315713245976 /*Product Offering*/;
  v_price_value_type nc_object_types.object_type_id%type := 9132192878413892886 /*Price Value*/;

  PROCEDURE set_cr_exception_occurred_true (cr_object_id number);
  FUNCTION has_exception (cr_object_id number) RETURN NUMBER;
  FUNCTION get_modifications_count(p_cr_id in nc_objects.object_id%type) RETURN NUMBER;
  FUNCTION get_external_status(p_object_id in nc_objects.object_id%type, p_language_id in nc_nls_object_types.language_id%type) RETURN VARCHAR2;
  FUNCTION get_modification_version(p_object_id in nc_objects.object_id%type) RETURN VARCHAR2;
  FUNCTION get_object_type_localized(p_object_type_id in nc_object_types.object_type_id%type, p_language_id in nc_nls_object_types.language_id%type) RETURN VARCHAR2;
  FUNCTION get_attr_name_localized(p_attr_id in nc_attributes.attr_id%type, p_language_id in nc_nls_attributes.language_id%type) RETURN VARCHAR2;
  PROCEDURE exclude_modifs(p_ids in arrayofstrings);



END PKG_PLM_CR_UTILS;
/
