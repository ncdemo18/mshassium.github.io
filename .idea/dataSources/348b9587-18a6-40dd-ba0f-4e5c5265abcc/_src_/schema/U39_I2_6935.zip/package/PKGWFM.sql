CREATE package pkgwfm is

  function get_wi_structure_rgs(wi_structure WFM_WORK_ITEM_STRUCTURES, work_schedule_id number) return WFM_WI_STRUCTURE_RGS;

  function get_wi_structure_capacity(wi_rgs WFM_WI_STRUCTURE_RGS) return wfm_work_item_capacities;

  function get_work_item_resource_groups(work_items arrayofnumbers, work_schedule_id number) return wfm_work_item_resource_groups;

  function get_work_units(wis wfm_work_item_capacities, exp_start date, exp_end date, enable_overbooking int, inactive_timeslots_on INT) return wfm_work_units;

  function get_work_schedules(wi_cap wfm_work_item_capacities, exp_start date, exp_end date, grid_used int) return wfm_work_schedules;

  --scheduling_option: ASAP = -1, ALL = 0, ALAP = 1
 function expose(capacities wfm_work_item_capacities, expose_start date, expose_end date,
                  enable_overbooking int, grid_used int, absolute_grid int, inactive_timeslots_on INT, scheduling_option int,
                  final_result_handler_func varchar2, strict_bounds int, work_periods wfm_table_of_dates, cutTimeslotsRGExpose INT) return wfm_work_items;

  --scheduling_option: ASAP = -1, ALL = 0, ALAP = 1
 function expose_by_work_item(expose_parameters WFM_EXPOSE_PARAMS) return wfm_work_items;

  function get_cells(wi_cap wfm_work_item_capacities, expose_start date, expose_end date, enable_overbooking int, grid_used int, absolute_grid int,
                     inactive_timeslots_on INT, final_result_handler_func varchar2, work_periods wfm_table_of_dates, cutTimeslotsRGExpose INT) return wfm_work_unit_cells;

  function check_work_order_dependency(work_order_id number) return int;

  function get_group_work_items(work_order_id number, scheduling_option int) return wfm_group_work_items;

  function get_all_dependenies(ids arrayofnumbers) return arrayofnumbers;

  function get_group_by_work_items_list(wi_list arrayofnumbers, scheduling_option int) return wfm_group_work_items;

  procedure booking_ix_by_id(booking_id number);

  procedure booking_ix_all;

  procedure booking_ix_by_wu_id(wu_id number);

  procedure booking_wu_ix_by_ts_id(ts_id number);

  procedure wu_ix_by_id(workunits_id number);

  procedure wu_ix_by_id_bulk(workunits arrayofnumbers);

  procedure wu_ix_all;

  procedure recreate_ix;

  function granulate(expose_from date,
                     expose_to DATE,
                     wu_from date,
                     wu_to date,
                     grid_used int,
                     absolute_grid int,
                     grid_gran number,
                     bookings wfm_bookings,
                     min_gran number,
                     ws_type number,
                     cut_timeslots INT) return wfm_cells;

  function grid_floor(which_date date, grid_from date, grid_gran number) return number;

  function grid_ceil(which_date date, grid_from date, grid_gran number) return number;

  function grid_to_date(grid_cell number, grid_from date, grid_gran number) return date;

  function grid_floor_to_date(which_date date, grid_from date, grid_gran number) return date;

  function grid_ceil_to_date(which_date date, grid_from date, grid_gran number) return date;

  function get_work_item_capacity(wi_rgs wfm_work_item_resource_groups) return wfm_work_item_capacities;

  function calculate_capacity(serving_area number, activity number, loc_type number, amount int) return number;

  FUNCTION get_skillset_leafs(skill_set_id NUMBER) RETURN arrayofnumbers;

  FUNCTION get_skillsets_tree(skill_set_id NUMBER) RETURN arrayofnumbers;

  FUNCTION get_rg_skillsets_tree(skill_set_id NUMBER) RETURN arrayofnumbers;

  procedure bulk_merge_timeslots(timeslot_ids in wfm_timeslots);

  function from_tz(p_date date, employee_id number) return date;

function get_tz_from_mapping(tz_name varchar2) return varchar2;

function getAllowedSeverityLevels(severity number) return arrayofnumbers;

function get_emp_work_periods_wc_only(emp_id number, date_from date, date_to date) RETURN TABLEOF2DATES;

function get_emp_working_periods(emp_id number, date_from date, date_to date, severity number  default null, ignore_employee_activities arrayofnumbers default null)
RETURN TABLEOF2DATES;

/*Return NC_User time zone*/
FUNCTION get_nc_user_timezone(user_id NUMBER) RETURN VARCHAR;

/*Return NC_User time in NC_user Time*/
FUNCTION get_nc_user_time(user_id NUMBER) RETURN DATE;

/*Return calculable attribute date value in timezone t_zone for object obj_id*/
FUNCTION calc_attr_date_in_tz(obj_id  NUMBER, attr_id NUMBER, t_zone varchar) RETURN DATE;

/*Return calculable attribute date value in DBtimezone t_zone for object obj_id*/
FUNCTION calc_attr_date_in_dbtz(obj_id  NUMBER, attr_id NUMBER) RETURN DATE;

/*Return ddate date at time zone tz with time ttime*/
FUNCTION date_in_tz_with_time(ddate DATE, ttime varchar, tz varchar) return DATE;

/*Return ddate date at time zone tz*/
FUNCTION date_in_tz(ddate DATE,  tz varchar, force number default 0) return DATE;

/*Return Employee ID for Position ID*/
function get_employee_by_position(position_id number) RETURN number;

/*Return Employee ID by NC User ID*/
function get_nc_user_employee(user_id number) RETURN arrayofnumbers;

/*Return substraction of 2 dates in seconds*/
function date_sub_to_seconds(date_from date, date_to date) return number;

/*Return subtraction of dates in seconds for table of 2 dates*/
function date_sub_to_seconds(input_dates TABLEOF2DATES) return number;

/*Return 2 dates which contains interval [interval_start, interval_end]
if start < interval_start return interval_start as first date,
if end < interval_end return interval_end as second date*/
function date_in_interval(date_from date, date_to date, interval_start date, interval_end date) return pairofdates;

/*Return substraction of 2 dates in seconds in timezone*/
function date_sub_in_interval(date_from date, date_to date, interval_start date, interval_end date) return number;

/*Return beautiful representation of seconds in format 'HH24:MI:SS'*/
function seconds_to_HH_MM_SS(date_in_seconds number) return varchar;

/*Return reducing and extending employee activity in time interval [interval_start, interval_end] by type: =1-Extending, else-Reducing, null - both
if From and To dates are not belongs to [interval_start, interval_end] then return null values*/
function get_employee_activities(employee_id number, interval_start date, interval_end date, extending_or_reducing number default null) return TABLEOF2DATES;

/*Return reducing and extending employee activity in time interval [interval_start, interval_end] by type: =1-Extending, else-Reducing, null - both
if From and To dates are not belongs to [interval_start, interval_end] then return values will not be return*/
function get_employee_activities_nn(employee_id number, interval_start date, interval_end date, extending_or_reducing number default null) return TABLEOF2DATES;

/* Deprecated. Moved in WOM. Returns assignments ids with corresponding concurrency values on the given position in the given time interval */
function get_concurrency_values(position number, assignment_to_ignore number default 0,
  start_date date default null, end_date date default null)
  return wfm_assignments_concurrency;
FUNCTION request_lock (lock_name IN VARCHAR2, lock_wait_time IN NUMBER) RETURN VARCHAR2;
PROCEDURE release_lock (lock_handle IN VARCHAR2);

function get_rg_working_periods_bulk(work_schedules_id ARRAYOFNUMBERS,
                                     s_date            date default null,
                                     e_date            date default null,
                                     severity number default null, ignore_employee_activities arrayofnumbers default null
) return rg_wt_dates;

end pkgwfm;
/
