CREATE PACKAGE PKG_OPF as

    /* The function returns collection of InflightStrategyLinks for InflightStrategyManager */
    function inflight_link(old_list arrayofnumbers, new_list arrayofnumbers, new_interactions arrayofnumbers) return order_array pipelined;

end PKG_OPF;
/
