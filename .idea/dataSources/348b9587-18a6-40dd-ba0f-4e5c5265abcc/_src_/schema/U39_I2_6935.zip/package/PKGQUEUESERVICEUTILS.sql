CREATE package pkgQueueServiceUtils
as
FUNCTION is_bind(given_attr_id NUMBER, given_ot_id NUMBER, given_attr_schema_id NUMBER) RETURN PLS_INTEGER;
FUNCTION parseNumber(input VARCHAR2,defaultValue NUMBER:=0) RETURN NUMBER;
FUNCTION normalize_name(name VARCHAR2) RETURN VARCHAR2;
end pkgQueueServiceUtils;
/
