CREATE PACKAGE pcg_med_dataflow IS
    FUNCTION get_session_id RETURN number;
    FUNCTION set_session_id(new_session_id in number) RETURN number;
END pcg_med_dataflow;
/
