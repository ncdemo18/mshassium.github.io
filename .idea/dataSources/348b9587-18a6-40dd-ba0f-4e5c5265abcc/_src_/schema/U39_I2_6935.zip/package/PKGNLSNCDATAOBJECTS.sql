CREATE PACKAGE pkgNlsNCDataObjects AS

  PROCEDURE mergeNlsObjects(fullMergeNlsObjects        NC_NLS_OBJECTS_TABLE_TYPE,
                            nameMergeNlsObjects        NC_NLS_OBJECTS_TABLE_TYPE,
                            descriptionMergeNlsObjects NC_NLS_OBJECTS_TABLE_TYPE,
                            deleteNlsObjects           NC_NLS_OBJECTS_TABLE_TYPE);

END pkgNlsNCDataObjects;
/
