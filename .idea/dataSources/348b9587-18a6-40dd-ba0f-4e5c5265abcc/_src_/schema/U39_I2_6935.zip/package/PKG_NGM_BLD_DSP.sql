CREATE PACKAGE PKG_NGM_BLD_DSP AS

/*Dispathers to call Node/Edge/Port/Path Sources Search Function*/
PROCEDURE exec_nsr_search_func(node_spec_id IN NUMBER, func_id IN NUMBER, func_type IN NUMBER);
PROCEDURE exec_esr_search_func(edge_spec_id IN NUMBER, func_id IN NUMBER, func_type IN NUMBER);
PROCEDURE exec_path_search_func(v_graph_id IN NUMBER, path_spec_id IN NUMBER, func_id IN NUMBER, func_type IN NUMBER);
PROCEDURE exec_port_search_func(v_graph_id IN NUMBER, port_spec_id IN NUMBER, func_id IN NUMBER, func_type IN NUMBER);

/*Dispathers to call Node/Edge Sources Group Function*/
PROCEDURE exec_nsr_group_func(node_spec_id IN NUMBER, func_id IN NUMBER, func_type IN NUMBER);
PROCEDURE exec_esr_group_func(v_graph_id IN NUMBER, edge_spec_id IN NUMBER, func_id IN NUMBER, func_type IN NUMBER);

/*Dispathers to set NSS Selector */
PROCEDURE exec_nss_selector(v_graph_id IN NUMBER, selector_id IN NUMBER, selector_type IN NUMBER);

/*Dispathers to set NFS/EFS Filter */
PROCEDURE exec_nfs_filter(v_graph_id IN NUMBER, filter_id IN NUMBER, filter_type IN NUMBER, num_step IN int);
PROCEDURE exec_efs_filter(v_graph_id IN NUMBER, filter_id IN NUMBER, filter_type IN NUMBER, num_step IN int);

/*Dispathers to call Param Spec Function*/
PROCEDURE exec_psr_calc_func(v_graph_id IN NUMBER, spec_id IN NUMBER,  param_spec_id IN NUMBER, func_id IN NUMBER, func_type IN NUMBER);

/*Dispathers to call Nested Edge Search Function*/
PROCEDURE exec_ner_search_func(v_graph_id IN NUMBER, nes_spec_id  IN NUMBER, func_id  IN NUMBER, func_type IN NUMBER);

/*Dispathers to execute Actualize Database Process*/
PROCEDURE exec_actualize_process(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, process_id IN NUMBER, process_type IN NUMBER);

/*Dispathers to execute Actualize Database Rule*/
PROCEDURE exec_actualize_rule(v_graph_id IN NUMBER, v_request_id  IN NUMBER, rev_num  IN NUMBER, rule_id IN NUMBER, rule_type IN NUMBER);

END PKG_NGM_BLD_DSP;
/
