CREATE PACKAGE pkgAttribute
AS
	/*Attribute types*/
--*** SECH0707 [09.20.07][DynamicModel development] Start
	ATTR_TYPE_TEXT CONSTANT NUMBER(1) := 0;
    ATTR_TYPE_NUMBER CONSTANT NUMBER(1) := 2;
    ATTR_TYPE_DECIMAL CONSTANT NUMBER(1) := 3;
	ATTR_TYPE_DATE CONSTANT NUMBER(1) := 4;
    ATTR_TYPE_MASKED CONSTANT NUMBER(1) := 5;
    ATTR_TYPE_URL CONSTANT NUMBER(1) := 6;
	ATTR_TYPE_LIST CONSTANT NUMBER(1) := 7;
	ATTR_TYPE_TABLE CONSTANT NUMBER(1) := 8;
    ATTR_TYPE_REFERENCE CONSTANT NUMBER(1) := 9;
    ATTR_TYPE_PASSWORD CONSTANT NUMBER(2) := 10;
	ATTR_TYPE_JAVA_OBJECT CONSTANT NUMBER(2) := 12;
        ATTR_TYPE_HTML CONSTANT NUMBER(2) := 14;
	ATTR_TYPE_XML CONSTANT NUMBER(2) := 15;
    ATTR_TYPE_CURRENCY CONSTANT NUMBER(2) := 16;
--*** SECH0707 [09.20.07][DynamicModel development] Start

	/*Attribute access types*/
	ACCESS_TYPE_SYSTEM CONSTANT NUMBER(1) := 1;
	ACCESS_TYPE_DISPLAYED CONSTANT NUMBER(1) := 4;

	/*Attribute flags*/
  -- ILSM0706 [July-14-2008] [AdminTool v2.0 AttributeLibrary SQL API implementation] [Start]
  FLAG_HIDDEN CONSTANT NUMBER(1)    := 1;
  FLAG_READ_ONLY CONSTANT NUMBER(1) := 2;
  -- ILSM0706 [July-14-2008] [AdminTool v2.0 AttributeLibrary SQL API implementation] [End]
	FLAG_SYSTEM CONSTANT NUMBER(1) := 2;
	FLAG_INTERNAL CONSTANT NUMBER(1) := 3;
--*** SECH0707 [09.20.07][DynamicModel development] Start
    FLAG_LIST_EXT_VALUES CONSTANT NUMBER(3) := 128;
    FLAG_CALCULATABLE CONSTANT NUMBER(3) := 256;
--*** SECH0707 [09.20.07][DynamicModel development] End

	/*Attribute uniqueness level constants*/
	SYSTEM_UNIQUE_LEVEL CONSTANT NUMBER(1) := 1;
	PROJECT_UNIQUE_LEVEL CONSTANT NUMBER(1) := 2;
	SITE_UNIQUE_LEVEL CONSTANT NUMBER(1) := 3;
--*** TASC0105 [06/20/08] [UniqueListener: check parameter's uniqueness by nc_params_uniqueness] start
        CONTAINER_UNIQUE_LEVEL CONSTANT NUMBER(1) := 4;
--*** TASC0105 [06/20/08] [UniqueListener: check parameter's uniqueness by nc_params_uniqueness] end

	CARRIER_ATTR_ID CONSTANT NUMBER(2) := 14;
	RESOURCE_ATTR_ID CONSTANT NUMBER(2) := 15;

--*** SECH0707 [09.20.07][DynamicModel development] Start
    FUNCTION extractProperty(
        properties IN nc_attributes.properties%TYPE,
        --TASC0105 [02/27/07] [Correct parsing for adapter properties] start
        --delim IN VARCHAR2 DEFAULT '^',
        delim IN VARCHAR2 DEFAULT ';',
        --TASC0105 [02/27/07] [Correct parsing for adapter properties] end
        property IN VARCHAR2
    ) RETURN VARCHAR2;

    FUNCTION getAttributeProperty(
        attribute_id IN nc_attributes.attr_id%TYPE,
        --TASC0105 [02/27/07] [Correct parsing for adapter properties] start
        --delim IN VARCHAR2 DEFAULT '^',
        delim IN VARCHAR2 DEFAULT ';',
        --TASC0105 [02/27/07] [Correct parsing for adapter properties] end
        property IN VARCHAR2
    ) RETURN VARCHAR2;
--*** SECH0707 [09.20.07][DynamicModel development] End
--*** KAKA1207 [12.24.07][Validate nc date mask to Oracle: taken from AttributeBean.getDatePatternSQL()] Start
    FUNCTION getDatePatternSQL(
        mask IN VARCHAR2
    ) RETURN VARCHAR2;
--*** KAKA1207 [12.24.07][Validate nc date mask to Oracle: taken from AttributeBean.getDatePatternSQL()] End

  -- ILSM0706 [July-14-2008] [AdminTool v2.0 AttributeLibrary SQL API implementation] [Start]
    /**
     * Returns default value for specified attribute.
     * If def_value is configured to store in nc_attr_object_types table than that table will be used.
     * Otherwise nc_attributes table will be used.
     */
    FUNCTION getDefValue(
        attrID IN nc_attributes.attr_id%TYPE,
        schemaID IN nc_attr_object_types.attr_schema_id%TYPE,
        otypeID IN nc_attr_object_types.object_type_id%TYPE
    ) RETURN nc_attr_object_types.default_value%TYPE;

    /**
    * Returns nearest link (ATTR+SCHEMA+OTYPE) in hierarchy that corresponds to input parameters
    */
    FUNCTION getActualLink(
        attrID IN nc_attr_object_types.attr_id%TYPE,
        schemaID IN nc_attr_object_types.attr_schema_id%TYPE,
        otypeID IN nc_attr_object_types.object_type_id%TYPE
    ) RETURN nc_attr_object_types%ROWTYPE;

    /**
    * Returs true if target attribute has READ_ONLY flag for corresponding link (ATTR+SCHEMA+OTYPE).
    * In case linkDefValueAndFlags are turned off or link flags are null than nc_attributes.flags if used
    */
    FUNCTION isReadOnly(
        attrID IN nc_attr_object_types.attr_id%TYPE,
        schemaID IN nc_attr_object_types.attr_schema_id%TYPE,
        otypeID IN nc_attr_object_types.object_type_id%TYPE
    ) RETURN boolean;

    /**
    * Returs true if target attribute has HIDDEN flag for corresponding link (ATTR+SCHEMA+OTYPE).
    * In case linkDefValueAndFlags are turned off or link flags are null than nc_attributes.flags if used
    */
    FUNCTION isHidden(
        attrID IN nc_attr_object_types.attr_id%TYPE,
        schemaID IN nc_attr_object_types.attr_schema_id%TYPE,
        otypeID IN nc_attr_object_types.object_type_id%TYPE
    ) RETURN boolean;

    /**
    * Returs flag mask for attribute.
    * In case linkDefValueAndFlags are turned off or link flags are null than nc_attributes.flags if used
    */
    FUNCTION getActualFlags(
        attrID IN nc_attr_object_types.attr_id%TYPE,
        schemaID IN nc_attr_object_types.attr_schema_id%TYPE,
        otypeID IN nc_attr_object_types.object_type_id%TYPE
    ) RETURN nc_attributes.flags%TYPE;

    /**
    * Set HIDDEN flag for attribute
    */
    PROCEDURE setHidden(
        attrID IN nc_attr_object_types.attr_id%TYPE,
        schemaID IN nc_attr_object_types.attr_schema_id%TYPE,
        otypeID IN nc_attr_object_types.object_type_id%TYPE,
        isSupported IN boolean
    );

    /**
    * Set READ_ONLY flag for attribute
    */
    PROCEDURE setReadOnly(
        attrID IN nc_attr_object_types.attr_id%TYPE,
        schemaID IN nc_attr_object_types.attr_schema_id%TYPE,
        otypeID IN nc_attr_object_types.object_type_id%TYPE,
        isSupported IN boolean
    );
  -- ILSM0706 [July-14-2008] [AdminTool v2.0 AttributeLibrary SQL API implementation] [End]

  -- ILSM0706 [July-25-2008] [DB Packages modifications] Start
    /**
     * Merges FLAG_HIDDEN and FLAG_READ_ONLY from link to the flags of nc_attributes table and returns result.
     * No one table update performs.
     */
    FUNCTION getJoinLinkedFlags(
        nc_attr_flags IN nc_attributes.flags%TYPE,
        nc_aot_flags IN nc_attr_object_types.flags%TYPE
    ) RETURN nc_attributes.flags%TYPE;
  -- ILSM0706 [July-25-2008] [DB Packages modifications] End

-- DMMU0906 01-27-10 Unroll metamodel start
    FUNCTION def_value_from_binding RETURN NUMBER;
-- DMMU0906 01-27-10 Unroll metamodel end

    FUNCTION isUnrollMetamodelEnabled RETURN boolean;

    -- return ISDISPLAYED value of real link
    FUNCTION getDisplayedFromActualLink(
          attrId NUMBER,
          attrSchemaId NUMBER,
          objectTypeId NUMBER)
       RETURN NUMBER;

END pkgAttribute;
/
