CREATE PACKAGE          "PKGDBRULESSUPPORT" 
AS
	TYPE attrstable IS TABLE OF nc_attributes.attr_id%TYPE
	INDEX BY BINARY_INTEGER;

	TYPE attraccesstable IS TABLE OF nc_attributes.attr_access_type%TYPE
	INDEX BY BINARY_INTEGER;

	TYPE flagstable IS TABLE OF nc_attributes.flags%TYPE
	INDEX BY BINARY_INTEGER;

	TYPE isdisplayedtable IS TABLE OF nc_attr_object_types.isdisplayed%TYPE
	INDEX BY BINARY_INTEGER;

	TYPE prioritytable IS TABLE OF nc_params.priority%TYPE
	INDEX BY BINARY_INTEGER;

	attrsPub attrstable;
	attraccessesPub attraccesstable;
	flagsPub flagstable;
	isdisplayedsPub isdisplayedtable;
	prioritiesPub prioritytable;

	TYPE attr_object_types_table IS TABLE OF nc_attr_object_types%ROWTYPE
	INDEX BY BINARY_INTEGER;

	TYPE object_types_table IS TABLE OF nc_object_types.object_type_id%TYPE
	INDEX BY BINARY_INTEGER;

	attr_object_types_records attr_object_types_table;
	object_types_records object_types_table;

	FUNCTION definePriority(
		attrAccessType IN nc_attributes.attr_access_type%TYPE,
		flags IN nc_attributes.flags%TYPE,
		isdisplayed IN nc_attr_object_types.isdisplayed%TYPE
	) RETURN nc_params.priority%TYPE;

	PROCEDURE fillAttributesCollection(
		objectID IN nc_objects.object_id%TYPE
	);

	PROCEDURE fillAttributesCollection(
		objectTypeID IN nc_objects.object_type_id%TYPE,
		attrSchemaID IN nc_objects.attr_schema_id%TYPE
	);

	PROCEDURE fillAttributesCollection(
		objectTypeID IN nc_objects.object_type_id%TYPE,
		attrSchemaID IN nc_objects.attr_schema_id%TYPE,
		attrID IN nc_attributes.attr_id%TYPE
	);


END pkgDBRulesSupport;




/
