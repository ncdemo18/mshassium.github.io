CREATE package path_management is

  function calculateRiPhysicalPath( physical_path_id IN nc_objects.object_id%TYPE)
    return arrayofnumbers;

  function calculateRiIsConnected( physical_path_id IN nc_objects.object_id%TYPE)
    return number;

  function calculateRiUsedByPhysicalPath( element_id IN nc_objects.object_id%TYPE)
    return arrayofnumbers;

end path_management;
/
