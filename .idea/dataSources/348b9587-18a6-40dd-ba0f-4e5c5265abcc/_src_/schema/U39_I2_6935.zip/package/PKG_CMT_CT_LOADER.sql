CREATE package pkg_cmt_ct_loader is
  -- Package PKG_CMT_CT_LOADER is part of the Solution Configuration Management project
  -- Author: ALCH
  -- Created: 15.04.2014

  procedure load_config(
    p_scope in numeric,
    p_config in clob);

  procedure fill_entity_tables(p_table_name in varchar2);

end pkg_cmt_ct_loader;
/
