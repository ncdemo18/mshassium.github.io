CREATE package pkgspf as
    procedure getdeltarefparams   (old_object_id in number, new_object_id in number);
    procedure getdeltaobjects     (old_object_id in number, new_object_id in number);
    procedure getdeltaparams      (old_object_id in number, new_object_id in number);
    procedure getdeltalistparams  (old_object_id in number, new_object_id in number);
    procedure getdeltadateparams  (old_object_id in number, new_object_id in number);
    procedure getdeltaproperties  (old_object_id in number, new_object_id in number);
    procedure getfiltereddelta    (new_object_id in number);
    procedure setdelta            (new_object_id in number);
    PROCEDURE calculateDeltaForComponent(prevOrderID in number, orderID in number);

    PROCEDURE fillParameters (om_session_id nc_objects.object_id%TYPE);
    procedure calculateDeltaForComponents(components tableof2numbers);
    procedure setdeltaparams (new_object_id in number);
    function buildDelta(p_old_object_id number, p_new_object_id number) return tableof2numbers;
end pkgspf;
/
