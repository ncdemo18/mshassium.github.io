CREATE PACKAGE pkg_nc_transition
IS
   PROCEDURE set_session_id (new_session_id IN VARCHAR2);

   FUNCTION get_session_id
      RETURN VARCHAR2;

   PROCEDURE set_validation_session_id (new_session_id IN NUMBER);

   FUNCTION get_validation_session_id
      RETURN NUMBER;

   PROCEDURE set_fallout_rows_count (new_fallout_rows_count IN NUMBER);

   FUNCTION get_fallout_rows_count
      RETURN NUMBER;

   PROCEDURE create_fallout_index (tableName IN VARCHAR2);

   PROCEDURE delete_validation_session (idb_tableset_id IN VARCHAR2, validation_session_id IN VARCHAR2);

   FUNCTION get_table_by_synonym(synonymName in VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION mte_to_number(source in VARCHAR2,pattern IN VARCHAR2 DEFAULT NULL, invalid_value IN VARCHAR2 DEFAULT NULL)
      RETURN NUMBER;

   FUNCTION mte_to_date(source in VARCHAR2, pattern IN VARCHAR2 DEFAULT NULL, invalid_value IN VARCHAR2 DEFAULT NULL)
      RETURN DATE;

   FUNCTION transition_lock(lock_id in VARCHAR2)
		RETURN INTEGER;

   FUNCTION transition_lock_wait(lock_id in VARCHAR2)
		RETURN NUMBER;

   PROCEDURE release_transition_lock(lock_id in VARCHAR2);

   FUNCTION get_validation_session(table_set in NUMBER, integration_session in VARCHAR2 DEFAULT NULL) RETURN NUMBER;

   FUNCTION get_fallout_table(vsession in NUMBER) RETURN VARCHAR2;

  type fwr_row is record(id nc_objects.object_id%type,
                         name nc_objects.name%type,
                         ref_id nc_references.reference%type,
                         ref_name nc_objects.name%type);
  type fwr_table is table of fwr_row;
  function find_wrong_references(table_set_id in number)
    return fwr_table pipelined;

END;
/
