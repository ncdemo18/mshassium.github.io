CREATE PACKAGE pkgWF is
    POOLED_ACTIVE_VERSION_ATTR_ID NUMBER(20) := 90000830;
    ACTIVE_VERSION_POOL_ID NUMBER(20) := 70004002;
--    SOURCE_PACKAGE_ATTR_ID NUMBER(20) := 90000710;
    TEMPLATE_PACKAGE_ATTR_ID NUMBER(20) := 90000710;
    SOURCE_VERSION_ATTR_ID NUMBER(20) := 6061143842013807284;
    ACTIVE_VERSION_ATTR_ID NUMBER(20) := 90000720;
    LAST_VERSION_ATTR_ID NUMBER(20) := 90000721;
    PROCESS_INSTANCE_TYPE_ID NUMBER(20) := 90000320;
    PROCESS_INSTANCES_PROJECT NUMBER(20) := 91000000;
    WF_SCHEMA NUMBER(20) := 90000000;
    YES_LIST_VALUE_ID NUMBER(20) := 90000611;
    NO_LIST_VALUE_ID NUMBER(20) := 90000612;
    INITIATOR_ATTR_ID NUMBER(20) := 90100835;
    DELETED_ITEMS_CONTAINER_ID NUMBER(20) := 1900010010;

    OBJECT_TYPE_ID_PROCESS_ERROR NUMBER(20)  := 6041544897013387317;
    OBJECT_TYPE_ID_SYSTEM_ERROR  NUMBER(20)  := 6041947715013387501;
    ERROR_ATTR_ID_SYSTEM_EVENT         NUMBER(20)   := 6041544897013387319;
    ERROR_ATTR_ID_PROCESS_EVENT        NUMBER(20)   := 6041544897013387323;
    ERROR_ATTR_ID_STATUS               NUMBER(20)   := 6042147300013387647;
    ERROR_STATUS_ACTIVE                VARCHAR2(10) := 'Active';
    EXECUTION_SNAPSHOT_ATTR_ID  NUMBER(20) := 6090541472013851494;

    ERROR_UNIQUE_ARC_VERSION     exception;

    TYPE var_cursor IS REF CURSOR RETURN nc_wfvars%ROWTYPE;
    TYPE process_node_type IS RECORD(
        process_id nc_wfprocesses.process_id%TYPE,
        node nc_wfprocesses.NODE%TYPE,
        priority nc_params.list_value_id%TYPE
    );

    TYPE process_node_cursor IS REF CURSOR RETURN process_node_type;

    TYPE node_event_cursor IS REF CURSOR RETURN nc_wfnode_events%ROWTYPE;

    TYPE activity_instance_type IS RECORD(
        object_id nc_objects.object_id%TYPE,
        object_type_id nc_objects.object_type_id%TYPE,
        name nc_objects.name%TYPE,
        description nc_objects.description%TYPE,
        object_class_id nc_objects.object_class_id%TYPE,
        type_name nc_object_types.name%TYPE
    );


    TYPE activity_instance_cursor IS REF CURSOR RETURN activity_instance_type;


    currentEventID nc_wfintegration_events.unique_id%TYPE; -- current event_id
    currentRoot VARCHAR2(4000); -- root element for currently processed event
    currentActivity NC_OBJECTS.OBJECT_ID%TYPE; -- currently processed activity_id

    targetProcesses arrayofnumbers;  --processes specified in ToProcessList
    processesForActivity arrayofnumbers;  --processes for which we should test event with currentActivity
    precalculationProcessList arrayofnumbers; -- processes for which precalculation should be done
    precalculationVarList arrayofnumbers; --variables used for precalculation

    PROCEDURE insertIntoNCReferences  (
        VAR_ATTR_ID IN NC_REFERENCES.ATTR_ID%TYPE,
        VAR_REFERENCE IN NC_REFERENCES.REFERENCE%TYPE,
        VAR_OBJECT_ID IN NC_REFERENCES.OBJECT_ID%TYPE,
        VAR_SHOW_ORDER IN NC_REFERENCES.SHOW_ORDER%TYPE,
        VAR_PRIORITY IN NC_REFERENCES.PRIORITY%TYPE,
        VAR_ATTR_ACCESS_TYPE IN NC_REFERENCES.ATTR_ACCESS_TYPE%TYPE
    );

    PROCEDURE insertIntoNCParams (
        VAR_ATTR_ID IN NC_PARAMS.ATTR_ID%TYPE,
        VAR_OBJECT_ID IN NC_PARAMS.OBJECT_ID%TYPE,
        VAR_ATTR_ACCESS_TYPE IN NC_PARAMS.ATTR_ACCESS_TYPE%TYPE,
        VAR_VALUE IN NC_PARAMS.VALUE%TYPE,
        VAR_DATA IN NC_PARAMS.DATA%TYPE,
        VAR_LIST_VALUE_ID IN NC_PARAMS.LIST_VALUE_ID%TYPE,
        VAR_SHOW_ORDER IN NC_PARAMS.SHOW_ORDER%TYPE,
        VAR_DATE_VALUE IN NC_PARAMS.DATE_VALUE%TYPE,
        VAR_PRIORITY IN NC_PARAMS.PRIORITY%TYPE
    );

    PROCEDURE insertObjectIntoNCParams (
        object_to_insert IN NC_PARAMS.OBJECT_ID%TYPE,
        object_to_select IN NC_PARAMS.OBJECT_ID%TYPE,
        attr_to_select   IN NC_PARAMS.ATTR_ID%TYPE
    );

    PROCEDURE insertIntoNCObjects (
        VAR_OBJECT_ID        IN NC_OBJECTS.OBJECT_ID%TYPE,
        VAR_PARENT_ID        IN NC_OBJECTS.PARENT_ID%TYPE,
        VAR_OBJECT_TYPE_ID   IN NC_OBJECTS.OBJECT_TYPE_ID%TYPE,
        VAR_OBJECT_CLASS_ID  IN NC_OBJECTS.OBJECT_CLASS_ID%TYPE,
        VAR_PROJECT_ID       IN NC_OBJECTS.PROJECT_ID%TYPE,
        VAR_PICTURE_ID       IN NC_OBJECTS.PICTURE_ID%TYPE,
        VAR_NAME             IN NC_OBJECTS.NAME%TYPE,
        VAR_DESCRIPTION      IN NC_OBJECTS.DESCRIPTION%TYPE,
        VAR_ATTR_SCHEMA_ID   IN NC_OBJECTS.ATTR_SCHEMA_ID%TYPE,
        VAR_ORDER_NUMBER     IN NC_OBJECTS.ORDER_NUMBER%TYPE,
        VAR_SOURCE_OBJECT_ID IN NC_OBJECTS.SOURCE_OBJECT_ID%TYPE,
        VAR_VERSION          IN NC_OBJECTS.VERSION%TYPE
    );

    PROCEDURE storeProcessEvent(
        action IN nc_wfprocess_events.action%TYPE,
        process_id IN nc_wfprocess_events.process_id%TYPE,
        data IN nc_wfprocess_events.data%TYPE,
        node OUT nc_wfprocesses.node%TYPE,
        int_event_id nc_wfintegration_events.unique_id%TYPE := NULL
    );

    PROCEDURE createProcessInstance(
        template_id IN NC_OBJECTS.OBJECT_ID%TYPE,
        name IN NC_OBJECTS.NAME%TYPE,
        user_id IN NC_OBJECTS.OBJECT_ID%TYPE,
        parent_process_id IN NC_OBJECTS.OBJECT_ID%TYPE,
        add_to_wf_hierarchy IN number,
        pp_parameter IN VARCHAR2,
        node IN nc_wfprocesses.node%TYPE,
        domain IN NC_OBJECTS.OBJECT_ID%TYPE,
        process_id OUT NC_OBJECTS.OBJECT_ID%TYPE,
        last_version_id OUT NC_OBJECTS.OBJECT_ID%TYPE,
        editable_mode IN number := 0
    );

    procedure createTaskInstance(
        activity_id in NC_OBJECTS.OBJECT_ID%TYPE,
        process_id in NC_OBJECTS.OBJECT_ID%TYPE,
        prev_instance_id NC_OBJECTS.OBJECT_ID%TYPE,
        username in NC_OBJECTS.NAME%TYPE,
        p_ret out NC_OBJECTS.OBJECT_ID%TYPE,
        state in NUMBER := 8100158888013874360,
        create_transitions in NUMBER := 1

    );

    procedure completeTask(
        instance_id in NC_OBJECTS.OBJECT_ID%TYPE
    );

    procedure createUpdateAndJoin(
        andjoin_id in NC_OBJECTS.OBJECT_ID%TYPE,
        process_id in NC_OBJECTS.OBJECT_ID%TYPE,
        predecessor_id in NC_OBJECTS.OBJECT_ID%TYPE );

-- set currentRoot, targetProcesses
-- if target process list contains 3 processes or less than skip filtering and return pairs to start processes
    procedure prepareActivityList(
        event_id IN NUMBER,
        root in VARCHAR2,
        to_processes in arrayofnumbers,
        threshold in NUMBER,
        activity_list out arrayofnumbers,
        cur out process_node_cursor );

--called for each activity in loop, sets: currentActivity, processesForActivity
    procedure prepareProcessListForActivity(
        activity_id in NC_OBJECTS.OBJECT_ID%TYPE );

--prepare list to perform precalculation, sets: precalculationProcessList, precalculationVarList
    procedure preparePrecalculationList(
        var_ids in arrayofnumbers,
        process_ids out arrayofnumbers );

-- removes processes for which precalculation has failed from processesForActivity list
    procedure removeFailedProcessesFromList(
        process_ids in arrayofnumbers
    );

-- retrieves fitred list of processes, nodes for current activity (this should be send to execution)
    procedure getProcessesForActivity(
        cur out process_node_cursor
    );

-- returns cursor to read process variables
    procedure getPrecalculationVariables( retCur OUT var_cursor );

    PROCEDURE garbageCollect(
        max_duration IN NUMBER,
        completed OUT NUMBER
    );

    PROCEDURE garbageCollect(
        max_duration IN NUMBER,
        delete_after_complete_override IN NUMBER,
        completed OUT NUMBER
    );

    procedure fetchNextProcessEvent(
        state IN VARCHAR2,
        process_id IN NUMBER,
        unique_id OUT NUMBER,
        data OUT VARCHAR2 );

    procedure storeIntegrationEvent(
        data IN CLOB,
        unique_id OUT NUMBER );

    procedure lockNodeEvent(
        unique_id IN nc_wfnode_events.unique_id%TYPE,
        locked OUT NUMBER
    );

    procedure lockProcessToNode(
        process_id IN nc_wfprocesses.process_id%TYPE,
        NODE IN nc_wfprocesses.node%TYPE,
        running_nodes IN VARCHAR2,
        locked OUT NUMBER
    );

    procedure lockProcess(
        process_id IN nc_wfprocesses.process_id%TYPE,
        locked OUT NUMBER
    );

    procedure storeProcess(
        process_id IN nc_wfprocesses.process_id%TYPE,
        state IN nc_wfprocesses.state%TYPE,
        queue IN nc_wfprocesses.queue%TYPE,
        change_number OUT nc_wfprocesses.change_number%TYPE
    );

    PROCEDURE getFindProcHierarchy(
      processes IN OUT arrayofnumbers,
      includeAsynch IN number,
      includeGroup IN number);

    PROCEDURE findinformparents (
      processes     IN  arrayofnumbers,
      inform_parent OUT arrayofnumbers,
      silent        OUT arrayofnumbers
     );

    PROCEDURE writeprocesslog (
      proc_id IN nc_wfprocess_logs.process_id%TYPE,
      data IN CLOB
    );

    PROCEDURE getNodeEventsToRecover (
        timeout IN NUMBER,
        maxEvents IN NUMBER,
        cur OUT node_event_cursor
    );

    PROCEDURE getProcessesToRecover (
        timeout IN NUMBER,
        maxProcesses IN NUMBER,
        currentID IN VARCHAR2,
        nodeList IN VARCHAR2,
        recoverToCurrentNode OUT arrayofnumbers,
        recoverOther OUT arrayofnumbers
    );

    PROCEDURE getFakeTaskID(
        process_id IN nc_wfprocesses.process_id%TYPE,
        task_id OUT NUMBER
    );

    FUNCTION getTaskDueDate(
        task_id IN NC_OBJECTS.OBJECT_ID%TYPE
    ) RETURN date;

    FUNCTION getProcessDueDate(
        process_id IN NC_OBJECTS.OBJECT_ID%TYPE
    ) RETURN date;

    PROCEDURE recreateTransitionsToVersion(
        version_id IN NC_OBJECTS.OBJECT_ID%TYPE
    );

    PROCEDURE linkTaskToGroup(
        group_id IN NC_OBJECTS.OBJECT_ID%TYPE,
        act_id IN NC_OBJECTS.OBJECT_ID%TYPE,
        proc_id IN NC_OBJECTS.OBJECT_ID%TYPE
    );

    PROCEDURE makeProcessEditable(
        proc_id NUMBER,
        on_create NUMBER
    );

	function updateLockRecord(
		version_id NUMBER,
		lockrec VARCHAR2
	)
	return VARCHAR2;

    function
        getAssignedTasks(
            usersAndGroups in arrayOfNumbers,
            limit in number
        )return arrayOfNumbers;

    function
        getAssignedTasks(
            usersAndGroups in arrayOfNumbers,
            taskTypes in arrayOfNumbers,
            limit in number
        )return arrayOfNumbers;

    procedure activate(
                   process_id in number,
                   version_id in number,
                   new_id out number
            );

   procedure storeLongVariable(p_id in number,
                            v_id in number,
                            clobvalue in clob
            );

    PROCEDURE updateNotLiveNodes(
        procList in arrayofnumbers,
        nodeList in arrayofnumbers
    );

end pkgWF;
/
