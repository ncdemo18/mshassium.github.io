CREATE PACKAGE PKG_MJ_API AS
/******************************************************************************
   NAME:       PKG_MJ_API
******************************************************************************/

  /** Message Record object type ID */
  MESSAGE_OBJECT_TYPE_ID       CONSTANT number(20) := 9142041350013170949;

  /** Message type list values */
  MESSAGE_TYPE_ERROR_ID        CONSTANT number(20) := 9142041440113171212;
  MESSAGE_TYPE_INFO_ID         CONSTANT number(20) := 9142041440113171214;
  MESSAGE_TYPE_WARNING_ID      CONSTANT number(20) := 9142041440113171216;

  /**
   * Add new Message Journal message.
   *
   * @groupID - an ID of grouping object. It references to exists object in DB
   * @sourceID - an ID of log message source object.
   * @objectID - an ID of logged object.
   * @messageTypeID - an ID of message type list value
   * @messageCode - message code
   * @plainMessage - plain message text
   */
  PROCEDURE log_message (groupID number,
                         sourceID number,
                         objectID number,
                         messageTypeID number,
                         messageCode varchar2,
                         plainMessage varchar2);

  /**
   * Add new Message Journal localized message with texts from resources.
   *
   * @groupID - an ID of grouping object. It references to exists object in DB
   * @sourceID - an ID of log message source object.
   * @objectID - an ID of logged object.
   * @messageTypeID - an ID of message type list value
   * @messageCodeID - message code string resource ID
   * @messageID - message text string resource ID. The string can be formatted in Java MessageFormat.format() manner
   * @arguments - message text arguments if necessary. It can be NULL or empty.
   */
  PROCEDURE log_message_loc (groupID number,
                         sourceID number,
                         objectID number,
                         messageTypeID number,
                         messageCodeID number,
                         messageID number,
                         arguments ARRAYOFSTRINGS);

  /**
   * Add new Message Journal message with information about logged object
   *
   * @groupID - an ID of grouping object. It references to exists object in DB
   * @sourceID - an ID of log message source object.
   * @objectID - an ID of logged object.
   * @objectTypeID - an ID of logged object type.
   * @objectName - a name of logged object.
   * @messageTypeID - an ID of message type list value
   * @messageCode - message code
   * @plainMessage - plain message text
   */
  PROCEDURE log_message_obj (groupID number,
                             sourceID number,
                             objectID number, objectTypeID number, objectName varchar2,
                             messageTypeID number,
                             messageCode varchar2,
                             plainMessage varchar2);

  /**
   * Add new Message Journal localized message with information about logged object
   *
   * @groupID - an ID of grouping object. It references to exists object in DB
   * @sourceID - an ID of log message source object.
   * @objectID - an ID of logged object.
   * @objectTypeID - an ID of logged object type.
   * @objectName - a name of logged object.
   * @messageTypeID - an ID of message type list value
   * @messageCode - message code string resource ID
   * @messageID - message text string resource ID. The string can be formatted in Java MessageFormat.format() manner
   * @arguments - message text arguments if necessary. It can be NULL or empty.
   */
  PROCEDURE log_message_obj_loc (groupID number,
                             sourceID number,
                             objectID number, objectTypeID number, objectName varchar2,
                             messageTypeID number,
                             messageCodeID number,
                             messageID number,
                             arguments ARRAYOFSTRINGS);

  /**
   * Copies log messages from oldGroupID to newGroupID
   * @oldGroupID - an ID of old grouping object
   * @newGroupID - an ID of new grouping object
   */
  PROCEDURE copy_messages_to_group(oldGroupID number, newGroupID number);

END PKG_MJ_API;
/
