CREATE PACKAGE pkg_cia_correlation_engine IS

-----------------Logging engine----------------
    --This debug level can change normal execution
    --Must be used only for manual debug during development
    trace_level_detail_debug CONSTANT PLS_INTEGER := 4;

    trace_level_debug CONSTANT PLS_INTEGER := 3;
    trace_level_error CONSTANT PLS_INTEGER := 2;
    trace_level PLS_INTEGER := trace_level_error;

    PROCEDURE log_debug(msg IN VARCHAR2);

    PROCEDURE log_error(msg IN VARCHAR2);

    PROCEDURE log_exception;

    PROCEDURE clear_log;
    ---------------End of logging engine------------


    --Returns RRGGBB string of <service_level> color
    FUNCTION get_service_level_color(service_level IN NUMBER) RETURN VARCHAR2;



    normal_service_level CONSTANT NUMBER := 100;
    good_service_level   CONSTANT NUMBER := 90;
    orange_service_level CONSTANT NUMBER := 10;
    red_service_level    CONSTANT NUMBER := 0;


    ------------------------------------------------------------------------------
    -- !!! Use these functions to add RTT (with impact tree) to nc_cia_dependencies/nc_cia_severities
    PROCEDURE add_ntt_autonomous(ntt_id IN NUMBER, object_id IN NUMBER, service_level IN NUMBER);

    PROCEDURE add_ntt_autonomous(ntt_list       IN arrayofnumbers,
                      object_ids     IN arrayofnumbers,
                      service_levels IN arrayofnumbers);

  -- Use with caution, might lead to unforeseeable complications
  PROCEDURE add_ntt(ntt_id             IN NUMBER,
                      object_id          IN NUMBER,
                      service_level      IN NUMBER,
                      propogated_objects IN dep_resources);

    ---------------------------------------------------------------------------------
    --  !!! Deprecated; if using add_ntt, make sure calling function commits/rolls back operation
    --
    --Dependency calculation after creating new network trouble ticket with id <ntt_id>
    PROCEDURE add_ntt(ntt_id IN NUMBER, object_id IN NUMBER, service_level IN NUMBER);

    --Dependency calculation after creating list <ntt_list> of new network trouble ticket
    PROCEDURE add_ntt(ntt_list       IN arrayofnumbers,
                      object_ids     IN arrayofnumbers,
                      service_levels IN arrayofnumbers);

    ------------------------------------------------------------------------------
    -- !!! Use these functions to remove RTT (with impact tree) from nc_cia_dependencies/nc_cia_severities
    PROCEDURE remove_ntt_autonomous(ntt_id IN NUMBER);

    PROCEDURE remove_ntt_autonomous(ntt_list IN arrayofnumbers);

    ---------------------------------------------------------------------------------
    --  !!! Deprecated; if using remove_ntt, make sure calling function commits/rolls back operation
    --
    --Dependency calculation after removing network trouble ticket with id <ntt_id>
    PROCEDURE remove_ntt(ntt_id IN NUMBER);

    --Dependency calculation after removing list <ntt_list> of network trouble ticket
    PROCEDURE remove_ntt(ntt_list IN arrayofnumbers);

    --  !!! Attention! if using reopen_ntt, make sure calling function commits/rolls back operation
    -- Reopens existing NTTs and recalculates all dependent service_level values.
    -- If corresponding value from <service_levels> IS NOT NULL then used new service_level value.
    -- Otherwise - the old value will be kept.
    PROCEDURE reopen_ntt( ntt_ids     IN arrayofnumbers,
                          service_levels IN arrayofnumbers DEFAULT NULL);

    --  !!! Attention! if using reopen_ntt, make sure calling function commits/rolls back operation
    -- The single-value argument form.
    PROCEDURE reopen_ntt( ntt_id     IN NUMBER,
                          service_level IN NUMBER DEFAULT NULL);

    --  !!! Attention! if using reopen_ntt_by_obj, make sure calling function commits/rolls back operation
    -- Works as refresh_ntt but using Object IDs instead of NTT IDs.
    PROCEDURE reopen_ntt_by_obj( object_ids     IN arrayofnumbers,
                                service_levels IN arrayofnumbers DEFAULT NULL);

    --  !!! Attention! if using reopen_ntt_by_obj, make sure calling function commits/rolls back operation
    -- The single-value argument form.
    PROCEDURE reopen_ntt_by_obj( object_id     IN NUMBER,
                                service_level IN NUMBER DEFAULT NULL);

    --Returning all customer facing services which were propagated by object with id <object_id>
    --Flag <is_impacted> controls whether to include not impacted customer facing services or not
    FUNCTION get_dependent_cfs(object_id        IN NUMBER,
                               is_impacted      IN NUMBER,
                               is_imaginary_ntt IN NUMBER) RETURN dep_resources;

    --Returning all customer facing services which were propagated by object with id <object_id>
    --and impacted by this object only in the current transaction. Existing NTTs are ignored.
    FUNCTION get_dependent_cfs_by_obj(object_id IN NUMBER) RETURN dep_resources;

    --Returning all objects which were propagated by object with id <object_id>
    --Flag <is_impacted> controls whether to include not impacted resources or not
    FUNCTION get_dependent_resources(object_id        IN NUMBER,
                                     is_impacted      IN NUMBER,
                                     is_imaginary_ntt IN NUMBER) RETURN dep_resources;

    --Returning all circuits, devices and ports from which impact can be propagated to <object_id>
    --(for service correlation report)
    FUNCTION get_back_propagation_report(object_id IN NUMBER)
        RETURN nc_cia_srv_corr_report_table;

    --Returning all objects from which impact can be propagated to <object_id>
    --(for jservice correlation jsp page report)
    FUNCTION get_back_propagation_jsp(object_id IN NUMBER)
        RETURN nc_cia_srv_corr_jsp_table;

    -- Returning all objects wich can be propagaded by impaction from objects in <obj_list> with service_level from <severity>.
    -- If corresponding value from <severity> IS NULL then old service_level value is used for propagation.
    -- Otherwise - the new value will be used for calculation.
    -- If new value is null, then existing impaction data will be used, recalculations won't be performed.
    FUNCTION get_impact_monitor_jsp( object_id IN NUMBER, service_level IN NUMBER ) RETURN nc_cia_imp_monitor_jsp_table;

    -- Returning all objects wich can be propagaded by impaction from objects in <obj_list> with service_level from <severity>.
    -- If corresponding value from <severity> IS NULL then old service_level value is used for propagation.
    -- Otherwise - the new value will be used for calculation.
    -- If new value is null, then existing impaction data will be used, recalculations won't be performed.
    -- All tickets which affect dependt objects are ignored.
    FUNCTION get_impact_monitor_jsp_skip_sl( object_id IN NUMBER, service_level IN NUMBER ) RETURN nc_cia_imp_monitor_jsp_table;

    FUNCTION get_nocaching_imp_mon_jsp( object_id IN NUMBER, service_level IN NUMBER ) RETURN nc_cia_imp_monitor_jsp_table;


    --Adapter to test backward propagation. Added only for testing system to call it.
    PROCEDURE back_propagation_test_adapter(object_id IN NUMBER);


    -- Returns all calculated dependent objects with nesting level (in the tree).
    -- by DIRECT impact propagation
    -- Propagation tree is built from <object_id> to objects of <end_obj_type>
    -- Severities are not calculated
    -- All changes are rolled back
    FUNCTION get_direct_propagation_tree(object_id IN NUMBER, end_obj_type IN NUMBER:=null)RETURN nc_cia_propagation_table;

    -- Returns all calculated dependent objects with nesting level (in the tree)
    -- by BACKWARD impact propagation
    -- Propagation tree is built from <object_id> to objects of <end_obj_type>
    -- Severities are not calculated
    -- All changes are rolled back
    FUNCTION get_backward_propagation_tree(object_id IN NUMBER, end_obj_type IN NUMBER:=null)RETURN nc_cia_propagation_table;

    -- Returns all calculated dependent objects by DIRECT impact propagation
    -- Propagation is built from <object_ids> to objects of <end_obj_type>
    -- Only objects impacted by all <object_ids> are included into result
    -- Severities are not calculated. Impacted objects are filtered by <obj_types>
    -- All changes are rolled back
    FUNCTION get_shared_elements_direct(object_ids IN arrayofnumbers, obj_types IN arrayofnumbers, end_obj_type IN NUMBER:=null)RETURN arrayofnumbers;

    -- Returns all calculated dependent objects by BACKWARD impact propagation
    -- Propagation is built from <object_ids> to objects of <end_obj_type>
    -- Only objects impacted by all <object_ids> are included into result
    -- Severities are not calculated. Impacted objects are filtered by <obj_types>
    -- All changes are rolled back
    FUNCTION get_shared_elements_bckwrd(object_ids IN arrayofnumbers, obj_types IN arrayofnumbers, end_obj_type IN NUMBER:=null)RETURN arrayofnumbers;

    -- Returns all calculated dependent objects with nesting level (in the tree)
    -- by DIRECT impact propagation
    -- Propagation tree is built from <object_id> to objects of <end_obj_type>
    -- severities are not calculated
    -- objects of input object types are excluded from tree
    -- all changes are rolled back
    FUNCTION get_direct_prop_tree_filtered(object_id IN NUMBER, skipped_obj_types IN arrayofnumbers, end_obj_type IN NUMBER:=null)
        RETURN nc_cia_propagation_table;

    FUNCTION get_direct_prop_tree_filter_1(object_id IN NUMBER, skipped_obj_types IN arrayofnumbers, end_obj_type IN NUMBER:=null)
        RETURN nc_cia_propagation_table;

    -- Returns all calculated dependent objects with nesting level (in the tree)
    -- by BACKWARD impact propagation
    -- Propagation tree is built from <object_id> to objects of <end_obj_type>
    -- severities are not calculated
    -- objects of input object types are excluded from tree
    -- all changes are rolled back
    FUNCTION get_back_prop_tree_filtered(object_id IN NUMBER, skipped_obj_types IN arrayofnumbers, end_obj_type IN NUMBER:=null)
        RETURN nc_cia_propagation_table;

    FUNCTION get_back_prop_tree_filter_1(object_id IN NUMBER, skipped_obj_types IN arrayofnumbers, end_obj_type IN NUMBER:=null)
        RETURN NC_CIA_PROPAGATION_TABLE;

    -- Builds DIRECT propagation tree from objects of <object_ids> till objects of <end_obj_type>
    -- Result is stored in nc_cia_dependencies_temp

    -- PAY ATTENTION!: After calling procedure don't forget to clean nc_cia_dependencies_temp

    PROCEDURE fill_dependencies_partial(object_id IN NUMBER, end_obj_type IN NUMBER:=null);

    -- Builds BACK propagation tree from <object_id> till objects of <end_obj_type>
    -- Result is stored in nc_cia_dependencies_temp

    -- PAY ATTENTION!: After calling procedure don't forget to clean nc_cia_dependencies_temp

    PROCEDURE init_backward_propagation_part(object_id IN NUMBER, end_obj_type IN NUMBER:=null);


    -------------------------------------------------------------------------------
    -- !!! Use these functions to remove+add RTT (with impact tree) to nc_cia_dependencies/nc_cia_severities
    PROCEDURE init_tree_recalc_autonomous(object_id IN NUMBER, service_level IN NUMBER, tt_id IN NUMBER := null);

    PROCEDURE init_tree_recalc_autonomous(tt_id IN NUMBER);

    -------------------------------------------------------------------------------
    --  !!! Deprecated; if using init_tree_recalculate, make sure calling function commits/rolls back operation
    --
    --Input: object_id of tree root element, service level of tree root element,
  -- tt_id - id of trouble ticket which affects root element (optional, default null).
  PROCEDURE init_tree_recalculate(object_id IN NUMBER, service_level IN NUMBER, tt_id IN NUMBER := null);
  PROCEDURE init_tree_recalculate(tt_id IN NUMBER);

  FUNCTION get_dependent_services(object_id        IN NUMBER,
                               object_types IN arrayofnumbers,
                               is_impacted      IN NUMBER,
                               is_imaginary_ntt IN NUMBER) RETURN dep_resources;


    FUNCTION get_impact_monitor_jsp_crop(object_id IN NUMBER,service_level IN NUMBER)
           RETURN nc_cia_imp_monitor_jsp_table;

    FUNCTION get_impact_monitor_jsp_sk_sl_c(object_id IN NUMBER, service_level IN NUMBER)
           RETURN nc_cia_imp_monitor_jsp_table;

    FUNCTION get_direct_topology_tree(object_id IN NUMBER, end_obj_type IN NUMBER:=null)
        RETURN nc_cia_propagation_tree;

    FUNCTION get_backward_topology_tree(object_id IN NUMBER, end_obj_type IN NUMBER:=null)
        RETURN nc_cia_propagation_tree;

    FUNCTION get_direct_topology_tree(object_id IN NUMBER, end_obj_types IN arrayofnumbers:=null)
        RETURN nc_cia_propagation_tree;

    FUNCTION get_backward_topology_tree(object_id IN NUMBER, end_obj_types IN arrayofnumbers:=null)
        RETURN nc_cia_propagation_tree;

    PROCEDURE addCroppedFeature(records IN OUT nc_cia_imp_monitor_jsp_table);

    -------------------------------------------------------------------------------
    PROCEDURE calc_tree(object_ids IN arrayofnumbers, service_levels IN arrayofnumbers);
    PROCEDURE calc_tree(object_ids_str in varchar2, service_levels_str in varchar2);
    FUNCTION get_current_impact_monitor_jsp RETURN nc_cia_imp_monitor_jsp_table;
    -------------------------------------------------------------------------------

END pkg_cia_correlation_engine;
/
