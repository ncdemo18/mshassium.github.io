CREATE package pkgAudit is

SUBTYPE SID_TYPE is nc_sessions.session_id%TYPE;
NOT_DEFINED_MACHINE_ID CONSTANT VARCHAR2(30) := 'UNDEFINED';

procedure add_login_event(
    p_session_id SID_TYPE,
    p_user_id number,
    p_cur_number number,
    p_user_name varchar2,
    p_host_ip varchar2,
	p_host_name varchar2,
    p_service_id number default null,
    p_login_logout_type varchar2,
    p_status_before_login varchar2,
    p_status_after_login varchar2,
    p_requested_link varchar2
);

procedure add_login_failed_event(
    p_user_id number,
    p_user_name varchar2,
    p_cur_number number,
    p_host_ip varchar2,
	p_host_name varchar2,
	p_login_name varchar2,
    p_reason varchar2,
    p_status_before_login varchar2,
    p_status_after_login varchar2,
    p_requested_link varchar2
);

procedure add_logout_event(
    p_session_id SID_TYPE,
    p_user_id number,
    p_cur_number number,
    p_user_name varchar2,
    p_host_ip varchar2,
	p_host_name varchar2,
    p_service_id number default null,
    p_logout_type varchar2
);

end pkgAudit;
/
