CREATE PACKAGE "GRAPH_VIEW_SAMPLES"
IS
    PROCEDURE CREATE_GV_SAMPLE_POLICY(
      policy_id IN NUMBER,
      policy_name IN VARCHAR2,
      policy_provider_id IN NUMBER,
      impl_class IN VARCHAR2,
      launch_url IN VARCHAR2,
      policy_description IN VARCHAR2,
      provider_type_id IN NUMBER DEFAULT 9132509149413103984,
      launch_hgv_url IN VARCHAR2 DEFAULT ''
    );

    PROCEDURE INSERT_PARAM_VALUE(
      objectId NUMBER,
      attrId NUMBER,
      value VARCHAR2
    );
END;
/
