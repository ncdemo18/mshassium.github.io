CREATE package pkgAttrObjectTypes as

    --current transaction_id need in triggers for activate job
    transaction_id VARCHAR2(50);
     --current transaction_timestamp need in triggers for activate job to determine if transaction_id is reused by Oracle
    transaction_timestamp TIMESTAMP(6);

    --refills all plain tables
    procedure recalculate_plain_model;

    --execute update_tables in case there are recent changes have been for a some time
    procedure update_tables_job;

    --sync all entities from sync tables to plain
    procedure update_tables;

    --check flat table where tracks modifications
    --return 0 if sync table contains data for synchronization, and 1 if they empty
    function is_sync_table_empty return number;

    --wait until all changes are synced
    --this procedure dangerous now, because they not turn on sync job if they die
    --wiil be fixed in next release PSUPCORE-15501
    procedure sync;

    procedure schedule_recalculate_ot(track_object_type_id in nc_object_type_parents_sync.object_type_id%type, schedule_recalculate_parents in boolean := false);
    procedure schedule_recalculate_attr(track_attr_id in nc_attr_object_types_sync.attr_id%type);
    procedure schedule_recalculate_attr(attr_ids in arrayofnumbers);
    procedure schedule_recalculate_schema(track_schema_id in nc_attr_schema_parents_sync.attr_schema_id%type, schedule_recalculate_parents in boolean := false);

    --utility function to get difference between two dates in seconds
    function datediff(p_d1 in date, p_d2 in date) return number;

    --utility function to get timestamp from scn or yesterday date in case
    --getting of scn fails
    function valid_scn_to_timestamp (p_scn in number) return date;

    --deprecated internal function
    function get_and_lock_all_sync_attrs return arrayofnumbers;

end;
/
