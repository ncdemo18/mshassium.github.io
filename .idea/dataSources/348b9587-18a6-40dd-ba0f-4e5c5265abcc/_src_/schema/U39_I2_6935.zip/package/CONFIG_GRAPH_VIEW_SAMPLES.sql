CREATE PACKAGE "CONFIG_GRAPH_VIEW_SAMPLES"
IS

    PROCEDURE CREATE_CONFIG_GV_SAMPLE_POLICY(
      policy_id IN NUMBER,
      policy_name IN VARCHAR2,
      policy_provider_id IN NUMBER,
      launch_url IN VARCHAR2,
      policy_description IN VARCHAR2,
      launch_hgv_url IN VARCHAR2
    );

    PROCEDURE BIND_CONFIGURATION_TO_PROVIDER(provider_id IN NUMBER, gv_configuration_id IN NUMBER);
END;
/
