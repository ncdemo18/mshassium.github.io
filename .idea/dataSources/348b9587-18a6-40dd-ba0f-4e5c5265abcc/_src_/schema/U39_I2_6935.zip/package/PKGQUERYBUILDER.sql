CREATE PACKAGE pkgQueryBuilder
IS


-- ANAR0707 [09.03.07] [Support for calculable attributes] [Start]
--   FUNCTION get_value_as_string(p_object_id NUMBER, p_attr_id NUMBER, a_attr_type_id NUMBER, p_language_id NUMBER, p_date_mask VARCHAR2 DEFAULT 'MM/dd/yyyy HH:mm:ss', p_multiple_delim VARCHAR2 DEFAULT '|:|', p_refs_delim VARCHAR2 DEFAULT '|::|')
--      RETURN VARCHAR2;
   FUNCTION get_value_as_string(p_object_id NUMBER, p_attr_id NUMBER, a_attr_type_id NUMBER, p_language_id NUMBER, p_is_attr_calc NUMBER DEFAULT 0, p_date_mask VARCHAR2 DEFAULT 'MM/dd/yyyy HH:mm:ss', p_multiple_delim VARCHAR2 DEFAULT '|:|', p_refs_delim VARCHAR2 DEFAULT '|::|')
      RETURN VARCHAR2;
-- ANAR0707 [09.03.07] [Support for calculable attributes] [End]


END pkgQueryBuilder;
/
