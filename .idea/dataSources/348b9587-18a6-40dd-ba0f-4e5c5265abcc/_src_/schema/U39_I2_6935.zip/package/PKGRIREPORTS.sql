CREATE package pkgRIReports as

  TYPE_ID_CIRCUIT_LAYOUT_CONF           constant number := 9128085564713897090;
  ATTR_ID_CIRCUIT_OBJECT_TYPE           constant number := 9128087047113897159;
  ATTR_ID_IS_ACTIVE                     constant number := 9128087047113897189;
  LIST_VALUE_ID_YES                     constant number := /*1*/7777001;
  ATTR_ID_WORKING_PATH_QUERY            constant number := 9128087047113897161;
  ATTR_ID_PROTECTION_PATH_QUERY         constant number := 9128087047113897163;
  TYPE_ID_CIRCUIT                       constant number := 8;
  OBJ_ID_RI_CONFIG_PROJECT              constant number := 9050746515013907290;


  type ref_cursor is ref cursor;

--SVMA0311 [09-12-2011] [Circuit Hierarchical View Tool] Start
  function getCLRConfiguration(circuitID number) return number;
--SVMA0311 [09-12-2011] [Circuit Hierarchical View Tool] End
  /**
   * Function returns cursor with data selected by query from
   * "Working Path Query" parameter of configuration. Query performed for
   * circuit specified in arguments.
   *
   * @param   circuitID                 ID for specified circuit
   * @return                            Cursor with data
   */
  function getWorkingPath(circuitID number) return ref_cursor;

  /**
   * Function returns cursor with data selected by query from
   * "Working Path Query" parameter of configuration with specified locale. Query performed for
   * circuit specified in arguments.
   *
   * @param   circuitID                 ID for specified circuit
   * @param   languageID                ID for specified language
   * @return                            Cursor with data
   */

  function getWorkingPath(circuitID number, languageID number) return ref_cursor;

--SVMA0311 [09-12-2011] [Circuit Hierarchical View Tool] Start
  /**
   * Function returns cursor used by circuits
  */
  function getUsedByCircuits(circuitID number) return ref_cursor;

  /**
   * Function returns ref curcor of node attributes to be displaed
  */
  function getShownAttributes(clrConfigID number, objectType number) return ref_cursor;

  /**
  * Function returns ref cursor of node attributes to be displaed for Elements of the circuit
  */
  function getShownAttributesForCircElem(circuit_id number, object_type number) return ref_cursor;
--SVMA0311 [09-12-2011] [Circuit Hierarchical View Tool] End
  /**
   * Function returns cursor with data selected by query from
   * "Protection Path Query" parameter of configuration. Query performed for
   * circuit specified in arguments.
   *
   * @param   circuitID   ID for specified circuit
   * @return              Cursor with data
   */
  function getProtectionPath(circuitID number) return ref_cursor;

/**
 * Function returns cursor with data selected by query from
 * "Protection Path Query" parameter of configuration. Query performed for
 * circuit and language specified in arguments.
 *
 * @param   circuitID   ID for specified circuit
 * @param   languageID  ID of current language
 * @return              Cursor with data
 */
  function getProtectionPath(circuitID number, languageID number) return ref_cursor;
  /**
   * Function returns table with date selected by query from
   * parameter of configuration with attribute <attr_id>. Query performed for
   * hierarchy of circuit specified in arguments.
   *
   * @param   circuitID   ID for specified circuit
   * @return              Table with date
   *
   * @deprecated
   */
  function getPathByAttrHierarchy(
            circuitID number,
            levelNumStart number,
            workPathAttrID number,
            protectPathAttrID number default null)
  return table_of_circuit_path_row pipelined;

  /**
   * Function returns table with data selected by query from
   * "Working Path Query" parameter of configuration and working path queries
   * specified for all underlying circuits for which configuration is defined
   * (means configuration for their OT exists and not empty. If configuration
   * does not exist, configuration of upper OT is searched).
   *
   * @param   circuitID                 ID for specified circuit
   * @return                            Table with date
   */
  function getWorkingPathHierarchy(circuitID number) return table_of_circuit_path_row;

  /**
   * Function returns table with data selected by query from
   * "Protection Path Query" parameter of configuration and protection path
   * queries specified for all underlying circuits. If protection path of any
   * underlying circuit is not defined, function expands its working path.
   *
   * @param   circuitID                 ID for specified circuit
   * @return                            Ctable with date
   */
  function getProtectionPathHierarchy(circuitID number) return table_of_circuit_path_row;

  /**
   * Function returns the html-path of the card-slot hierarchy from Shelf to
   * Resource.  For example, for device Dev and resource Port will
   * [Dev >] Slot > Card > SubSlot > SubCard  > (etc) [> Port] (with hyperlinks)
   *
   * @param   shelfID       Device ID
   * @param   resourceID    Resource ID
   * @return                The html-path string
   */
  function getHtmlCardPath(shelfID number, resourceID number)
  return varchar2;

  /**
    * Function returns the cursor with path of circuit
    * @param    circuitID  ID circuit
    * @param    attrID     ID Path Query attribute
    * @return              cursor with path of circuit
    */
  function getPathByAttr(circuitID number, attrID number)
  return ref_cursor;

  /**
    * Function returns the cursor with path of circuit
    * @param    circuitID  ID circuit
    * @param    attrID     ID Path Query attribute
	* @param	clrConfID  ID of CLR Configuration
	* @param	languageID ID of current language
    * @return              cursor with path of circuit
    */
  function getPathByAttrLocalized(circuitID number, attrID number, clrConfID number, languageID number)
  return ref_cursor;

  /**
    * Function returns the cursor with path of circuit
    * @param    circuitID  ID circuit
    * @param    attrID     ID Path Query attribute
	* @param	languageID ID of language
    * @return              cursor with path of circuit
    */
  function getPathByAttrLocalized(circuitID number, attrID number, languageID number)
  return ref_cursor;

  /**
   * Function returns table with standart hierarchical CLR Report
   *
   * @param   circuitID           ID for specified circuit
   * @param   isProtectionPath    0 - Working Path, 1 - Protection Path
   * @return                      Table with report
   */
  function getDefaultCLRReport(circuitID number, isProtectionPath number)
  return table_of_oob_clr_report_row pipelined;

end pkgRIReports;
/
