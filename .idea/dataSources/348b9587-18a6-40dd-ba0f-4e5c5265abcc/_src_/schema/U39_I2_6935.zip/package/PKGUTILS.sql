CREATE PACKAGE pkgutils
IS
  c_count     NUMBER := 100;

  value_index_length number(4) := 50;

  FUNCTION params_ix(val NUMBER)
      RETURN VARCHAR2 PARALLEL_ENABLE DETERMINISTIC;

  FUNCTION params_ix(val VARCHAR2)
      RETURN VARCHAR2 PARALLEL_ENABLE DETERMINISTIC;

  FUNCTION params_ix(val DATE)
      RETURN VARCHAR2 PARALLEL_ENABLE DETERMINISTIC;

  FUNCTION params_ix(val TIMESTAMP)
      RETURN VARCHAR2 PARALLEL_ENABLE DETERMINISTIC;

  FUNCTION params_ix_like(val VARCHAR2, escape_char CHAR DEFAULT NULL)
      RETURN VARCHAR2 PARALLEL_ENABLE DETERMINISTIC;

  FUNCTION getValueIndexLength
      RETURN NUMBER PARALLEL_ENABLE DETERMINISTIC;

  TYPE ref_cur IS REF CURSOR;

  v_host_id   NUMBER := NULL;
  v_server_hash VARCHAR2(200) := NULL;

 FUNCTION get_ids_as_array(p_count INTEGER)
    RETURN arrayofnumbers;

  FUNCTION getid
    RETURN NUMBER;

  FUNCTION getid (p_count NUMBER)
    RETURN ref_cur;

  FUNCTION sethostid (p_host_id NUMBER)
    RETURN NUMBER;

  FUNCTION gethostid
    RETURN NUMBER;

  FUNCTION getpath (site_id NUMBER)
    RETURN VARCHAR2;

  --@DEPRECATED!
  FUNCTION getchassisid (port_id NUMBER)
    RETURN NUMBER;

  FUNCTION getalphanumericaltext (VALUE VARCHAR2)
    RETURN VARCHAR2;

  FUNCTION to_numberx (VALUE VARCHAR2)
    RETURN NUMBER;

  FUNCTION getparentidwithtype (connid NUMBER, typeid NUMBER)
    RETURN NUMBER;

  FUNCTION tonumber (VALUE VARCHAR2)
    RETURN NUMBER;

  --@DEPRECATED!
  FUNCTION getcardpath (card_id NUMBER, sep VARCHAR2, altsep VARCHAR2)
    RETURN VARCHAR2;

  FUNCTION geteasting (lat NUMBER, lon number)
    RETURN NUMBER;

  FUNCTION getnorthing (lat number, lon number)
    RETURN NUMBER;

  FUNCTION getintercepting (
    sx   VARCHAR2,
    sy   VARCHAR2,
    sh   VARCHAR2,
    sw   VARCHAR2,
    x1   NUMBER,
    y1   NUMBER,
    h1   NUMBER,
    w1   NUMBER
  )
    RETURN NUMBER;

  FUNCTION getlatitude(north NUMBER,east NUMBER)
  RETURN NUMBER;

  FUNCTION getlongitude(north NUMBER,east NUMBER)
  RETURN NUMBER;

  FUNCTION gettimedtasks (username VARCHAR2, hashedusername VARCHAR2)
      RETURN ref_cur;

  FUNCTION containsusername (
      username         VARCHAR2,
      hashedusername   VARCHAR2,
      data             CLOB
   )
      RETURN INTEGER;
  -- Calculate degrees from Longitude/Latitude represented in dd mm ss
  FUNCTION todegrees (x varchar2)
  RETURN NUMBER;

  FUNCTION gethtmlcardpath (
     p_object_id          NUMBER,
	 separator            VARCHAR2,
	 is_url               NUMBER,
	 url_prefix           VARCHAR2,
	 last_object_class_id NUMBER,
	 last_object_include  NUMBER
  )
    RETURN VARCHAR2;

  FUNCTION date_to_id(date_for_id DATE)
     RETURN NUMBER;

   FUNCTION id_to_date(id NUMBER)
     RETURN DATE;

END;
/
