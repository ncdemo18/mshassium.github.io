CREATE PACKAGE PKG_BAIP_RBM_WRAPPERS AS


/*******************************************************************************
                      Catalog Processing
*******************************************************************************/
  procedure check_package;

  procedure createCatalogue2NC(datarow in out SDB_RBM_CSYNCH_CATALOG_CHANGES%rowtype);

  procedure modifyCatalogueProperties1NC(datarow in out SDB_RBM_CSYNCH_CATALOG_CHANGES%rowtype);

  procedure processCatalogue(datarow_input SDB_RBM_CSYNCH_CATALOG_CHANGES%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Composite Filter Processing
*******************************************************************************/
  procedure createCompositeFilter1NC(datarow in out SDB_RBM_CSYNCH_COMPOSITEFILTER%rowtype);

  procedure deleteCompositeFilter1NC(datarow in pkg_baip_catalog_const.CompositeFilter);

  procedure processCompositeFilter(datarow_input SDB_RBM_CSYNCH_COMPOSITEFILTER%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Aggregate Pricing
*******************************************************************************/
  procedure createAggregatePricing1NC(datarow in out SDB_RBM_CSYNCH_AGGR_PRC_DISC%rowtype);

  procedure modifyAggregatePricing1NC(datarow in out SDB_RBM_CSYNCH_AGGR_PRC_DISC%rowtype);

  procedure processAggregatePricing(datarow_input SDB_RBM_CSYNCH_AGGR_PRC_DISC%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Banded Discount
*******************************************************************************/
  procedure createBandedDiscount1NC(datarow in out SDB_RBM_CSYNCH_BANDED_DISC%rowtype);

  procedure modifyBandedDiscount1NC(datarow in out SDB_RBM_CSYNCH_BANDED_DISC%rowtype);

  procedure processBandedDiscount(datarow_input SDB_RBM_CSYNCH_BANDED_DISC%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Discounted Usage
*******************************************************************************/
  procedure createLimitRatDiscount10NC(datarow in out SDB_RBM_CSYNCH_DISC_USAGE%rowtype);

  procedure modifyLimitRatDiscount10NC(datarow in out SDB_RBM_CSYNCH_DISC_USAGE%rowtype);

  procedure processDiscountedUsage(datarow_input SDB_RBM_CSYNCH_DISC_USAGE%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Pre-Post Itemization
*******************************************************************************/
  procedure createBasicDiscount1NC(datarow in out SDB_RBM_CSYNCH_PRE_POST_DISC%rowtype);

  procedure modifyBasicDiscount1NC(datarow in out SDB_RBM_CSYNCH_PRE_POST_DISC%rowtype);

  procedure processPrePostItemization(datarow_input SDB_RBM_CSYNCH_PRE_POST_DISC%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Tax
*******************************************************************************/
  procedure createTaxDiscount1NC(datarow in out SDB_RBM_CSYNCH_TAX_DISC%rowtype);

  procedure modifyTaxDiscount1NC(datarow in out SDB_RBM_CSYNCH_TAX_DISC%rowtype);

  procedure processTax(datarow_input SDB_RBM_CSYNCH_TAX_DISC%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Usage Counter
*******************************************************************************/
  procedure createEventUsageCounter4NC(datarow in out SDB_RBM_CSYNCH_DISC_USAGECNTER%rowtype);

  procedure modifyEventUsageCounter4NC(datarow in out SDB_RBM_CSYNCH_DISC_USAGECNTER%rowtype);

  procedure processUsageCounter(datarow_input SDB_RBM_CSYNCH_DISC_USAGECNTER%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Flat Rate
*******************************************************************************/
  procedure createFlatRatDiscount3NC(datarow in out SDB_RBM_CSYNCH_FLAT_DISC%rowtype);

  procedure modifyFlatRatDiscount3NC(datarow in out SDB_RBM_CSYNCH_FLAT_DISC%rowtype);

  procedure processFlatRate(datarow_input SDB_RBM_CSYNCH_FLAT_DISC%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Bonus Scheme
*******************************************************************************/
  procedure createBonusSchemeDiscount1NC(datarow in out SDB_RBM_CSYNCH_BONUS_SCHM_DISC%rowtype);

  procedure modifyBonusSchemeDiscount1NC(datarow in out SDB_RBM_CSYNCH_BONUS_SCHM_DISC%rowtype);

  procedure processBonusScheme(datarow_input SDB_RBM_CSYNCH_BONUS_SCHM_DISC%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Event Discount Step
*******************************************************************************/
  procedure createEventDiscountStep1NC(datarow in out SDB_RBM_CSYNCH_DISC_STEP%rowtype);

  procedure modifyEventDiscountStep1NC(datarow in out SDB_RBM_CSYNCH_DISC_STEP%rowtype);

  procedure processEventDiscountStep(datarow_input SDB_RBM_CSYNCH_DISC_STEP%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Event Filter
*******************************************************************************/
  procedure createEventFilter2NC(datarow in out SDB_RBM_CSYNCH_EVENT_FILTER%rowtype);

  procedure modifyEventFilter2NC(datarow in out SDB_RBM_CSYNCH_EVENT_FILTER%rowtype);

  procedure processEventFilter(datarow_input SDB_RBM_CSYNCH_EVENT_FILTER%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Filter Element
*******************************************************************************/
  procedure createFilterElement1NC(datarow in out SDB_RBM_CSYNCH_FILTER_ELEMENT%rowtype);

  procedure modifyFilterElement1NC(datarow in out SDB_RBM_CSYNCH_FILTER_ELEMENT%rowtype);

  procedure processFilterElement(datarow_input SDB_RBM_CSYNCH_FILTER_ELEMENT%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Installment Plan
*******************************************************************************/
  procedure createOtcInstlmentDetails1NC(datarow in out SDB_RBM_CSYNCH_INSTALLMNT_PLAN%rowtype);

  procedure modifyOtcInstlmentDetails1NC(datarow in out SDB_RBM_CSYNCH_INSTALLMNT_PLAN%rowtype);

  procedure processInstallmentPlan(datarow_input SDB_RBM_CSYNCH_INSTALLMNT_PLAN%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Late Fee Rule Credit Class
*******************************************************************************/
  procedure createLateFeeCreditclass1NC(datarow in out SDB_RBM_CSYNCH_FEECREDITCLASS%rowtype);

  procedure processLateFeeRuleCreditClass(datarow_input SDB_RBM_CSYNCH_FEECREDITCLASS%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Late Fee Rule Market Segment
*******************************************************************************/
  procedure createLateFeeMktSegment1NC(datarow in out SDB_RBM_CSYNCH_LATE_FEE_MARKET%rowtype);

  procedure processLFRuleMarketSegment(datarow_input SDB_RBM_CSYNCH_LATE_FEE_MARKET%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Late Fee Rule
*******************************************************************************/
  procedure createLateFeeRule1NC(datarow in out SDB_RBM_CSYNCH_LATE_FEE_RULE%rowtype);

  procedure modifyLateFeeRule1NC(datarow in out SDB_RBM_CSYNCH_LATE_FEE_RULE%rowtype);

  procedure processLateFeeRule(datarow_input SDB_RBM_CSYNCH_LATE_FEE_RULE%rowtype, df_session_id varchar2);

/*******************************************************************************
                      One Time Charge Attributes
*******************************************************************************/
  procedure createOneTimeChargeAttr1NC(datarow in out SDB_RBM_CSYNCH_OTC_ATTRIBUTES%rowtype);

  procedure modifyOneTimeChargeAttr1NC(datarow in out SDB_RBM_CSYNCH_OTC_ATTRIBUTES%rowtype);

  procedure processOTCAttributes(vp_object_id  number, vp_session_id varchar2, df_session_id varchar2);

/*******************************************************************************
                      One Time Charge
*******************************************************************************/
  procedure createOneTimeCharge2NC(datarow in out SDB_RBM_CSYNCH_ONE_TIME_CHARGE%rowtype);

  procedure modifyOneTimeCharge2NC(datarow in out SDB_RBM_CSYNCH_ONE_TIME_CHARGE%rowtype);

  procedure processOneTimeCharge(datarow_input SDB_RBM_CSYNCH_ONE_TIME_CHARGE%rowtype, df_session_id varchar2);

  procedure processOTChasMarketsegment(p_session_id sdb_rbm_csynch_otcmktseg.session_id%type, p_df_session_id varchar2);

/*******************************************************************************
                      One Time Charge Tariff
*******************************************************************************/
  procedure createOneTimeChargeTariff1NC(datarow in out SDB_RBM_CSYNCH_ONE_TIME_CHARGE%rowtype);

  procedure modifyOneTimeChargeTariff1NC(datarow in out SDB_RBM_CSYNCH_ONE_TIME_CHARGE%rowtype);

  procedure processOneTimeChargeTariff(datarow_input SDB_RBM_CSYNCH_ONETMCHRGTARIFF%rowtype, df_session_id varchar2);

/*******************************************************************************
                      One Time Charge Type
*******************************************************************************/
  procedure createOneTimeChargeType1NC(datarow in out SDB_RBM_CSYNCH_ONETIMECHRGTYPE%rowtype);

  procedure modifyOneTimeChargeType1NC(datarow in out SDB_RBM_CSYNCH_ONETIMECHRGTYPE%rowtype);

  procedure processOneTimeChargeType(datarow_input SDB_RBM_CSYNCH_ONETIMECHRGTYPE%rowtype, df_session_id varchar2);

/*******************************************************************************
                      One Time Charge Type Taxation
*******************************************************************************/
  procedure createCpsOtcTypeTax1NC(datarow in out sdb_rbm_csynch_cpsotctypetax%rowtype);

  procedure modifyCpsOtcTypeTax1NC(datarow in out sdb_rbm_csynch_cpsotctypetax%rowtype);

  procedure processOTCTypeTax(datarow_input sdb_rbm_csynch_cpsotctypetax%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Payment Method Discount
*******************************************************************************/
  procedure createBillDiscount1NC(datarow in out SDB_RBM_CSYNCH_METHOD_DISCOUNT%rowtype);

  procedure modifyBillDiscount1NC(datarow in out SDB_RBM_CSYNCH_METHOD_DISCOUNT%rowtype);

  procedure processPaymentMethodDiscount(datarow_input SDB_RBM_CSYNCH_METHOD_DISCOUNT%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Payment Plan Discount
*******************************************************************************/
  procedure createBudgetPlanDiscount1NC(datarow in out SDB_RBM_CSYNCH_PLAN_DISCOUNT%rowtype);

  procedure modifyBudgetPlanDiscount1NC(datarow in out SDB_RBM_CSYNCH_PLAN_DISCOUNT%rowtype);

  procedure processPaymentPlanDiscounte(datarow_input SDB_RBM_CSYNCH_PLAN_DISCOUNT%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Payment Plan
*******************************************************************************/
  procedure createBudgetPaymentplan3NC(datarow in out SDB_RBM_CSYNCH_PAYMENT_PLAN%rowtype);

  procedure modifyBudgetPaymentPlan3NC(datarow in out SDB_RBM_CSYNCH_PAYMENT_PLAN%rowtype);

  procedure processPaymentPlan(datarow_input SDB_RBM_CSYNCH_PAYMENT_PLAN%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Price Override
*******************************************************************************/
  procedure deleteTariffElementOverride(datarow in pkg_baip_catalog_const.PriceOverride);

  procedure createTariffElementOverride(datarow in out pkg_baip_catalog_const.PriceOverride);

  procedure createOverride(datarow_input pkg_baip_catalog_const.PriceOverride);

/*******************************************************************************
                      Product Attributes
*******************************************************************************/
  procedure createProductAttribute2NC(datarow in out SDB_RBM_CSYNCH_PROD_ATTRIBUTES%rowtype);

  procedure modifyProductAttribute2NC(datarow in out SDB_RBM_CSYNCH_PROD_ATTRIBUTES%rowtype);

  procedure processProductAttributes(vp_product_id number, vp_attribute_bill_name varchar2,
    vp_product_attr_sub_id number, vp_rbm_id_sign varchar2, vp_session_id varchar2, df_session_id varchar2);

/*******************************************************************************
                      Product Event Specification
*******************************************************************************/
  procedure createProdHasEventType1NC(datarow in out sdb_rbm_csynch_prod_event_spec%rowtype);

  procedure deleteProdHasEventType1NC(datarow in out sdb_rbm_csynch_prod_event_spec%rowtype);

  procedure deleteProdHasEventType(prod_id in number);

  procedure processProductEventSpec(datarow_input sdb_rbm_csynch_prod_event_spec%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Product Family Bill Style
*******************************************************************************/
  procedure createProdFamilyBillStyle1NC(datarow in out SDB_RBM_CSYNCH_PRODF_BILLSTYLE%ROWTYPE);

  procedure deleteProdFamilyBillStyle1NC(datarow in out SDB_RBM_CSYNCH_PRODF_BILLSTYLE%ROWTYPE);

  procedure deleteProdFamilyBillStyle(prod_family_id in number);

  procedure processProdFamilyBillStyle(datarow_input SDB_RBM_CSYNCH_PRODF_BILLSTYLE%ROWTYPE, df_session_id varchar2);

/*******************************************************************************
                      Product Family
*******************************************************************************/
  procedure createProductFamily1NC(datarow in out SDB_RBM_CSYNCH_PRODUCT_FAMILY%rowtype);

  procedure modifyProductFamily1NC(datarow in out SDB_RBM_CSYNCH_PRODUCT_FAMILY%rowtype);

  procedure processProductFamily(datarow_input SDB_RBM_CSYNCH_PRODUCT_FAMILY%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Product Offering Taxation
*******************************************************************************/
  procedure createCPSProductTax1NC(datarow in out SDB_RBM_CSYNCH_PROD_OFFERTAX%rowtype);

  procedure modifyCPSProductTax1NC(datarow in out SDB_RBM_CSYNCH_PROD_OFFERTAX%rowtype);

  procedure processProdOfferingTax(datarow_input SDB_RBM_CSYNCH_PROD_OFFERTAX%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Product
*******************************************************************************/
  procedure createProductType3NC(datarow in out SDB_RBM_CSYNCH_PRODUCT%rowtype);

  procedure modifyProductType3NC(datarow in out SDB_RBM_CSYNCH_PRODUCT%rowtype);

  procedure processProduct(datarow_input SDB_RBM_CSYNCH_PRODUCT%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Product Has Parent
*******************************************************************************/
  procedure createProdHasParentProd1NC(datarow in out SDB_RBM_CSYNCH_PROD_HAS_PARENT%rowtype);

  procedure deleteProdHasParentProd1NC(datarow in out SDB_RBM_CSYNCH_PROD_HAS_PARENT%rowtype);

  procedure processProductHasParent(datarow_input SDB_RBM_CSYNCH_PROD_HAS_PARENT%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Subscription
*******************************************************************************/
  procedure createSubscriptionType2NC(datarow in out SDB_RBM_CSYNCH_SUBSCR_TYPE%ROWTYPE);

  procedure modifySubscriptionType2NC(datarow in out SDB_RBM_CSYNCH_SUBSCR_TYPE%ROWTYPE);

  procedure processSubscription(datarow_input SDB_RBM_CSYNCH_SUBSCR_TYPE%ROWTYPE, df_session_id varchar2);

/*******************************************************************************
                      ICo Has Subscription
*******************************************************************************/

  procedure processICoHasSubscription(df_session_id varchar2);

/*******************************************************************************
                      Tariff Element Discount
*******************************************************************************/
  procedure createTariffElmntDisc1NC(datarow in out SDB_RBM_CSYNCH_TARIFFELEMDISC%rowtype);

  procedure modifyTariffElmntDisc1NC(datarow in out SDB_RBM_CSYNCH_TARIFFELEMDISC%rowtype);

  procedure processTariffElementDiscount(datarow_input SDB_RBM_CSYNCH_TARIFFELEMDISC%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Tariff Element
*******************************************************************************/
  procedure deleteProductPrice5NC(datarow in pkg_baip_catalog_const.ProductPrice);

  procedure createProductPrice5NC(datarow in out pkg_baip_catalog_const.ProductPrice);

  procedure createPrice(datarow_input in pkg_baip_catalog_const.ProductPrice, df_session_id varchar2);

/*******************************************************************************
                      Tariff Element Band
*******************************************************************************/
  procedure rbmDeleteThreshold(datarow in pkg_baip_catalog_const.TariffElementBand);

  procedure createParametricThreshold1NC(datarow in pkg_baip_catalog_const.TariffElementBand);

  procedure processThreshold(datarow_input pkg_baip_catalog_const.TariffElementBand);

/*******************************************************************************
                      Tariff Has Rating Tariff
*******************************************************************************/
  procedure createTariffRatingTariff1NC(datarow in out sdb_rbm_csynch_tariff_n_rating%rowtype);

  procedure deleteTariffRatingTariff1NC(datarow in out sdb_rbm_csynch_tariff_n_rating%rowtype);

  procedure processTariffHasRatingTariff(datarow_input sdb_rbm_csynch_tariff_n_rating%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Tariff
*******************************************************************************/
  procedure createTariff1NC(datarow in out sdb_rbm_csynch_tariff%rowtype);

  procedure modifyTariff1NC(datarow in out sdb_rbm_csynch_tariff%rowtype);

  procedure processNewTariff(datarow_input sdb_rbm_csynch_tariff%rowtype, df_session_id varchar2);

  procedure processParentTariff(datarow_input sdb_rbm_csynch_tariff%rowtype, df_session_id varchar2);

/*******************************************************************************
  Offer Price Component status setting and error handling
*******************************************************************************/
  procedure update_provisioning_status(p_session_id varchar2, p_df_session_id varchar2);

/*******************************************************************************
                      Threshold redemptions
*******************************************************************************/
  procedure createthresholdredemption1nc(datarow in out sdb_rbm_csynch_threshold_redem%rowtype);

  procedure modifythresholdredemption1nc(datarow in out sdb_rbm_csynch_threshold_redem%rowtype);

  procedure processnewthresholdredemption(datarow_input sdb_rbm_csynch_threshold_redem%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Bonus Scheme
*******************************************************************************/
  procedure createbonusscheme1nc(datarow in out sdb_rbm_csynch_bonus_scheme%rowtype);

  procedure modifybonusscheme1nc(datarow in out sdb_rbm_csynch_bonus_scheme%rowtype);

  procedure processnewbonusscheme(datarow_input sdb_rbm_csynch_bonus_scheme%rowtype, df_session_id varchar2);

/*******************************************************************************
                      Market
*******************************************************************************/
  procedure createMarket(datarow in out SDB_RBM_CSYNCH_MARKET%rowtype);

  procedure modifyMarket(datarow in out SDB_RBM_CSYNCH_MARKET%rowtype);

  procedure processMarket(datarow_input SDB_RBM_CSYNCH_MARKET%rowtype, df_session_id varchar2);

END PKG_BAIP_RBM_WRAPPERS;
/
