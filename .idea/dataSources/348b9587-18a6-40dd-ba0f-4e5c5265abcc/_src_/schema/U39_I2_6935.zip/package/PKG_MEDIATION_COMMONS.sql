CREATE PACKAGE pkg_mediation_commons
IS

   FUNCTION lock_object(lock_id in VARCHAR2,waitTime in NUMBER) RETURN NUMBER;

   PROCEDURE unlock_object(lock_id in VARCHAR2);

   PROCEDURE db_cache_put(v_key in VARCHAR2, v_value in BLOB,
        c_table in VARCHAR2, c_key in VARCHAR2, c_value in VARCHAR2, c_time in VARCHAR2);

   PROCEDURE db_cache_lock(v_key in VARCHAR2,
        c_table in VARCHAR2, c_key in VARCHAR2, c_value in VARCHAR2, c_time in VARCHAR2);

END;
/
