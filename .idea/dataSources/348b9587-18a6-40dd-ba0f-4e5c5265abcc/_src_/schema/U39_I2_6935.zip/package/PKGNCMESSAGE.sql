CREATE package pkgNCMessage
as
    procedure post_message(
                    message_id     nc_messages.message_id%TYPE,
                    id             nc_messages.id%TYPE,
                    recipient_id   nc_messages.recipient_id%TYPE,
                    topic          nc_messages.topic%TYPE,
                    message_body   nc_messages.message_body%TYPE,
                    post_time      nc_messages.post_time%TYPE,
                    time_to_live   nc_messages.time_to_live%TYPE,
                    priority       nc_messages.priority%TYPE,
                    delivered      nc_messages.delivered%TYPE
    );

-- SNEG1010 [18-Apr-2011] [Support different delivery destinations for messages through the use of flags] Start
    procedure post_message(
                    message_id     nc_messages.message_id%TYPE,
                    id             nc_messages.id%TYPE,
                    recipient_id   nc_messages.recipient_id%TYPE,
                    topic          nc_messages.topic%TYPE,
                    message_body   nc_messages.message_body%TYPE,
                    post_time      nc_messages.post_time%TYPE,
                    time_to_live   nc_messages.time_to_live%TYPE,
                    priority       nc_messages.priority%TYPE,
                    delivered      nc_messages.delivered%TYPE,
                    flags          nc_messages.flags%TYPE
    );

    type unread_msgs_cursor_t is ref cursor;
    function get_unread_messages(recepient_id varchar2, flags integer) return unread_msgs_cursor_t;

    --new api
    --not delete returned messages
    function get_messages_spec_types(recepient_id varchar2, messages_types arrayofnumbers) return unread_msgs_cursor_t;

    procedure delete_messages_spec_types(recepient_id varchar2, messages_types arrayofnumbers);

    procedure delete_messages_by_message_ids(recepient_id varchar2, message_ids arrayofnumbers);

end pkgNCMessage;
/
