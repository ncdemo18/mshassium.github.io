CREATE VIEW NC_HDS_OBJECT_ATTRS_VIEW AS SELECT DISTINCT objects.object_id,
		objects.object_type_id,
		objects.attr_schema_id,
		metadata.attr_id,
		metadata.attr_type_id,
		metadata.flags,
		metadata.attr_access_type,
		metadata.adaptername,
		metadata.mask,
		metadata.config_id,
		metadata.version,
		objects.hds_object_id hds_object_id,
		objects.params_section_num,
		objects.da_mapping_id
	FROM nc_hds_tmp_attr_object_types metadata,
		 nc_hds_tmp_objects objects
	WHERE objects.attr_schema_id        = metadata.attr_schema_id
	AND objects.object_type_id          = metadata.object_type_id
	AND objects.config_id               = metadata.config_id
	AND objects.version                 = metadata.version
	AND objects.action_type            != 2
	AND metadata.attr_type_id          IN (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 14, 15, 16)
	AND metadata.attr_access_type NOT  IN (2, 3)
	AND bitand(metadata.flags, 2624568) = 0
/
COMMENT ON VIEW NC_HDS_OBJECT_ATTRS_VIEW IS 'View for optimizing attributes copying. Simplifies multiple access to DB for forming analogous selects '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.OBJECT_ID IS 'Object Id '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.ATTR_SCHEMA_ID IS 'Attribute schema Id '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.ATTR_ID IS 'Id of attribute to be stored '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.ATTR_TYPE_ID IS 'Type of attribute '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.FLAGS IS 'Attribute flags '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.ATTR_ACCESS_TYPE IS 'Access type of attribute '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.CONFIG_ID IS 'Id of config '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.VERSION IS 'Session version '
/
COMMENT ON COLUMN NC_HDS_OBJECT_ATTRS_VIEW.SECTION_NUM IS 'Sections number '
/
