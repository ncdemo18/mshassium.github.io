CREATE VIEW RTE_FK_TABS AS select /* distinct -- there is "union" inside */
       table_name
     , table_id
     , src_table
     , foreign_key fk_column
     , attr_column attr_column
     , show_order_column show_order_column
     , kind
     , data_source_name
     , instance_name
  from (
select t.table_name
     , t.table_id
     , 'PLAIN' kind
     , src_table
     , fk.foreign_key
     , fk.attr_column
     , fk.show_order_column
     , fk.data_source_name
     , t.instance_name
  from rte_tab_cols t
     , rte_fk_tables fk
 where fk.data_source_name = t.data_source_name
   and fk.table_name = t.src_table
union
select 'N2N'||c.configuration_id table_name
     , c.configuration_id table_id
     , 'NC2NC' kind
     , tables.source_table
     , foreign_key fk_column
     , attr_column attr_column
     , show_order_column show_order_column
     , fk.data_source_name
     , c.instance_name
  from rte_n2n_configs c,
       rte_n2n_table_names tables,
       rte_n2n_filters f,
       rte_n2n_a a,
       rte_supported_attributes na
     , rte_fk_tab_attributes type2tbl
     , rte_fk_tables fk
 where c.state = 1
   and f.configuration_id = c.configuration_id
   and f.state = 1
   and a.filter_id = f.filter_id
   and tables.configuration_id = c.configuration_id
   and tables.source_table = type2tbl.table_name
   and na.attr_id = a.attr_id
   and type2tbl.data_source_name = nvl(c.data_source_name, 'DEFAULT')
   and type2tbl.attr_type = na.type_name
   and fk.data_source_name = type2tbl.data_source_name
   and fk.table_name = type2tbl.table_name
)
/
