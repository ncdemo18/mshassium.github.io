CREATE VIEW RTE_TAB_TYPES AS select table_id, type_id
from (
select /*+ cardinality(x 2) */
       t.table_id
     , x.field1 type_id
     -- The row for particular object_type_id for specific filter_id with lowest level is most important
     , max(t.exclude) keep (dense_rank first order by x.field2) exclude
  from (select * from rte_table_types) t
     , table(cast(multiset
      (
        select pairofnumbers(object_type_id, level)
          from nc_object_types s
         start with object_type_id = t.object_type_id
       connect by prior object_type_id = parent_id
                    and (t.children <> 'CLASS' or nvl(isclass, 0) = 0)
                    and (t.children <> 'NONE')
                    and not exists (
                      -- We do not need to connect hierarchy in case there is specific row to include object_type
                      -- That row would be considered in "t" above
                      select object_type_id
                        from rte_table_types q
                       where table_id = t.table_id
                         and object_type_id = s.object_type_id
                         and exclude = 'N'
                    )
      ) as tableof2numbers) multiset union all tableof2numbers())(+) x
      group by table_id, x.field1
) ots
 where exclude = 'N'
/
