CREATE VIEW V_NC_EI_PSE_STATS AS SELECT /*+ leading(e s) cardinality(e 15)*/
       s.pse_stat_id
  FROM EI$NC_PSE_STAT_EXECS e, nc_pse_stats s
 WHERE s.query_pse_stat_key_id NOT LIKE 'PSE%'
   AND s.unit_pse_stat_key_id NOT LIKE 'PSE%'
   AND s.pse_exec_id = e.pse_exec_id
UNION ALL
-- units
SELECT /*+ leading(e s) cardinality(e 15)*/
       s.pse_stat_id
  FROM EI$NC_PSE_STAT_EXECS e, nc_pse_stats s
 WHERE s.query_pse_stat_key_id IS NULL
   AND s.unit_pse_stat_key_id NOT LIKE 'PSE%'
   AND s.pse_exec_id = e.pse_exec_id
/
