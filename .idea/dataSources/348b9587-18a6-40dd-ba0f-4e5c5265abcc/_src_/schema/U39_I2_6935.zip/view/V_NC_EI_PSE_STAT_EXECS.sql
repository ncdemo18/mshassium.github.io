CREATE VIEW V_NC_EI_PSE_STAT_EXECS AS SELECT t.pse_exec_id, t.component_id, t.script_group_id
  FROM (SELECT se.pse_exec_id,
               se.component_id,
               se.script_group_id,
               row_number() over(PARTITION BY se.component_id, se.script_group_id, se.script_id ORDER BY se.create_date DESC) rn
          FROM nc_pse_stat_execs se, nc_pse_servers srv
         WHERE se.script_id NOT LIKE 'PSE%'
           AND se.status = 10
           AND srv.pse_server_id = se.pse_server_id
       ) t
 WHERE t.rn <= (SELECT nvl(MAX(VALUE), 0) FROM nc_directory d WHERE d.key = 'nc.pse.usable_execs_count')
/
