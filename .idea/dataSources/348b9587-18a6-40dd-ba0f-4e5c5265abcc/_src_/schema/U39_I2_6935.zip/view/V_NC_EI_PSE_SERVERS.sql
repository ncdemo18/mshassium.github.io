CREATE VIEW V_NC_EI_PSE_SERVERS AS SELECT srv.pse_server_id
  FROM NC_PSE_SERVERS srv
 WHERE exists (select 1
                 from nc_pse_stat_execs se
                where se.pse_server_id = srv.pse_server_id
                  and se.status = 10
                  and se.script_id NOT LIKE 'PSE%')
/
