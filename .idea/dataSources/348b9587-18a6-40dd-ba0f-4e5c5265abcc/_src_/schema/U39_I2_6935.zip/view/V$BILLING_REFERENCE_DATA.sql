CREATE VIEW V$BILLING_REFERENCE_DATA AS select bill_ref_data_obj.object_id, bill_ref_data_obj.object_type_id
  from (select coalesce(target_proj_ref.reference, def_parent_obj.project_id) parent_project_id,
               object_type_ref.ref_object_type_id
          from nc_objects         ent_table_obj,
               nc_references      def_parent_obj_ref,
               nc_objects         def_parent_obj,
               nc_references      target_proj_ref,
               nc_meta_references object_type_ref
         where ent_table_obj.object_type_id = 8052340005013831606 /* IDB Entity Table */
           and ent_table_obj.parent_id = 9136019827913322939 /* TOMs RBM Billing Reference Data Table Set */
           and target_proj_ref.attr_id(+) = 8060666936013834191 /* Table Target Project */
           and target_proj_ref.object_id(+) = ent_table_obj.object_id
           and def_parent_obj_ref.attr_id = 8060666936013834192 /* Default Parent Object */
           and def_parent_obj_ref.object_id = ent_table_obj.object_id
           and def_parent_obj.object_id = def_parent_obj_ref.reference
           and object_type_ref.attr_id = 8052944210013832055 /* NC Object Types */
           and object_type_ref.object_id = ent_table_obj.object_id
           and object_type_ref.ref_object_type_id not in
               (9135709383713330027 /* Offering Taxation Involvement */)) types_and_roots,
       nc_objects bill_ref_data_obj
 where bill_ref_data_obj.object_type_id = types_and_roots.ref_object_type_id
   and bill_ref_data_obj.project_id = types_and_roots.parent_project_id
   and decode(types_and_roots.ref_object_type_id, 9136079954513608570 /* Catalog Version */,
       case when exists(select 1 from nc_objects rating_cat_parent_obj
          where rating_cat_parent_obj.object_id = bill_ref_data_obj.parent_id
          and rating_cat_parent_obj.object_type_id = 9135749750013343699 /* Rating Catalog */)
         and exists(select 1 from nc_params cat_status_par
          where cat_status_par.object_id = bill_ref_data_obj.object_id
          and cat_status_par.attr_id = 9136079954513608574 /* Catalog Status */
          and cat_status_par.list_value_id = 9136079954513608582 /* Live */) then 1 else 0 end, 1) = 1
/
