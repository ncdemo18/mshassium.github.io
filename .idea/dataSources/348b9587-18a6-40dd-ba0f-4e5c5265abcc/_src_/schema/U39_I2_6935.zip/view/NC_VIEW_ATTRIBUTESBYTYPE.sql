CREATE VIEW NC_VIEW_ATTRIBUTESBYTYPE AS select t.name root_type, getobjecttypepath (tp.object_type_id) object_type,
          a.name attribute, s.attr_schema_id attr_schema_id, s.name schema,
          g.name group_name, at.isdisplayed,
          decode (at.attr_schema_id, 1, 1, 0) issystem, a.isextgenerated,
          a.ismultiple, instr (a.adaptername, 'com') iscalculated,
          getattributetypetext (a.attr_type_id, to_type.name, d.name) attribute_type,
          getattributesamplevalue (a.attr_id) values_, a.description
     from nc_attr_object_types at,
          nc_attributes a,
          nc_object_types t,
          nc_object_types tp,
          nc_attr_schemes s,
          nc_attr_groups g,
          nc_attr_type_defs d,
          nc_object_types to_type
    where tp.object_type_id = at.object_type_id
      and a.attr_id = at.attr_id
      and at.attr_schema_id = s.attr_schema_id
      and g.attr_group_id = a.attr_group_id
      and tp.object_type_id in (select     object_type_id
                                      from nc_object_types
                                start with object_type_id = t.object_type_id
                                connect by prior object_type_id = parent_id)
      and a.name <> '$'
      and a.name <> '\-'
      and d.attr_type_def_id(+) = a.attr_type_def_id
      and s.attr_schema_id <> 1102673154013366493
      and (   a.params is null
           or instr (a.params, 'g2adapter') = 0
          )
      and to_type.object_type_id(+) = d.object_type_id
          with read only
/
