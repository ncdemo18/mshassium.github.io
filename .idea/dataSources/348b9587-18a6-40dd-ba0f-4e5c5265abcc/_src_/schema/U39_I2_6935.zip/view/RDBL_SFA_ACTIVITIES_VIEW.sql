CREATE VIEW RDBL_SFA_ACTIVITIES_VIEW AS SELECT rdbl."ACTIVITY_ID",rdbl."ACTIVITY_NAME",rdbl."OWNERS_MANAGER",rdbl."ACTIVITY_START_DATE",rdbl."ACTIVITY_END_DATE",rdbl."END_TIME",rdbl."DUE_DATE",rdbl."OWNER_NAME",rdbl."OWNER",rdbl."CREATED_BY",rdbl."RELATED_OBJECT_NAME",rdbl."RELATED_OBJECT",rdbl."COMPLETE",rdbl."PRIORITY_ID",rdbl."PRIORITY",rdbl."MODIFIED_WHEN",rdbl."OBJECT_TYPE_ID", STATUSES.STATUS, (SELECT lv.value
                            FROM nc_list_values lv
                            WHERE lv.list_value_id = STATUSES.STATUS and rownum=1) AS STATUS_NAME
  FROM (SELECT t.ACTIVITY_ID, CASE WHEN t.object_type_id = 9134256123213156346
                                        THEN (SELECT par.LIST_VALUE_ID FROM nc_params par
                                          WHERE par.ATTR_ID=9134256020013155863 and par.OBJECT_ID = t.ACTIVITY_ID)
                                    WHEN (t.ACTIVITY_START_DATE < sysdate and t.ACTIVITY_END_DATE < sysdate)
                                        THEN 9134256020013155868 
                                    WHEN (t.ACTIVITY_START_DATE <= sysdate and t.ACTIVITY_END_DATE >=sysdate)
                                        THEN  9134256020013155867 
                                    ELSE  9134731257513182982 
                             END AS STATUS
            FROM rdbl_sfa_activities t      
      ) STATUSES, RDBL_SFA_ACTIVITIES rdbl
      WHERE rdbl.ACTIVITY_ID=STATUSES.ACTIVITY_ID
/
