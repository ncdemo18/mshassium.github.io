CREATE VIEW RTE_SUPPORTED_ATTRIBUTES AS select a."ATTR_ID",a."NAME",a."ATTR_TYPE_ID",a."ATTR_TYPE_DEF_ID",a."ISMULTIPLE", sa.type_name
  from (
    select attr_id
         , name
         , case
             when attr_type_id = 7 /* list */
              and bitand(flags, 128) = 128 /* ext generated */
             then 0 /* text */
             else attr_type_id
           end attr_type_id
         , attr_type_def_id
         , ismultiple
      from nc_attributes a
) a, rte_supported_attr_types sa
 where a.attr_type_id = sa.attr_type_id
/
