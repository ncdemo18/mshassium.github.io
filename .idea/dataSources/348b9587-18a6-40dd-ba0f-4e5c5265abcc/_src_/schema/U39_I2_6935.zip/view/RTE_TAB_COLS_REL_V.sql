CREATE VIEW RTE_TAB_COLS_REL_V AS select x."RANK",x."TABLE_ID",x."TABLE_NAME",x."COLUMN_NAME",x."ATTR_ID",x."SRC_TABLE",x."SRC_EXPRESSION",x."ATTR_TYPE",x."ALIAS",x."IS_MULTIPLE",x."IS_SUPER_MULTIPLE",x."MULTIPLES",x."IS_REALTIME",x."TABLE_IS_MULTIPLE",x."IS_PRIMARY_KEY",x."ATTR_RANK",x."SQL_TYPE",x."SQL_LENGTH",x."NC_SQL_TYPE",x."NC_SQL_LENGTH",x."SRC_TRANSFORM",x."DATA_SOURCE_NAME",x."PK_TABLE_NAME",x."PK_PRIMARY_KEY",x."ATTR_COLUMN",x."SHOW_ORDER_COLUMN",x."INSTANCE_NAME"
     , sql_type||nullif('('||sql_length||')', '()') sql_fulltype
     , nc_sql_type||nullif('('||nc_sql_length||')', '()') nc_sql_fulltype
     , row_number() over(partition by x.table_id,x.column_name order by x.is_multiple desc, rank) mult_rank
  from (
select  rank
      , table_id
      , table_name
      , column_name
      , attr_id
      , nvl(nc_table_name,
            case
            when attr_id = 'CONSTANT' then 'DUAL'
            when attr_id = 'SYS:MODIFIED_WHEN' then 'DUAL'
            when attr_id = 'SYS:CREATED_WHEN' then 'DUAL'
            end) src_table
      , case
        when nc_column_name is not null then 't.'||nc_column_name
        when attr_id = 'CONSTANT' then nvl(action_, 'null')
        when attr_id = 'SYS:MODIFIED_WHEN' then 'current_timestamp'
        -- Note: this expression is parsed in rte_partition_body, see SYS:CREATED_WHEN_M01 marker
        when attr_id = 'SYS:CREATED_WHEN' then 'pkgutils.id_to_date(t.'||pk_primary_key||')'
        end src_expression
      , attr_type
      , alias
      , is_multiple
      , is_super_multiple
      , multiples
      , is_realtime
      , table_is_multiple
      , case when nc_table_name = pk_table_name
              and nc_column_name = pk_primary_key
              and table_is_multiple = 'N'
              and attr_rank = 1
             then 'Y' else 'N'
        end is_primary_key
      , attr_rank
      , case
          when data_type is not null then data_type
          when trim(nvl(def_src_transform/*<-- this can be space*/, case when attr_id <> 'CONSTANT' then action_ end)) is null
            then nvl(attr_data_type, nc_sql_type)
        end sql_type
      , case
          when data_type is not null then data_length
          when trim(nvl(def_src_transform/*<-- this can be space*/, case when attr_id <> 'CONSTANT' then action_ end)) is null
            then case when attr_data_type is not null then attr_data_length
                      else case when nc_sql_type = 'DATE' then null else nc_sql_length end
                 end
        end sql_length
      , case when attr_id in ('SYS:MODIFIED_WHEN', 'SYS:CREATED_WHEN') then 'TIMESTAMP WITH TIME ZONE' else nc_sql_type end nc_sql_type
      , case when nc_sql_type = 'DATE' then null else nc_sql_length end nc_sql_length
      , trim(nvl(def_src_transform/*<-- this can be space*/, case when attr_id <> 'CONSTANT' then action_ end)) src_transform
      , data_source_name
      , pk_table_name
      , pk_primary_key
      , attr_column
      , show_order_column
      , instance_name
from  (
      select /*+ push_pred(utc) */
             rank
           , x.table_id
           , x.table_name
           , x.column_name
           , x.attr_id
           , nullif(x.action_, '#$value$#') action_ -- optimization for the case of identity transformation
           , x.data_type
           , x.data_length
           , x.attr_type
           , x.alias
           , x.is_multiple
           , decode(count(0) over(partition by x.table_id, x.column_name), 1, 'N', 'Y') is_super_multiple
           , x.multiples
           , x.is_realtime
           , x.attr_data_type
           , x.attr_data_length
           , attr_rank
           , decode(nc_table_if_multiple, null, 'N', 'Y') table_is_multiple
           , utc.table_name  nc_table_name
           , utc.column_name nc_column_name
           , utc.data_type   nc_sql_type
           , case
               when utc.char_used is not null then utc.char_length||' '||decode(utc.char_used, 'C', 'CHAR', 'BYTE')
               when utc.data_precision is not null then utc.data_precision||','||utc.data_scale
               else to_char(utc.data_length)
             end nc_sql_length
           , case
               when lower(x.action_) in ('id', 'list_value_id', 'object_type_id', 'attr_id', 'attr_schema_id') then ' '
               when x.attr_type = 'LIST' and (x.action_ is null or lower(x.action_) in ('value', 'name')) then 'select value from nc_list_values where list_value_id=#$value$# /*STRICT*/'
               when x.attr_type = 'LIST' and (x.action_ is null or lower(x.action_) in ('additional')) then 'select additional from nc_list_values where list_value_id=#$value$# /*STRICT*/'
               when (x.attr_type = 'REF_TO_OBJECT_TYPE' and (x.action_ is null or lower(x.action_) = 'name'))
                 or (utc.column_name = x.pk_type_column and utc.table_name = x.pk_table_name and lower(x.action_) = 'name')
                 or (utc.column_name = 'OBJECT_CLASS_ID' and utc.table_name = 'NC_OBJECTS' and lower(x.action_) = 'name')
                 then 'select name from nc_object_types where object_type_id=#$value$# /*STRICT*/'
               when x.attr_type = 'REF_TO_ATTR_DEF' and (x.action_ is null or lower(x.action_) = 'name')    then 'select name from nc_attributes where attr_id=#$value$# /*STRICT*/'
               when x.attr_type = 'REF_TO_ATTR_SCHEMA' and (x.action_ is null or lower(x.action_) = 'name')    then 'select name from nc_attr_schemes where attr_schema_id=#$value$# /*STRICT*/'
             end def_src_transform
           , data_source_name
           , pk_table_name
           , pk_primary_key
           , nvl(attr_column, attr_if_multiple) attr_column
           , nvl(show_order_column, show_order_if_multiple) show_order_column
           , instance_name
      from  (
            select x.*
                 , max(decode(x.is_multiple, 'Y', nc_table_name)) over (partition by x.table_id) nc_table_if_multiple
                 , max(attr_column) over (partition by x.table_id) attr_if_multiple
                 , max(show_order_column) over (partition by x.table_id) show_order_if_multiple
                 , row_number() over (partition by table_id, attr_id order by rank, decode(action_, null, 1, 2), column_name) attr_rank
              from (
                    select x.*
                    from  (
                          select /*+ use_nl(a)  */ m.table_id, tbl.table_name, m.column_name, m.attr_id, m.action_, m.data_type, m.data_length,
                                  type2tbl.table_name nc_table_name, type2tbl.storage_column nc_column_name,
                                  case
                                    when nvl(a.ismultiple, 0) = 1 and (m.comments is null or lower(m.comments) not like '%no%multiple%')
                                    then 'Y'
                                  else 'N'
                                  end is_multiple,
                                  nvl(tbl.multiples, 'ROWID') multiples,
                                  case
                                    when lower(m.comments) like '%realtime%' or lower(m.comments) like '%real_time%'
                                    then 'Y'
                                  else 'N'
                                  end is_realtime,
                                  type2tbl.attr_type,
                                  case when attr_types_from.value = 'ATTRIBUTE' then type2tbl.data_type end attr_data_type,
                                  case when attr_types_from.value = 'ATTRIBUTE' then type2tbl.data_length end attr_data_length,
                                  m.id rank,
                                  m.ord,
                                  m.alias,
                                  pk_table.table_name pk_table_name,
                                  pk_table.primary_key pk_primary_key,
                                  pk_table.type_column pk_type_column,
                                  pk_table.data_source_name,
                                  fk_tab.attr_column,
                                  fk_tab.show_order_column,
                                  tbl.instance_name
                          from  (
                                select *
                                from  (
                                      select  m.*,
                                              rank() over (partition by table_id, attr_id order by ord) rnk
                                      from (
                                           select 1 ord, id, table_id, column_name,
                                                  attr_id,
                                                  action_, comments,
                                                  data_type data_type,
                                                  data_length
                                                , attr_type
                                                , alias
                                                , file_name
                                           from rte_mapping m
                                           union all
                                           select 2, -rn*10, m.table_id
                                                , decode(rn, 1, fk_tab.show_order_column, 2, type_column, 3, 'OBJECT_NAME', 4, primary_key)
                                                , decode(rn, 1, fk_tab.show_order_column, 2, type_column, 3, 'NAME', 4, primary_key)
                                                , null, null, null, null
                                                , null
                                                , null
                                                , null
                                           from (select m.table_id,
                                                        a.attr_id,
                                                        m.comments,
                                                        row_number() over (partition by table_id order by nvl(a.ismultiple, 0) desc, isnumber(m.attr_id) desc) row_ord,
                                                        m.attr_type,
                                                        a.type_name
                                                   from rte_mapping m
                                                 left join rte_supported_attributes a on a.attr_id = case when isnumber(m.attr_id) = 1 then m.attr_id end and nvl(a.ismultiple, 0) = 1 and (m.comments is null or lower(m.comments) not like '%no%multiple%')
                                           ) m
                                           left join rte_tables tbl on tbl.table_id = m.table_id -- to get data_source_name
                                           inner join rte_pk_tables pk_table on pk_table.data_source_name = nvl(tbl.data_source_name, 'DEFAULT')
                                           left join rte_fk_tab_attributes type2tbl on type2tbl.data_source_name = pk_table.data_source_name and type2tbl.attr_type = nvl(m.attr_type, m.type_name)
                                           left join rte_fk_tables fk_tab on fk_tab.data_source_name = type2tbl.data_source_name and fk_tab.table_name = type2tbl.table_name
                                           cross join
                                                (select           1 rn from dual
                                                 union all select 2 from dual
                                                 union all select 3 from dual
                                                 union all select 4 from dual)
                                            where row_ord = 1
                                              and (rn<>1 or m.attr_id is not null) /* show_order only in tables for multiple attributes */
                                              and (rn<>1 or fk_tab.show_order_column is not null) /* show_order only when fk table really has one */
                                              and (rn not in (2,3) or m.attr_id is null) /* type_column, name only in non-multiple tables */
                                              and (rn<>3 or exists(select null from user_tab_cols where table_name=pk_table.table_name and column_name=primary_key))
                                           ) m
                                      ) m
                                where rnk = 1
                                ) m
                          left join rte_tables tbl on tbl.table_id = m.table_id -- to get data_source_name
                          inner join rte_pk_tables pk_table on pk_table.data_source_name = nvl(tbl.data_source_name, 'DEFAULT')
                          /* this two step a1, then a join is required so Oracle can do VIEW PUSHED PREDICATE to push a.attr_id into the view. See  */
                          left join nc_attributes a1 on a1.attr_id = case when isnumber(m.attr_id) = 1 then m.attr_id end
                          left join rte_supported_attributes a on a.attr_id = a1.attr_id
                          left join rte_fk_tab_attributes type2tbl on type2tbl.data_source_name = pk_table.data_source_name and type2tbl.attr_type = nvl(m.attr_type, a.type_name)
                          left join rte_fk_tables fk_tab on fk_tab.data_source_name = type2tbl.data_source_name and fk_tab.table_name = type2tbl.table_name
                          left join rte_config_file_params attr_types_from on attr_types_from.file_name = m.file_name and attr_types_from.name = 'DEFAULT_DATA_TYPE_FROM'
                          ) x
                  ) x
            ) x
      left join (select * from user_tab_columns where table_name in (select table_name from rte_pk_tables union all select table_name from rte_fk_tables)) utc
           on utc.table_name =   case
                                   when attr_id=show_order_if_multiple and nc_table_if_multiple is not null then nc_table_if_multiple
                                   else nvl(nc_table_name, pk_table_name)
                                 end
           and utc.column_name = nvl(nc_column_name, attr_id)
      )
) x
/
