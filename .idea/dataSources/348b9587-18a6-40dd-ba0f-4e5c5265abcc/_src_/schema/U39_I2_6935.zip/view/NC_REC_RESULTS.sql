CREATE VIEW NC_REC_RESULTS AS select "TRANSACTION_ID","RESULT","RESULT_NOTES","RESULT_ID" from table(pkgreconciliation.get_nc_rec_results)
/
