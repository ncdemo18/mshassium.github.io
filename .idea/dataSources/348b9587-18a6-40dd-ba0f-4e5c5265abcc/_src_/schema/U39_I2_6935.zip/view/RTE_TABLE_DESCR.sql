CREATE VIEW RTE_TABLE_DESCR AS select distinct table_name, 'NC_OBJECTS' pk_table, 'OBJECT_TYPE_ID' type_column
  from rte_tab_cols where src_table in ('NC_OBJECTS', 'NC_PARAMS', 'NC_REFERENCES', 'NC_META_REFERENCES')
/
