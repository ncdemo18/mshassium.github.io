CREATE VIEW RTE$TAB_COLS_REL_RENAME AS select /*+ cardinality(q 1) */
  RANK,
  o.table_id,
  nvl(t.new_name, o.table_name) TABLE_NAME,
  nvl(c.new_name, o.column_name) COLUMN_NAME,
  o.table_name OLD_TABLE_NAME,
  o.column_name OLD_COLUMN_NAME,
  ATTR_ID,
  SRC_TABLE,
  SRC_EXPRESSION,
  ATTR_TYPE,
  ALIAS,
  IS_MULTIPLE,
  IS_SUPER_MULTIPLE,
  MULTIPLES,
  IS_REALTIME,
  TABLE_IS_MULTIPLE,
  IS_PRIMARY_KEY,
  ATTR_RANK,
  SQL_TYPE,
  SQL_LENGTH,
  NC_SQL_TYPE,
  NC_SQL_LENGTH,
  case when tc.new_name is not null then
     regexp_substr(o.src_transform, '^[st]\.', 1, 1, 'i')||tc.new_name
     else o.src_transform
  end SRC_TRANSFORM,
  o.src_transform OLD_SRC_TRANSFORM,
  DATA_SOURCE_NAME,
  PK_TABLE_NAME,
  PK_PRIMARY_KEY,
  ATTR_COLUMN,
  SHOW_ORDER_COLUMN,
  o.INSTANCE_NAME,
  SQL_FULLTYPE,
  NC_SQL_FULLTYPE
 from rte$tab_cols_rel o
    , rte_rename_table t
    , rte_rename_column c
    , rte_rename_table rt2
    , rte_rename_column rc2
    -- TODO: improve rename detection for relation actions
    -- currently this code handles only "t.COLUMN_NAME" and "s.COLUMN_NAME" expressions and other renames are undetected
    , rte$_relations r
    , table(tableof2strings(pairofstrings(
        case when upper(o.src_transform) like 'S.%' then r.target_table_id
             else r.target_table_id
        end,
        case when regexp_like(o.src_transform, '[st]\.', 'i')
             then upper(substr(o.src_transform, 3)) else o.src_transform end
        ))
      ) q
    , rte_rename_column tc
 where t.session_id(+) = sys_context('userenv', 'client_info')
  and t.table_id(+) = o.table_id
  -- when a table is dropped and another is renamed to its name,
  -- we avoid returning dropped table
  and rt2.new_name(+) = o.table_name
  and rt2.session_id(+) = sys_context('userenv', 'client_info')
  and (rt2.new_name is null or t.new_name is not null)
  and c.session_id(+) = sys_context('userenv', 'client_info')
  and c.table_id(+) = o.table_id
  and c.old_name(+) = o.column_name
  -- when column is dropped and anoter is renamed to its name,
  -- we avoid returning dropped column
  and rc2.session_id(+) = sys_context('userenv', 'client_info')
  and rc2.table_id(+) = o.table_id
  and rc2.new_name(+) = o.column_name
  and (rc2.new_name is null or c.new_name is not null)
  and r.name(+) = o.attr_id
  and r.instance_name (+) = o.instance_name
  and tc.session_id(+) = sys_context('userenv', 'client_info')
  and tc.table_id(+) = q.field1
  and tc.old_name(+)   = q.field2
/
