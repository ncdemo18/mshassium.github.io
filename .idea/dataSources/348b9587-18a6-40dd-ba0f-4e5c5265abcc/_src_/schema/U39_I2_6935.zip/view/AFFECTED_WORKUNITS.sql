CREATE VIEW AFFECTED_WORKUNITS AS select /*+ index(impact xif76nc_params)*/
    workunits.object_id as workunit_id,
    timeslots.object_id as timeslot_id,
    timeslots.parent_id as resource_group_id,
    worksch.parent_id as work_schedule_id,
    impact.list_value_id as status
  from nc_objects workunits, nc_objects timeslots, nc_params impact,
  nc_references workcom, nc_objects worksch, nc_list_values lvs
  where workunits.object_type_id in (
    select ts.object_type_id from nc_object_types ts
    start with ts.object_type_id = 9102266442013844231/*Work Units*/
    connect by prior ts.object_type_id = ts.parent_id
  )
  and impact.attr_id = 9124640073213865347/*Impact*/
  and workunits.object_id = impact.object_id
  and impact.list_value_id = lvs.list_value_id
  and lvs.attr_type_def_id = 9124640073213865342
  and lvs.list_value_id != 9124640073213865343/*None*/
  and timeslots.object_id = workunits.parent_id
  and workcom.attr_id(+) = 9124631985213865024/*Resource Group*/
  and workcom.reference(+) = timeslots.parent_id
  and worksch.object_id(+) = workcom.object_id
/
