CREATE VIEW RTE_N2N_OT_V AS select filter_id, object_type_id
     , exclude
from (
select /*+ cardinality(x 2) */
       t.filter_id
     , t.object_type_id
     -- The row for particular object_type_id for specific filter_id with lowest level is most important
     , max(t.exclude) keep (dense_rank first order by t.ot_level) exclude
  from (
  select /*+ cardinality(x 2) */
         t.filter_id
       , x.field1 object_type_id
       , t.exclude
       , x.field2 ot_level
    from (select * from rte_n2n_ot) t
      , table(cast(multiset
      (
        select pairofnumbers(object_type_id, level)
          from nc_object_types s
         start with object_type_id = t.object_type_id
       connect by prior object_type_id = parent_id
                    and (t.children <> 'CLASS' or nvl(isclass, 0) = 0)
                    and (t.children <> 'NONE')
                    and not exists (
                      -- We do not need to connect hierarchy in case there is specific row to include object_type
                      -- That row would be considered in "t" above
                      select /*+ index(q FILTER_OT__RTE_N2N_OT)*/  object_type_id
                        from rte_n2n_ot q
                       where filter_id = t.filter_id
                         and object_type_id = s.object_type_id
                         and exclude = 'N'
                    )
      ) as tableof2numbers)
       -- WA for Oracle 10g. Without this WA it uses index FULL SCAN in "start with"
       multiset union all tableof2numbers()
      )(+) x
      union all
        -- All filters that have only "exclude=Y" have implicit "include all but excluded" meaning
        select /*+ index_ffs(s) */ t.filter_id
             , s.object_type_id
             , 'N' exclude
             , 10000 ot_level
         from (select filter_id, max(exclude) from rte_n2n_ot group by filter_id having min(exclude)='Y') t
            , nc_object_types s
        where 1 = 1 -- Merge join cartesian for nc_object_types is expected
  ) t
  group by filter_id, t.object_type_id
) ots
/
