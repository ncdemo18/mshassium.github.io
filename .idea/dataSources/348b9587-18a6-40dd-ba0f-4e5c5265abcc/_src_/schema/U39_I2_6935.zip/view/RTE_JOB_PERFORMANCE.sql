CREATE VIEW RTE_JOB_PERFORMANCE AS select x."REFRESH_STARTED",x."TOTAL_DURATION",x."MLOG_DURATION",x."REFRESH_DURATION",x."INPUT_ROWS",x."FILTERED_INPUT_ROWS",x."MLOG_THREADS",x."REFRESH_THREADS",x."DURATION_AS_SECONDS"
    , case when duration_as_seconds>0 then to_char(input_rows/duration_as_seconds, '9999999999') end input_rows_per_sec
    , case when duration_as_seconds>0 then to_char(filtered_input_rows/duration_as_seconds, '9999999999') end filtered_rows_per_sec
from (
select x.*
     , extract (day from total_duration) * 86400 + extract (hour from total_duration) * 3600 + extract (minute from total_duration) * 60 + extract (second from total_duration)
       duration_as_seconds
 from (
select min(ts) refresh_started,
       max(ts+numtodsinterval(nvl(refresh_time/100, 0)+nvl(mlog_update_time/100, 0), 'SECOND'))-min(ts) total_duration,
       max(case when mlog_update_time is not null then ts+numtodsinterval(mlog_update_time/100, 'SECOND') end)-
       min(case when mlog_update_time is not null then ts end)
         mlog_duration,
       max(case when refresh_time is not null then ts+numtodsinterval(refresh_time/100, 'SECOND') end)-
       min(case when refresh_time is not null then ts end)
         refresh_duration,
       sum(case when mlog_update_time is not null then objects+params+references end) input_rows,
       sum(case when refresh_time is not null then objects+params+references end) filtered_input_rows,
       count(mlog_update_time) mlog_threads,
       count(refresh_time) refresh_threads
  from rte_status where objects>0 or params>0 or references>0
 group by current_scn
order by 1 desc
) x
) x
/
