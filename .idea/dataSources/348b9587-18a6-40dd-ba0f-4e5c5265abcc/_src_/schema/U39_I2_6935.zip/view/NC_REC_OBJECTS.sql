CREATE VIEW NC_REC_OBJECTS AS select "TRANSACTION_ID","NAME","OBJECT_ID","PARENT_ID","OBJECT_TYPE_ID","ACTION" from table(pkgreconciliation.get_nc_rec_objects)
/
