CREATE VIEW NC_TRANSITION_HISTORY AS select table_set_ref.reference as table_set_id,
       int_session_id.value as integration_session_id,
       int_session_id.value as dataflow_session_id,
       s.object_id as transition_object_id,
       s.object_type_id as transition_object_type_id,
       to_timestamp(end_time.date_value) as finish_time
  from nc_objects    s,
       nc_params     end_time,
       nc_params     int_session_id,
       nc_references table_set_ref
 where object_type_id in (8091249192013839906 /* Validation Session */, 9062238171013116543 /* Transformation Session */)
   and s.object_id = end_time.object_id
   and end_time.attr_id = 9062260383013117447 /* End Time */
   and table_set_ref.object_id = s.object_id
   and table_set_ref.attr_id = 9062355060013090876 /* Table Set */
   and int_session_id.attr_id(+) = 9080751104013183036 /* Integration Session ID */
   and int_session_id.object_id(+) = s.object_id
/
