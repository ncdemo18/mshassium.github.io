CREATE VIEW NC_REC_PATTERNS AS select "TRANSACTION_ID","CASE_ID","PATTERN_ID","DISCREPANCY_ID" from table(pkgreconciliation.get_nc_rec_patterns)
/
