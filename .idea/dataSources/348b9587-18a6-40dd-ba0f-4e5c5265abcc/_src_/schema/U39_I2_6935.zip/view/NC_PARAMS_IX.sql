CREATE VIEW NC_PARAMS_IX AS select p."ATTR_ID",p."OBJECT_ID",p."ATTR_ACCESS_TYPE",p."VALUE",p."DATA",p."LIST_VALUE_ID",p."SHOW_ORDER",p."DATE_VALUE",p."PRIORITY", coalesce(to_char(date_value,'YYYYMMDDHH24MISS'), to_char(list_value_id),upper(substr(value,1,50))) ix_key from nc_params p
/
