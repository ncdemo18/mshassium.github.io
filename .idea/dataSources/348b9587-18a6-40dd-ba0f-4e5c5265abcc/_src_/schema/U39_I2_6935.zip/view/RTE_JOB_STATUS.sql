CREATE VIEW RTE_JOB_STATUS AS select 'Latest error messages from rte_log:' title, value status from (
    select /*+ no_merge no_eliminate_oby */ to_char(log_date||' ('||rte_parallel_execution.format_interval(cast(systimestamp as timestamp)-log_date, 0)|| ' ago, sid: '||sid||') '||substr(log_message, 1, 3500)) value, rownum rn from (
      select /*+ index_desc(s) */ s.*, case when log_level>=4 then log_date end error_date
      from rte_log s
    )
    where error_date is not null
                            and (rownum<10 or (rownum<20 and error_date>(select i.current_timestamp from rte_instance i)))
    order by log_date
  ) union all
  select 'Job status:' title, rte_parallel_execution.calc_job_attr('RTE_REFRESH_JOB', 'chainjob_status') value from dual union all
  select 'Job schedule:' title, rte_parallel_execution.calc_job_attr('RTE_REFRESH_JOB', 'schedule') value from dual union all
  select 'Plain table staleness:' title, rte_parallel_execution.calc_job_attr('RTE_REFRESH_JOB', 'data_staleness') value from dual union all
  select 'Last start:' title, rte_parallel_execution.calc_job_attr('RTE_REFRESH_JOB', 'last_start') value from dual union all
  select 'Last successful finish:' title, (
    select case when i.successful_finish_timestamp is null then 'n/a' else i.successful_finish_timestamp||' ('||rte_parallel_execution.relative_timestamp(i.successful_finish_timestamp)||')' end value
    from rte_instance i
  ) value from dual union all
  select 'Next run:' title, rte_parallel_execution.calc_job_attr('RTE_REFRESH_JOB', 'next_run') value from dual union all
  select 'Run count:' title, rte_parallel_execution.calc_job_attr('RTE_REFRESH_JOB', 'run_count') value from dual union all
  select 'Max parallelism:' title, nvl(to_char(max_parallelism), 'n/a') from rte_instance union all
  select 'Rows to process:' title, to_char(target_mlog_rows) from rte_instance union all
  select 'Running step:' title, v.value status from (
                                                      select step_name||', duration: '||rte_parallel_execution.format_interval(coalesce(end_date, systimestamp) - start_date, 0)||
                                                             ' (started at '||start_date||')'||
                                                             case when lo.sid is not null then
                                                               ', '||lo.sofar||' of '||lo.totalwork||' '||lo.units||' complete. '||lo.time_remaining||' seconds left (estimated finish time is '||(systimestamp+numtodsinterval(lo.time_remaining, 'SECOND'))||')'
                                                             end
                                                        value
                                                      from user_scheduler_running_chains c, user_scheduler_running_jobs j, gv$session_longops lo
                                                      where c.job_name = 'RTE_REFRESH_JOB'
                                                            and c.state = 'RUNNING'
                                                            and j.job_name(+) = c.job_name
                                                            and j.job_subname(+) = c.step_name
                                                            and lo.sid(+) = session_id
                                                            and lo.inst_id(+) = running_instance
                                                            and decode(lo.sofar(+), lo.totalwork(+), 1) is null
                                                      order by step_name
                                                    ) v union all
  select 'Exception:' title, value from (
    select /*+ no_merge */ d.log_date||' ('||rte_parallel_execution.format_interval(systimestamp-d.log_date, 0)||' ago), state: '||c.state||', '||additional_info value
    from user_scheduler_running_chains c, user_scheduler_job_run_details d
    where c.job_name = 'RTE_REFRESH_JOB'
          and d.log_id = c.step_job_log_id
  ) union all
  select 'Recovery Job status:' title, rte_parallel_execution.calc_job_attr('RTE_RECOVER_JOB', 'job_status') value from dual union all
  select 'Recovery Job schedule:' title, rte_parallel_execution.calc_job_attr('RTE_RECOVER_JOB', 'schedule') value from dual union all
  select 'Recovery Last start:' title, rte_parallel_execution.calc_job_attr('RTE_RECOVER_JOB', 'last_start') value from dual union all
  select 'Recovery Next run:' title, rte_parallel_execution.calc_job_attr('RTE_RECOVER_JOB', 'next_run') value from dual union all
  select 'Recovery Run count:' title, rte_parallel_execution.calc_job_attr('RTE_RECOVER_JOB', 'run_count') value from dual union all
  select 'Number of recovery attempts:' title, to_char(nvl(recovery_count,0)) from rte_instance
/
