CREATE FUNCTION rte_to_number(num varchar2)
  RETURN number DETERMINISTIC parallel_enable
IS
BEGIN
    if num is null then
      return null;
    end if;
    return to_number(num);
  exception when others then
    return null;
END;
/
