CREATE FUNCTION          "GETLOCATION" (p_Object_ID in number) return varchar2 is
    path varchar2(2000);
    pth varchar2(2000);
--		parent  varchar2(2000);
    top number;
    project number;
    cursor cur01(did number) is
        select name
        from nc_objects
        where parent_id = top
        start with object_id=did
        connect by prior parent_id=object_id;

-- select name from nc_objects where parent_id = top;
begin
    select project_id
    into project
    from nc_objects
    where object_id = p_Object_ID;
    select object_id
    into top
    from nc_objects
    where name = 'Top' and
    project_id = project;
--		select parent_id into parent from nc_objects where object_id = p_Object_ID;
    OPEN cur01(p_Object_ID);
    LOOP
        FETCH cur01 into pth;
        EXIT WHEN cur01%NOTFOUND;
        path:=pth||'\'||path;
    END LOOP;
    CLOSE cur01;
    path:=substr(path,0,length(path)-1);
    return path;
end;




/
