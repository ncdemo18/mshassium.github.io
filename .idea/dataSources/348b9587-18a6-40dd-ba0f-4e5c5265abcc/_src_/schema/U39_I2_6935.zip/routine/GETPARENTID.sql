CREATE FUNCTION          "GETPARENTID" (object_id number, type_ids varchar2 ) return number is

        CURSOR path_cur(id number) is
            select obj.object_id, obj.object_type_id, obj.object_class_id
            from nc_objects obj
            start with object_id=id
            connect by prior parent_id=object_id;

       chassis_id number;
begin
    chassis_id := object_id;
    for path_rec in path_cur(object_id) loop
         if instr(type_ids,'|'||path_rec.object_type_id||'|') > 0
         then
         begin
         chassis_id := path_rec.object_id;
         EXIT;
         end;
         end if;
    end loop;
    return chassis_id;
end;




/
