CREATE function nc_cmt_ct_in_scope(
  p_scope_id in number,
  p_table_name in varchar2,
  p_arr in NC_CMT_Hash_Table,
  p_ci_id in varchar2,
  p_ci_table_name in varchar2,
  p_ci_key in varchar2) return boolean
is
begin
  return pkg_cmt_ct_config_scope.in_scope(
    p_scope_id,
    p_table_name,
    p_arr ,
    p_ci_id,
    p_ci_table_name,
    p_ci_key);
end nc_cmt_ct_in_scope;
/
