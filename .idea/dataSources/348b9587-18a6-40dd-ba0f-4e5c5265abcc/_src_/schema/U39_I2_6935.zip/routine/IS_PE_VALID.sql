CREATE FUNCTION is_pe_valid(car1_id number, car2_id number) return number is

cursor get_btype(obj number) is
 select /*+ncid.pl:is_pd.get_e*/ object_type_id
 from nc_object_types
 where parent_id=0 or object_type_id=116328 or object_type_id=3061830882013808530
 start with object_type_id in
  (
     select object_type_id
     from nc_objects
     where object_id=obj
  )
 connect by prior object_type_id!=116328 and prior object_type_id!=3061830882013808530 and prior parent_id=object_type_id;

cursor get_aggr_attrs(obj number) is
select /*+ncid.pl:is_pd.get_s*/ substr(properties,instr(properties, 'aggregate_attrs=')+16) "val"
from nc_object_types
where instr(properties, 'aggregate_attrs=') > 0
start with object_type_id in
(
    select object_type_id
    from nc_objects
    where object_id=obj
)
connect by prior object_type_id!=3061830882013808530 and prior parent_id=object_type_id;

-----------------------------------------------------

  cursor is_port_port(port1 number, port2 number) is
    select /*+ncid.pl:is_pd.is_pt*/ p1.object_id
    from
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select *
        from nc_objects
        start with object_id=port1
        connect by prior parent_id=object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p1,
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select *
        from nc_objects
        start with object_id=port2
        connect by prior parent_id=object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p2
    where
     p1.object_id=p2.object_id;

----------------------------------------------------

  cursor is_cable_cable(cable1 number, cable2 number) is
    select /*+ncid.pl:is_pd.is_ce*/ p1.object_id
    from
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select no.*
        from nc_objects no
        start with no.object_id in
          (
            select ncd2.object_id
            from
              nc_objects no1,
              nc_connection_data ncd1,
              nc_connection_data ncd2
            where
              no1.parent_id=cable1
              and ncd1.connector_id=no1.object_id
              and ncd2.link_id=ncd1.link_id
              and ncd2.connector_id!=ncd1.connector_id
          )
        connect by prior no.parent_id=no.object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p1,
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select no.*
        from nc_objects no
        start with no.object_id in
          (
            select ncd2.object_id
            from
              nc_objects no1,
              nc_connection_data ncd1,
              nc_connection_data ncd2
            where
              no1.parent_id=cable2
              and ncd1.connector_id=no1.object_id
              and ncd2.link_id=ncd1.link_id
              and ncd2.connector_id!=ncd1.connector_id
          )
        connect by prior no.parent_id=no.object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p2
    where
     p1.object_id=p2.object_id;


---------------------------------------------------------------

  cursor is_port_cable(port1 number, cable2 number) is
    select /*+ncid.pl:is_pd.is_pe*/ p1.object_id
    from
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select *
        from nc_objects
        start with object_id=port1
        connect by prior parent_id=object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p1,
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select no.*
        from nc_objects no
        start with no.object_id in
          (
            select ncd2.object_id
            from
              nc_objects no1,
              nc_connection_data ncd1,
              nc_connection_data ncd2
            where
              no1.parent_id=cable2
              and ncd1.connector_id=no1.object_id
              and ncd2.link_id=ncd1.link_id
              and ncd2.connector_id!=ncd1.connector_id
          )
        connect by prior no.parent_id=no.object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p2
    where
     p1.object_id=p2.object_id;

---------------------------------------------------------------

  cursor is_port_device(port1 number, device2 number) is
    select /*+ncid.pl:is_pd.is_pe*/ p1.object_id
    from
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select *
        from nc_objects
        start with object_id=port1
        connect by prior parent_id=object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p1
    where
     p1.object_id=device2;

-----------------------------------------------------------------

  cursor is_cable_device(cable1 number, device2 number) is
    select /*+ncid.pl:is_pd.is_ce*/ p1.object_id
    from
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select no.*
        from nc_objects no
        start with no.object_id in
          (
            select ncd2.object_id
            from
              nc_objects no1,
              nc_connection_data ncd1,
              nc_connection_data ncd2
            where
              no1.parent_id=cable1
              and ncd1.connector_id=no1.object_id
              and ncd2.link_id=ncd1.link_id
              and ncd2.connector_id!=ncd1.connector_id
          )
        connect by prior no.parent_id=no.object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p1
    where
     p1.object_id=device2;

--------------------------------------------------------------

  cursor is_cable_circuit(cable1 number, circuit2 number) is
    select /*+ncid.pl:is_pd.is_ct*/ p1.object_id
    from
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select no.*
        from nc_objects no
        start with no.object_id in
          (
            select ncd2.object_id
            from
              nc_objects no1,
              nc_connection_data ncd1,
              nc_connection_data ncd2
            where
              no1.parent_id=cable1
              and ncd1.connector_id=no1.object_id
              and ncd2.link_id=ncd1.link_id
              and ncd2.connector_id!=ncd1.connector_id
          )
        connect by prior no.parent_id=no.object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p1,
    (
select w1.object_id
from
(
select *
from nc_objects
start with object_id in
(
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=600 or object_type_id=116328
  connect by prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
)
connect by prior parent_id=object_id
) w1,
nc_objects no
where
 w1.parent_id=no.object_id
 and w1.object_class_id=301
 and no.object_class_id=300
union all
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=301
  connect by object_type_id!=116328 and prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
    ) p2
    where
     p1.object_id=p2.object_id;

  cursor is_circuit_circuit(circuit1 number, circuit2 number) is
    select /*+ncid.pl:is_pd.is_ct*/ p1.object_id
    from
    (
select w1.object_id
from
(
select *
from nc_objects
start with object_id in
(
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=600 or object_type_id=116328
  connect by prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit1
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
)
connect by prior parent_id=object_id
) w1,
nc_objects no
where
 w1.parent_id=no.object_id
 and w1.object_class_id=301
 and no.object_class_id=300
union all
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=301
  connect by object_type_id!=116328 and prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit1
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
    ) p1,
    (
select w1.object_id
from
(
select *
from nc_objects
start with object_id in
(
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=600 or object_type_id=116328
  connect by prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
)
connect by prior parent_id=object_id
) w1,
nc_objects no
where
 w1.parent_id=no.object_id
 and w1.object_class_id=301
 and no.object_class_id=300
union all
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=301
  connect by object_type_id!=116328 and prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
    ) p2
    where
     p1.object_id=p2.object_id;

---------------------------------------

  cursor is_port_circuit(port1 number, circuit2 number) is
    select /*+ncid.pl:is_pd.is_pt*/ p1.object_id
    from
    (
    select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
    from
      (
        select *
        from nc_objects
        start with object_id=port1
        connect by prior parent_id=object_id
      ) w1,
      nc_objects no
    where
      w1.parent_id=no.object_id
      and w1.object_class_id=301
      and no.object_class_id=300
    ) p1,
    (
select w1.object_id
from
(
select *
from nc_objects
start with object_id in
(
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=600 or object_type_id=116328
  connect by prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
)
connect by prior parent_id=object_id
) w1,
nc_objects no
where
 w1.parent_id=no.object_id
 and w1.object_class_id=301
 and no.object_class_id=300
union all
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=301
  connect by object_type_id!=116328 and prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
    ) p2
    where
     p1.object_id=p2.object_id;

-----------------------------------------------

  cursor is_device_circuit(device1 number, circuit2 number) is
    select /*+ncid.pl:is_pd.is_dt*/ p1.object_id
    from
    (
select w1.object_id
from
(
select *
from nc_objects
start with object_id in
(
select no2.object_id
from
 nc_objects no,
 nc_objects no2,

 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=600 or object_type_id=116328
  connect by prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
)
connect by prior parent_id=object_id
) w1,
nc_objects no
where
 w1.parent_id=no.object_id
 and w1.object_class_id=301
 and no.object_class_id=300
union all
select no2.object_id
from
 nc_objects no,
 nc_objects no2,
 nc_references nr,
 (select *
  from nc_object_types
  start with object_type_id=301
  connect by object_type_id!=116328 and prior object_type_id=parent_id
 ) ots
where
 no.parent_id=circuit2
 and no.object_class_id=9
 and nr.object_id=no.object_id
 and nr.attr_id=14
 and nr.reference=no2.object_id
 and no2.object_type_id=ots.object_type_id
    ) p1
    where
     p1.object_id=device1;

--------------------------------------------
  cursor is_cable_ne(cable1 number, ne2 number, aggr_attrs varchar2) is
    select /*+ncid.pl:is_pd.is_ce*/ p1.object_id
    from
    (
        select w1.object_id, w1.name, w1.object_type_id, w1.object_class_id
        from
        (
            select no.*
            from nc_objects no
            start with no.object_id in
            (
                select ncd2.object_id
                from
                    nc_objects no1,
                    nc_connection_data ncd1,
                    nc_connection_data ncd2
                where
                    no1.parent_id=cable1
                    and ncd1.connector_id=no1.object_id
                    and ncd2.link_id=ncd1.link_id
                    and ncd2.connector_id!=ncd1.connector_id
            )
            connect by prior no.parent_id=no.object_id
        ) w1,
        nc_objects no
        where
            w1.parent_id=no.object_id
            and w1.object_class_id=301
            and no.object_class_id=300
    ) p1,
-- DMBOSDG to support both NE models
    (select object_id, reference
     from nc_references
     where reference=ne2
     and instr(aggr_attrs,to_char(attr_id)) > 0
     union
     select reference, object_id
     from nc_references
     where object_id=ne2
     and attr_id = 30402
     ) ref
     where
        p1.object_id=ref.object_id;
--        and ref.reference=ne2
--        and instr(aggr_attrs,to_char(ref.attr_id)) > 0;
-- DMBOSDG to support both NE models End

  cursor is_ne_circuit(ne1 number, circuit2 number, aggr_attrs varchar2) is
    select /*+ncid.pl:is_pd.is_nt*/ p1.object_id
    from
    (
        select w1.object_id
        from
        (
            select *
            from nc_objects
            start with object_id in
            (
                select no2.object_id
                from
                    nc_objects no,
                    nc_objects no2,
                    nc_references nr,
                    (select * from nc_object_types
                     start with object_type_id=600 or object_type_id=116328
                     connect by prior object_type_id=parent_id
                    ) ots
                where
                    no.parent_id=circuit2
                    and no.object_class_id=9
                    and nr.object_id=no.object_id
                    and nr.attr_id=14
                    and nr.reference=no2.object_id
                    and no2.object_type_id=ots.object_type_id
            )
            connect by prior parent_id=object_id
        ) w1,
        nc_objects no
        where
            w1.parent_id=no.object_id
            and w1.object_class_id=301
            and no.object_class_id=300
        union all
        select no2.object_id
        from
            nc_objects no,
            nc_objects no2,
            nc_references nr,
            (select * from nc_object_types
             start with object_type_id=301
             connect by object_type_id!=116328 and prior object_type_id=parent_id
            ) ots
        where
            no.parent_id=circuit2
            and no.object_class_id=9
            and nr.object_id=no.object_id
            and nr.attr_id=14
            and nr.reference=no2.object_id
            and no2.object_type_id=ots.object_type_id
    ) p1,
-- DMBOSDG to support both NE models
    (select object_id, reference
     from nc_references
     where reference=ne1
     and instr(aggr_attrs,to_char(attr_id)) > 0
     union
     select reference, object_id
     from nc_references
     where object_id=ne1
     and attr_id = 30402
     ) ref
--    nc_references ref
    where
        p1.object_id=ref.object_id;
--        and ref.reference=ne1
--        and instr(aggr_attrs,to_char(ref.attr_id)) > 0;
-- DMBOSDG to support both NE models end

---------------------------------------------
-- DMBOSDG Add to support prewiring
  cursor is_ne_device(ne1 number, device2 number, aggr_attrs varchar2) is
    select /*+ncid.pl:is_pd.is_ne*/ ne_ports.object_id
    from
   (
    select object_id
    from nc_objects
    where object_class_id in (600, 176) -- port, connectors
    start with object_id in
    (
         select devices.object_id
         from
            nc_objects devices,
            (select object_id, reference
             from nc_references
             where reference=ne1
             and instr(aggr_attrs,to_char(attr_id)) > 0
             union
             select reference, object_id
             from nc_references
             where object_id=ne1
             and attr_id = 30402
            ) ref
             where
        devices.object_id=ref.object_id
        and devices.object_class_id = 301
     )
     connect by prior object_id = parent_id
   ) ne_ports,
   (
    select object_id
    from nc_objects
     where object_class_id in (600, 176) -- port, connectors
     start with object_id = device2
     connect by prior object_id = parent_id
    ) device_ports,
    (select object_id, reference
     from nc_references
     where attr_id=3012935634013428525 -- prewiredTo
     union
     select reference, object_id
     from nc_references
     where attr_id=3012935634013428525
     ) ref
    where
    ne_ports.object_id=ref.object_id
    and device_ports.object_id = ref.reference;
-- DMBOSDG to support both NE models End

--------------------------------------------

ipp is_port_port%ROWTYPE;
icc is_cable_cable%ROWTYPE;
icici is_circuit_circuit%ROWTYPE;

ipc is_port_cable%ROWTYPE;
ipd is_port_device%ROWTYPE;
icd is_cable_device%ROWTYPE;
icci is_cable_circuit%ROWTYPE;
ipci is_port_circuit%ROWTYPE;
idci is_device_circuit%ROWTYPE;
icn is_cable_ne%ROWTYPE;
inc is_ne_circuit%ROWTYPE;
ind is_ne_device%ROWTYPE;

car1_type nc_object_types.object_type_id%TYPE;
car2_type nc_object_types.object_type_id%TYPE;

aggr_attrs nc_object_types.properties%TYPE;
ret1 number;


---------------------------------------------------------------------------

begin
  ret1:=0;

  open get_btype(car1_id);
  fetch get_btype into car1_type;
  close get_btype;

  open get_btype(car2_id);
  fetch get_btype into car2_type;
  close get_btype;

  if car1_type=176 then
  car1_type:=600;
  end if;
  if car2_type=176 then
  car2_type:=600;
  end if;
  DBMS_OUTPUT.put_line('c1 '||car1_type||' c2 '||car2_type);
  if (car1_type=600 or car1_type=116328) and (car2_type=600 or car2_type=116328) then
  -- port-port
    open is_port_port(car1_id,car2_id);
    fetch is_port_port into ipp;
    if is_port_port%FOUND then
      ret1:=1;
    end if;
    close is_port_port;
  elsif car1_type=174 and car2_type=174 then
  -- cable-cable
    open is_cable_cable(car1_id,car2_id);
    fetch is_cable_cable into icc;
    if is_cable_cable%FOUND then
      ret1:=1;
    end if;
    close is_cable_cable;
  elsif car1_type=173 and car2_type=173 then
  -- device-device
    if car1_id=car2_id then
      ret1:=1;
    end if;
  elsif car1_type=8 and car2_type=8 then
  -- circuit-circuit
    open is_circuit_circuit(car1_id,car2_id);
    fetch is_circuit_circuit into icici;
    if is_circuit_circuit%FOUND then
      ret1:=1;
    end if;
    close is_circuit_circuit;
  elsif (car1_type=600 or car1_type=116328) and car2_type=174 then
  -- port-cable
    open is_port_cable(car1_id,car2_id);
    fetch is_port_cable into ipc;
    if is_port_cable%FOUND then
      ret1:=1;
    end if;
    close is_port_cable;
  elsif car1_type=174 and (car2_type=600 or car2_type=116328) then
  -- cable-port
    open is_port_cable(car2_id,car1_id);
    fetch is_port_cable into ipc;
    if is_port_cable%FOUND then
      ret1:=1;
    end if;
    close is_port_cable;
  elsif car1_type=173 and (car2_type=600 or car2_type=116328) then
  -- device-port
    open is_port_device(car2_id,car1_id);
    fetch is_port_device into ipd;
    if is_port_device%FOUND then
      ret1:=1;
    end if;
    close is_port_device;
  elsif (car1_type=600 or car1_type=116328) and car2_type=173 then
  -- port-device
    open is_port_device(car1_id,car2_id);
    fetch is_port_device into ipd;
    if is_port_device%FOUND then
      ret1:=1;
    end if;
    close is_port_device;
  elsif car1_type=173 and car2_type=174 then
  -- device-cable
    open is_cable_device(car2_id,car1_id);
    fetch is_cable_device into icd;
    if is_cable_device%FOUND then
      ret1:=1;
    end if;
    close is_cable_device;
  elsif car1_type=174 and car2_type=173 then
  -- cable-device
    open is_cable_device(car1_id,car2_id);
    fetch is_cable_device into icd;
    if is_cable_device%FOUND then
      ret1:=1;
    end if;
    close is_cable_device;
  elsif car1_type=8 and car2_type=174 then
  -- circuit-cable
    open is_cable_circuit(car2_id,car1_id);
    fetch is_cable_circuit into icci;
    if is_cable_circuit%FOUND then
      ret1:=1;
    end if;
    close is_cable_circuit;
  elsif car1_type=174 and car2_type=8 then
  -- cable-circuit
    open is_cable_circuit(car1_id,car2_id);
    fetch is_cable_circuit into icci;
    if is_cable_circuit%FOUND then
      ret1:=1;
    end if;
    close is_cable_circuit;
  elsif car1_type=8 and (car2_type=600 or car2_type=116328) then
  -- circuit-port
    open is_port_circuit(car2_id,car1_id);
    fetch is_port_circuit into ipci;
    if is_port_circuit%FOUND then
      ret1:=1;
    end if;
    close is_port_circuit;
  elsif (car1_type=600 or car1_type=116328) and car2_type=8 then
  -- port-circuit
    open is_port_circuit(car1_id,car2_id);
    fetch is_port_circuit into ipci;
    if is_port_circuit%FOUND then
      ret1:=1;
    end if;
    close is_port_circuit;
  elsif car1_type=8 and car2_type=173 then
  -- circuit-device
    open is_device_circuit(car2_id,car1_id);
    fetch is_device_circuit into idci;
    if is_device_circuit%FOUND then
      ret1:=1;
    end if;
    close is_device_circuit;
  elsif car1_type=173 and car2_type=8 then
  -- device-circuit
    open is_device_circuit(car1_id,car2_id);
    fetch is_device_circuit into idci;
    if is_device_circuit%FOUND then
      ret1:=1;
    end if;
    close is_device_circuit;
-----------------------------------
  elsif car1_type=174 and car2_type=3061830882013808530 then
  -- cable-ne
    open get_aggr_attrs(car2_id);
    fetch get_aggr_attrs into aggr_attrs;
    close get_aggr_attrs;
    open is_cable_ne(car1_id,car2_id, aggr_attrs);
    fetch is_cable_ne into icn;
    if is_cable_ne%FOUND then
      ret1:=1;
    end if;
    close is_cable_ne;
  elsif car1_type=3061830882013808530 and car2_type=174 then
  -- ne-cable
    open get_aggr_attrs(car1_id);
    fetch get_aggr_attrs into aggr_attrs;
    close get_aggr_attrs;
    open is_cable_ne(car2_id,car1_id,aggr_attrs);
    fetch is_cable_ne into icn;
    if is_cable_ne%FOUND then
      ret1:=1;
    end if;
    close is_cable_ne;
  elsif car1_type=8 and car2_type=3061830882013808530 then
  -- circuit-ne
    open get_aggr_attrs(car2_id);
    fetch get_aggr_attrs into aggr_attrs;
    close get_aggr_attrs;
    open is_ne_circuit(car2_id,car1_id,aggr_attrs);
    fetch is_ne_circuit into inc;
    if is_ne_circuit%FOUND then
      ret1:=1;
    end if;
    close is_ne_circuit;
  elsif car1_type=3061830882013808530 and car2_type=8 then
  -- ne-circuit
    open get_aggr_attrs(car1_id);
    fetch get_aggr_attrs into aggr_attrs;
    close get_aggr_attrs;
    open is_ne_circuit(car1_id,car2_id,aggr_attrs);
    fetch is_ne_circuit into inc;
    if is_ne_circuit%FOUND then
      ret1:=1;
    end if;
    close is_ne_circuit;
  elsif car1_type=3061830882013808530 and car2_type=173 then
  -- ne-device (prewiredTo)
    open get_aggr_attrs(car1_id);
    fetch get_aggr_attrs into aggr_attrs;
    close get_aggr_attrs;
    open is_ne_device(car1_id,car2_id,aggr_attrs);
    fetch is_ne_device into ind;
    if is_ne_device%FOUND then
      ret1:=1;
    end if;
    close is_ne_device;
  elsif car2_type=3061830882013808530 and car1_type=173 then
  -- ne-device (prewiredTo)
    open get_aggr_attrs(car2_id);
    fetch get_aggr_attrs into aggr_attrs;
    close get_aggr_attrs;
    open is_ne_device(car2_id,car1_id,aggr_attrs);
    fetch is_ne_device into ind;
    if is_ne_device%FOUND then
      ret1:=1;
    end if;
    close is_ne_device;
-----------------------------------
  end if;

  return ret1;
end;
/
