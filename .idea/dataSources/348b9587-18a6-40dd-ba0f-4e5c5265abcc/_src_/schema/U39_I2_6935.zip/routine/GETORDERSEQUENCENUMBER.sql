CREATE function GETORDERSEQUENCENUMBER(PADDING in NUMBER)
   return varchar2
is
   NUM   varchar2(200);
begin
   select /*+ncid.pl:GETOR*/ LPAD (ORDERNAMINGSEQUENCE.nextval, PADDING, '0') into NUM from DUAL;
   return NUM;
end;
/
