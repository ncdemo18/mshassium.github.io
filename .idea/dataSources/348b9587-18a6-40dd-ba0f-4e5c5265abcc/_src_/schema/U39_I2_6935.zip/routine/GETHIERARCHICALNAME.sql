CREATE function getHierarchicalName(objectId in number, max_level in number, delimiter varchar2, skip_top varchar2) return varchar is
  TYPE names_type IS REF CURSOR;
  names names_type;
  where_cond varchar2(100);
  Result varchar2(4000);
  sql_string varchar2(2000);
  the_name varchar2(200);
  c number;
  skipped boolean := false;
begin
  sql_string := 'select /*+ncid.pl:gHNe*/ name from nc_objects';
  where_cond := ' where level<=' || to_char(max_level);
  IF (max_level >0)
  THEN
      sql_string := sql_string || where_cond;
  END IF;
  sql_string := sql_string || ' start with object_id = '||to_char(objectId)|| ' connect by object_id = prior parent_id order by level desc';
  c := 0;

  OPEN names FOR sql_string;
  LOOP
     FETCH names INTO the_name;
     EXIT WHEN names%NOTFOUND;
     if (lower(skip_top) = 'true' and not skipped)
     then
       skipped := true;
     else
       IF (c>0)
       THEN
           Result := Result||delimiter;
       END IF ;
       Result := Result || the_name;
       c := c+1;
     end if;
  END LOOP;
  return(Result);
end getHierarchicalName;
/
