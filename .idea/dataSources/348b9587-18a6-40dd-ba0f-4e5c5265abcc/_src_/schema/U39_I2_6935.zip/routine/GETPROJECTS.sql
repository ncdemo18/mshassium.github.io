CREATE FUNCTION          "GETPROJECTS" (p_Attr_ID
                            in  number) return varchar2 is

        path     varchar2(2000);
        pth     varchar2(2000);

      	cursor cur01(aattr_id	number) is
        select distinct
                    nvl(pot.name, oot.name)||':'||nvl(pr.name, o.name) as "project"
                 from nc_objects pr,
                     nc_objects o,
                     nc_params p,
                     nc_object_types pot,
                     nc_object_types oot
                 where
                    p.attr_id=aattr_id
                    and p.object_id=o.object_id
                    and pr.object_id(+)=o.project_id
                    and o.object_class_id=oot.object_type_id
                    and pr.object_class_id=pot.object_type_id(+);

        begin
           	OPEN cur01(p_Attr_ID);
			LOOP
				FETCH cur01 into pth;
                EXIT WHEN cur01%NOTFOUND;

                path:=pth||'    '||path;

            END LOOP;
    		CLOSE cur01;

            path:=substr(path,0,length(path)-1);
            return path;
        end;




/
