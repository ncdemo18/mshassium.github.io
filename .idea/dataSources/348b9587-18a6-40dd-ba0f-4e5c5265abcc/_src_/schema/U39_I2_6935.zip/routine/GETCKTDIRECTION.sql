CREATE FUNCTION          "GETCKTDIRECTION" 
(sourcePeID number, cur_pe number,cur_pe_o_n number,cur_ring_pe_o_n number )RETURN NUMBER

IS

cursor direct(cur_pe_o_n number,cur_ring_pe_o_n number ) is
Select ((cur_pe_o_n - t.pe_o_n)*(cur_ring_pe_o_n-t.ring_pe_o_n)) as direction from
(
 Select pes.ORDER_NUMBER pe_o_n, ring_pes.order_number ring_pe_o_n
  from nc_objects pes, nc_objects o,
(
	Select o1.order_number, r1.object_id from nc_objects o1,nc_references r1,nc_objects o2, nc_objects o3
	 where o1.object_id=r1.reference
		 and r1.attr_id=14 and r1.reference=o2.object_id
		 and o2.object_class_id=9 and o2.parent_id=o3.parent_id
		 and o3.object_id=sourcePeID
	) ring_pes

where pes.object_class_id=9
and pes.parent_id=o.parent_id
and o.object_id=cur_pe
and pes.object_id not in (cur_pe)
and pes.object_id=ring_pes.object_id
and rownum=1
)  t;
   direction   NUMBER;
BEGIN
   direction:=1;
   FOR dir IN direct (cur_pe_o_n,cur_ring_pe_o_n)
   LOOP
      direction := dir.direction;
      EXIT;
   END LOOP;
   RETURN direction;
END;




/
