CREATE FUNCTION          "GETPATH" (p_object_id IN NUMBER)
  RETURN VARCHAR2
IS
  PATH   VARCHAR2 (2000);
  pth    VARCHAR2 (2000);

  CURSOR cur01 (did NUMBER)
  IS
    SELECT     NAME
          FROM nc_objects
    START WITH object_id = did
    CONNECT BY PRIOR parent_id = object_id;
BEGIN
  OPEN cur01 (p_object_id);

  LOOP
    FETCH cur01 INTO pth;
    EXIT WHEN cur01%NOTFOUND;
    PATH := pth || '\' || PATH;
  END LOOP;
  CLOSE cur01;
  PATH := SUBSTR (PATH, 0, LENGTH (PATH) - 1);
  RETURN PATH;
END;




/
