CREATE FUNCTION          "GETPARENTIDFROMCOTS" (object_id NUMBER, type_ids VARCHAR2 ) RETURN NUMBER IS
   CURSOR path_cur (id NUMBER)
   IS
      SELECT     obj.object_id, obj.object_type_id, obj.object_class_id
            FROM NC_OBJECTS obj
	  WHERE obj.object_type_id IN (SELECT object_type_id FROM autorouting$cots)      
      START WITH object_id = id
      CONNECT BY PRIOR parent_id = object_id;


   chassis_id   NUMBER;
BEGIN
   chassis_id := object_id;

   FOR path_rec IN path_cur (object_id)
   LOOP
      chassis_id := path_rec.object_id;
      EXIT;
   END LOOP;
   RETURN chassis_id;
END;




/
