CREATE FUNCTION agg_or (
                           input IN RAW
                           ) RETURN RAW
-- function agg_or for reconciliation_model
PARALLEL_ENABLE AGGREGATE USING mask_agg_type;
/
