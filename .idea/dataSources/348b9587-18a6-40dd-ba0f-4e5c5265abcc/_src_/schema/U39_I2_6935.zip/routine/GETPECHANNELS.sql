CREATE FUNCTION          "GETPECHANNELS" (peID number) return varchar2 is

channels varchar2(400);
id number;
channelName varchar2(255);
i number;

cursor resources is
    select /*+ORDERED*/ pes.object_id, c.NAME
    from NC_OBJECTS pes , NC_REFERENCES r, NC_OBJECTS c
    where pes.object_id = peID
    and pes.OBJECT_ID = r.OBJECT_ID
    and r.REFERENCE = c.OBJECT_ID
    and c.object_class_id = 610
	order by c.name;
    
begin
	i := 0;

	OPEN resources;
	LOOP
		FETCH resources INTO id, channelName;
		IF resources%FOUND THEN
			IF i <> 0 THEN
				channels := channels || '<br>&nbsp;';
			END IF;

			channels := channels || channelName;

			i := 1;
		END IF;
		EXIT WHEN resources%NOTFOUND;
	END LOOP;
	CLOSE resources;
 
    return channels;
end;





/
