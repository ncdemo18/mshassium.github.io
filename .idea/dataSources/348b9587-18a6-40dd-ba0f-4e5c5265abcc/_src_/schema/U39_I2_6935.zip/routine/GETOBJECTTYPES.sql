CREATE FUNCTION          "GETOBJECTTYPES" (p_Attr_ID
                            in  number) return varchar2 is

        path     varchar2(2000);
        pth     varchar2(2000);
      	cursor cur01(aattr_id	number) is
                 select to_char(ot.object_type_id)||'-'|| ot.name
                 from nc_object_types ot,
                    nc_attr_object_types aot
                 where aot.attr_id=aattr_id
                 and ot.object_type_id=aot.object_type_id
                 order by ot.name;

        begin
           	OPEN cur01(p_Attr_ID);
			LOOP
				FETCH cur01 into pth;
                EXIT WHEN cur01%NOTFOUND;

                path:=pth||'    '||path;

            END LOOP;
    		CLOSE cur01;

            path:=substr(path,0,length(path)-1);
            return path;
        end;




/
