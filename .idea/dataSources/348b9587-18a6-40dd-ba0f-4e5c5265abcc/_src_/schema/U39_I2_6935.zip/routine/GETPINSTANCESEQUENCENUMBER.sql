CREATE function GETPINSTANCESEQUENCENUMBER(PADDING in NUMBER)
   return varchar2
is
   NUM   varchar2(200);
begin
   select /*+ncid.pl:GETPR*/ LPAD (PINSTANCENAMINGSEQUENCE.nextval, PADDING, '0') into NUM from DUAL;
   return NUM;
end;
/
