CREATE function getattributesamplevalue (p_attr_id in  number)
        return varchar2 is
        strlistvalues   varchar2(2000);
        strvalue        varchar2(200);
        attr_type       number;
        attr_type_def   number;
        attr_mask       varchar2(200);

              cursor listvalues(aattr_type_def_id        number) is
                 select /*+ncid.pl:getae.lists*/ value as value1
                 from nc_list_values
                 where attr_type_def_id=aattr_type_def_id and rownum<10;

        begin
                 select /*+ncid.pl:getae*/ a.attr_type_id, a.attr_type_def_id, mask into attr_type, attr_type_def, attr_mask
                   from nc_attributes a
                  where a.attr_id=p_attr_id;

                  if ( attr_type=7 ) then

                            open listvalues(attr_type_def);
                                           loop
                                                fetch listvalues into strvalue;
                        exit when listvalues%notfound;

                          if ( length(strlistvalues)>0 ) then
                              strlistvalues:=strlistvalues||'<br>';
                          end if;

                          strlistvalues:=strlistvalues||strvalue;

                        end loop;
                                  close listvalues;
                               --elsif ( attr_type<>9 ) then
                              --    select min(value) into strlistvalues
                              --      from nc_params where attr_id=p_attr_id;
                              elsif ( attr_type=5 ) then
                                  strlistvalues:=attr_mask;
                  end if;

            return strlistvalues;

        end;
/
