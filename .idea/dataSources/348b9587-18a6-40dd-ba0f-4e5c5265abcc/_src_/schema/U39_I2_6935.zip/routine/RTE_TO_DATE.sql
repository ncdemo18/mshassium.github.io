CREATE FUNCTION rte_to_date(vc IN VARCHAR2)
  RETURN date DETERMINISTIC parallel_enable
IS
  res date;
BEGIN
  return to_date(vc, 'YYYYMMDDHH24MISS');
EXCEPTION
  WHEN OTHERS
  THEN
    RETURN null;
END;
/
