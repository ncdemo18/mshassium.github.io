CREATE FUNCTION          "GETPORTFORCONNECTOR" (CONN_ID IN NUMBER) RETURN NUMBER IS
	   CURSOR conns IS
	   SELECT conn1.connector_id FROM NC_CONNECTION_DATA conn1, NC_CONNECTION_DATA conn2
	   		  WHERE
			  		conn1.connection_type=3  AND
			 		conn1.link_id=conn2.link_id  AND
			  		conn2.connector_id<>conn1.connector_id AND
			  		conn2.connector_id=conn_id;
       PORT_ID NUMBER;
BEGIN
	 OPEN conns;
 	 LOOP
		  FETCH conns INTO PORT_ID;
                EXIT WHEN conns%NOTFOUND;
          END LOOP;
	 CLOSE conns;

	 RETURN PORT_ID;

END;




/
