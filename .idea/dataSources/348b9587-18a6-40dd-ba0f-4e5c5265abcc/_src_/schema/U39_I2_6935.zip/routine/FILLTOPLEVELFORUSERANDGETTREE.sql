CREATE function fillTopLevelForUserAndGetTree(v_user_id in number,v_object_id in number) return arrayofnumbers
is result arrayofnumbers;
pragma autonomous_transaction;
BEGIN
delete from nc_params
where value = v_user_id
and attr_id = 9132076724513320640 /* Top for Bulk edit tool  */;

insert into nc_params
values (9132076724513320640 /* Top for Bulk edit tool */, v_object_id, null, v_user_id, null, null, null, null, 1);

commit;

with tree as (
  select offer_comp.* , level, rownum as show_order
  from nc_objects offer_comp
  where offer_comp.object_type_id in (7021759920013445069, 7030657925013157563,9128710112013295047,9129295724213127355)/* Offer Comp*/
  START WITH offer_comp.object_id = v_object_id
  CONNECT BY offer_comp.parent_id = prior offer_comp.object_id
)
select object_id BULK COLLECT INTO result
from (
    select price_discount.object_id , tree.show_order
    from tree
      join nc_params entity_type
       on (entity_type.attr_id = 	9132086005513398910 /* Select Entity Type */
       and entity_type.object_id = v_object_id )
      join nc_objects price_discount
       on (price_discount.parent_id = tree.object_id
       and (price_discount.object_type_id  = decode(entity_type.list_value_id ,	9132086005513398908,8062729702013833676 /* Offering Price */ ,-1)
            or price_discount.object_class_id = decode(entity_type.list_value_id ,	9132086005513398909,7021851555013445377 /* Discount */ ,-1)))
    union all
    select tree.object_id , show_order
    from tree
    where object_type_id = 9128710112013295047)
order by show_order;

return result;
END;
/
