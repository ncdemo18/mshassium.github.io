CREATE FUNCTION          "GETOBJECTTYPEPATH" (p_Object_type_ID in number) return varchar2 is
    path varchar2(2000);
    pth varchar2(2000);
    cursor cur01(did number) is
        select name
        from nc_object_types
        where object_type_id<>0
        start with object_type_id=did
        connect by prior parent_id=object_type_id;
begin
    OPEN cur01(p_Object_type_ID);
    LOOP
        FETCH cur01 into pth;
        EXIT WHEN cur01%NOTFOUND;
        path:=pth||'\'||path;
    END LOOP;
    CLOSE cur01;
    path:=substr(path,0,length(path)-1);
    return path;
end;




/
