CREATE function get_server_id return NUMBER authid current_user is
           server_id varchar2(200);
    begin
      execute immediate  'select (sys_context(''USERENV'',''DB_NAME'') || instance_name || host_name || user) from v$instance' into server_id;
      return dbms_utility.get_hash_value(server_id, 0,1000);
end;
/
