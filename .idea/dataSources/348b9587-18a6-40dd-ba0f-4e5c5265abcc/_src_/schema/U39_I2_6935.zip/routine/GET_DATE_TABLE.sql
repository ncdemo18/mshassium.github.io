CREATE FUNCTION get_date_table(start_date date, count_iter number, shift number, back number) return DATE_TABLE is
ret DATE_TABLE;
i number:=0;
begin
   if back <= 0 then
     FOR i IN 0..count_iter LOOP
         if ret is null
        then
            ret := DATE_TABLE(DATE_ROW(start_date+(i-1)*shift));
        else
            if i != count_iter then
               ret.extend;
            end if;
            ret(i) := DATE_ROW(start_date+(i-1)*shift);
        end if;
     end loop;
    else
    i :=count_iter;
     while i >= 0
     LOOP
         if ret is null
        then
            ret := DATE_TABLE(DATE_ROW(start_date-(count_iter-i-1)*shift));
        else
            if i != 0 then
               ret.extend;
            end if;
            ret(count_iter - i) := DATE_ROW(start_date-(count_iter-i-1)*shift);
        end if;
        i := i-1;
     end loop;
    end if;
  return ret;
 exception when others then begin
    if start_date is null or count_iter is null then
        return DATE_TABLE(DATE_ROW(null));
    end if;
 end;
end get_date_table;
/
