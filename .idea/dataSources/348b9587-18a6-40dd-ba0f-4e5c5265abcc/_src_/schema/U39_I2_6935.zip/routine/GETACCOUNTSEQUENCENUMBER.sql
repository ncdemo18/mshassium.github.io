CREATE function GETACCOUNTSEQUENCENUMBER(PADDING in NUMBER)
   return varchar2
as
   NUM   varchar2(200);
begin
   select /*+ncid.pl:GETAR*/ LPAD (ACCOUNTNAMINGSEQUENCE.nextval, PADDING, '0') into NUM from DUAL;
   return NUM;
end;
/
