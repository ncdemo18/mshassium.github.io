CREATE FUNCTION          "PARSE_MBPS" (value in  varchar2) return number is

        bits         number;
        i            number;

        begin

            bits:=0;

            i:=instr(value,'Mbps');
            if i <> 0 then
                bits:=to_number(substr(value,0,i-2))*1000000;
                return bits;
            end if;

            i:=instr(value,'Gbps');
            if i <> 0 then
                bits:=to_number(substr(value,0,i-2))*1000000000;
                return bits;
            end if;

            i:=instr(value,'Kbps');
            if i <> 0 then
                bits:=to_number(substr(value,0,i-2))*1000;
                return bits;
            end if;


            return bits;

        end;



/
