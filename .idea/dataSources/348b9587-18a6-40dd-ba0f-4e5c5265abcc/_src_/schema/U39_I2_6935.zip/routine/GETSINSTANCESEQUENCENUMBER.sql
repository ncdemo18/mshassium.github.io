CREATE function GETSINSTANCESEQUENCENUMBER(PADDING in NUMBER)
   return varchar2
is
   NUM   varchar2(200);
begin
   select /*+ncid.pl:GETSR*/ LPAD (SINSTANCENAMINGSEQUENCE.nextval, PADDING, '0') into NUM from DUAL;
   return NUM;
end;
/
