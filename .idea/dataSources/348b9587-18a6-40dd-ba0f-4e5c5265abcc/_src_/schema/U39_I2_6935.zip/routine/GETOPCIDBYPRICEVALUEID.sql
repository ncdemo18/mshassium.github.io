CREATE FUNCTION getopcidbypricevalueid (priceid NUMBER)RETURN NUMBER
  IS
    chid   NUMBER;
  BEGIN

   SELECT  object_id into chid FROM nc_objects
                                   WHERE object_type_id = 9132191822913888858
                              START WITH nc_objects.object_id = priceid
                              CONNECT BY PRIOR nc_objects.parent_id = nc_objects.object_id;
    RETURN chid;
END;
/
