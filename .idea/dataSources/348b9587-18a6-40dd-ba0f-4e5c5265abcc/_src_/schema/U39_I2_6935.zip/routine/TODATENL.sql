CREATE FUNCTION todatenl (dstr VARCHAR2, fmt VARCHAR2)
   RETURN DATE
IS
   ret   DATE;
BEGIN
   BEGIN
      ret := TO_DATE (dstr, fmt);
   EXCEPTION
      WHEN OTHERS
      THEN
         ret := NULL;
   END;

   RETURN ret;
END todatenl;
/
