CREATE function getPeriods(t in NUMBER, start_date in date, end_date in date) return arrayofstrings is
result arrayofstrings := arrayofstrings();
  curr_date date;
  next_date date;
  next_date_char VARCHAR2(4) ;
  list_size pls_integer := 0;
BEGIN
  curr_date := start_date;

  if t = 9130027993513856341 then
      while curr_date < end_date LOOP
        result.extend;
        list_size := list_size + 1;
        result(list_size) := TO_CHAR(curr_date,'dd.mm.yy');
        curr_date := curr_date + 1;
      END LOOP;
   elsif t = 9130027993513856342 then
        while curr_date < end_date LOOP
          result.extend;
          list_size := list_size + 1;
          next_date := LAST_DAY(curr_date);
          if end_date < next_date then
              next_date := end_date;
          END IF;
          result(list_size) := TO_CHAR(curr_date,'dd.mm.yy')||'-'||TO_CHAR(next_date,'dd.mm.yy');
          curr_date := next_date+1;
        END LOOP;
    elsif t = 9130027993513856343 then
       while curr_date < end_date LOOP
          result.extend;
          list_size := list_size + 1;
          next_date := LAST_DAY(curr_date)+1;
          next_date_char := TO_CHAR(next_date,'Q');
          while next_date_char = TO_CHAR(next_date,'Q') LOOP
             next_date := LAST_DAY(next_date)+1;
          END LOOP;
          if end_date < next_date then
              next_date := end_date;
          else
              next_date := next_date - 1;
          END IF;
          result(list_size) := TO_CHAR(curr_date,'dd.mm.yy')||'-'||TO_CHAR(next_date,'dd.mm.yy');
          curr_date := next_date + 1;
        END LOOP;
   elsif t = 9130027993513856344 then
       while curr_date < end_date LOOP
          result.extend;
          list_size := list_size + 1;
          next_date := LAST_DAY(curr_date)+1;
          next_date_char := TO_CHAR(next_date,'YYYY');
          while next_date_char = TO_CHAR(next_date,'YYYY') LOOP
             next_date := LAST_DAY(next_date)+1;
          END LOOP;
          if end_date < next_date then
              next_date := end_date;
          else
              next_date := next_date - 1;
          END IF;
          result(list_size) := TO_CHAR(curr_date,'dd.mm.yy')||'-'||TO_CHAR(next_date,'dd.mm.yy');
          curr_date := next_date + 1;
        END LOOP;
   elsif t = 9130027993513856345 then
         result.extend;
         list_size := 1;
         result(list_size) := TO_CHAR(start_date,'dd.mm.yy')||'-'||TO_CHAR(end_date,'dd.mm.yy');
   END IF;
return result;
END;
/
