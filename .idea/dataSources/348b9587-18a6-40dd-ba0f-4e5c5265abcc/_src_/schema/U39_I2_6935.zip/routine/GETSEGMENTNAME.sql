CREATE FUNCTION getSegmentName (segment_id in number, node_status_list_value_id in number)
return varchar2 is
firstnode number;
flag number;
var number;
segmentorder number;
currentorder number;
cirname varchar2(4000);
nodename varchar2(4000);
before_var number;
result varchar2(4000);
cursor cur(	segmentID number, list_value number ) is
select /*+ncid.pl:gSNe.cur*/ pes.object_id from nc_objects segments, nc_objects pes where
    segments.object_id = segmentID and
    pes.parent_id = segments.parent_id and
    pes.object_type_id = 2121834827013591277 and
    pes.object_id not in
    (
        select object_id from nc_params where
        attr_id = 3012977647013999477 and
        list_value_id = list_value
    )
    order by pes.order_number;
begin
before_var:=0;
firstnode:=0;
flag:=0;
select /*+ncid.pl:gSNe*/ circuit.name into cirname from nc_objects segments, nc_objects circuit where
segments.object_id = segment_id and
circuit.object_id = segments.parent_id;
select /*+ncid.pl:gSNe*/ order_number into segmentorder from nc_objects where object_id = segment_id;
result:=cirname||'-';
OPEN cur(segment_id, node_status_list_value_id);
    LOOP
        FETCH cur into var;
        EXIT WHEN cur%NOTFOUND;
        IF firstnode=0 THEN
        firstnode:=var;
        END IF;
        select /*+ncid.pl:gSNe*/ order_number into currentorder from nc_objects where object_id = var;
        IF currentorder>segmentorder AND flag=0 THEN
        flag:=2;
        END IF;
        IF currentorder>segmentorder AND flag=1 THEN
        select /*+ncid.pl:gSNe*/ name into nodename from nc_objects where object_id = before_var;
        result:=result||nodename||'-';
        select /*+ncid.pl:gSNe*/ name into nodename from nc_objects where object_id = var;
        result:=result||nodename;
        flag:=3;
        END IF;
        IF flag=0 THEN
        flag:=1;
        END IF;
        before_var := var;
    END LOOP;
CLOSE cur;
IF( flag < 3 ) THEN
select /*+ncid.pl:gSNe*/ name into nodename from nc_objects where object_id = var;
result:=result||nodename||'-';
select /*+ncid.pl:gSNe*/ name into nodename from nc_objects where object_id = firstnode;
result := result||nodename;
END IF;
return result;
end;
/
