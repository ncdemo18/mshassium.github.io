CREATE function fillCRIDForUser(v_user_id in number,v_object_id in number,v_attr_id in number) return arrayofnumbers
is result arrayofnumbers;
pragma autonomous_transaction;
BEGIN
delete from nc_params
where value = v_user_id
and attr_id = v_attr_id;

insert into nc_params
values (v_attr_id, v_object_id, null, v_user_id, null, null, null, null, 1);

commit;

select h.object_id value BULK COLLECT INTO result
from nc_history h
inner join
(
  select o.object_id
  from nc_objects o, nc_params p
  where o.parent_id = to_number(p.value) and p.attr_id = 9132007925513764595 and p.object_id = v_object_id
  group by o.object_id
) t on h.task_id = t.object_id
inner join nc_objects o on (o.object_id = h.object_id)
where o.object_type_id in (
  select ot.object_type_id
  from nc_object_types ot
  where ot.object_type_id not in (2050878077013769312,2050878077013769313,2093059656013008927)
  start with ot.object_type_id in (2050878077013769311,9127730282013917184,8080145876013843961)
  connect by prior ot.object_type_id = ot.parent_id
)
group by h.object_id;

return result;
END;
/
