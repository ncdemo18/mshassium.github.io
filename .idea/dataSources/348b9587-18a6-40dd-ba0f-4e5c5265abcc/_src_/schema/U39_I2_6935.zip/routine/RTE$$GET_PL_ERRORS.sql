CREATE function rte$$get_pl_errors(
  p_name user_objects.object_name%type
  , p_type user_objects.object_type%type
  , p_prefix_length number := 1000
  , p_suffix_length number := 1000
  , p_marker varchar2 := '=ERROR=>'
) return arrayofstrings is
  res arrayofstrings;
begin
  select /*+ leading(e) no_merge(e) use_nl(e,s) push_pred(s) */
    nvl(regexp_substr(e.text, '\w{3}-\d{5}:'), 'ORA-20202:')
    ||' '||e.name||' '||e.type||'('||e.line||':'||e.position||'): '
    ||translate(trim(regexp_replace(e.text, '\w{3}-\d{5}:', '', 1, 1)), chr(13)||chr(10), '  ')||': '
    ||translate(trim(
        case when e.position>0
             then substr(s.text, greatest(1, e.position - p_prefix_length), e.position-1)
                  ||p_marker
                  ||substr(s.text, e.position, p_suffix_length)
          else substr(s.text, 1, least(length(s.text), p_prefix_length + p_suffix_length))
        end), chr(13)||chr(10), '  ')
  line
    bulk collect into res
  from user_errors e
    , user_source s
  where e.name = p_name
        and e.type = p_type
        and e.text not in (
    'PL/SQL: Declaration ignored'
    , 'PL/SQL: SQL Statement ignored'
    , 'PL/SQL: Statement ignored'
    , 'PL/SQL: Item ignored'
    , 'PL/SQL: Compilation unit analysis terminated'
  )
        and e.text not like 'PLS-00364: loop index variable %'
        and s.name(+) = e.name
        and s.type(+) = e.type
        and s.line(+) = e.line
  order by e.name, e.type, e.line, e.position, e.sequence;
  return res;
end;
/
