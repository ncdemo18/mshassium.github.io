CREATE FUNCTION          "GETCONTAINERID" (connID number, typeID number) return number is
    chID number;
begin
    select chassisID into chID from
    (
        select e.*, rownum r from
        (
            select *  from
            (
                select object_id chassisID, level l
                from nc_objects where object_class_id = typeID
                start with nc_objects.object_id = connID
                connect by prior nc_objects.parent_id=nc_objects.object_id
                order by level desc
            ) w
        order by l /*desc*/
        )e
    ) where r =1;
    return chID;
end;




/
