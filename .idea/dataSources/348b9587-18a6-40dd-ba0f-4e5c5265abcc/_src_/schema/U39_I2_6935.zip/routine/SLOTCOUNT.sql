CREATE FUNCTION          "SLOTCOUNT" (p_object_id in number) return number is
        cnt number;
        begin

        select count(object_id) into cnt from nc_objects where object_class_id=601 and upper(name) not like upper('%connector%')
        start with parent_id=p_object_id connect by prior object_id=parent_id;

        return cnt;
        end;



/
