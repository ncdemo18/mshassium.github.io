CREATE FUNCTION GETWORKINGMINUTESCOUNT (d_from TIMESTAMP, d_to TIMESTAMP, cal_id NUMBER) RETURN  NUMBER IS
  calendar_id NUMBER := cal_id;
  date_from TIMESTAMP := d_from; --('DD-mmm-YYYY HH24:MI:SS')
  date_to TIMESTAMP := d_to; --('DD-mmm-YYYY HH24:MI:SS')
  spec_day_date DATE;
  spec_day_str VARCHAR2(15);

  general_work_hours INTERVAL DAY TO SECOND := numtodsinterval(9*60, 'minute');

  work_hours VARCHAR2(30);
  work_hour_from INTERVAL DAY TO SECOND;
  work_hour_to INTERVAL DAY TO SECOND;


  date_for_count TIMESTAMP := date_from;
  r INTERVAL DAY(5) TO SECOND := numtodsinterval(0, 'minute');
  r_day NUMBER := EXTRACT(day from (date_to - date_from)) + 1;
  nonworking_day NUMBER := 0;


  TYPE var_of_varchar IS TABLE OF VARCHAR2(30);
  week_days var_of_varchar;

  coun_for_week_days NUMBER;

  TYPE var_of_numb IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  week_days_in_num var_of_numb;

  TYPE hashMap is table of varchar2(15) index by varchar2(15);
  special_day hashMap;

  day_of_week NUMBER;

  CURSOR cur1 is select  value from nc_params where attr_id = 5092164374013828383 and object_id = calendar_id;

  CURSOR spec_d is
  SELECT param.date_value
  FROM nc_params param, nc_objects obj
  WHERE obj.parent_id  = calendar_id
    AND obj.object_type_id = 5091453385013824874
    AND param.object_id    = obj.object_id
    AND param.attr_id      = 5091453385013824876;

begin

--check if both date in one day
  if to_char(date_to, 'DD-MM-YYYY') = to_char(date_from, 'DD-MM-YYYY') then
    r := date_to - date_from;
    RETURN (extract(minute from r) + extract(hour from r)*60 + extract(day from r)*3600);
  end if;
--

--select off day
  select name
    BULK COLLECT into week_days
    from nc_objects
  where object_type_id = 5091453385013824875 and parent_id = calendar_id;

-- select work hours Start
  OPEN cur1;
  FETCH cur1 into work_hours;

  if work_hours is not null
  then
    work_hour_from := numtodsinterval(SUBSTR(work_hours,1,2)*60, 'minute') + numtodsinterval(SUBSTR(work_hours,4,2), 'minute');
    work_hour_to := numtodsinterval(SUBSTR(work_hours,7,2)*60, 'minute') + numtodsinterval(SUBSTR(work_hours,10,2), 'minute');
    general_work_hours := work_hour_to - work_hour_from;
  else
    work_hour_from := numtodsinterval(9*60, 'minute');
    work_hour_to := numtodsinterval(18*60, 'minute');
  end if;
-- select work hours End

-- select special day Start
  OPEN spec_d;
  LOOP
    FETCH spec_d INTO spec_day_date;
    spec_day_str := to_char(spec_day_date, 'DD-MM-YYYY');
    special_day(spec_day_str) := spec_day_str;
    EXIT WHEN spec_d%NOTFOUND;
  END LOOP;
-- select special day End


--    weekDay => numbOfWeekDay
  coun_for_week_days := week_days.count();
	for i IN 1..coun_for_week_days loop
      case week_days(i)
        when 'Monday' then week_days_in_num(2) := 2;
        when 'Tuesday' then week_days_in_num(3) := 3;
        when 'Wednesday' then week_days_in_num(4) := 4;
        when 'Thursday' then week_days_in_num(5) := 5;
        when 'Friday' then week_days_in_num(6) := 6;
        when 'Saturday' then week_days_in_num(7) := 7;
        when 'Sunday' then week_days_in_num(1) := 1;
      end case;
	end loop;

	for i IN 1..r_day loop
    day_of_week := TO_CHAR(date_for_count, 'D');
    if  (week_days_in_num.EXISTS(day_of_week) OR  special_day.EXISTS(to_char(date_for_count, 'DD-MM-YYYY')))
    then
      nonworking_day := nonworking_day + 1;
    else
      if to_char(date_for_count, 'DD-MM-YYYY') = to_char(date_from, 'DD-MM-YYYY')
      then
        r := r + (work_hour_to - (numtodsinterval(to_char(date_from, 'HH24')*60, 'minute') + numtodsinterval(to_char(date_from, 'MI'), 'minute')));
      elsif to_char(date_for_count, 'DD-MM-YYYY') = to_char(date_to, 'DD-MM-YYYY')
      then
        r := r + ((numtodsinterval(to_char(date_to, 'HH24')*60, 'minute') + numtodsinterval(to_char(date_to, 'MI'), 'minute')) - work_hour_from);
      else
        r := r + (work_hour_to - work_hour_from);
      end if;
    end if;
    date_for_count := date_for_count + 1;
	end loop;

  RETURN (extract(minute from r) + extract(hour from r)*60 + extract(day from r)*1440);

end;
/
