CREATE function get_element(p_arr arrayofstrings, p_position number default 1) return varchar2 as
begin
 return case when p_arr is null then null
             when p_arr.count >= p_position then p_arr(p_position)
             else null end;
end;
/
