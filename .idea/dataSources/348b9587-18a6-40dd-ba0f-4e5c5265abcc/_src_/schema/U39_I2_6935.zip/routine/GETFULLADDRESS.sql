CREATE Function getFullAddress
   (addressId IN number)
   RETURN varchar2
IS
   fulladdress varchar2(4000);

BEGIN
   select substr(dbms_xmlgen.convert(xmlagg(xmlelement(addr, ', '||addr).extract('//text()') order by lvl desc).getstringval(), 1), 3) into fulladdress
  from(
          select
              level lvl,
              object_id,
              name addr,
              connect_by_root object_id address_id
          from nc_objects
          start with object_id in (addressId)
          connect by object_id = prior parent_id and object_type_id != 9129538948013885633 /* Top */
      ) addr
   group by address_id;

RETURN fulladdress;
end;
/
