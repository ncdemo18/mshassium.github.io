CREATE FUNCTION          "CHILDRENCOUNT" ( id in number ) return varchar is
ct number;
result varchar(200);
begin
select count(object_id) value into ct
from nc_objects
start with parent_id = id
connect by prior object_id = parent_id;

result:='';
if ( ct<>0 ) then result:=TO_CHAR(ct);
end if;

return result;
end;




/
