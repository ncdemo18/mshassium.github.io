CREATE FUNCTION "ISOBJECTTYPEUSED" (id NUMBER)
  RETURN  VARCHAR2 IS
   cnt NUMBER;
        BEGIN
        SELECT COUNT(*) INTO cnt FROM
	      (

           SELECT 'x' FROM NC_OBJECTS objs,
           (
               SELECT alltypes.object_type_id FROM NC_OBJECT_TYPES alltypes
               CONNECT BY PRIOR object_type_id = parent_id
               START WITH object_type_id = id
           ) typs
           WHERE objs.object_type_id = typs.object_type_id
           AND ROWNUM = 1
        );
	    IF (cnt > 0) THEN RETURN 'USED';
        ELSE RETURN 'UNUSED';
	    END IF;
END;
/
