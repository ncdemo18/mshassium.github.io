CREATE function scm_check_number(p_num in varchar2, p_default in number, p_format in varchar2 := null) return number is
  result number;
begin
  if (p_format is null) then
    result := to_number(p_num);
  else
    result := to_number(p_num, p_format);
  end if;
  return result;
exception
  when others then
    return p_default;
end scm_check_number;
/
