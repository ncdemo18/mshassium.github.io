CREATE FUNCTION getQualifiedName
(
    Pref IN VARCHAR2,
    Num_len IN PLS_INTEGER
)
RETURN nc_objects.name%TYPE
IS
    retVal nc_objects.name%TYPE := '';
    pId NC_CURRENT_UNIQUE_IDS.id%TYPE;
    uc_violation EXCEPTION;
    PRAGMA EXCEPTION_INIT(uc_violation, -1);
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    UPDATE NC_CURRENT_UNIQUE_IDS
    SET ID = ID + 1
    WHERE Prefix = Pref
    RETURNING ID INTO pID;
    IF SQL%ROWCOUNT = 0 THEN
   BEGIN
          INSERT INTO NC_CURRENT_UNIQUE_IDS VALUES(Pref,1)
        RETURNING ID INTO pID;
   EXCEPTION
    WHEN uc_violation THEN
         UPDATE NC_CURRENT_UNIQUE_IDS
  SET ID = ID + 1
  WHERE Prefix = Pref
  RETURNING ID INTO pID;
   END;
    END IF;
    COMMIT;
    RETURN (LPAD(TO_CHAR(pID),Num_Len,'0'));
END;
/
