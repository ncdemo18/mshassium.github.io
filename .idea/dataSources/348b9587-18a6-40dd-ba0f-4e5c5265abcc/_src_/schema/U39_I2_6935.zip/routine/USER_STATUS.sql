CREATE FUNCTION          "USER_STATUS" ( id in number ) return varchar2
    is act varchar2(20);
    str varchar2(20) := 'never logged in';
    da date;
    begin
        select max( act_date )into da from nc_access
        where user_id = id;

        if da is null then return str;
        else select action into act from nc_access
            where act_date = da and rownum = 1;
        return act;
        end if;
    end;




/
