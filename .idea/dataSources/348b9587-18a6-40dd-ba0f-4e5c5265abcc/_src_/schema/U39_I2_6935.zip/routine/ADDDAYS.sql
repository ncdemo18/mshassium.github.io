CREATE FUNCTION          "ADDDAYS" (dstr date, days number) return date is
        ret date;
        begin
        	begin
        		ret := dstr + days;
        	exception
                when others then
                ret := null;
            end;
        	return ret;
        end adddays;



/
