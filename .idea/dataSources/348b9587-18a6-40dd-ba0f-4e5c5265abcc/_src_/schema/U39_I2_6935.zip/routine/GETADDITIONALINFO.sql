CREATE FUNCTION GETADDITIONALINFO
(o_id in number, o_type	in	varchar2) return varchar2 is
        result varchar2(4100); -- +100
        max_res_len constant number := 4000;
        value varchar2(1000);
	--[NIMA0409][GETADDITIONALINFO function fails on long attribute/OT names] Begin
        attr_name varchar(200);
        type_name varchar(200);
	--[NIMA0409][GETADDITIONALINFO function fails on long attribute/OT names] End
        schema_name varchar(100);
        object_name varchar(100);
        group_name varchar(100);
        attr_id varchar(30);
        type_id varchar(30);
        schema_id varchar(30);
        object_ref_attr_id varchar(30);
        attr_ref_id varchar(30);
        dots boolean;

        v_dummy number;
        ismultiple number;
        flags number;
--        result_counter number;
        cursor cur01 (id number) is select value from nc_list_values where attr_type_def_id = id;

        cursor group_bindings (gID number) is
        select a.name attr_name, to_char(bind.attr_id) attr_id,
        o.name type_name, to_char(bind.object_type_id) object_type_id,
        s.name schema_name, to_char(bind.attr_schema_id) schema_id
        from (
        select attr_id, object_type_id, attr_schema_id from nc_attr_object_types where attr_id in
        (select attr_id from nc_attributes where attr_group_id = gID)
        ) bind, nc_attributes a, nc_object_types o, nc_attr_schemes s
        where a.attr_id = bind.attr_id
        and o.object_type_id = bind.object_type_id
        and s.attr_schema_id = bind.attr_schema_id;

        begin
--             result_counter:=0;
             if o_type = 'attr' then
                select t.name, g.name, a.ismultiple, a.flags
                into attr_name, group_name, ismultiple, flags
                from nc_attributes a, nc_attr_types t, nc_attr_groups g
                where a.attr_id = o_id and a.attr_type_id = t.attr_type_id and a.attr_group_id = g.attr_group_id;
                if attr_name = 'ATTR_TYPE_REFERENCE' or attr_name = 'ATTR_TYPE_ATTR_REF' then
                select attr_type_def_id into v_dummy from nc_attributes where attr_id = o_id;
                result:= getadditionalinfo(v_dummy, 'attr_def');
                else result:= concat('Type: ', attr_name);
                end if;
                result:=concat(result,' | Multiple: ');
                if ismultiple = 1 then
                result:= concat(result,'Yes');
                else result:=concat(result,'No');
                end if;
                result:=concat(result, ' | Writeable: ');
                if BITAND(flags, 2) = 2 then
                result:=concat(result, 'No');
                else result:=concat(result, 'Yes');
                end if;
                result:=concat(result, ' | Calculable: ');
                if BITAND(flags, 256) = 256 then
                result:=concat(result, 'Yes');
                else result:=concat(result, 'No');
                end if;
                result:=concat(result, ' | Group: ');
                result:=concat(result, group_name);
             end if;
             if o_type = 'attr_def' then
                select attr_type_id into v_dummy from nc_attr_type_defs where attr_type_def_id = o_id;
                if v_dummy = 7 then --list
                result := 'List of: ';

                dots := false;
               	OPEN cur01(o_id);
    			LOOP
    				FETCH cur01 into value;
                    EXIT WHEN cur01%NOTFOUND;
                    if (length(result) + length(value)>=max_res_len) and not dots then
--                    if result_counter = 21 then //^^correct string overflow checking
                        result:= concat(result, '...');
                        dots := true;
                    end if;
                    if not dots then
--                    if result_counter <=20 then
                        result := concat(result, value);
                        result := concat(result, ';');
--                        result_counter:= result_counter + 1;
                    end if;
                END LOOP;
        		CLOSE cur01;
                end if;
                if v_dummy = 9 or v_dummy = 11 then -- reference
                result:= 'Reference to ';
                select to_char(nvl(td.object_type_id, -1)), to_char(nvl(td.object_ref_attr_id, -1)), to_char(nvl(td.attr_ref_id, -1)),
                nvl(ot.name, 'NULL'), nvl(obj.name, 'NULL'), nvl(attr.name, 'NULL')
                into type_id, object_ref_attr_id, attr_ref_id, type_name, object_name, attr_name
                from nc_attr_type_defs td, nc_object_types ot, nc_objects obj, nc_attributes attr
                where td.attr_type_def_id = o_id
                and td.object_type_id = ot.object_type_id
                and td.object_ref_attr_id = obj.object_id(+)
                and td.attr_ref_id = attr.attr_id(+);
                if attr_ref_id  != '-1' and attr_name != 'NULL' then
                result:= concat(result, 'attribute ');
                result:= concat(result, attr_name);
                result:=concat(result, ' of ');
                end if;
                if object_ref_attr_id != '-1' and object_name != 'NULL' then
                result := concat(result, 'object ');
                result:=concat(result, object_name);
                result:= concat(result, ' of ');
                end if;
                if type_id != '-1' then
                result:=concat(result, 'type ');
                result:=concat(result, type_name);
                end if;
                end if;
             end if;
             if o_type = 'attr_group' then
             result:='Bound attributes:';

             dots := false;
             open group_bindings(o_id);
    			LOOP
    				FETCH group_bindings into attr_name, attr_id, type_name, type_id, schema_name, schema_id;
                    EXIT WHEN group_bindings%NOTFOUND;
                    if (length(result) + length(schema_name) + length(type_name) + length(attr_name) + 18 >= max_res_len) and not dots then
--                    if result_counter = 21 then
                        result:= concat(result, '...');
                        dots := true;
--                        result_counter:= result_counter + 1;
                    end if;
                    if not dots then
                        result:= concat(result, ' "');
                        result:= concat(result, schema_name);
                        result:= concat (result, '" - "');
                        result:= concat(result, type_name);
                        result:= concat (result, '" - "');
                        result:= concat(result, attr_name);
                        result:= concat(result, '"; ');
--                        result_counter:= result_counter + 1;
                    end if;
                END LOOP;
        		CLOSE group_bindings;

             end if;
             if o_type = 'list_value' then
                result := 'List  value';
             end if;
        return result;
        end;
/
