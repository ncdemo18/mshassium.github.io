CREATE FUNCTION          "PARSE_LOCATION_A" (name in  varchar2) return varchar2 is

        location     varchar2(2000);
        i            number;
        j            number;
        begin

            i:=instr(name,'/',1,2);
            j:=instr(name,'/',1,3);

            if i = 0 then
             return 'WRONG_CONVENTIONS';
            end if;

            if j-i < 8 then
             return 'WRONG_CONVENTIONS';
            end if;


            location:= substr(name,i+1,8);

            if location is null then
               return 'WRONG_CONVENTIONS';
            end if;


            return location;

        end;



/
