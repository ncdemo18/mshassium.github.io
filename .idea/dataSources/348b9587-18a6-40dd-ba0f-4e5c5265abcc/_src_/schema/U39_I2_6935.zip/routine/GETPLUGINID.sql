CREATE function getPluginID(p_obj_id number, p_level number) return number is
begin
  return pkgri.get_plugin_by_object(p_obj_id, p_level);
end;
/
