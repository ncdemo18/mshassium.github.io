CREATE function getChassisID(p_obj_id number) return number is
begin
  return pkgri.get_chassis_by_object(p_obj_id);
end;
/
