CREATE function getattributetypetext (attr_type in number, to_type in  varchar2, typedef in varchar2 )
        return varchar2 is
        typetext varchar2(200);

        begin

            if ( attr_type=7 ) then
                 return 'list - '||typedef;
            end if;


            if ( attr_type=9 ) then
                    return 'reference to '||to_type;
                              elsif ( attr_type=0 ) then
                                     return 'text';
                              elsif ( attr_type=1 ) then
                                     return 'memo';
                  elsif ( attr_type=2 ) then
                                     return 'number';
                              elsif ( attr_type=3 ) then
                                     return 'decimal';
                              elsif ( attr_type=4 ) then
                                     return 'date';
                              elsif ( attr_type=5 ) then
                                     return 'masked';
                              elsif ( attr_type=6 ) then
                                     return 'url';
                             elsif ( attr_type=10 ) then
                                     return 'password';
                             elsif ( attr_type=11 ) then
                                     return 'reference to attribute';
                             elsif ( attr_type=13 ) then
                                     return 'attachment';
                             elsif ( attr_type=14 ) then
                                     return 'html code';
                             elsif ( attr_type=16 ) then
                                     return 'currency';
               end if;

            return typetext;
        end;
/
