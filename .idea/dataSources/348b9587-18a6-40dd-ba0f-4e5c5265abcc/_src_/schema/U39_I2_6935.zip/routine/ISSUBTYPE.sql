CREATE FUNCTION          "ISSUBTYPE" (ot in number, root_ot in number) return number is
	ret number := null;
begin
	select /*+ncid.pl:issue*/ (case when count(1) > 0 then 1 else 0 end) into ret
	from nc_object_types
	where object_type_id=ot
	start with object_type_id=root_ot
	connect by prior object_type_id=parent_id;

	return ret;
end;



/
