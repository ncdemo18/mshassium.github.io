CREATE FUNCTION          "GETREFERENCE" (p_Object_ID         in  number, p_Attr_ID in number) return number is
            reference     number;

        begin
            select reference into reference from nc_references where object_id=p_Object_ID and
            attr_id=p_Attr_ID;

            return reference;
        end;




/
