CREATE FUNCTION          "GETPROJECTBYOBJECT" ( p_Object_ID         in  number) return number is
            v_Project_ID     number;
        begin
            select project_id into v_Project_ID from nc_objects where object_id=p_Object_ID;
            return v_Project_ID;
        end;




/
