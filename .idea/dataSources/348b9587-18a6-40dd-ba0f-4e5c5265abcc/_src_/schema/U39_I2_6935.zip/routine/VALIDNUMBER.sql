CREATE function VALIDNUMBER(p_num varchar2, p_default number, p_format varchar2 := null)
  return number is
  Result number;
begin
  if (p_format is null) then
    Result := TO_NUMBER(p_num);
  else
    Result := TO_NUMBER(p_num, p_format);
  end if;
  RETURN result;
EXCEPTION
  WHEN OTHERS THEN
    RETURN p_default;
end;
/
