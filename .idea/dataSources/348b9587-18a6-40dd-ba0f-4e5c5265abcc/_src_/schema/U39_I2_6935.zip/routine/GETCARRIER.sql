CREATE FUNCTION          "GETCARRIER" (p_Object_ID in number) return number is
    reference number;
begin
    select reference
    into reference
    from nc_references
    where object_id=p_Object_ID and
    attr_id=14;
    return reference;
end;




/
