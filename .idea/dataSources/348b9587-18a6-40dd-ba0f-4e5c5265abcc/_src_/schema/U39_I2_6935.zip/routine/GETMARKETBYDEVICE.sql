CREATE FUNCTION getMarketByDevice (device_id IN NUMBER)

   RETURN NUMBER

IS

   ret   NUMBER;

BEGIN

   SELECT /*+LEADING(SITES) USE_NL(TOP, O) ncid.pl:gMBDe*/

          o.object_id

     INTO ret

     FROM (SELECT     object_id, project_id, LEVEL l, ROWNUM r

                 FROM nc_objects n

           CONNECT BY PRIOR n.parent_id = n.object_id

           START WITH n.object_id = device_id) sites,

          nc_objects top,

          nc_objects o

    WHERE top.parent_id IS NULL

      AND top.object_class_id = 300

      AND top.project_id = sites.project_id

      AND o.parent_id = top.object_id

      AND sites.object_id = o.object_id;



   RETURN ret;

END;
/
