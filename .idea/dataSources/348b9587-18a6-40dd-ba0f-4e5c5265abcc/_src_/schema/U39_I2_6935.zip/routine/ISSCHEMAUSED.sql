CREATE FUNCTION          "ISSCHEMAUSED" (id NUMBER)
    RETURN VARCHAR2
    IS
        cnt NUMBER;
        BEGIN
        SELECT COUNT(*) INTO cnt FROM
	   (
	   (
           SELECT attr_schema_id FROM NC_OBJECTS WHERE attr_schema_id IN
           (
               SELECT allschemes.attr_schema_id FROM NC_ATTR_SCHEMES allschemes
               CONNECT BY PRIOR attr_schema_id = parent_id
               START WITH attr_schema_id = id
           )
       )
       UNION
	   (
           SELECT attr_schema_id FROM NC_ATTR_TYPE_DEFS WHERE attr_schema_id IN
           (
               SELECT allschemes.attr_schema_id FROM NC_ATTR_SCHEMES allschemes
               CONNECT BY PRIOR attr_schema_id = parent_id
               START WITH attr_schema_id = id
           )
       )
	   );
	   IF (cnt > 0) THEN RETURN 'USED';
       ELSE RETURN 'UNUSED';
	   END IF;
        END;




/
