CREATE FUNCTION          "LASTORDERNUMBER" ( id in number ) return number is
result number;
begin
select count(object_id) value into result
from nc_objects
where parent_id = id;
return result;
end;




/
