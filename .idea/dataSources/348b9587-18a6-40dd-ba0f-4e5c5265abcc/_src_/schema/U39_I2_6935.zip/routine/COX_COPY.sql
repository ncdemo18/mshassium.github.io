CREATE function cox_copy
   (sourceId in number, desId in number)
   return number
is
   newid number;
BEGIN
    Pkgcopy.Simple_Copy(sourceId,desId,newid);
    return newid;
END cox_copy;
/
