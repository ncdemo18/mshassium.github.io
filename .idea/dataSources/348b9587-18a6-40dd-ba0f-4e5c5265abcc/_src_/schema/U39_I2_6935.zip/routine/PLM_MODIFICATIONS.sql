CREATE function plm_modifications(p_activity_id in nc_cmt_ct_modifs.activity_id%type, p_language_id in nc_objects.object_id%type)
return plm_modifs_type pipelined as
pragma autonomous_transaction;
v_max_rows number;
begin
  select nvl(value, 1000) into v_max_rows from nc_directory where key = 'nc.uids.max_table_size';
  merge into plm_modifications_tab d
  using (
    select
        m.modif_id || p_language_id as id,
        m.modif_id,
        m.activity_id,
        o.object_id, o.name object_name,
        ot.object_type_id, PKG_PLM_CR_UTILS.get_object_type_localized(ot.object_type_id, p_language_id) object_type_name,
        to_char(cast(m.ts as date), 'dd.mm.yyyy hh24:mi:ss') modified_when,
        decode(m.operation, 'C    ', 9137214403013298823 /*Create*/,
                          'CM   ', 9137214403013298823 /*Create*/,
                          'MC   ', 9137214403013298823 /*Create*/,
                          'M    ', 9137214403013298824 /*Modify*/,
                          'D    ', 9137214403013298825 /*Delete*/,
                          'A    ', 9143603181013630880 /*Aggregate*/,
                          'R    ', 9142473118013371561 /*Rolled Back*/,
                          null) operation_id,
        decode(m.operation, 'C    ', 'Create', 'CM   ', 'Create', 'MC   ', 'Create', 'M    ', 'Modify',
                          'D    ', 'Delete', 'A    ', 'Aggregate', 'R    ', 'Rolled Back', null) operation_name,
        decode(m.operation, 'C    ', 9144474903513897136, 'CM   ', 9144474903513897136, 'MC   ', 9144474903513897136, 'M    ', 9144474903513897137,
                          'D    ', 9144474903513897138, 'A    ', 9144474903513897139, 'R    ', 9144474903513897140, null) operation_resource_id,
        o.version,
        decode(o.version, 'n/a', 9144460661013881735 /*n/a resource_id*/, null) as version_resource_id,
        PKG_PLM_CR_UTILS.get_external_status(o.object_id, p_language_id) as external_status,
        9144467234213892077 /*PLM Modifications*/ as object_type_id_map,
        p_language_id language_id,
        m.ci_table_name
      from
      (select modif_id, activity_id, ts, operation, ci_table_name, ci_id from nc_cmt_ct_modifs where activity_id = p_activity_id and rownum <= v_max_rows) m,
      (select object_id, object_type_id, name, PKG_PLM_CR_UTILS.get_modification_version(object_id) version from nc_objects) o,
      (select object_type_id from nc_object_types) ot
      where
      o.object_id = m.ci_id
      and o.object_type_id = ot.object_type_id) s
    on (d.id = s.id and d.language_id = s.language_id)
    when not matched then
    insert (id, modif_id, activity_id, object_id, object_name, object_type_id, object_type_name, modified_when, operation_id,
            operation_name, operation_resource_id, version, version_resource_id, external_status, object_type_id_map,
            language_id, ci_table_name)
    values (s.id, s.modif_id, s.activity_id, s.object_id, s.object_name, s.object_type_id, s.object_type_name, s.modified_when, s.operation_id,
            s.operation_name, s.operation_resource_id, s.version, s.version_resource_id, s.external_status, s.object_type_id_map,
            s.language_id, s.ci_table_name);
    commit;
    for i in (
      select m.modif_id || p_language_id as id
      from
        (select modif_id, activity_id, to_number(ci_id) ci_id from nc_cmt_ct_modifs where activity_id = p_activity_id and rownum <= v_max_rows) m,
        nc_objects o
      where
      o.object_id = m.ci_id)
    loop
      pipe row (plm_modifs_object(i.id));
    end loop;
return;
end plm_modifications;
/
