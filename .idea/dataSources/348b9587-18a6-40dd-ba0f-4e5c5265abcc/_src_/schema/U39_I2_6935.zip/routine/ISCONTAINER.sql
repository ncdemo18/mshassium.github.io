CREATE FUNCTION          "ISCONTAINER" (p_Object_ID         in  number) return number is

            v_dummy     pls_integer;

        begin
            select count(*) into v_dummy from nc_objects where object_id=p_Object_ID and
            object_type_id in ( select object_type_id from nc_object_types
            start with object_type_id=300 connect by prior
            object_type_id=parent_id );

            if v_dummy>0 then return 1;
            else return 0;
            end if;
        end;





/
