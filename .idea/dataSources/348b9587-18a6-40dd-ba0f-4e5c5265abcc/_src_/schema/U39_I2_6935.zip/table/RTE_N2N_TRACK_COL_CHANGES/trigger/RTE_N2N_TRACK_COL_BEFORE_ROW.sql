CREATE TRIGGER RTE_N2N_TRACK_COL_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_N2N_TRACK_COL_CHANGES
FOR EACH ROW
  rte_validation.rte_n2n_track_col_before_row(
    :new.source_table
    , :new.column_name
    , :new.track_changed_in
)

;
/
