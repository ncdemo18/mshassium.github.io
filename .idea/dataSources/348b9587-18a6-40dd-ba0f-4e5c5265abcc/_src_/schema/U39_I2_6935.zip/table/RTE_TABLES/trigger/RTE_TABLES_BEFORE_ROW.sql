CREATE TRIGGER RTE_TABLES_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_TABLES
FOR EACH ROW
  rte_validation.rte_tables_before_row(
      :new.instance_name,
      :new.data_source_name
    , :new.table_name
    , :new.multiples
    , :new.alias
    , :new.refresh_type
    , :new.track_deletes_in
    , :new.track_mergers_in
    , :new.is_background
    , :new.fill_mode
  )

;
/
