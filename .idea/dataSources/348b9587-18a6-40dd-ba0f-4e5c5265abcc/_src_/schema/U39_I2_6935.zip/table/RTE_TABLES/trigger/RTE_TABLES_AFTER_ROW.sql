CREATE TRIGGER RTE_TABLES_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_TABLES
FOR EACH ROW
  rte_validation.rte_tables_after_row(
      :new.data_source_name
    , :new.table_name
    , :new.track_deletes_in
    , :new.track_mergers_in
  )

;
/
