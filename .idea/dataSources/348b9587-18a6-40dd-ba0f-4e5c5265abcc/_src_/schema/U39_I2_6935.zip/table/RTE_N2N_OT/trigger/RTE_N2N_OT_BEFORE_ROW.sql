CREATE TRIGGER RTE_N2N_OT_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_N2N_OT
FOR EACH ROW
  rte_validation.rte_n2n_ot_before_row(
    :new.exclude
    , :new.children
)

;
/
