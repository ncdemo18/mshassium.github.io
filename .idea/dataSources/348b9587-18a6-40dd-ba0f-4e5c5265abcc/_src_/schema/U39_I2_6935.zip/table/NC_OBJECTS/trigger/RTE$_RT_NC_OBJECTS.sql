CREATE TRIGGER RTE$_RT_NC_OBJECTS
AFTER INSERT OR UPDATE OR DELETE
  ON NC_OBJECTS
FOR EACH ROW
  declare
             t RTE$DISPATCHER_READ.t_pk1;
           begin null;
             t.OBJECT_ID := case when deleting then :old.OBJECT_ID else :new.OBJECT_ID end;
             t.old$type_id := :old.OBJECT_TYPE_ID;
             t.OBJECT_TYPE_ID := :new.OBJECT_TYPE_ID;
           t.DESCRIPTION := case when deleting then :old.DESCRIPTION else :new.DESCRIPTION end;
           t.OBJECT_CLASS_ID := case when deleting then :old.OBJECT_CLASS_ID else :new.OBJECT_CLASS_ID end;
           t.PARENT_ID := case when deleting then :old.PARENT_ID else :new.PARENT_ID end;
           t.NAME := case when deleting then :old.NAME else :new.NAME end;
           t.ORDER_NUMBER := case when deleting then :old.ORDER_NUMBER else :new.ORDER_NUMBER end;
           t.source_rowid := case when deleting then :old.rowid else :new.rowid end;
           if DELETING then
             RTE$DISPATCHER_READ.pk_rt1(false, t);
             return;
           end if;
           if UPDATING and :old.OBJECT_TYPE_ID <> :new.OBJECT_TYPE_ID then
             RTE$DISPATCHER_READ.pk_rt1(false, t);
             RTE$DISPATCHER_READ.pk_rt1(true, t);
             RTE$DISPATCHER_READ.pk_rt_reload1(t);
             return;
           end if;
           if :new.OBJECT_TYPE_ID is not null then RTE$DISPATCHER_READ.pk_rt1(true, t); end if;
end;
/
