CREATE TRIGGER RTE_CONFIG_FILE_PARAMS
BEFORE INSERT OR UPDATE
  ON RTE_CONFIG_FILE_PARAMS
FOR EACH ROW
  rte_validation.rte_cfg_file_params_before_row(
      :new.name
    , :new.value
  )

;
/
