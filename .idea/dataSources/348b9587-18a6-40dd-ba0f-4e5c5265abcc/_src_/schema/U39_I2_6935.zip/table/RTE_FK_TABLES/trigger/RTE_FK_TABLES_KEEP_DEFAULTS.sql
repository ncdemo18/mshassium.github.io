CREATE TRIGGER RTE_FK_TABLES_KEEP_DEFAULTS
BEFORE UPDATE OF DATA_SOURCE_NAME OR DELETE
  ON RTE_FK_TABLES
FOR EACH ROW WHEN (FOR EACH ROW )
begin
  rte_installer_logger.raise_error(-1072,
    'Do not rename or delete DEFAULT data source'
  );
end;
/
