CREATE TRIGGER RTE_FK_TABLES_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_FK_TABLES
FOR EACH ROW
  rte_validation.rte_fk_tables_after_row(
      :new.data_source_name
    , :new.table_name
    , :new.foreign_key
    , :new.attr_column
    , :new.show_order_column
    , :new.index_name
  )

;
/
