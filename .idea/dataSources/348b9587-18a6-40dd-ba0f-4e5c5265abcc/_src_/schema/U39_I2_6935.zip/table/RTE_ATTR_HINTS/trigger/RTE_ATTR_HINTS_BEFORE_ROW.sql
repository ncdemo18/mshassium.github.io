CREATE TRIGGER RTE_ATTR_HINTS_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_ATTR_HINTS
FOR EACH ROW
  rte_validation.rte_attr_hints_before_row(
      :new.data_source_name
    , :new.attr_id
    , :new.join_type
  )

;
/
