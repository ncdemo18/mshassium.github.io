CREATE TRIGGER TRG_BAM_NC_OMD_ORDERS
AFTER INSERT OR UPDATE OR DELETE
  ON NC_OMD_ORDERS
FOR EACH ROW
  declare
	orderNumber number(20);
	commandType varchar2(20);
	tableNotExists exception;
	pragma exception_init(tableNotExists, -00942);
begin
	if inserting then
		commandType := 'INSERTING';
	elsif updating then
		commandType := 'UPDATING';
	else
		commandType := 'DELETING';
	end if;

	select NC_OMD_ORDERS_LOG_SEQ.nextval into orderNumber from dual;

	if commandType = 'INSERTING' or commandType = 'UPDATING' then
		execute immediate '
			insert into NC_OMD_ORDERS_LOG (
				ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_ORDER_CREATION_DATE, NEW_ORDER_COMPL_DATE, NEW_DURATION, NEW_ORDER_ID, NEW_ORDER_TYPE, NEW_NEW_OTHER_TYPE, NEW_SPECIFICATION, NEW_ORDER_LEVEL, NEW_SLA_STATE, NEW_SCENARIO, NEW_STATUS, NEW_IS_COMPLETED, NEW_OLD_IS_ERROR, NEW_ORDER_AIM, NEW_IN_ERROR
			)
			values (
				:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_ORDER_CREATION_DATE, :NEW_ORDER_COMPL_DATE, :NEW_DURATION, :NEW_ORDER_ID, :NEW_ORDER_TYPE, :NEW_NEW_OTHER_TYPE, :NEW_SPECIFICATION, :NEW_ORDER_LEVEL, :NEW_SLA_STATE, :NEW_SCENARIO, :NEW_STATUS, :NEW_IS_COMPLETED, :NEW_OLD_IS_ERROR, :NEW_ORDER_AIM, :NEW_IN_ERROR
			)'
		using
			orderNumber, commandType, :old.id, :new.id, :new.order_creation_date, :new.order_compl_date, :new.duration, :new.order_id, :new.order_type, :new.new_other_type, :new.specification, :new.order_level, :new.sla_state, :new.scenario, :new.status, :new.is_completed, :new.OLD_is_error, :new.order_aim, :new.in_error;
	end if;
exception
	when tableNotExists then
		pkg_bam_kpi_transport.lock_log_table_shared(9133339697413373034);
		if commandType = 'INSERTING' or commandType = 'UPDATING' then
			execute immediate '
				insert into NC_OMD_ORDERS_LOG (
					ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_ORDER_CREATION_DATE, NEW_ORDER_COMPL_DATE, NEW_DURATION, NEW_ORDER_ID, NEW_ORDER_TYPE, NEW_NEW_OTHER_TYPE, NEW_SPECIFICATION, NEW_ORDER_LEVEL, NEW_SLA_STATE, NEW_SCENARIO, NEW_STATUS, NEW_IS_COMPLETED, NEW_OLD_IS_ERROR, NEW_ORDER_AIM, NEW_IN_ERROR
				)
				values (
					:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_ORDER_CREATION_DATE, :NEW_ORDER_COMPL_DATE, :NEW_DURATION, :NEW_ORDER_ID, :NEW_ORDER_TYPE, :NEW_NEW_OTHER_TYPE, :NEW_SPECIFICATION, :NEW_ORDER_LEVEL, :NEW_SLA_STATE, :NEW_SCENARIO, :NEW_STATUS, :NEW_IS_COMPLETED, :NEW_OLD_IS_ERROR, :NEW_ORDER_AIM, :NEW_IN_ERROR
				)'
			using
				orderNumber, commandType, :old.id, :new.id, :new.order_creation_date, :new.order_compl_date, :new.duration, :new.order_id, :new.order_type, :new.new_other_type, :new.specification, :new.order_level, :new.sla_state, :new.scenario, :new.status, :new.is_completed, :new.OLD_is_error, :new.order_aim, :new.in_error;
		end if;
end TRG_BAM_NC_OMD_ORDERS;
/
