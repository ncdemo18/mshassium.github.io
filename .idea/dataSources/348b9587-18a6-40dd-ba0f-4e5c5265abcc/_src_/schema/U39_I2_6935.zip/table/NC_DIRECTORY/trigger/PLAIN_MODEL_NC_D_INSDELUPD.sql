CREATE TRIGGER PLAIN_MODEL_NC_D_INSDELUPD
AFTER INSERT OR UPDATE OR DELETE
  ON NC_DIRECTORY
FOR EACH ROW
  begin
    if (:old.key = 'netcracker.metadata.link(flags,def_value).used'
    and
            (:old.value is not null and :new.value is null
        or :old.value is null and :new.value is not null
        or :old.value <> :new.value)
    )
    then
        declare
            cursor recalculate_attrs_cur is
                select distinct a.attr_id
                from
                    nc_attributes a,
                    nc_attr_object_types aot
                where
                    a.attr_id = aot.attr_id
                    and (aot.default_value is not null or aot.flags is not null);

            attr_sync arrayofnumbers;
        begin
            open recalculate_attrs_cur;
            fetch recalculate_attrs_cur bulk collect into attr_sync;
            pkgAttrObjectTypes.schedule_recalculate_attr(attr_sync);
            close recalculate_attrs_cur;
        exception
            when others then
                if recalculate_attrs_cur%isopen
                then
                    close recalculate_attrs_cur;
                end if;
        end;
    end if;
end;
/
