CREATE TRIGGER RTE$_RT_NC_REFERENCES_AFT
AFTER DELETE
  ON NC_REFERENCES
  declare
  t RTE$DISPATCHER_READ.t_fk3;
  o RTE$DISPATCHER_READ.t_pk1;
begin
  for xman in (select * from RTE_TMP_MUTATION_IDS where table_name = 'NC_REFERENCES')
  loop
    begin
      t.OBJECT_ID := xman.object_id;
      t.old$attr_id := xman.old$attr_id;
      RTE$DISPATCHER_READ.load_object_info_rt1(t.OBJECT_ID, o);
      t.source_rowid := xman.source_rowid;
      RTE$DISPATCHER_READ.fk_rt3(t, o);
    exception WHEN OTHERS THEN rte_installer_logger.error('Unable to process realtime row [NC_REFERENCES: rowid('||xman.source_rowid||'),object_id('||xman.object_id||'),old$attr_id('||xman.old$attr_id||']');
    end;
  end loop;
  if t.old$attr_id is not null then delete from RTE_TMP_MUTATION_IDS where table_name = 'NC_REFERENCES'; end if;
end;
/
