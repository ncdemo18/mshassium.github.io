CREATE TRIGGER DR$CTX__NC_ADDRESSESTC
AFTER INSERT OR UPDATE
  ON NC_ADDRESSES
FOR EACH ROW
  declare   reindex boolean := FALSE;   updop   boolean := FALSE; begin   ctxsys.drvdml.c_updtab.delete;   ctxsys.drvdml.c_numtab.delete;   ctxsys.drvdml.c_vctab.delete;   ctxsys.drvdml.c_rowid := :new.rowid;   if (inserting or updating('ADDR') or       :new."ADDR" <> :old."ADDR") then     reindex := TRUE;     updop := (not inserting);     ctxsys.drvdml.c_text_vc2 := :new."ADDR";   end if;   ctxsys.drvdml.c_cntab(0) := 'TYPE_ID';  ctxsys.drvdml.c_cttab(0) := 'NUMBER';  ctxsys.drvdml.c_updtab(0) := updating('TYPE_ID');   ctxsys.drvdml.c_numtab(0) := :new."TYPE_ID";  ctxsys.drvdml.ctxcat_dml('U39_I2_6935','CTX__NC_ADDRESSES', reindex, updop); end;
/
