CREATE TRIGGER RTE_T_TYPES_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_TABLE_TYPES
FOR EACH ROW
  rte_validation.rte_t_types_before_row(
      :new.exclude
    , :new.children
  )

;
/
