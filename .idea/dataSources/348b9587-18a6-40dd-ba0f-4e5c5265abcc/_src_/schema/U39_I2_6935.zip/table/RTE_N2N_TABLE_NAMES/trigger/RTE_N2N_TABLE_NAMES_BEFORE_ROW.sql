CREATE TRIGGER RTE_N2N_TABLE_NAMES_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_N2N_TABLE_NAMES
FOR EACH ROW
  rte_validation.rte_n2n_table_names_before_row(
    :new.configuration_id
    , :new.source_table
    , :new.destination_table
)

;
/
