CREATE TRIGGER HISTORY_NC_LIST_VALUES
AFTER INSERT OR UPDATE OR DELETE
  ON NC_LIST_VALUES
FOR EACH ROW
  declare
   m_old_list_value nc_list_values%rowtype;
   m_new_list_value nc_list_values%rowtype;
begin

   if DELETING or UPDATING then
      m_old_list_value.list_value_id    := :old.list_value_id;
      m_old_list_value.attr_type_def_id := :old.attr_type_def_id;
      m_old_list_value.value            := :old.value;
      m_old_list_value.show_order       := :old.show_order;
      m_old_list_value.additional       := :old.additional;
      m_old_list_value.flags            := :old.flags;
   end if;

   if not DELETING then
      m_new_list_value.list_value_id    := :new.list_value_id;
      m_new_list_value.attr_type_def_id := :new.attr_type_def_id;
      m_new_list_value.value            := :new.value;
      m_new_list_value.show_order       := :new.show_order;
      m_new_list_value.additional       := :new.additional;
      m_new_list_value.flags            := :new.flags;
   end if;

   if    DELETING  then pkg_history_metadata.fire_delete_list_value(m_old_list_value);
   elsif INSERTING then pkg_history_metadata.fire_insert_list_value(m_new_list_value);
   elsif UPDATING  then
    begin
        if (m_old_list_value.list_value_id    <> m_new_list_value.list_value_id)
        or (m_old_list_value.attr_type_def_id <> m_new_list_value.attr_type_def_id)
        or (m_old_list_value.value            <> m_new_list_value.value)
        or (m_old_list_value.show_order       <> m_new_list_value.show_order)
        or (m_old_list_value.additional       <> m_new_list_value.additional)
        or (m_old_list_value.flags            <> m_new_list_value.flags)
        then
            pkg_history_metadata.fire_update_list_value(m_old_list_value, m_new_list_value);
        end if;
    end;
   end if;
end;
/
