CREATE TRIGGER HISTORY_NC_ATTR_TYPE_DEFS
AFTER INSERT OR UPDATE OR DELETE
  ON NC_ATTR_TYPE_DEFS
FOR EACH ROW
  declare
   m_old_type_def nc_attr_type_defs%rowtype;
   m_new_type_def nc_attr_type_defs%rowtype;
begin

   if DELETING or UPDATING then
      m_old_type_def.attr_type_def_id   := :old.attr_type_def_id;
      m_old_type_def.attr_type_id       := :old.attr_type_id;
      m_old_type_def.attr_schema_id     := :old.attr_schema_id;
      m_old_type_def.object_type_id     := :old.object_type_id;
      m_old_type_def.name               := :old.name;
      m_old_type_def.dtd                := :old.dtd;
      m_old_type_def.attr_access_type   := :old.attr_access_type;
      m_old_type_def.object_ref_attr_id := :old.object_ref_attr_id;
      m_old_type_def.attr_ref_id        := :old.attr_ref_id;
      m_old_type_def.flags              := :old.flags;
   end if;

   if not DELETING then
      m_new_type_def.attr_type_def_id   := :new.attr_type_def_id;
      m_new_type_def.attr_type_id       := :new.attr_type_id;
      m_new_type_def.attr_schema_id     := :new.attr_schema_id;
      m_new_type_def.object_type_id     := :new.object_type_id;
      m_new_type_def.name               := :new.name;
      m_new_type_def.dtd                := :new.dtd;
      m_new_type_def.attr_access_type   := :new.attr_access_type;
      m_new_type_def.object_ref_attr_id := :new.object_ref_attr_id;
      m_new_type_def.attr_ref_id        := :new.attr_ref_id;
      m_new_type_def.flags              := :new.flags;
      -- TODO: all field must be filled
   end if;

   if    DELETING  then pkg_history_metadata.fire_delete_type_def(m_old_type_def);
   elsif INSERTING then pkg_history_metadata.fire_insert_type_def(m_new_type_def);
   elsif UPDATING  then
    begin
        if (m_old_type_def.attr_type_def_id   <> m_new_type_def.attr_type_def_id)
        or (m_old_type_def.attr_type_id       <> m_new_type_def.attr_type_id)
        or (m_old_type_def.attr_schema_id     <> m_new_type_def.attr_schema_id)
        or (m_old_type_def.object_type_id     <> m_new_type_def.object_type_id)
        or (m_old_type_def.name               <> m_new_type_def.name)
        or (m_old_type_def.dtd                <> m_new_type_def.dtd)
        or (m_old_type_def.attr_access_type   <> m_new_type_def.attr_access_type)
        or (m_old_type_def.object_ref_attr_id <> m_new_type_def.object_ref_attr_id)
        or (m_old_type_def.attr_ref_id        <> m_new_type_def.attr_ref_id)
        or (m_old_type_def.flags              <> m_new_type_def.flags)
        then
            pkg_history_metadata.fire_update_type_def(m_old_type_def, m_new_type_def);
        end if;
    end;
   end if;
end;
/
