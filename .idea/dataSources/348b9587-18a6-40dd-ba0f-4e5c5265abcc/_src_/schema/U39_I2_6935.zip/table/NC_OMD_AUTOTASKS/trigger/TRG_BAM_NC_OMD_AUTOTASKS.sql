CREATE TRIGGER TRG_BAM_NC_OMD_AUTOTASKS
AFTER INSERT OR UPDATE OR DELETE
  ON NC_OMD_AUTOTASKS
FOR EACH ROW
  declare
	orderNumber number(20);
	commandType varchar2(20);
	tableNotExists exception;
	pragma exception_init(tableNotExists, -00942);
begin
	if inserting then
		commandType := 'INSERTING';
	elsif updating then
		commandType := 'UPDATING';
	else
		commandType := 'DELETING';
	end if;

	select NC_OMD_AUTOTASKS_LOG_SEQ.nextval into orderNumber from dual;

	if commandType = 'INSERTING' or commandType = 'UPDATING' then
		execute immediate '
			insert into NC_OMD_AUTOTASKS_LOG (
				ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_CREATION_DATE, NEW_EXP_END_DATE, NEW_ACT_END_DATE, NEW_TASK_ID, NEW_ACTUAL_DURATION, NEW_STATUS, NEW_IS_COMPLETED, NEW_ORDER_TYPE_ID, NEW_ORDER_TYPE_NEW_OTHER, NEW_INTERACTION_ITEM, NEW_INTERACTION, NEW_SPECIFICATION, NEW_PRIORITY, NEW_SLA_STATE, NEW_ACTION_TYPE_ID, NEW_ACTION_CLASS_ID, NEW_HAD_ERROR
			)
			values (
				:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_CREATION_DATE, :NEW_EXP_END_DATE, :NEW_ACT_END_DATE, :NEW_TASK_ID, :NEW_ACTUAL_DURATION, :NEW_STATUS, :NEW_IS_COMPLETED, :NEW_ORDER_TYPE_ID, :NEW_ORDER_TYPE_NEW_OTHER, :NEW_INTERACTION_ITEM, :NEW_INTERACTION, :NEW_SPECIFICATION, :NEW_PRIORITY, :NEW_SLA_STATE, :NEW_ACTION_TYPE_ID, :NEW_ACTION_CLASS_ID, :NEW_HAD_ERROR
			)'
		using
			orderNumber, commandType, :old.id, :new.id, :new.creation_date, :new.exp_end_date, :new.act_end_date, :new.task_id, :new.actual_duration, :new.status, :new.is_completed, :new.order_type_id, :new.order_type_new_other, :new.interaction_item, :new.interaction, :new.specification, :new.priority, :new.sla_state, :new.action_type_id, :new.action_class_id, :new.had_error;
	end if;
exception
	when tableNotExists then
		pkg_bam_kpi_transport.lock_log_table_shared(9133357515213009298);
		if commandType = 'INSERTING' or commandType = 'UPDATING' then
			execute immediate '
				insert into NC_OMD_AUTOTASKS_LOG (
					ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_CREATION_DATE, NEW_EXP_END_DATE, NEW_ACT_END_DATE, NEW_TASK_ID, NEW_ACTUAL_DURATION, NEW_STATUS, NEW_IS_COMPLETED, NEW_ORDER_TYPE_ID, NEW_ORDER_TYPE_NEW_OTHER, NEW_INTERACTION_ITEM, NEW_INTERACTION, NEW_SPECIFICATION, NEW_PRIORITY, NEW_SLA_STATE, NEW_ACTION_TYPE_ID, NEW_ACTION_CLASS_ID, NEW_HAD_ERROR
				)
				values (
					:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_CREATION_DATE, :NEW_EXP_END_DATE, :NEW_ACT_END_DATE, :NEW_TASK_ID, :NEW_ACTUAL_DURATION, :NEW_STATUS, :NEW_IS_COMPLETED, :NEW_ORDER_TYPE_ID, :NEW_ORDER_TYPE_NEW_OTHER, :NEW_INTERACTION_ITEM, :NEW_INTERACTION, :NEW_SPECIFICATION, :NEW_PRIORITY, :NEW_SLA_STATE, :NEW_ACTION_TYPE_ID, :NEW_ACTION_CLASS_ID, :NEW_HAD_ERROR
				)'
			using
				orderNumber, commandType, :old.id, :new.id, :new.creation_date, :new.exp_end_date, :new.act_end_date, :new.task_id, :new.actual_duration, :new.status, :new.is_completed, :new.order_type_id, :new.order_type_new_other, :new.interaction_item, :new.interaction, :new.specification, :new.priority, :new.sla_state, :new.action_type_id, :new.action_class_id, :new.had_error;
		end if;
end TRG_BAM_NC_OMD_AUTOTASKS;
/
