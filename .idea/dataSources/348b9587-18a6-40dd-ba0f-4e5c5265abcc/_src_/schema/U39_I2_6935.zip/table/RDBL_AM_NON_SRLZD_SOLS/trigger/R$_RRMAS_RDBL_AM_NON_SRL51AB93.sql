CREATE TRIGGER R$_RRMAS_RDBL_AM_NON_SRL51AB93
AFTER INSERT OR UPDATE OR DELETE
  ON RDBL_AM_NON_SRLZD_SOLS
  begin
  -- TODO: if it turns out the common case is the table is not updated, need to optimize for that
  RTE$RELATIONS.process_realtime;
end;
/
