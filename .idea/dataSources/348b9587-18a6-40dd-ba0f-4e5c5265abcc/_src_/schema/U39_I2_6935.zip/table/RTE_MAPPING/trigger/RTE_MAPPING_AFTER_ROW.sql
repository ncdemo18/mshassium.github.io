CREATE TRIGGER RTE_MAPPING_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_MAPPING
FOR EACH ROW
  rte_validation.rte_mapping_after_row(
      :new.table_id
    , :new.column_name
    , :new.attr_id
    , :new.attr_type
    , :new.data_type
    , :new.data_length
    , :new.id
  )

;
/
