CREATE TRIGGER RTE_RTE_INCR_R_THHS_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_INCR_REFILL_THRESHOLDS
FOR EACH ROW
  rte_validation.rte_rte_incr_r_thhs_before_row(
  :new.instance_name
  , :new.table_name
  , :new.threshold_type
)

;
/
