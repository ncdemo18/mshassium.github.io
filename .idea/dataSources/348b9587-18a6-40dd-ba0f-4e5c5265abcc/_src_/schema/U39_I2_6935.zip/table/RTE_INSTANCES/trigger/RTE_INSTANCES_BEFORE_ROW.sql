CREATE TRIGGER RTE_INSTANCES_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_INSTANCES
FOR EACH ROW
  rte_validation.rte_instances_before_row(
      :new.instance_name
  )

;
/
