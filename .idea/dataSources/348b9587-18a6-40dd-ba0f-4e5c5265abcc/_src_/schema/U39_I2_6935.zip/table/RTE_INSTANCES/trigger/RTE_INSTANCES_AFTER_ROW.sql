CREATE TRIGGER RTE_INSTANCES_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_INSTANCES
FOR EACH ROW
  rte_validation.rte_instances_after_row(
      :new.instance_name
  )

;
/
