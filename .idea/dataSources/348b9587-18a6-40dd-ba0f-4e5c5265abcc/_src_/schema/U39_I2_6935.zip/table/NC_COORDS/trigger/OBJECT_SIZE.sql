CREATE TRIGGER OBJECT_SIZE
BEFORE INSERT OR UPDATE OF MIN_X, MAX_X, MIN_Y, MAX_Y
  ON NC_COORDS
FOR EACH ROW
  DECLARE
   width    NUMBER;
   height   NUMBER;
BEGIN
   width :=   :NEW.max_x
            - :NEW.min_x;
   height :=   :NEW.max_y
             - :NEW.min_y;

   IF (width < height)
   THEN
      width := height;
   END IF;

   :NEW.object_size := width;
END;
/
