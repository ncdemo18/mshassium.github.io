CREATE TRIGGER R$_RRMAR_RDBL_SFA_OPP_A16B079E
AFTER INSERT OR UPDATE OF AGENT_ID OR DELETE
  ON RDBL_SFA_OPP_ASSIGNMENT
FOR EACH ROW
  declare
  AGENT_ID boolean := :old.AGENT_ID<>:new.AGENT_ID or (:old.AGENT_ID is null and :new.AGENT_ID is not null or :old.AGENT_ID is not null and :new.AGENT_ID is null);
begin
  -- Check if relation AGENT_ID.RDBL_SFA_OPP_ASSIGNMENT-3>RDBL_SALES_AGENTS.AGENT_ID needs to be updated
  if   AGENT_ID
  then
    R$_RRM_RDBL_SFA_OPP_ASSIGNMENT.AGENT_IDRDBL_SFA_OPP_AS6E5607C(nvl(:old.rowid, :new.rowid)) := null;
  end if;
end;
/
