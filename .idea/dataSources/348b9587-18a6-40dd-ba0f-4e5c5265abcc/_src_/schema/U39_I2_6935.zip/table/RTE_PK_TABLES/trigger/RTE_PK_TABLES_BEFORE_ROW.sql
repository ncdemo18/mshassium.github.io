CREATE TRIGGER RTE_PK_TABLES_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_PK_TABLES
FOR EACH ROW
  rte_validation.rte_pk_tables_before_row(
      :new.data_source_name
    , :new.table_name
    , :new.primary_key
    , :new.type_column
    , :new.index_name
    , :new.db_link
  )

;
/
