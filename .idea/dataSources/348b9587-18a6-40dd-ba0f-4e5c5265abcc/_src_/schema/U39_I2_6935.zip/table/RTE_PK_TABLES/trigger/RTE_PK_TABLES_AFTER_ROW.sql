CREATE TRIGGER RTE_PK_TABLES_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_PK_TABLES
FOR EACH ROW
  rte_validation.rte_pk_tables_after_row(
      :new.data_source_name
    , :new.table_name
    , :new.primary_key
    , :new.type_column
    , :new.index_name
  )

;
/
