CREATE TRIGGER RTE_RELATIONS_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_RELATIONS
FOR EACH ROW
  rte_validation.rte_relations_after_row(
      :new.name
  )

;
/
