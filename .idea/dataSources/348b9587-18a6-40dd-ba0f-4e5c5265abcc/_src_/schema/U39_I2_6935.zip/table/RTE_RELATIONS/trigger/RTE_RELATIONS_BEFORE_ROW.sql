CREATE TRIGGER RTE_RELATIONS_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_RELATIONS
FOR EACH ROW
  rte_validation.rte_relations_before_row(
      :new.name,
      :new.source_column,
      :new.target_table,
      :new.target_column
  )

;
/
