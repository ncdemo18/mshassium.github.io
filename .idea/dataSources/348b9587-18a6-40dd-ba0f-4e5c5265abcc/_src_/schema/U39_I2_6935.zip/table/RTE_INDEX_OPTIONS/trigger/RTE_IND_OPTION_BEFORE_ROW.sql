CREATE TRIGGER RTE_IND_OPTION_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_INDEX_OPTIONS
FOR EACH ROW
  rte_validation.rte_ind_option_before_row(
      :new.instance_name
    , :new.table_name
  )

;
/
