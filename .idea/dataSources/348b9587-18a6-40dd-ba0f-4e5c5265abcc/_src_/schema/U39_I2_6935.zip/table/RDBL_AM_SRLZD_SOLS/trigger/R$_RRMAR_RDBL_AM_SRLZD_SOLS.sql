CREATE TRIGGER R$_RRMAR_RDBL_AM_SRLZD_SOLS
AFTER INSERT OR UPDATE OF PARENT_ID OR DELETE
  ON RDBL_AM_SRLZD_SOLS
FOR EACH ROW
  declare
  PARENT_ID boolean := :old.PARENT_ID<>:new.PARENT_ID or (:old.PARENT_ID is null and :new.PARENT_ID is not null or :old.PARENT_ID is not null and :new.PARENT_ID is null);
begin
  -- Check if relation PARENT_ID.RDBL_AM_SRLZD_SOLS-2>RDBL_AM_SHOS.OBJECT_ID needs to be updated
  if   PARENT_ID
  then
    R$_RRM_RDBL_AM_SRLZD_SOLS.PARENT_IDRDBL_AM_SRLZD_C6F3236(nvl(:old.rowid, :new.rowid)) := null;
  end if;
end;
/
