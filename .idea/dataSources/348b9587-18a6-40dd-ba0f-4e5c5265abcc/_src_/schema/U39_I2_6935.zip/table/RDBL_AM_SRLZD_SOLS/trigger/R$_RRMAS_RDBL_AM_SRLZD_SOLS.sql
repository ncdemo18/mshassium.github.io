CREATE TRIGGER R$_RRMAS_RDBL_AM_SRLZD_SOLS
AFTER INSERT OR UPDATE OR DELETE
  ON RDBL_AM_SRLZD_SOLS
  begin
  -- TODO: if it turns out the common case is the table is not updated, need to optimize for that
  RTE$RELATIONS.process_realtime;
end;
/
