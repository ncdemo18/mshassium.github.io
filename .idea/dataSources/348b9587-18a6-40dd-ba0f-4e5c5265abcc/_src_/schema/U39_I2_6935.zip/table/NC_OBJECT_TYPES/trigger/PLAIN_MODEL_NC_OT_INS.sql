CREATE TRIGGER PLAIN_MODEL_NC_OT_INS
AFTER INSERT
  ON NC_OBJECT_TYPES
FOR EACH ROW
  begin
    pkgAttrObjectTypes.schedule_recalculate_ot(:new.object_type_id);
end;
/
