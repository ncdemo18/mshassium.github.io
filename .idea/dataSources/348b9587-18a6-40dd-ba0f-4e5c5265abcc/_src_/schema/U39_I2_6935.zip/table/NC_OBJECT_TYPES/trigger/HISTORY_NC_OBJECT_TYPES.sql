CREATE TRIGGER HISTORY_NC_OBJECT_TYPES
AFTER INSERT OR UPDATE OR DELETE
  ON NC_OBJECT_TYPES
FOR EACH ROW
  declare
   m_old_object_type nc_object_types%rowtype;
   m_new_object_type nc_object_types%rowtype;
begin

   if DELETING or UPDATING then
      m_old_object_type.object_type_id := :old.object_type_id;
      m_old_object_type.parent_id      := :old.parent_id;
      m_old_object_type.picture_id     := :old.picture_id;
      m_old_object_type.name           := :old.name;
      m_old_object_type.description    := :old.description;
      m_old_object_type.isclass        := :old.isclass;
      m_old_object_type.issystem       := :old.issystem;
      m_old_object_type.issearchable   := :old.issearchable;
      m_old_object_type.icon_id        := :old.icon_id;
      m_old_object_type.flags          := :old.flags;
      m_old_object_type.properties     := :old.properties;
      m_old_object_type.isabstract     := :old.isabstract;
      m_old_object_type.internal_name  := :old.internal_name;
   end if;

   if not DELETING then
      m_new_object_type.object_type_id := :new.object_type_id;
      m_new_object_type.parent_id      := :new.parent_id;
      m_new_object_type.picture_id     := :new.picture_id;
      m_new_object_type.name           := :new.name;
      m_new_object_type.description    := :new.description;
      m_new_object_type.isclass        := :new.isclass;
      m_new_object_type.issystem       := :new.issystem;
      m_new_object_type.issearchable   := :new.issearchable;
      m_new_object_type.icon_id        := :new.icon_id;
      m_new_object_type.flags          := :new.flags;
      m_new_object_type.properties     := :new.properties;
      m_new_object_type.isabstract     := :new.isabstract;
      m_new_object_type.internal_name  := :new.internal_name;
   end if;

   if    DELETING  then pkg_history_metadata.fire_delete_object_type(m_old_object_type);
   elsif INSERTING then pkg_history_metadata.fire_insert_object_type(m_new_object_type);
   elsif UPDATING  then
    begin
        if (m_old_object_type.object_type_id <> m_new_object_type.object_type_id)
        or (m_old_object_type.parent_id      <> m_new_object_type.parent_id)
        or pkg_history_metadata.isDifferent(m_old_object_type.picture_id   , m_new_object_type.picture_id)
        or (m_old_object_type.name           <> m_new_object_type.name)
        or pkg_history_metadata.isDifferent(m_old_object_type.description  , m_new_object_type.description)
        or pkg_history_metadata.isDifferent(m_old_object_type.isclass      , m_new_object_type.isclass)
        or pkg_history_metadata.isDifferent(m_old_object_type.issystem     , m_new_object_type.issystem)
        or pkg_history_metadata.isDifferent(m_old_object_type.issearchable , m_new_object_type.issearchable)
        or pkg_history_metadata.isDifferent(m_old_object_type.icon_id      , m_new_object_type.icon_id)
        or (m_old_object_type.flags          <> m_new_object_type.flags)
        or pkg_history_metadata.isDifferent(m_old_object_type.properties   , m_new_object_type.properties)
        or pkg_history_metadata.isDifferent(m_old_object_type.isabstract   , m_new_object_type.isabstract)
        or pkg_history_metadata.isDifferent(m_old_object_type.internal_name, m_new_object_type.internal_name)
        then
            pkg_history_metadata.fire_update_object_type(m_old_object_type, m_new_object_type);
        end if;
    end;
   end if;
end;
/
