CREATE TRIGGER PLAIN_MODEL_NC_OT_DEL
AFTER DELETE
  ON NC_OBJECT_TYPES
FOR EACH ROW
  begin
    pkgAttrObjectTypes.schedule_recalculate_ot(:old.object_type_id, true);
end;
/
