CREATE TRIGGER DELETE_GRANTS_ON_OT_DELETE
AFTER DELETE
  ON NC_OBJECT_TYPES
FOR EACH ROW
  begin
  delete from nc_grants where object_id = :old.object_type_id;
end;
/
