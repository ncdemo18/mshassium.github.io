CREATE TRIGGER TAUFER_NC_WFM_NOTIF_RESULT
AFTER UPDATE OF RESULT
  ON NC_WFM_NOTIF
FOR EACH ROW
  begin
  if :new.result is not null then
    pkgwfm_dispatcher.trigger_notif_upd_result(:new.callback_id, :new.result);
  end if;
end;
/
