CREATE TRIGGER HISTORY_NC_ATTRIBUTES
AFTER INSERT OR UPDATE OR DELETE
  ON NC_ATTRIBUTES
FOR EACH ROW
  declare
   m_old_attribute nc_attributes%rowtype;
   m_new_attribute nc_attributes%rowtype;
begin

   if DELETING or UPDATING then
      m_old_attribute.attr_id               := :old.attr_id;
      m_old_attribute.attr_type_id          := :old.attr_type_id;
      m_old_attribute.attr_type_def_id      := :old.attr_type_def_id;
      m_old_attribute.attr_group_id         := :old.attr_group_id;
      m_old_attribute.attr_schema_id        := :old.attr_schema_id;
      m_old_attribute.name                  := :old.name;
      m_old_attribute.attr_access_type      := :old.attr_access_type;
      m_old_attribute.ismultiple            := :old.ismultiple;
      m_old_attribute.isextgenerated        := :old.isextgenerated;
      m_old_attribute.adaptername           := :old.adaptername;
      m_old_attribute.params                := :old.params;
      m_old_attribute.unique_level          := :old.unique_level;
      m_old_attribute.show_order            := :old.show_order;
      m_old_attribute.show_history          := :old.show_history;
      m_old_attribute.issearchable          := :old.issearchable;
      m_old_attribute.mask                  := :old.mask;
      m_old_attribute.def_value             := :old.def_value;
      m_old_attribute.flags                 := :old.flags;
      m_old_attribute.description           := :old.description;
      m_old_attribute.properties            := :old.properties;
      m_old_attribute.rules                 := :old.rules;
      m_old_attribute.tooltip               := :old.tooltip;
      m_old_attribute.av_adapter_name       := :old.av_adapter_name;
      m_old_attribute.av_adapter_properties := :old.av_adapter_properties;
      m_old_attribute.internal_name         := :old.internal_name;
   end if;

   if not DELETING then
      m_new_attribute.attr_id               := :new.attr_id;
      m_new_attribute.attr_type_id          := :new.attr_type_id;
      m_new_attribute.attr_type_def_id      := :new.attr_type_def_id;
      m_new_attribute.attr_group_id         := :new.attr_group_id;
      m_new_attribute.attr_schema_id        := :new.attr_schema_id;
      m_new_attribute.name                  := :new.name;
      m_new_attribute.attr_access_type      := :new.attr_access_type;
      m_new_attribute.ismultiple            := :new.ismultiple;
      m_new_attribute.isextgenerated        := :new.isextgenerated;
      m_new_attribute.adaptername           := :new.adaptername;
      m_new_attribute.params                := :new.params;
      m_new_attribute.unique_level          := :new.unique_level;
      m_new_attribute.show_order            := :new.show_order;
      m_new_attribute.show_history          := :new.show_history;
      m_new_attribute.issearchable          := :new.issearchable;
      m_new_attribute.mask                  := :new.mask;
      m_new_attribute.def_value             := :new.def_value;
      m_new_attribute.flags                 := :new.flags;
      m_new_attribute.description           := :new.description;
      m_new_attribute.properties            := :new.properties;
      m_new_attribute.rules                 := :new.rules;
      m_new_attribute.tooltip               := :new.tooltip;
      m_new_attribute.av_adapter_name       := :new.av_adapter_name;
      m_new_attribute.av_adapter_properties := :new.av_adapter_properties;
      m_new_attribute.internal_name         := :new.internal_name;
   end if;

   if    DELETING  then pkg_history_metadata.fire_delete_attribute(m_old_attribute);
   elsif INSERTING then pkg_history_metadata.fire_insert_attribute(m_new_attribute);
   elsif UPDATING  then
    begin
        if (m_old_attribute.attr_id               <> m_new_attribute.attr_id)
        or (m_old_attribute.attr_type_id          <> m_new_attribute.attr_type_id)
        or pkg_history_metadata.isDifferent(m_old_attribute.attr_type_def_id      , m_new_attribute.attr_type_def_id)
        or (m_old_attribute.attr_group_id         <> m_new_attribute.attr_group_id)
        or (m_old_attribute.attr_schema_id        <> m_new_attribute.attr_schema_id)
        or (m_old_attribute.name                  <> m_new_attribute.name)
        or pkg_history_metadata.isDifferent(m_old_attribute.attr_access_type      , m_new_attribute.attr_access_type)
        or pkg_history_metadata.isDifferent(m_old_attribute.ismultiple            , m_new_attribute.ismultiple)
        or pkg_history_metadata.isDifferent(m_old_attribute.isextgenerated        , m_new_attribute.isextgenerated)
        or pkg_history_metadata.isDifferent(m_old_attribute.adaptername           , m_new_attribute.adaptername)
        or pkg_history_metadata.isDifferent(m_old_attribute.params                , m_new_attribute.params)
        or pkg_history_metadata.isDifferent(m_old_attribute.unique_level          , m_new_attribute.unique_level)
        or pkg_history_metadata.isDifferent(m_old_attribute.show_order            , m_new_attribute.show_order)
        or pkg_history_metadata.isDifferent(m_old_attribute.show_history          , m_new_attribute.show_history)
        or pkg_history_metadata.isDifferent(m_old_attribute.issearchable          , m_new_attribute.issearchable)
        or pkg_history_metadata.isDifferent(m_old_attribute.mask                  , m_new_attribute.mask)
        or pkg_history_metadata.isDifferent(m_old_attribute.def_value             , m_new_attribute.def_value)
        or pkg_history_metadata.isDifferent(m_old_attribute.flags                 , m_new_attribute.flags)
        or pkg_history_metadata.isDifferent(m_old_attribute.description           , m_new_attribute.description)
        or pkg_history_metadata.isDifferent(m_old_attribute.properties            , m_new_attribute.properties)
        or pkg_history_metadata.isDifferent(m_old_attribute.rules                 , m_new_attribute.rules)
        or pkg_history_metadata.isDifferent(m_old_attribute.tooltip               , m_new_attribute.tooltip)
        or pkg_history_metadata.isDifferent(m_old_attribute.av_adapter_name       , m_new_attribute.av_adapter_name)
        or pkg_history_metadata.isDifferent(m_old_attribute.av_adapter_properties , m_new_attribute.av_adapter_properties)
        or pkg_history_metadata.isDifferent(m_old_attribute.internal_name         , m_new_attribute.internal_name)
        then
            pkg_history_metadata.fire_update_attribute(m_old_attribute, m_new_attribute);
        end if;
    end;
   end if;
end;
/
