CREATE TRIGGER PLAIN_MODEL_NC_A_UPD
AFTER UPDATE
  ON NC_ATTRIBUTES
FOR EACH ROW
  begin
  if (:old.def_value is not null and :new.def_value is null
     or :old.def_value is null and :new.def_value is not null
     or :old.def_value <> :new.def_value
     or :old.flags is not null and :new.flags is null
     or :old.flags is null and :new.flags is not null
     or :old.flags <> :new.flags)
  then
      pkgAttrObjectTypes.schedule_recalculate_attr(:new.attr_id);
  end if;
end;
/
