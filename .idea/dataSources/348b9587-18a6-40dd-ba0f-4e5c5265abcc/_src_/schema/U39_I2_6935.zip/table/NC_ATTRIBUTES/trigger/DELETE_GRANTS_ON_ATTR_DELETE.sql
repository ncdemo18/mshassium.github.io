CREATE TRIGGER DELETE_GRANTS_ON_ATTR_DELETE
AFTER DELETE
  ON NC_ATTRIBUTES
FOR EACH ROW
  begin
  delete from nc_grants where object_id = :old.attr_id;
end;
/
