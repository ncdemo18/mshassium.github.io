CREATE TRIGGER TRG_BAM_NC_OMD_MANUAL_TASKS
AFTER INSERT OR UPDATE OR DELETE
  ON NC_OMD_MANUAL_TASKS
FOR EACH ROW
  declare
	orderNumber number(20);
	commandType varchar2(20);
	tableNotExists exception;
	pragma exception_init(tableNotExists, -00942);
begin
	if inserting then
		commandType := 'INSERTING';
	elsif updating then
		commandType := 'UPDATING';
	else
		commandType := 'DELETING';
	end if;

	select NC_OMD_MANUAL_TASKS_LOG_SEQ.nextval into orderNumber from dual;

	if commandType = 'INSERTING' or commandType = 'UPDATING' then
		execute immediate '
			insert into NC_OMD_MANUAL_TASKS_LOG (
				ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_CREATED_WHEN, NEW_ACT_COMPL_DATE, NEW_MANUAL_TASK_ID, NEW_STATUS, NEW_SLA_STATE, NEW_ASSIGNED_TO, NEW_INITIAL_ASSIGN, NEW_IS_ASSIGNED, NEW_ORDER_TYPE_ID, NEW_INTERACTION_ITEM, NEW_INTERACTION, NEW_SPECIFICATION, NEW_IS_HIDDEN
			)
			values (
				:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_CREATED_WHEN, :NEW_ACT_COMPL_DATE, :NEW_MANUAL_TASK_ID, :NEW_STATUS, :NEW_SLA_STATE, :NEW_ASSIGNED_TO, :NEW_INITIAL_ASSIGN, :NEW_IS_ASSIGNED, :NEW_ORDER_TYPE_ID, :NEW_INTERACTION_ITEM, :NEW_INTERACTION, :NEW_SPECIFICATION, :NEW_IS_HIDDEN
			)'
		using
			orderNumber, commandType, :old.id, :new.id, :new.created_when, :new.act_compl_date, :new.manual_task_id, :new.status, :new.sla_state, :new.assigned_to, :new.initial_assign, :new.is_assigned, :new.order_type_id, :new.interaction_item, :new.interaction, :new.specification, :new.is_hidden;
	end if;
exception
	when tableNotExists then
		pkg_bam_kpi_transport.lock_log_table_shared(9133384718613012785);
		if commandType = 'INSERTING' or commandType = 'UPDATING' then
			execute immediate '
				insert into NC_OMD_MANUAL_TASKS_LOG (
					ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_CREATED_WHEN, NEW_ACT_COMPL_DATE, NEW_MANUAL_TASK_ID, NEW_STATUS, NEW_SLA_STATE, NEW_ASSIGNED_TO, NEW_INITIAL_ASSIGN, NEW_IS_ASSIGNED, NEW_ORDER_TYPE_ID, NEW_INTERACTION_ITEM, NEW_INTERACTION, NEW_SPECIFICATION, NEW_IS_HIDDEN
				)
				values (
					:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_CREATED_WHEN, :NEW_ACT_COMPL_DATE, :NEW_MANUAL_TASK_ID, :NEW_STATUS, :NEW_SLA_STATE, :NEW_ASSIGNED_TO, :NEW_INITIAL_ASSIGN, :NEW_IS_ASSIGNED, :NEW_ORDER_TYPE_ID, :NEW_INTERACTION_ITEM, :NEW_INTERACTION, :NEW_SPECIFICATION, :NEW_IS_HIDDEN
				)'
			using
				orderNumber, commandType, :old.id, :new.id, :new.created_when, :new.act_compl_date, :new.manual_task_id, :new.status, :new.sla_state, :new.assigned_to, :new.initial_assign, :new.is_assigned, :new.order_type_id, :new.interaction_item, :new.interaction, :new.specification, :new.is_hidden;
		end if;
end TRG_BAM_NC_OMD_MANUAL_TASKS;
/
