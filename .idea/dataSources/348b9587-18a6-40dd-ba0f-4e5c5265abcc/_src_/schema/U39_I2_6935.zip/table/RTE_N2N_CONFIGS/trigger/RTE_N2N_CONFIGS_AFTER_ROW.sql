CREATE TRIGGER RTE_N2N_CONFIGS_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_N2N_CONFIGS
FOR EACH ROW
  rte_validation.rte_n2n_configs_after_row(
      :new.data_source_name
  )

;
/
