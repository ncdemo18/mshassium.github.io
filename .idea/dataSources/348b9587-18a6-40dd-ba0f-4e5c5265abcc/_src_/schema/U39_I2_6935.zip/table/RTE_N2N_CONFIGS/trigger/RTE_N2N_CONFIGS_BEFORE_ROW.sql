CREATE TRIGGER RTE_N2N_CONFIGS_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_N2N_CONFIGS
FOR EACH ROW
  rte_validation.rte_n2n_configs_before_row(
      :new.data_source_name
      , :new.on_delete
      , :new.instance_name
  )

;
/
