CREATE TRIGGER R$_RRMAR_RDBL_SFA_ACTIVITIES
AFTER INSERT OR UPDATE OF ACTIVITY_ID, END_TIME, DUE_DATE, OWNER, RELATED_OBJECT OR DELETE
  ON RDBL_SFA_ACTIVITIES
FOR EACH ROW
  declare
  ACTIVITY_ID boolean := :old.ACTIVITY_ID<>:new.ACTIVITY_ID or (:old.ACTIVITY_ID is null and :new.ACTIVITY_ID is not null or :old.ACTIVITY_ID is not null and :new.ACTIVITY_ID is null);
  DUE_DATE boolean := :old.DUE_DATE<>:new.DUE_DATE or (:old.DUE_DATE is null and :new.DUE_DATE is not null or :old.DUE_DATE is not null and :new.DUE_DATE is null);
  END_TIME boolean := :old.END_TIME<>:new.END_TIME or (:old.END_TIME is null and :new.END_TIME is not null or :old.END_TIME is not null and :new.END_TIME is null);
  RELATED_OBJECT boolean := :old.RELATED_OBJECT<>:new.RELATED_OBJECT or (:old.RELATED_OBJECT is null and :new.RELATED_OBJECT is not null or :old.RELATED_OBJECT is not null and :new.RELATED_OBJECT is null);
  OWNER boolean := :old.OWNER<>:new.OWNER or (:old.OWNER is null and :new.OWNER is not null or :old.OWNER is not null and :new.OWNER is null);
begin
  -- Check if relation ACTIVITY_ID.RDBL_SFA_ACTIVITIES-2>RDBL_SFA_ACTIVITIES.ACTIVITY_ID needs to be updated
  if   ACTIVITY_ID
  then
    R$_RRM_RDBL_SFA_ACTIVITIES.ACTIVITY_IDRDBL_SFA_ACT8611FF9(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- update of column in RDBL_SFA_ACTIVITIES affects target side of join ACTIVITY_ID.RDBL_SFA_ACTIVITIES-2>RDBL_SFA_ACTIVITIES.ACTIVITY_ID
  if ACTIVITY_ID then
    if :old.ACTIVITY_ID is not null then
      R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B.extend; R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B(R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B.count) := :old.ACTIVITY_ID;
    end if;
    if :new.ACTIVITY_ID is not null then
      R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B.extend; R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B(R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B.count) := :new.ACTIVITY_ID;
    end if;
  end if;

  if DUE_DATE
      or END_TIME
      or RELATED_OBJECT then
    R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B.extend; R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B(R$_RRM_RDBL_SFA_ACTIVITIES.RV$ACTIVITY_IDRDBL_SFA_8D5BE5B.count) := :new.ACTIVITY_ID;
  end if;

  -- Check if relation OWNER.RDBL_SFA_ACTIVITIES-2>RDBL_SALES_AGENTS.AGENT_ID needs to be updated
  if   OWNER
  then
    R$_RRM_RDBL_SFA_ACTIVITIES.OWNERRDBL_SFA_ACTIVITIE841A6FB(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- Check if relation OWNER.RDBL_SFA_ACTIVITIES-3>RDBL_SALES_AGENTS.AGENT_ID needs to be updated
  if   OWNER
  then
    R$_RRM_RDBL_SFA_ACTIVITIES.OWNERRDBL_SFA_ACTIVITIE1C8D775(nvl(:old.rowid, :new.rowid)) := null;
  end if;
end;
/
