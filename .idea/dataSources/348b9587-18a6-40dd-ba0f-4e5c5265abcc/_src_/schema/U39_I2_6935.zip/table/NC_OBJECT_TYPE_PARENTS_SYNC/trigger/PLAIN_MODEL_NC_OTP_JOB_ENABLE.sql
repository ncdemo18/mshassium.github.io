CREATE TRIGGER PLAIN_MODEL_NC_OTP_JOB_ENABLE
AFTER INSERT
  ON NC_OBJECT_TYPE_PARENTS_SYNC
  DECLARE
  cur_transaction_id VARCHAR2(50);
  cur_timestamp TIMESTAMP(6);
  l_job number;
begin
    cur_transaction_id := DBMS_TRANSACTION.LOCAL_TRANSACTION_ID(false);
    select systimestamp
      into cur_timestamp
      from dual;
    --in one transaction only one job should be submitted. To determine if transaction is the same, transaction_id saved in package variable should be same as curent transaction_id
    -- and current timestamp shouldn't be less then 60 minutes differs, because in some cases transaction_id can be reuse by Oracle
    IF ((pkgAttrObjectTypes.transaction_id is NOT NULL) AND (pkgAttrObjectTypes.transaction_timestamp IS NOT NULL)
      AND (pkgAttrObjectTypes.transaction_id = cur_transaction_id)
        AND (extract(MINUTE FROM cur_timestamp - pkgAttrObjectTypes.transaction_timestamp) <= 60 )
        ) THEN
        pkgAttrObjectTypes.transaction_timestamp := cur_timestamp;
    ELSE
        --should use dbms_job to enable 'NC_UNROLL_METADATA_JOB' because 'DBMS_SCHEDULER.enable' call implicit commit - this is not allowed in trigger and throw exception.  dbms_job.submit call after transaction is sumbitted
        dbms_job.submit(job => l_job,
                        what => 'DBMS_SCHEDULER.enable (name => ''NC_UNROLL_METADATA_JOB'');',
                        next_date => sysdate,
                        interval => '');
        pkgAttrObjectTypes.transaction_id := cur_transaction_id;
        pkgAttrObjectTypes.transaction_timestamp := cur_timestamp;
    END IF;
end;
/
