CREATE TRIGGER RTE_FK_TAB_ATTR_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_FK_TAB_ATTRIBUTES
FOR EACH ROW
  rte_validation.rte_fk_tab_attr_after_row(
      :new.data_source_name
    , :new.attr_type
    , :new.table_name
    , :new.storage_column
  )

;
/
