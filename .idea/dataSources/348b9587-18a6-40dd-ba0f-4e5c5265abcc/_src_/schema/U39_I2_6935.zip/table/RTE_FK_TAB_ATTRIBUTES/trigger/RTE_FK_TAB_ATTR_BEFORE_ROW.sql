CREATE TRIGGER RTE_FK_TAB_ATTR_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_FK_TAB_ATTRIBUTES
FOR EACH ROW
  rte_validation.rte_fk_tab_attr_before_row(
      :new.data_source_name
    , :new.attr_type
    , :new.table_name
    , :new.storage_column
    , :new.auto_index
  )

;
/
