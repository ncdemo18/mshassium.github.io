CREATE TRIGGER TAUFER_NC_WFM_NOTIF_QUEUE_ADR
AFTER UPDATE
  ON NC_WFM_NOTIF_QUEUE_ADDRESS
FOR EACH ROW
  begin
  if :old.status <> :new.status and :new.status in (pkgwfm_dispatcher.MS_SUCCESS, pkgwfm_dispatcher.MS_FAILURE) then
    pkgwfm_dispatcher.trigger_transport_upd_result(:new.employee_id, :new.notification_id, :new.status);
  end if;
end;
/
