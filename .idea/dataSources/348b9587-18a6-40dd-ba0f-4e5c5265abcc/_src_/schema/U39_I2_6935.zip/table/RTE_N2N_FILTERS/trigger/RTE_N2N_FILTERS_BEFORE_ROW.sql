CREATE TRIGGER RTE_N2N_FILTERS_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_N2N_FILTERS
FOR EACH ROW
  rte_validation.rte_n2n_filters_before_row(
    :new.attribute_list_for
)

;
/
