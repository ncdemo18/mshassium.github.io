CREATE TRIGGER R$_RRMAR_RDBL_SFA_RGU_GROUPS
AFTER INSERT OR UPDATE OF ID, NAME OR DELETE
  ON RDBL_SFA_RGU_GROUPS
FOR EACH ROW
  declare
  ID boolean := :old.ID<>:new.ID or (:old.ID is null and :new.ID is not null or :old.ID is not null and :new.ID is null);
  NAME boolean := :old.NAME<>:new.NAME or (:old.NAME is null and :new.NAME is not null or :old.NAME is not null and :new.NAME is null);
begin
  -- Check if relation GROUP_ID.RDBL_SFA_RGU_INSTANCES-2>RDBL_SFA_RGU_GROUPS.ID needs to be updated
  -- update of column in RDBL_SFA_RGU_GROUPS affects target side of join GROUP_ID.RDBL_SFA_RGU_INSTANCES-2>RDBL_SFA_RGU_GROUPS.ID
  if ID then
    if :old.ID is not null then
      R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7.extend; R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7(R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7.count) := :old.ID;
    end if;
    if :new.ID is not null then
      R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7.extend; R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7(R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7.count) := :new.ID;
    end if;
  end if;

  if NAME then
    R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7.extend; R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7(R$_RRM_RDBL_SFA_RGU_GROUPS.RV$GROUP_IDRDBL_SFA_RGUA8211C7.count) := :new.ID;
  end if;

end;
/
