CREATE TRIGGER PLAIN_MODEL_NC_AOT_UPD
AFTER UPDATE
  ON NC_ATTR_OBJECT_TYPES
FOR EACH ROW
  begin
    if (:old.attr_id <> :new.attr_id) then
        pkgAttrObjectTypes.schedule_recalculate_attr(:new.attr_id);
        pkgAttrObjectTypes.schedule_recalculate_attr(:old.attr_id);
    elsif (:old.object_type_id <> :new.object_type_id
        or :old.attr_schema_id <> :new.attr_schema_id
        or :old.options is not null and :new.options is null
        or :old.options is null and :new.options is not null
        or :old.options <> :new.options
        or :old.default_value is not null and :new.default_value is null
        or :old.default_value is null and :new.default_value is not null
        or :old.default_value <> :new.default_value
        or :old.flags is not null and :new.flags is null
        or :old.flags is null and :new.flags is not null
        or :old.flags <> :new.flags)
    then
        pkgAttrObjectTypes.schedule_recalculate_attr(:new.attr_id);
    end if;
end;
/
