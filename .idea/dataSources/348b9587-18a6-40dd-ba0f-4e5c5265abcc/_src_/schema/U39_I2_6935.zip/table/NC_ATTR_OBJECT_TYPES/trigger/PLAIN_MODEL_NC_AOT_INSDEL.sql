CREATE TRIGGER PLAIN_MODEL_NC_AOT_INSDEL
AFTER INSERT OR DELETE
  ON NC_ATTR_OBJECT_TYPES
FOR EACH ROW
  begin
    if(:new.attr_id is not null) then
        pkgAttrObjectTypes.schedule_recalculate_attr(:new.attr_id);
    else
        pkgAttrObjectTypes.schedule_recalculate_attr(:old.attr_id);
    end if;
end;
/
