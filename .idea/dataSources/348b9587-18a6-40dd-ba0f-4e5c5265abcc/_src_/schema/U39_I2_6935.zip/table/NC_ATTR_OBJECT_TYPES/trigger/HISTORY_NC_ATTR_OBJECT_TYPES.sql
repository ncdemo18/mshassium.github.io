CREATE TRIGGER HISTORY_NC_ATTR_OBJECT_TYPES
AFTER INSERT OR UPDATE OR DELETE
  ON NC_ATTR_OBJECT_TYPES
FOR EACH ROW
  declare
   m_old_attr_type_link nc_attr_object_types%rowtype;
   m_new_attr_type_link nc_attr_object_types%rowtype;
begin

   if DELETING or UPDATING then
      m_old_attr_type_link.attr_id        := :old.attr_id;
      m_old_attr_type_link.object_type_id := :old.object_type_id;
      m_old_attr_type_link.attr_schema_id := :old.attr_schema_id;
      m_old_attr_type_link.isdisplayed    := :old.isdisplayed;
      m_old_attr_type_link.required       := :old.required;
      m_old_attr_type_link.options        := :old.options;
--      m_old_attr_type_link.default_value  := :old.default_value;
--      m_old_attr_type_link.flags          := :old.flags;
   end if;

   if not DELETING then
      m_new_attr_type_link.attr_id        := :new.attr_id;
      m_new_attr_type_link.object_type_id := :new.object_type_id;
      m_new_attr_type_link.attr_schema_id := :new.attr_schema_id;
      m_new_attr_type_link.isdisplayed    := :new.isdisplayed;
      m_new_attr_type_link.required       := :new.required;
      m_new_attr_type_link.options        := :new.options;
--      m_new_attr_type_link.default_value  := :new.default_value;
--      m_new_attr_type_link.flags          := :new.flags;
   end if;

   if    DELETING  then pkg_history_metadata.fire_delete_attr_type_link(m_old_attr_type_link);
   elsif INSERTING then pkg_history_metadata.fire_insert_attr_type_link(m_new_attr_type_link);
   elsif UPDATING  then
    begin
        if (m_old_attr_type_link.attr_id        <> m_new_attr_type_link.attr_id)
        or (m_old_attr_type_link.object_type_id <> m_new_attr_type_link.object_type_id)
        or (m_old_attr_type_link.attr_schema_id <> m_new_attr_type_link.attr_schema_id)
        or (m_old_attr_type_link.isdisplayed    <> m_new_attr_type_link.isdisplayed)
        or (m_old_attr_type_link.required       <> m_new_attr_type_link.required)
        or (m_old_attr_type_link.options        <> m_new_attr_type_link.options)
        then
            pkg_history_metadata.fire_update_attr_type_link(m_old_attr_type_link, m_new_attr_type_link);
        end if;
    end;
   end if;
end;
/
