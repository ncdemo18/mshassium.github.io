CREATE TRIGGER SEQ_BFI
BEFORE INSERT
  ON PRICE_PLAN
FOR EACH ROW
  BEGIN
         SELECT ID_SQ.nextval
         INTO :NEW.ID
         FROM dual;
        END seq_bfi;
/
