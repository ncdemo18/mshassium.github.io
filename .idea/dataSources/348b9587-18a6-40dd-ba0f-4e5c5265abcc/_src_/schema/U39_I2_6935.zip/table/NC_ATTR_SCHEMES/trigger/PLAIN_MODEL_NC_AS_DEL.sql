CREATE TRIGGER PLAIN_MODEL_NC_AS_DEL
AFTER DELETE
  ON NC_ATTR_SCHEMES
FOR EACH ROW
  begin
    pkgAttrObjectTypes.schedule_recalculate_schema(:old.attr_schema_id, true);
end;
/
