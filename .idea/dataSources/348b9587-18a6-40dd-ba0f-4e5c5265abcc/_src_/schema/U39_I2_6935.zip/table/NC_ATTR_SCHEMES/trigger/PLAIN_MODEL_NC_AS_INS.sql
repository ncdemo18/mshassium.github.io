CREATE TRIGGER PLAIN_MODEL_NC_AS_INS
AFTER INSERT
  ON NC_ATTR_SCHEMES
FOR EACH ROW
  begin
    pkgAttrObjectTypes.schedule_recalculate_schema(:new.attr_schema_id);
end;
/
