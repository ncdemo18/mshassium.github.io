CREATE TRIGGER HISTORY_NC_ATTR_SCHEMES
AFTER INSERT OR UPDATE OR DELETE
  ON NC_ATTR_SCHEMES
FOR EACH ROW
  declare
   m_old_schema nc_attr_schemes%rowtype;
   m_new_schema nc_attr_schemes%rowtype;
begin

   if DELETING or UPDATING then
      m_old_schema.attr_schema_id   := :old.attr_schema_id;
      m_old_schema.parent_id        := :old.parent_id;
      m_old_schema.name             := :old.name;
      m_old_schema.attr_access_type := :old.attr_access_type;
      m_old_schema.issystem         := :old.issystem;
      m_old_schema.description      := :old.description;
      m_old_schema.flags            := :old.flags;
      m_old_schema.internal_name    := :old.internal_name;
   end if;

   if not DELETING then
      m_new_schema.attr_schema_id   := :new.attr_schema_id;
      m_new_schema.parent_id        := :new.parent_id;
      m_new_schema.name             := :new.name;
      m_new_schema.attr_access_type := :new.attr_access_type;
      m_new_schema.issystem         := :new.issystem;
      m_new_schema.description      := :new.description;
      m_new_schema.flags            := :new.flags;
      m_new_schema.internal_name    := :new.internal_name;
   end if;

   if    DELETING  then pkg_history_metadata.fire_delete_schema(m_old_schema);
   elsif INSERTING then pkg_history_metadata.fire_insert_schema(m_new_schema);
   elsif UPDATING  then
    begin
        if (m_old_schema.attr_schema_id   <> m_new_schema.attr_schema_id)
        or (m_old_schema.parent_id        <> m_new_schema.parent_id)
        or (m_old_schema.name             <> m_new_schema.name)
        or (m_old_schema.attr_access_type <> m_new_schema.attr_access_type)
        or (m_old_schema.issystem         <> m_new_schema.issystem)
        or (m_old_schema.description      <> m_new_schema.description)
        or (m_old_schema.flags            <> m_new_schema.flags)
        or (m_old_schema.internal_name    <> m_new_schema.internal_name)
        then
            pkg_history_metadata.fire_update_schema(m_old_schema, m_new_schema);
        end if;
    end;
   end if;
end;
/
