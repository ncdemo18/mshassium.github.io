CREATE TRIGGER PLAIN_MODEL_NC_AS_UPD
AFTER UPDATE
  ON NC_ATTR_SCHEMES
FOR EACH ROW
  begin
    if (:old.parent_id is not null and :new.parent_id is null
        or :old.parent_id is null and :new.parent_id is not null
        or :old.parent_id <> :new.parent_id)
    then
        pkgAttrObjectTypes.schedule_recalculate_schema(:new.attr_schema_id);
    end if;
end;
/
