CREATE TRIGGER R$_RRMAS_RDBL_SFA_CONTA60156DA
AFTER INSERT OR UPDATE OR DELETE
  ON RDBL_SFA_CONTACT_ROLES
  begin
  -- TODO: if it turns out the common case is the table is not updated, need to optimize for that
  RTE$RELATIONS.process_realtime;
end;
/
