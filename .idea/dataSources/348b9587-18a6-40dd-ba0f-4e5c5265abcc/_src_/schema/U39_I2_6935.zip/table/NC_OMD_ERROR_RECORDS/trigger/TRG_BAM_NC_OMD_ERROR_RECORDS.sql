CREATE TRIGGER TRG_BAM_NC_OMD_ERROR_RECORDS
AFTER INSERT OR UPDATE OR DELETE
  ON NC_OMD_ERROR_RECORDS
FOR EACH ROW
  declare
	orderNumber number(20);
	commandType varchar2(20);
	tableNotExists exception;
	pragma exception_init(tableNotExists, -00942);
begin
	if inserting then
		commandType := 'INSERTING';
	elsif updating then
		commandType := 'UPDATING';
	else
		commandType := 'DELETING';
	end if;

	select NC_OMD_ERROR_RECORDS_LOG_SEQ.nextval into orderNumber from dual;

	if commandType = 'INSERTING' or commandType = 'UPDATING' then
		execute immediate '
			insert into NC_OMD_ERROR_RECORDS_LOG (
				ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_ER_REC_CREATION_DATE, NEW_OMD_ERREC_RESOL_DATE, NEW_ERROR_RECORD_ID, NEW_SPECIFICATION, NEW_ORDER_TYPE, NEW_ORDER_LEVEL, NEW_ERROR_CLASS, NEW_STATUS
			)
			values (
				:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_ER_REC_CREATION_DATE, :NEW_OMD_ERREC_RESOL_DATE, :NEW_ERROR_RECORD_ID, :NEW_SPECIFICATION, :NEW_ORDER_TYPE, :NEW_ORDER_LEVEL, :NEW_ERROR_CLASS, :NEW_STATUS
			)'
		using
			orderNumber, commandType, :old.id, :new.id, :new.er_rec_creation_date, :new.omd_errec_resol_date, :new.error_record_id, :new.specification, :new.order_type, :new.order_level, :new.error_class, :new.status;
	end if;
exception
	when tableNotExists then
		pkg_bam_kpi_transport.lock_log_table_shared(9133471304913049200);
		if commandType = 'INSERTING' or commandType = 'UPDATING' then
			execute immediate '
				insert into NC_OMD_ERROR_RECORDS_LOG (
					ORDER_NUMBER, COMMAND_TYPE, OLD_ID, NEW_ID, NEW_ER_REC_CREATION_DATE, NEW_OMD_ERREC_RESOL_DATE, NEW_ERROR_RECORD_ID, NEW_SPECIFICATION, NEW_ORDER_TYPE, NEW_ORDER_LEVEL, NEW_ERROR_CLASS, NEW_STATUS
				)
				values (
					:ORDER_NUMBER, :COMMAND_TYPE, :OLD_ID, :NEW_ID, :NEW_ER_REC_CREATION_DATE, :NEW_OMD_ERREC_RESOL_DATE, :NEW_ERROR_RECORD_ID, :NEW_SPECIFICATION, :NEW_ORDER_TYPE, :NEW_ORDER_LEVEL, :NEW_ERROR_CLASS, :NEW_STATUS
				)'
			using
				orderNumber, commandType, :old.id, :new.id, :new.er_rec_creation_date, :new.omd_errec_resol_date, :new.error_record_id, :new.specification, :new.order_type, :new.order_level, :new.error_class, :new.status;
		end if;
end TRG_BAM_NC_OMD_ERROR_RECORDS;
/
