CREATE TRIGGER RTE$_RT_NC_META_REFERENCES
AFTER INSERT OR UPDATE OR DELETE
  ON NC_META_REFERENCES
FOR EACH ROW
  declare
  t RTE$DISPATCHER_READ.t_fk1;
  o RTE$DISPATCHER_READ.t_pk1;
begin null;
  if UPDATING and (:old.OBJECT_ID != :new.OBJECT_ID or :old.ATTR_ID != :new.ATTR_ID)
     and RTE$DISPATCHER_READ.is_rt_attr(:old.ATTR_ID) then
    t.old$attr_id := :old.ATTR_ID;
    if not RTE$DISPATCHER_READ.is_rt_attr(t.old$attr_id) then return; end if;
    t.OBJECT_ID := :old.OBJECT_ID;
    begin
      RTE$DISPATCHER_READ.load_object_info_rt1(t.OBJECT_ID, o);
      -- Workaround for rows deleted by constraints - in this case we cannot query PK table (ORA-04091)
      exception when RTE$DISPATCHER4ADF268B5106A02F.mutating_error then return;
    end;
    RTE$DISPATCHER_READ.fk_rt1(t, o);
  end if;
  t.old$attr_id := case when deleting then :old.ATTR_ID else :new.ATTR_ID end;
  if not RTE$DISPATCHER_READ.is_rt_attr(t.old$attr_id) then return; end if;
  t.OBJECT_ID := case when deleting then :old.OBJECT_ID else :new.OBJECT_ID end;
  if t.OBJECT_ID = o.OBJECT_ID then null; else
    begin
      RTE$DISPATCHER_READ.load_object_info_rt1(t.OBJECT_ID, o);
      -- Workaround for rows deleted by constraints - in this case we cannot query PK table (ORA-04091)
      exception when RTE$DISPATCHER4ADF268B5106A02F.mutating_error then 
        return;
    end;
  end if;
  t.ATTR_ID := :new.ATTR_ID;
  t.REF_OBJECT_TYPE_ID := :new.REF_OBJECT_TYPE_ID;
  t.SHOW_ORDER := :new.SHOW_ORDER;
  t.source_rowid := case when deleting then :old.rowid else :new.rowid end;
  -- Cases with attribute or pk column modification are not supported as for now
  RTE$DISPATCHER_READ.fk_rt1(t, o);
end;
/
