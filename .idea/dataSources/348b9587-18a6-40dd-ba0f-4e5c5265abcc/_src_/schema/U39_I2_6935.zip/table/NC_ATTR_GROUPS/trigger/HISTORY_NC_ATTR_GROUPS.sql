CREATE TRIGGER HISTORY_NC_ATTR_GROUPS
AFTER INSERT OR UPDATE OR DELETE
  ON NC_ATTR_GROUPS
FOR EACH ROW
  declare
   m_old_group nc_attr_groups%rowtype;
   m_new_group nc_attr_groups%rowtype;
begin

   if DELETING or UPDATING then
      m_old_group.attr_group_id    := :old.attr_group_id;
      m_old_group.attr_schema_id   := :old.attr_schema_id;
      m_old_group.name             := :old.name;
      m_old_group.show_order       := :old.show_order;
      m_old_group.attr_access_type := :old.attr_access_type;
      m_old_group.flags            := :old.flags;
      m_old_group.description      := :old.description;
      m_old_group.subgroup         := :old.subgroup;
      m_old_group.alias            := :old.alias;
   end if;

   if not DELETING then
      m_new_group.attr_group_id    := :new.attr_group_id;
      m_new_group.attr_schema_id   := :new.attr_schema_id;
      m_new_group.name             := :new.name;
      m_new_group.show_order       := :new.show_order;
      m_new_group.attr_access_type := :new.attr_access_type;
      m_new_group.flags            := :new.flags;
      m_new_group.description      := :new.description;
      m_new_group.subgroup         := :new.subgroup;
      m_new_group.alias            := :new.alias;
   end if;

   if    DELETING  then pkg_history_metadata.fire_delete_group(m_old_group);
   elsif INSERTING then pkg_history_metadata.fire_insert_group(m_new_group);
   elsif UPDATING  then
    begin
        if (m_old_group.attr_group_id    <> m_new_group.attr_group_id)
        or (m_old_group.attr_schema_id   <> m_new_group.attr_schema_id)
        or (m_old_group.name             <> m_new_group.name)
        or (m_old_group.show_order       <> m_new_group.show_order)
        or (m_old_group.attr_access_type <> m_new_group.attr_access_type)
        or (m_old_group.flags            <> m_new_group.flags)
        or (m_old_group.description      <> m_new_group.description)
        or (m_old_group.subgroup         <> m_new_group.subgroup)
        or (m_old_group.alias            <> m_new_group.alias)
        then
            pkg_history_metadata.fire_update_group(m_old_group, m_new_group);
        end if;
    end;
   end if;
end;
/
