CREATE TRIGGER R$_RRMAR_RDBL_SFA_LEADS
AFTER INSERT OR UPDATE OF LEAD_ID, SALES_TERRITORY, CUSTOMER_ID, AGENT_ID, LINKED_OPPORTUNITY, CUSTOMER_CATEGORY, PRIMARY_CONTACT_ROLE, PRIMARY_CONTACT OR DELETE
  ON RDBL_SFA_LEADS
FOR EACH ROW
  declare
  AGENT_ID boolean := :old.AGENT_ID<>:new.AGENT_ID or (:old.AGENT_ID is null and :new.AGENT_ID is not null or :old.AGENT_ID is not null and :new.AGENT_ID is null);
  CUSTOMER_ID boolean := :old.CUSTOMER_ID<>:new.CUSTOMER_ID or (:old.CUSTOMER_ID is null and :new.CUSTOMER_ID is not null or :old.CUSTOMER_ID is not null and :new.CUSTOMER_ID is null);
  LEAD_ID boolean := :old.LEAD_ID<>:new.LEAD_ID or (:old.LEAD_ID is null and :new.LEAD_ID is not null or :old.LEAD_ID is not null and :new.LEAD_ID is null);
  CUSTOMER_CATEGORY boolean := :old.CUSTOMER_CATEGORY<>:new.CUSTOMER_CATEGORY or (:old.CUSTOMER_CATEGORY is null and :new.CUSTOMER_CATEGORY is not null or :old.CUSTOMER_CATEGORY is not null and :new.CUSTOMER_CATEGORY is null);
  SALES_TERRITORY boolean := :old.SALES_TERRITORY<>:new.SALES_TERRITORY or (:old.SALES_TERRITORY is null and :new.SALES_TERRITORY is not null or :old.SALES_TERRITORY is not null and :new.SALES_TERRITORY is null);
  PRIMARY_CONTACT boolean := :old.PRIMARY_CONTACT<>:new.PRIMARY_CONTACT or (:old.PRIMARY_CONTACT is null and :new.PRIMARY_CONTACT is not null or :old.PRIMARY_CONTACT is not null and :new.PRIMARY_CONTACT is null);
  LINKED_OPPORTUNITY boolean := :old.LINKED_OPPORTUNITY<>:new.LINKED_OPPORTUNITY or (:old.LINKED_OPPORTUNITY is null and :new.LINKED_OPPORTUNITY is not null or :old.LINKED_OPPORTUNITY is not null and :new.LINKED_OPPORTUNITY is null);
  PRIMARY_CONTACT_ROLE boolean := :old.PRIMARY_CONTACT_ROLE<>:new.PRIMARY_CONTACT_ROLE or (:old.PRIMARY_CONTACT_ROLE is null and :new.PRIMARY_CONTACT_ROLE is not null or :old.PRIMARY_CONTACT_ROLE is not null and :new.PRIMARY_CONTACT_ROLE is null);
begin
  -- Check if relation AGENT_ID.RDBL_SFA_LEADS-3>RDBL_SALES_AGENTS.AGENT_ID needs to be updated
  if   AGENT_ID
  then
    R$_RRM_RDBL_SFA_LEADS.AGENT_IDRDBL_SFA_LEADS332763F0(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- Check if relation CUSTOMER_ID.RDBL_SFA_LEADS-2>RDBL_SFA_CUSTOMERS.CUSTOMER_ID needs to be updated
  if   CUSTOMER_ID
  then
    R$_RRM_RDBL_SFA_LEADS.CUSTOMER_IDRDBL_SFA_LEA3DC2097(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- Check if relation LEAD_ID.RDBL_SFA_LEADS-2>RDBL_SFA_LEADS.LEAD_ID needs to be updated
  if   LEAD_ID
  then
    R$_RRM_RDBL_SFA_LEADS.LEAD_IDRDBL_SFA_LEADS2R30B29E7(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- update of column in RDBL_SFA_LEADS affects target side of join LEAD_ID.RDBL_SFA_LEADS-2>RDBL_SFA_LEADS.LEAD_ID
  if LEAD_ID then
    if :old.LEAD_ID is not null then
      R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559.extend; R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559(R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559.count) := :old.LEAD_ID;
    end if;
    if :new.LEAD_ID is not null then
      R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559.extend; R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559(R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559.count) := :new.LEAD_ID;
    end if;
  end if;

  if CUSTOMER_CATEGORY
      or SALES_TERRITORY then
    R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559.extend; R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559(R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD5A3E559.count) := :new.LEAD_ID;
  end if;

  -- Check if relation LEAD_ID.RDBL_SFA_LEADS-3>RDBL_SFA_LEADS.LEAD_ID needs to be updated
  if   LEAD_ID
  then
    R$_RRM_RDBL_SFA_LEADS.LEAD_IDRDBL_SFA_LEADS3RD76A523(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- update of column in RDBL_SFA_LEADS affects target side of join LEAD_ID.RDBL_SFA_LEADS-3>RDBL_SFA_LEADS.LEAD_ID
  if LEAD_ID then
    if :old.LEAD_ID is not null then
      R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB.extend; R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB(R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB.count) := :old.LEAD_ID;
    end if;
    if :new.LEAD_ID is not null then
      R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB.extend; R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB(R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB.count) := :new.LEAD_ID;
    end if;
  end if;

  if PRIMARY_CONTACT then
    R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB.extend; R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB(R$_RRM_RDBL_SFA_LEADS.RV$LEAD_IDRDBL_SFA_LEAD788E3AB.count) := :new.LEAD_ID;
  end if;

  -- Check if relation LINKED_OPPORTUNITY.RDBL_SFA_LEADS-2>RDBL_SFA_OPPORTUNITIES.OPPORTUNITY_ID needs to be updated
  if   LINKED_OPPORTUNITY
  then
    R$_RRM_RDBL_SFA_LEADS.LINKED_OPPORTUNITYRDBL_CB784CA(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- Check if relation LINKED_OPPORTUNITY.RDBL_SFA_LEADS-4>RDBL_SFA_OPPORTUNITIES.OPPORTUNITY_ID needs to be updated
  if   LINKED_OPPORTUNITY
  then
    R$_RRM_RDBL_SFA_LEADS.LINKED_OPPORTUNITYRDBL_79C69D2(nvl(:old.rowid, :new.rowid)) := null;
  end if;
  -- Check if relation PRIMARY_CONTACT_ROLE.RDBL_SFA_LEADS-2>RDBL_SFA_CONTACT_ROLES.CONTACT_ROLE_ID needs to be updated
  if   PRIMARY_CONTACT_ROLE
  then
    R$_RRM_RDBL_SFA_LEADS.PRIMARY_CONTACT_ROLERDBDD07938(nvl(:old.rowid, :new.rowid)) := null;
  end if;
end;
/
