CREATE TRIGGER RTE_CHANGE_TRACKERS_AFTER_ROW
AFTER INSERT OR UPDATE
  ON RTE_CHANGE_TRACKERS
FOR EACH ROW
  rte_validation.rte_change_trackers_after_row(
      :new.track_table,
      :new.data_type,
      :new.time_zone
  )

;
/
