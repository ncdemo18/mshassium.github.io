CREATE TRIGGER RTE_CHANGE_TRACKERS_BEFORE_ROW
BEFORE INSERT OR UPDATE
  ON RTE_CHANGE_TRACKERS
FOR EACH ROW
  rte_validation.rte_change_trackers_before_row(
      :new.instance_name,
      :new.track_table,
      :new.RETENTION_PERIOD,
      :new.data_type,
      :new.time_zone
  )

;
/
