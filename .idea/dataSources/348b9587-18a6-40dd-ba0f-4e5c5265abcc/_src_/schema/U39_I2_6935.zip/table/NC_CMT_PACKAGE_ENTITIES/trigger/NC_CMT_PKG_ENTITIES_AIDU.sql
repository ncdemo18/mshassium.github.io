CREATE TRIGGER NC_CMT_PKG_ENTITIES_AIDU
AFTER INSERT OR UPDATE OR DELETE
  ON NC_CMT_PACKAGE_ENTITIES
FOR EACH ROW
  declare
    op varchar(1);
begin
    op := (case when INSERTING then 'C' when UPDATING then 'M' when DELETING then 'D' end);
    insert into NC_CMT_PKG_ENTITIES_HISTORY (
        entity_id,
        entity_group,
        change_date,
        user_id,
        operation,
        old_package_name,
        new_package_name,
        old_entity_type_id,
        new_entity_type_id)
    values (
        coalesce(:new.entity_id, :old.entity_id),
        coalesce(:new.entity_group, :old.entity_group),
        sysdate,
        pkg_cmt_ct.get_user_id(),
        op,
        :old.package_name,
        :new.package_name,
        :old.entity_type_id,
        :new.entity_type_id
    );
exception
    when others then null;
end;
/
